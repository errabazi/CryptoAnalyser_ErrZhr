/** CryptoAnalyser activation backend with receipt email notification (no SMS).
 * Deploy as Web app: Execute as Me; access: Anyone.
 * Keep the spreadsheet and receipt folder private. Do not share activation codes until payment is verified.
 */
const CONFIG = {
  SPREADSHEET_ID: '1wsOzTj5oEX_LN0KERuSqLShwcErDzpdF6oyh6g-ckPw',
  SHEET_NAME: 'ActivationRequests',
  ADMIN_EMAIL: 'errabazi@gmail.com',
  CASHPLUS_BENEFICIARY: 'Errabazi Zouhair',
  PAYMENT_AMOUNT_MAD: 50,
  ACTIVE_WINDOW_SECONDS: 100,
  REQUEST_COOLDOWN_SECONDS: 300,
  MAX_RECEIPT_BYTES: 4 * 1024 * 1024,
  HEADERS: ['Created At', 'Email', 'Request ID', 'Activation Code', 'Receipt File Name', 'Receipt File ID', 'Receipt URL', 'Payment Status', 'Activation Status', 'Device ID', 'Session Token', 'Last Seen', 'Notes', 'Updated At']
};

function doGet() {
  return json_({ok:true, service:'CryptoAnalyser', message:'Backend is running.', actions:['request','activate','login','recoverCode','heartbeat','authorizeAnalysis','logout']});
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const input = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = String(input.action || '');
    if (!lock.tryLock(10000)) return json_({ok:false, message:'الخدمة مشغولة. أعد المحاولة بعد قليل.'});
    const sheet = getSheet_();
    const now = new Date();
    const email = normalizeEmail_(input.email);
    const deviceId = String(input.deviceId || '').trim().slice(0,128);

    if (action === 'request' || action === 'register') {
      if (!email || !deviceId) return json_({ok:false, message:'أدخل بريدًا إلكترونيًا صحيحًا.'});
      const mime = String(input.receiptMimeType || '').toLowerCase();
      const b64 = String(input.receiptBase64 || input.receiptData || '');
      if (!b64) return json_({ok:false, message:'يجب إرفاق إيصال الدفع.'});
      if (!['image/jpeg','image/png','application/pdf'].includes(mime)) return json_({ok:false, message:'نوع الإيصال غير مدعوم. استخدم JPG أو PNG أو PDF.'});
      const bytes = Utilities.base64Decode(b64);
      if (!bytes.length || bytes.length > CONFIG.MAX_RECEIPT_BYTES) return json_({ok:false, message:'حجم الإيصال فارغ أو يتجاوز 4 ميغابايت.'});
      const rows = readRows_(sheet);
      const recent = rows.find(r => r.email === email && (now.getTime()-r.createdAt.getTime())/1000 < CONFIG.REQUEST_COOLDOWN_SECONDS && ['PENDING','PAID'].includes(r.paymentStatus));
      if (recent) return json_({ok:false, message:'يوجد طلب حديث لهذا البريد. انتظر مراجعة الدفع أو استخدم كود التفعيل إذا وصلك.'});

      const folder = getReceiptFolder_();
      const filename = sanitizeFileName_(String(input.receiptFileName || 'payment-receipt'));
      const blob = Utilities.newBlob(bytes, mime, filename);
      const file = folder.createFile(blob);
      const requestId = Utilities.getUuid();
      const code = makeCode_(24);
      const row = [now, email, requestId, code, filename, file.getId(), file.getUrl(), 'PENDING', 'NOT_ACTIVATED', deviceId, '', '', 'بانتظار التحقق اليدوي من وصول 50 درهمًا.', now];
      sheet.appendRow(row);
      const subject = 'CryptoAnalyser — طلب تفعيل جديد';
      const body = 'وصل طلب تفعيل جديد لتطبيق CryptoAnalyser.\n\n' +
        'البريد الإلكتروني: ' + email + '\n' +
        'رقم الطلب: ' + requestId + '\n' +
        'تاريخ الطلب: ' + Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss') + '\n' +
        'المبلغ المطلوب: ' + CONFIG.PAYMENT_AMOUNT_MAD + ' MAD\n' +
        'المستفيد: ' + CONFIG.CASHPLUS_BENEFICIARY + '\n' +
        'اسم الإيصال: ' + filename + '\n' +
        'ملف الإيصال محفوظ في مجلد Drive خاص ومرفق بهذه الرسالة.\n\n' +
        'الإجراء: تحقق يدويًا من وصول المال أولًا. بعد التأكد، غيّر Payment Status إلى PAID في ورقة ActivationRequests، ثم أرسل كود التفعيل الموجود في العمود Activation Code إلى صاحب البريد. لا ترسل الكود قبل تأكيد الدفع.\n\n' +
        'تنبيه: الإيصال وحده لا يثبت وصول المال.';
      MailApp.sendEmail({to:CONFIG.ADMIN_EMAIL, subject:subject, body:body, attachments:[blob.copyBlob()]});
      return json_({ok:true, message:'تم إرسال طلب التفعيل والإيصال للمراجعة. انتظر تأكيد الدفع وكود التفعيل عبر البريد الإلكتروني.', requestId:requestId});
    }

    const rows = readRows_(sheet);

    if (action === 'recoverCode' || action === 'forgotCode') {
      if (!email) return json_({ok:false, message:'أدخل بريدًا إلكترونيًا صحيحًا.'});
      // Rate-limit recovery attempts per email to reduce abuse.
      const props = PropertiesService.getScriptProperties();
      const emailHash = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, email, Utilities.Charset.UTF_8)
        .map(b => ('0' + ((b + 256) % 256).toString(16)).slice(-2)).join('');
      const rateKey = 'RECOVERY_LAST_' + emailHash;
      const usedKey = 'RECOVERY_USED_ONCE_' + emailHash;
      const lastSent = Number(props.getProperty(rateKey) || '0');
      const genericMessage = 'إذا كان البريد مرتبطًا بطلب مدفوع ومؤكد ولم تُستخدم استعادة الكود من قبل، فستصلك رسالة بالبريد الإلكتروني. تحقق أيضًا من مجلد الرسائل غير المرغوب فيها.';
      // Recovery is a one-time account feature. This is enforced server-side so reinstalling
      // the app or changing phones cannot reset the limit.
      if (props.getProperty(usedKey) === 'YES') {
        return json_({ok:true, message:'تم استخدام استعادة كود التفعيل لهذا البريد من قبل. لأسباب أمنية، تواصل مع الدعم على ' + CONFIG.ADMIN_EMAIL + '.'});
      }
      if (Date.now() - lastSent < 300000) return json_({ok:true, message:genericMessage});
      const paidRow = rows.slice().reverse().find(r => r.email === email && r.paymentStatus === 'PAID' && r.activationCode && r.activationStatus !== 'SUSPENDED');
      if (paidRow) {
        MailApp.sendEmail({
          to: email,
          subject: 'CryptoAnalyser — استعادة كود التفعيل (استخدام لمرة واحدة)',
          body: 'مرحبًا،\n\nطلبت استعادة كود التفعيل الخاص بتطبيق CryptoAnalyser. هذه خاصية استعادة لمرة واحدة فقط لهذا البريد الإلكتروني.\n\nكود التفعيل: ' + paidRow.activationCode + '\n\nأدخل البريد الإلكتروني نفسه وهذا الكود داخل التطبيق. إذا لم تطلب هذه الرسالة، يمكنك تجاهلها. لا تشارك الكود مع أي شخص.\n\nCryptoAnalyser by ErrZhr'
        });
        // Mark as used only after MailApp accepts the send operation.
        props.setProperty(usedKey, 'YES');
        props.setProperty(rateKey, String(Date.now()));
      }
      return json_({ok:true, message:genericMessage});
    }

    if (!email || !deviceId) return json_({ok:false, message:'البريد الإلكتروني أو معرّف الجهاز غير صالح.'});

    if (action === 'activate' || action === 'login') {
      const code = String(input.code || input.activationCode || '').trim();
      if (!code || code.length > 64) return json_({ok:false, message:'كود التفعيل غير صالح.'});
      const row = rows.slice().reverse().find(r => r.email === email && constantTimeEqual_(r.activationCode, code));
      if (!row) return json_({ok:false, message:'البريد الإلكتروني أو الكود غير صحيح.'});
      if (row.paymentStatus !== 'PAID') return json_({ok:false, message:'لم يؤكد صاحب التطبيق الدفع بعد.'});
      if (row.activationStatus === 'SUSPENDED') return json_({ok:false, message:'تم إيقاف هذا الحساب. تواصل مع صاحب التطبيق.'});
      const activeOther = rows.find(r => r.email === email && r.activationStatus === 'ACTIVATED' && r.deviceId && r.deviceId !== deviceId && isFresh_(r.lastSeen, now));
      if (activeOther) return json_({ok:false, code:'DUPLICATE_SESSION', message:'هذا الحساب نشط على جهاز آخر.'});
      rows.filter(r => r.email === email && r.activationStatus === 'ACTIVATED' && r.sheetRow !== row.sheetRow).forEach(r => sheet.getRange(r.sheetRow,9).setValue('SESSION_REPLACED'));
      const token = Utilities.getUuid() + Utilities.getUuid();
      sheet.getRange(row.sheetRow,9).setValue('ACTIVATED');
      sheet.getRange(row.sheetRow,10).setValue(deviceId);
      sheet.getRange(row.sheetRow,11).setValue(token);
      sheet.getRange(row.sheetRow,12).setValue(now);
      sheet.getRange(row.sheetRow,14).setValue(now);
      return json_({ok:true, message:'تم تفعيل الحساب.', sessionToken:token});
    }

    if (action === 'heartbeat' || action === 'authorizeAnalysis') {
      const active = rows.find(r => r.email === email && r.activationStatus === 'ACTIVATED');
      if (!active || active.paymentStatus !== 'PAID') return json_({ok:false, message:'لا يوجد ترخيص مفعّل لهذا البريد.'});
      if (active.deviceId !== deviceId) return json_({ok:false, code:'DUPLICATE_SESSION', message:'هذا الحساب نشط على جهاز آخر. تم تسجيل الخروج.'});
      sheet.getRange(active.sheetRow,12).setValue(now);
      sheet.getRange(active.sheetRow,14).setValue(now);
      return json_({ok:true, message:action === 'authorizeAnalysis' ? 'Analysis request authorized.' : 'الجلسة صالحة.'});
    }

    if (action === 'logout') {
      const active = rows.find(r => r.email === email && r.activationStatus === 'ACTIVATED' && r.deviceId === deviceId);
      if (active) {
        sheet.getRange(active.sheetRow,9).setValue('LOGGED_OUT');
        sheet.getRange(active.sheetRow,10).clearContent();
        sheet.getRange(active.sheetRow,11).clearContent();
        sheet.getRange(active.sheetRow,12).clearContent();
        sheet.getRange(active.sheetRow,14).setValue(now);
      }
      return json_({ok:true, message:'تم تسجيل الخروج.'});
    }
    return json_({ok:false, message:'طلب غير معروف.'});
  } catch (err) {
    console.error(err && err.stack ? err.stack : err);
    return json_({ok:false, message:'حدث خطأ في خدمة التفعيل. تحقق من إعدادات Apps Script وحاول لاحقًا.'});
  } finally {
    try { lock.releaseLock(); } catch (_) {}
  }
}

function setupSheet() {
  const sheet = getSheet_();
  sheet.setFrozenRows(1);
  sheet.getRange(1,1,1,CONFIG.HEADERS.length).setFontWeight('bold');
  sheet.setColumnWidths(1, CONFIG.HEADERS.length, 170);
  sheet.getRange('A:A').setNumberFormat('yyyy-mm-dd hh:mm:ss');
  sheet.getRange('N:N').setNumberFormat('yyyy-mm-dd hh:mm:ss');
  getReceiptFolder_();
  return 'ActivationRequests is ready.';
}

function getSheet_() {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  let sheet = ss.getSheetByName(CONFIG.SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(CONFIG.SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1,1,1,CONFIG.HEADERS.length).setValues([CONFIG.HEADERS]);
  } else {
    const existing = sheet.getRange(1,1,1,Math.max(sheet.getLastColumn(),1)).getValues()[0].map(String);
    if (existing.length === 7 && existing[0] === 'Request timestamp') {
      // Preserve existing rows while expanding the older seven-column schema.
      sheet.getRange(1,1,1,CONFIG.HEADERS.length).setValues([CONFIG.HEADERS]);
      const last = sheet.getLastRow();
      if (last > 1) {
        const old = sheet.getRange(2,1,last-1,7).getValues();
        const upgraded = old.map(r => [r[0], r[1], Utilities.getUuid(), r[2], '', '', '', r[3] === 'PAID' ? 'PAID' : 'PENDING', r[3] === 'ACTIVE' ? 'ACTIVATED' : 'NOT_ACTIVATED', r[4] || '', '', r[5] || '', 'Migrated from previous version', r[6] || new Date()]);
        sheet.getRange(2,1,upgraded.length,CONFIG.HEADERS.length).setValues(upgraded);
      }
    } else {
      const first = existing.slice(0, CONFIG.HEADERS.length);
      if (first[0] !== CONFIG.HEADERS[0] || first[1] !== CONFIG.HEADERS[1]) {
        throw new Error('ActivationRequests headers do not match the expected schema. Back up the sheet before changing headers.');
      }
      if (sheet.getLastColumn() < CONFIG.HEADERS.length) sheet.insertColumnsAfter(sheet.getLastColumn(), CONFIG.HEADERS.length - sheet.getLastColumn());
      sheet.getRange(1,1,1,CONFIG.HEADERS.length).setValues([CONFIG.HEADERS]);
    }
  }
  return sheet;
}

function getReceiptFolder_() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('CRYPTOANALYSER_RECEIPT_FOLDER_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (_) {} }
  const folder = DriveApp.createFolder('CryptoAnalyser_Private_Receipts');
  props.setProperty('CRYPTOANALYSER_RECEIPT_FOLDER_ID', folder.getId());
  return folder;
}

function readRows_(sheet) {
  if (sheet.getLastRow() < 2) return [];
  return sheet.getRange(2,1,sheet.getLastRow()-1,CONFIG.HEADERS.length).getValues().map((r,i) => ({
    createdAt:r[0] instanceof Date ? r[0] : new Date(r[0]), email:normalizeEmail_(r[1]), requestId:String(r[2]||''),
    activationCode:String(r[3]||''), receiptFileName:String(r[4]||''), receiptFileId:String(r[5]||''), receiptUrl:String(r[6]||''),
    paymentStatus:String(r[7]||''), activationStatus:String(r[8]||''), deviceId:String(r[9]||''), sessionToken:String(r[10]||''),
    lastSeen:r[11] instanceof Date ? r[11] : (r[11] ? new Date(r[11]) : null), notes:String(r[12]||''), updatedAt:r[13], sheetRow:i+2
  }));
}
function makeCode_(length) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*-_';
  let out = '';
  while (out.length < length) {
    const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, Utilities.getUuid()+':'+Date.now()+':'+Math.random());
    for (let i=0; i<bytes.length && out.length<length; i++) out += chars[(bytes[i] & 0xff) % chars.length];
  }
  return out;
}
function normalizeEmail_(value) { const email=String(value||'').trim().toLowerCase(); return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : ''; }
function isFresh_(date, now) { return date instanceof Date && !isNaN(date.getTime()) && (now.getTime()-date.getTime())/1000 <= CONFIG.ACTIVE_WINDOW_SECONDS; }
function constantTimeEqual_(a,b) { a=String(a); b=String(b); let d=a.length^b.length; for(let i=0,n=Math.max(a.length,b.length);i<n;i++) d|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0); return d===0; }
function sanitizeFileName_(name) { return name.replace(/[\\/:*?"<>|\r\n]/g,'_').slice(0,120) || 'payment-receipt'; }
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
