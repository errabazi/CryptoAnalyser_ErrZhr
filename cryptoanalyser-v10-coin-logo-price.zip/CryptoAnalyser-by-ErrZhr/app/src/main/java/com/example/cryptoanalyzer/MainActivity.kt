
package com.example.cryptoanalyzer

import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import android.speech.tts.TextToSpeech
import android.text.Html
import android.webkit.WebView
import android.webkit.WebViewClient
import android.util.Xml
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZonedDateTime
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val appLanguages = listOf(
    "en" to "English", "fr" to "Français", "ar" to "العربية", "zh" to "中文",
    "ja" to "日本語", "es" to "Español", "de" to "Deutsch", "it" to "Italiano", "ko" to "한국어"
)

private val baseUiTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf(
        "PRIVACY" to "CONFIDENTIALITÉ", "PUBLIC MARKET DATA · BITGET API" to "DONNÉES PUBLIQUES · API BITGET",
        "YOUR MARKET,\nCLEARER." to "VOTRE MARCHÉ,\nPLUS CLAIR.", "Technical signals and multi-timeframe insights in one place." to "Signaux techniques et analyses multi-unités de temps au même endroit.",
        "PUBLIC BITGET DATA" to "DONNÉES PUBLIQUES BITGET", "ANALYZE A MARKET" to "ANALYSER UN MARCHÉ", "Choose a pair and market type" to "Choisissez une paire et un type de marché",
        "Coin or trading pair" to "Crypto ou paire de trading", "Type BTC, ETH, AI…" to "Saisissez BTC, ETH, AI…", "MARKET TYPE" to "TYPE DE MARCHÉ",
        "ANALYZING MARKET…" to "ANALYSE DU MARCHÉ…", "✦  ANALYZE MARKET" to "✦  ANALYSER LE MARCHÉ", "LISTEN TO THE SUMMARY" to "ÉCOUTER LE RÉSUMÉ",
        "Choose a voice, then tap the speaker button. Voice availability depends on the text-to-speech engine installed on your phone." to "Choisissez une voix, puis appuyez sur le bouton audio. La disponibilité dépend du moteur vocal installé sur votre téléphone.",
        "👩  Woman" to "👩  Femme", "👨  Man" to "👨  Homme", "🔊  HEAR SUMMARY" to "🔊  ÉCOUTER LE RÉSUMÉ", "Preparing voice…" to "Préparation de la voix…",
        "ENTRY PLAN · AUTOMATIC" to "PLAN D’ENTRÉE · AUTOMATIQUE", "PRICE RANGE" to "FOURCHETTE DE PRIX", "HIGH / LOW" to "HAUT / BAS", "PRICE CHART · CANDLESTICKS" to "GRAPHIQUE · BOUGIES JAPONAISES", "15 minutes" to "15 minutes", "1 hour" to "1 heure", "4 hours" to "4 heures", "1 day" to "1 jour", "1 month" to "1 mois", "Run analysis to load the price chart." to "Lancez l’analyse pour charger le graphique.", "Candlestick data is unavailable for this pair and timeframe." to "Données de bougies indisponibles pour cette paire et cette période.",
        "ALL-TIME HIGH" to "PLUS HAUT HISTORIQUE", "ALL-TIME LOW" to "PLUS BAS HISTORIQUE", "24H HIGH" to "PLUS HAUT 24 H", "24H LOW" to "PLUS BAS 24 H",
        "Unavailable" to "Indisponible", "Close" to "Fermer", "Fermer" to "Fermer", "LANGUAGE" to "LANGUE", "PLATFORM" to "PLATEFORME", "PUBLIC MARKET DATA" to "DONNÉES PUBLIQUES",
        "Stop" to "Arrêter", "−5 sec" to "−5 s", "+5 sec" to "+5 s", "Restart" to "Recommencer"
    ),
    "ar" to mapOf(
        "PRIVACY" to "الخصوصية", "PUBLIC MARKET DATA · BITGET API" to "بيانات السوق العامة · واجهة BITGET",
        "YOUR MARKET,\nCLEARER." to "سوقك،\nبوضوح أكبر.", "Technical signals and multi-timeframe insights in one place." to "إشارات فنية وتحليلات لعدة أطر زمنية في مكان واحد.",
        "PUBLIC BITGET DATA" to "بيانات BITGET العامة", "ANALYZE A MARKET" to "تحليل السوق", "Choose a pair and market type" to "اختر زوج التداول ونوع السوق",
        "Coin or trading pair" to "العملة أو زوج التداول", "Type BTC, ETH, AI…" to "اكتب BTC أو ETH أو AI…", "MARKET TYPE" to "نوع السوق",
        "ANALYZING MARKET…" to "جارٍ تحليل السوق…", "✦  ANALYZE MARKET" to "✦  تحليل السوق", "LISTEN TO THE SUMMARY" to "استمع إلى الملخص",
        "Choose a voice, then tap the speaker button. Voice availability depends on the text-to-speech engine installed on your phone." to "اختر الصوت ثم اضغط زر التشغيل. يعتمد توفر الصوت على محرك تحويل النص إلى كلام المثبت على هاتفك.",
        "👩  Woman" to "👩  امرأة", "👨  Man" to "👨  رجل", "🔊  HEAR SUMMARY" to "🔊  استمع إلى الملخص", "Preparing voice…" to "جارٍ تجهيز الصوت…",
        "ENTRY PLAN · AUTOMATIC" to "خطة الدخول · تلقائي", "PRICE RANGE" to "نطاق السعر", "HIGH / LOW" to "الأعلى / الأدنى", "PRICE CHART · CANDLESTICKS" to "الرسم البياني · الشموع اليابانية", "15 minutes" to "15 دقيقة", "1 hour" to "ساعة واحدة", "4 hours" to "4 ساعات", "1 day" to "يوم واحد", "1 month" to "شهر واحد", "Run analysis to load the price chart." to "ابدأ التحليل لتحميل الرسم البياني.", "Candlestick data is unavailable for this pair and timeframe." to "بيانات الشموع غير متاحة لهذا الزوج والإطار الزمني.",
        "ALL-TIME HIGH" to "أعلى سعر تاريخي", "ALL-TIME LOW" to "أدنى سعر تاريخي", "24H HIGH" to "أعلى سعر خلال 24 ساعة", "24H LOW" to "أدنى سعر خلال 24 ساعة",
        "Unavailable" to "غير متاح", "Close" to "إغلاق", "Fermer" to "إغلاق", "LANGUAGE" to "اللغة", "PLATFORM" to "المنصة", "PUBLIC MARKET DATA" to "بيانات السوق العامة",
        "Stop" to "إيقاف", "−5 sec" to "−5 ثوانٍ", "+5 sec" to "+5 ثوانٍ", "Restart" to "إعادة من البداية"
    ),
    "es" to mapOf("PRIVACY" to "PRIVACIDAD", "ANALYZE A MARKET" to "ANALIZAR MERCADO", "Choose a pair and market type" to "Elige un par y tipo de mercado", "MARKET TYPE" to "TIPO DE MERCADO", "ANALYZING MARKET…" to "ANALIZANDO MERCADO…", "✦  ANALYZE MARKET" to "✦  ANALIZAR MERCADO", "LISTEN TO THE SUMMARY" to "ESCUCHAR EL RESUMEN", "👩  Woman" to "👩  Mujer", "👨  Man" to "👨  Hombre", "🔊  HEAR SUMMARY" to "🔊  ESCUCHAR RESUMEN", "ENTRY PLAN · AUTOMATIC" to "PLAN DE ENTRADA · AUTOMÁTICO", "PRICE RANGE" to "RANGO DE PRECIOS", "ALL-TIME HIGH" to "MÁXIMO HISTÓRICO", "ALL-TIME LOW" to "MÍNIMO HISTÓRICO", "24H HIGH" to "MÁXIMO 24 H", "24H LOW" to "MÍNIMO 24 H", "Unavailable" to "No disponible", "LANGUAGE" to "IDIOMA", "Stop" to "Detener", "−5 sec" to "−5 s", "+5 sec" to "+5 s", "Restart" to "Reiniciar"),
    "de" to mapOf("PRIVACY" to "DATENSCHUTZ", "ANALYZE A MARKET" to "MARKT ANALYSIEREN", "Choose a pair and market type" to "Wähle ein Handelspaar und einen Markttyp", "MARKET TYPE" to "MARKTTYP", "ANALYZING MARKET…" to "MARKTANALYSE…", "✦  ANALYZE MARKET" to "✦  MARKT ANALYSIEREN", "LISTEN TO THE SUMMARY" to "ZUSAMMENFASSUNG ANHÖREN", "👩  Woman" to "👩  Frau", "👨  Man" to "👨  Mann", "🔊  HEAR SUMMARY" to "🔊  ZUSAMMENFASSUNG", "ENTRY PLAN · AUTOMATIC" to "EINSTIEGSPLAN · AUTOMATISCH", "PRICE RANGE" to "PREISBEREICH", "ALL-TIME HIGH" to "ALLZEITHOCH", "ALL-TIME LOW" to "ALLZEITTIEF", "24H HIGH" to "24H-HOCH", "24H LOW" to "24H-TIEF", "Unavailable" to "Nicht verfügbar", "LANGUAGE" to "SPRACHE", "Stop" to "Stopp", "−5 sec" to "−5 Sek.", "+5 sec" to "+5 Sek.", "Restart" to "Neu starten"),
    "it" to mapOf("PRIVACY" to "PRIVACY", "ANALYZE A MARKET" to "ANALIZZA MERCATO", "Choose a pair and market type" to "Scegli una coppia e il tipo di mercato", "MARKET TYPE" to "TIPO DI MERCATO", "ANALYZING MARKET…" to "ANALISI DEL MERCATO…", "✦  ANALYZE MARKET" to "✦  ANALIZZA MERCATO", "LISTEN TO THE SUMMARY" to "ASCOLTA IL RIEPILOGO", "👩  Woman" to "👩  Donna", "👨  Man" to "👨  Uomo", "🔊  HEAR SUMMARY" to "🔊  ASCOLTA RIEPILOGO", "ENTRY PLAN · AUTOMATIC" to "PIANO DI INGRESSO · AUTOMATICO", "PRICE RANGE" to "INTERVALLO DI PREZZO", "ALL-TIME HIGH" to "MASSIMO STORICO", "ALL-TIME LOW" to "MINIMO STORICO", "24H HIGH" to "MASSIMO 24 ORE", "24H LOW" to "MINIMO 24 ORE", "Unavailable" to "Non disponibile", "LANGUAGE" to "LINGUA", "Stop" to "Ferma", "−5 sec" to "−5 s", "+5 sec" to "+5 s", "Restart" to "Ricomincia"),
    "zh" to mapOf("PRIVACY" to "隐私", "ANALYZE A MARKET" to "分析市场", "Choose a pair and market type" to "选择交易对和市场类型", "MARKET TYPE" to "市场类型", "ANALYZING MARKET…" to "正在分析市场…", "✦  ANALYZE MARKET" to "✦  分析市场", "LISTEN TO THE SUMMARY" to "收听摘要", "👩  Woman" to "👩  女声", "👨  Man" to "👨  男声", "🔊  HEAR SUMMARY" to "🔊  收听摘要", "ENTRY PLAN · AUTOMATIC" to "自动入场计划", "PRICE RANGE" to "价格区间", "ALL-TIME HIGH" to "历史最高价", "ALL-TIME LOW" to "历史最低价", "24H HIGH" to "24小时最高", "24H LOW" to "24小时最低", "Unavailable" to "不可用", "LANGUAGE" to "语言", "Stop" to "停止", "−5 sec" to "后退5秒", "+5 sec" to "前进5秒", "Restart" to "从头播放"),
    "ja" to mapOf("PRIVACY" to "プライバシー", "ANALYZE A MARKET" to "市場を分析", "Choose a pair and market type" to "取引ペアと市場タイプを選択", "MARKET TYPE" to "市場タイプ", "ANALYZING MARKET…" to "市場を分析中…", "✦  ANALYZE MARKET" to "✦  市場を分析", "LISTEN TO THE SUMMARY" to "要約を聞く", "👩  Woman" to "👩  女性", "👨  Man" to "👨  男性", "🔊  HEAR SUMMARY" to "🔊  要約を聞く", "ENTRY PLAN · AUTOMATIC" to "エントリープラン · 自動", "PRICE RANGE" to "価格範囲", "ALL-TIME HIGH" to "史上最高値", "ALL-TIME LOW" to "史上最安値", "24H HIGH" to "24時間高値", "24H LOW" to "24時間安値", "Unavailable" to "利用不可", "LANGUAGE" to "言語", "Stop" to "停止", "−5 sec" to "5秒戻る", "+5 sec" to "5秒進む", "Restart" to "最初から再生"),
    "ko" to mapOf("PRIVACY" to "개인정보", "ANALYZE A MARKET" to "시장 분석", "Choose a pair and market type" to "거래 쌍과 시장 유형 선택", "MARKET TYPE" to "시장 유형", "ANALYZING MARKET…" to "시장 분석 중…", "✦  ANALYZE MARKET" to "✦  시장 분석", "LISTEN TO THE SUMMARY" to "요약 듣기", "👩  Woman" to "👩  여성 음성", "👨  Man" to "👨  남성 음성", "🔊  HEAR SUMMARY" to "🔊  요약 듣기", "ENTRY PLAN · AUTOMATIC" to "자동 진입 계획", "PRICE RANGE" to "가격 범위", "ALL-TIME HIGH" to "역대 최고가", "ALL-TIME LOW" to "역대 최저가", "24H HIGH" to "24시간 최고가", "24H LOW" to "24시간 최저가", "Unavailable" to "사용 불가", "LANGUAGE" to "언어", "Stop" to "중지", "−5 sec" to "5초 뒤로", "+5 sec" to "5초 앞으로", "Restart" to "처음부터 재생")
)

private val additionalTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf(
        "COIN RESEARCH REPORT" to "RAPPORT DE RECHERCHE SUR LA CRYPTO", "Summary and source checks" to "Résumé et vérification des sources", "Project identity and utility" to "Projet et utilité", "Launch and first market data" to "Lancement et premières données de marché", "Investors and funding" to "Investisseurs et financement", "Token unlock schedule" to "Calendrier de déblocage des tokens", "Adoption and partnerships" to "Adoption et partenariats", "Price scenarios: 1 month to 5 years" to "Scénarios de prix : 1 mois à 5 ans", "Search sources inside app" to "Rechercher les sources dans l’application", "Close" to "Fermer", "No claim is treated as confirmed unless a reliable source supports it. Check the selected coin name and ticker to avoid confusing projects with similar symbols." to "Aucune affirmation n’est considérée comme confirmée sans source fiable. Vérifiez le nom et le symbole pour éviter toute confusion entre projets similaires.", "The report separates verified facts from claims that still need checking. Forecasts are scenarios, not guarantees. Data not found is marked unknown instead of being invented." to "Le rapport distingue les faits vérifiés des affirmations à confirmer. Les prévisions sont des scénarios, pas des garanties. Les données introuvables sont signalées comme inconnues, sans invention.", "Source access depends on public availability. Private groups and some social-platform posts cannot be searched automatically; missing data is not proof that no information exists." to "L’accès aux sources dépend de leur disponibilité publique. Les groupes privés et certaines publications sociales ne peuvent pas être recherchés automatiquement ; une donnée manquante ne prouve pas son inexistence.",
        "LIVE PRICE" to "PRIX EN DIRECT", "Live public market data · Bitget" to "Données publiques en direct · Bitget", "MAX. 4" to "MAX. 4",
        "Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global." to "Les nouvelles sont filtrées selon leur date et leur pertinence pour la crypto choisie ou le marché global.",
        "Chargement des actualités récentes…" to "Chargement des actualités récentes…", "PUBLIC BITGET DATA" to "DONNÉES PUBLIQUES BITGET",
        "Signal interpretation" to "Interprétation du signal", "Scores are heuristic signals, not calibrated probabilities." to "Les scores sont des indicateurs heuristiques, pas des probabilités calibrées.",
        "BACKTEST LAB" to "LABORATOIRE DE BACKTEST", "EMA 9/21 crossover" to "Croisement EMA 9/21", "PROJECT RESEARCH" to "RECHERCHE SUR LE PROJET",
        "Fundamentals & investors" to "Fondamentaux et investisseurs", "What this app does" to "Fonctionnement de l’application", "Network and privacy" to "Réseau et confidentialité",
        "Financial risk" to "Risques financiers", "Third-party services" to "Services tiers", "Stop loss (SL)" to "Stop-loss (SL)",
        "Entry / trigger" to "Entrée / déclencheur", "BULLISH SCORE" to "SCORE HAUSSIER", "BEARISH SCORE" to "SCORE BAISSIER",
        "MOVING AVERAGES" to "MOYENNES MOBILES", "MOMENTUM" to "MOMENTUM", "SUPPORT" to "SUPPORT", "RESISTANCE" to "RÉSISTANCE"
    ),
    "ar" to mapOf(
        "COIN RESEARCH REPORT" to "تقرير بحث العملة", "Summary and source checks" to "ملخص والتحقق من المصادر", "Project identity and utility" to "تعريف المشروع واستخدام العملة", "Launch and first market data" to "الإطلاق وأول بيانات السوق", "Investors and funding" to "المستثمرون والتمويل", "Token unlock schedule" to "جدول تحرير العملات", "Adoption and partnerships" to "التبني والشراكات", "Price scenarios: 1 month to 5 years" to "سيناريوهات السعر: من شهر إلى 5 سنوات", "Search sources inside app" to "البحث في المصادر داخل التطبيق", "Close" to "إغلاق", "No claim is treated as confirmed unless a reliable source supports it. Check the selected coin name and ticker to avoid confusing projects with similar symbols." to "لن تُعد أي معلومة مؤكدة دون مصدر موثوق. تحقق من اسم العملة ورمزها لتجنب الخلط بين المشاريع المتشابهة.", "The report separates verified facts from claims that still need checking. Forecasts are scenarios, not guarantees. Data not found is marked unknown instead of being invented." to "يفصل التقرير بين الحقائق المؤكدة والادعاءات التي تحتاج إلى تحقق. التوقعات سيناريوهات وليست ضمانات. ستُعرض البيانات غير المتاحة على أنها مجهولة بدل اختلاقها.", "Source access depends on public availability. Private groups and some social-platform posts cannot be searched automatically; missing data is not proof that no information exists." to "يعتمد الوصول إلى المصادر على إتاحتها للعامة. لا يمكن البحث آليًا في المجموعات الخاصة وبعض منشورات المنصات الاجتماعية؛ وعدم العثور على معلومة لا يعني أنها غير موجودة.",
        "LIVE PRICE" to "السعر المباشر", "Live public market data · Bitget" to "بيانات السوق العامة المباشرة · Bitget", "MAX. 4" to "الحد الأقصى 4",
        "Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global." to "تُرشّح الأخبار حسب حداثتها ومدى ارتباطها بالعملة المختارة أو بالسوق عمومًا.",
        "Chargement des actualités récentes…" to "جارٍ تحميل آخر الأخبار…", "PUBLIC BITGET DATA" to "بيانات Bitget العامة",
        "Signal interpretation" to "تفسير الإشارة", "Scores are heuristic signals, not calibrated probabilities." to "الدرجات مؤشرات تقديرية وليست احتمالات معايرة.",
        "BACKTEST LAB" to "مختبر الاختبار التاريخي", "EMA 9/21 crossover" to "تقاطع EMA 9/21", "PROJECT RESEARCH" to "بحث المشروع",
        "Fundamentals & investors" to "الأساسيات والمستثمرون", "What this app does" to "وظيفة التطبيق", "Network and privacy" to "الشبكة والخصوصية",
        "Financial risk" to "المخاطر المالية", "Third-party services" to "خدمات الجهات الخارجية", "Stop loss (SL)" to "وقف الخسارة (SL)",
        "Entry / trigger" to "الدخول / شرط التفعيل", "BULLISH SCORE" to "درجة الصعود", "BEARISH SCORE" to "درجة الهبوط",
        "MOVING AVERAGES" to "المتوسطات المتحركة", "MOMENTUM" to "الزخم", "SUPPORT" to "الدعم", "RESISTANCE" to "المقاومة"
    ),
    "es" to mapOf("LIVE PRICE" to "PRECIO EN VIVO", "Signal interpretation" to "Interpretación de señales", "BACKTEST LAB" to "LABORATORIO DE BACKTEST", "PROJECT RESEARCH" to "INVESTIGACIÓN DEL PROYECTO", "Fundamentals & investors" to "Fundamentos e inversores", "BULLISH SCORE" to "PUNTUACIÓN ALCISTA", "BEARISH SCORE" to "PUNTUACIÓN BAJISTA", "MOVING AVERAGES" to "MEDIAS MÓVILES", "SUPPORT" to "SOPORTE", "RESISTANCE" to "RESISTENCIA", "Stop loss (SL)" to "Stop loss (SL)"),
    "de" to mapOf("LIVE PRICE" to "LIVE-PREIS", "Signal interpretation" to "Signalinterpretation", "BACKTEST LAB" to "BACKTEST-LABOR", "PROJECT RESEARCH" to "PROJEKTRECHERCHE", "Fundamentals & investors" to "Fundamentaldaten und Investoren", "BULLISH SCORE" to "AUFWÄRTSWERT", "BEARISH SCORE" to "ABWÄRTSWERT", "MOVING AVERAGES" to "GLEITENDE DURCHSCHNITTE", "SUPPORT" to "UNTERSTÜTZUNG", "RESISTANCE" to "WIDERSTAND", "Stop loss (SL)" to "Stop-Loss (SL)"),
    "it" to mapOf("LIVE PRICE" to "PREZZO LIVE", "Signal interpretation" to "Interpretazione del segnale", "BACKTEST LAB" to "LABORATORIO BACKTEST", "PROJECT RESEARCH" to "RICERCA SUL PROGETTO", "Fundamentals & investors" to "Fondamentali e investitori", "BULLISH SCORE" to "PUNTEGGIO RIALZISTA", "BEARISH SCORE" to "PUNTEGGIO RIBASSISTA", "MOVING AVERAGES" to "MEDIE MOBILI", "SUPPORT" to "SUPPORTO", "RESISTANCE" to "RESISTENZA", "Stop loss (SL)" to "Stop loss (SL)"),
    "zh" to mapOf("LIVE PRICE" to "实时价格", "Signal interpretation" to "信号解读", "BACKTEST LAB" to "回测实验室", "PROJECT RESEARCH" to "项目研究", "Fundamentals & investors" to "基本面与投资者", "BULLISH SCORE" to "看涨评分", "BEARISH SCORE" to "看跌评分", "MOVING AVERAGES" to "移动平均线", "SUPPORT" to "支撑位", "RESISTANCE" to "阻力位", "Stop loss (SL)" to "止损 (SL)"),
    "ja" to mapOf("LIVE PRICE" to "リアルタイム価格", "Signal interpretation" to "シグナル解釈", "BACKTEST LAB" to "バックテスト", "PROJECT RESEARCH" to "プロジェクト調査", "Fundamentals & investors" to "ファンダメンタルズと投資家", "BULLISH SCORE" to "強気スコア", "BEARISH SCORE" to "弱気スコア", "MOVING AVERAGES" to "移動平均線", "SUPPORT" to "サポート", "RESISTANCE" to "レジスタンス", "Stop loss (SL)" to "損切り (SL)"),
    "ko" to mapOf("LIVE PRICE" to "실시간 가격", "Signal interpretation" to "신호 해석", "BACKTEST LAB" to "백테스트 실험실", "PROJECT RESEARCH" to "프로젝트 조사", "Fundamentals & investors" to "펀더멘털 및 투자자", "BULLISH SCORE" to "상승 점수", "BEARISH SCORE" to "하락 점수", "MOVING AVERAGES" to "이동평균", "SUPPORT" to "지지선", "RESISTANCE" to "저항선", "Stop loss (SL)" to "손절매 (SL)")
)

private val uiTranslations: Map<String, Map<String, String>> = baseUiTranslations.mapValues { (language, translations) ->
    translations + additionalTranslations[language].orEmpty()
}

private val tradingTermTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf(
        "Aggressive entry" to "Entrée agressive", "Breakout-confirmation entry" to "Entrée après confirmation de cassure", "More conservative entry" to "Entrée plus prudente",
        "Near support; higher risk. Prefer a visible support reaction." to "Près du support ; risque plus élevé. Attendez une réaction visible du support.",
        "Trigger only after a candle closes above resistance; a retest is preferable." to "Déclenchez l’entrée seulement après la clôture d’une bougie au-dessus de la résistance ; un retest est préférable.",
        "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "Attendez une hausse plus nette au-dessus de la résistance et confirmez le volume ; le prix d’entrée peut être plus élevé.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "Les trois scénarios sont affichés ensemble. Les niveaux utilisent le support et la résistance en 4 h. TP1–TP3 sont des objectifs indicatifs à 1R/2R/3R calculés depuis la distance du stop-loss ; ils ne sont pas garantis.",
        "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "Risque : ces niveaux sont des repères d’analyse, pas des ordres réels. Une entrée sur cassure exige une confirmation ; un stop peut subir du glissement en période volatile.",
        "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "Niveaux de trading indisponibles : les données de support/résistance ne sont pas assez fiables pour établir un plan.",
        "ABOVE" to "AU-DESSUS", "BELOW" to "EN DESSOUS", "Spot" to "Marché au comptant", "USDT Futures" to "Contrats à terme USDT",
        "Entry / trigger" to "Entrée / déclencheur", "Stop loss (SL)" to "Stop-loss (SL)", "TAKE PROFIT" to "PRISE DE BÉNÉFICES", "Volume" to "Volume", "Price" to "Prix", "Change" to "Variation", "Market cap" to "Capitalisation", "Liquidity" to "Liquidité", "Trend" to "Tendance", "Buy" to "Acheter", "Sell" to "Vendre", "Bullish" to "Haussier", "Bearish" to "Baissier", "Timeframe" to "Unité de temps", "Last close" to "Dernière clôture", "Signal" to "Signal", "History" to "Historique", "Risk/Reward" to "Risque/rendement", "Take profit" to "Prise de bénéfices", "Stop loss" to "Stop-loss", "Entry price" to "Prix d’entrée", "Current price" to "Prix actuel", "High" to "Plus haut", "Low" to "Plus bas", "Support" to "Support", "Resistance" to "Résistance", "Momentum" to "Momentum (dynamique)", "Moving averages" to "Moyennes mobiles", "Bullish score" to "Score haussier", "Bearish score" to "Score baissier"
    ),
    "ar" to mapOf(
        "Aggressive entry" to "دخول هجومي", "Breakout-confirmation entry" to "دخول بعد تأكيد الاختراق", "More conservative entry" to "دخول أكثر تحفظًا",
        "Near support; higher risk. Prefer a visible support reaction." to "بالقرب من الدعم؛ المخاطرة أعلى. يُفضّل انتظار ارتداد واضح من الدعم.",
        "Trigger only after a candle closes above resistance; a retest is preferable." to "لا تُفعّل الدخول إلا بعد إغلاق شمعة فوق المقاومة؛ وإعادة اختبار المستوى أفضل.",
        "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "انتظر حركة أقوى فوق المقاومة وتأكد من حجم التداول؛ قد يكون سعر الدخول أعلى.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "تُعرض السيناريوهات الثلاثة معًا. تعتمد المستويات على الدعم والمقاومة في إطار 4 ساعات. أهداف TP1–TP3 توضيحية عند 1R و2R و3R وفق مسافة وقف الخسارة، وليست نتائج مضمونة.",
        "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "تنبيه للمخاطر: هذه مستويات مرجعية للتحليل وليست أوامر تداول فعلية. الدخول بعد الاختراق يحتاج إلى تأكيد، وقد يتجاوز التنفيذ سعر وقف الخسارة أثناء التقلبات.",
        "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "مستويات التداول غير متاحة: بيانات الدعم والمقاومة غير كافية لبناء خطة.",
        "ABOVE" to "أعلى من", "BELOW" to "أدنى من", "Spot" to "السوق الفوري", "USDT Futures" to "العقود الآجلة USDT",
        "Entry / trigger" to "سعر الدخول / شرط التفعيل", "Stop loss (SL)" to "وقف الخسارة (SL)", "TAKE PROFIT" to "جني الأرباح", "Volume" to "حجم التداول", "Price" to "السعر", "Change" to "التغير", "Market cap" to "القيمة السوقية", "Liquidity" to "السيولة", "Trend" to "الاتجاه", "Buy" to "شراء", "Sell" to "بيع", "Bullish" to "صاعد", "Bearish" to "هابط", "Timeframe" to "الإطار الزمني", "Last close" to "آخر إغلاق", "Signal" to "الإشارة", "History" to "السجل التاريخي", "Risk/Reward" to "المخاطرة إلى العائد", "Take profit" to "جني الأرباح", "Stop loss" to "وقف الخسارة", "Entry price" to "سعر الدخول", "Current price" to "السعر الحالي", "High" to "الأعلى", "Low" to "الأدنى", "Support" to "الدعم", "Resistance" to "المقاومة", "Momentum" to "الزخم", "Moving averages" to "المتوسطات المتحركة", "Bullish score" to "درجة الصعود", "Bearish score" to "درجة الهبوط"
    ),
    "es" to mapOf(
        "Aggressive entry" to "Entrada agresiva", "Breakout-confirmation entry" to "Entrada tras confirmar la ruptura", "More conservative entry" to "Entrada más conservadora",
        "Near support; higher risk. Prefer a visible support reaction." to "Cerca del soporte; mayor riesgo. Es preferible ver una reacción clara del soporte.",
        "Trigger only after a candle closes above resistance; a retest is preferable." to "Activar solo después de que una vela cierre por encima de la resistencia; es preferible un retesteo.",
        "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "Espera un movimiento más fuerte por encima de la resistencia y confirma el volumen; la entrada puede ser más alta.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "Se muestran los tres escenarios. Los niveles usan el soporte y la resistencia de 4 h. TP1–TP3 son objetivos orientativos 1R/2R/3R según la distancia al stop-loss; no están garantizados.",
        "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "Riesgo: estos niveles son referencias de análisis, no órdenes reales. Las entradas por ruptura requieren confirmación; las órdenes stop pueden sufrir deslizamiento con volatilidad.",
        "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "Niveles de operación no disponibles: los datos de soporte/resistencia no bastan para crear un plan.",
        "ABOVE" to "POR ENCIMA", "BELOW" to "POR DEBAJO", "Spot" to "Mercado al contado", "USDT Futures" to "Futuros USDT",
        "Entry / trigger" to "Entrada / activación", "Stop loss (SL)" to "Stop-loss (SL)", "TAKE PROFIT" to "TOMA DE GANANCIAS", "Volume" to "Volumen", "Price" to "Precio", "Change" to "Variación", "Market cap" to "Capitalización de mercado", "Liquidity" to "Liquidez", "Trend" to "Tendencia", "Buy" to "Comprar", "Sell" to "Vender", "Bullish" to "Alcista", "Bearish" to "Bajista", "Timeframe" to "Marco temporal", "Last close" to "Último cierre", "Signal" to "Señal", "History" to "Historial", "Risk/Reward" to "Riesgo/beneficio", "Take profit" to "Toma de ganancias", "Stop loss" to "Stop-loss", "Entry price" to "Precio de entrada", "Current price" to "Precio actual", "High" to "Máximo", "Low" to "Mínimo", "Support" to "Soporte", "Resistance" to "Resistencia", "Momentum" to "Impulso", "Moving averages" to "Medias móviles", "Bullish score" to "Puntuación alcista", "Bearish score" to "Puntuación bajista"
    ),
    "de" to mapOf(
        "Aggressive entry" to "Aggressiver Einstieg", "Breakout-confirmation entry" to "Einstieg nach Ausbruchsbestätigung", "More conservative entry" to "Konservativerer Einstieg",
        "Near support; higher risk. Prefer a visible support reaction." to "Nahe der Unterstützung; höheres Risiko. Eine erkennbare Reaktion an der Unterstützung abwarten.",
        "Trigger only after a candle closes above resistance; a retest is preferable." to "Erst auslösen, wenn eine Kerze über dem Widerstand schließt; ein Retest ist vorzuziehen.",
        "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "Eine stärkere Bewegung über den Widerstand abwarten und das Volumen bestätigen; der Einstieg kann höher liegen.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "Alle drei Szenarien werden angezeigt. Die Niveaus basieren auf Unterstützung und Widerstand im 4-Stunden-Zeitrahmen. TP1–TP3 sind beispielhafte 1R/2R/3R-Ziele anhand des Stop-Abstands und nicht garantiert.",
        "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "Risikohinweis: Dies sind Analyse-Referenzwerte, keine Live-Orders. Ausbruchseinstiege benötigen eine Bestätigung; Stop-Orders können bei Volatilität abweichen.",
        "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "Handelsniveaus nicht verfügbar: Die Unterstützungs-/Widerstandsdaten reichen für einen Plan nicht aus.",
        "ABOVE" to "DARÜBER", "BELOW" to "DARUNTER", "Spot" to "Spotmarkt", "USDT Futures" to "USDT-Futures",
        "Entry / trigger" to "Einstieg / Auslöser", "Stop loss (SL)" to "Stop-Loss (SL)", "TAKE PROFIT" to "GEWINNMITNAHME", "Volume" to "Volumen", "Price" to "Preis", "Change" to "Änderung", "Market cap" to "Marktkapitalisierung", "Liquidity" to "Liquidität", "Trend" to "Trend", "Buy" to "Kaufen", "Sell" to "Verkaufen", "Bullish" to "Bullisch", "Bearish" to "Bärisch", "Timeframe" to "Zeitrahmen", "Last close" to "Letzter Schlusskurs", "Signal" to "Signal", "History" to "Verlauf", "Risk/Reward" to "Risiko/Rendite", "Take profit" to "Gewinnmitnahme", "Stop loss" to "Stop-Loss", "Entry price" to "Einstiegspreis", "Current price" to "Aktueller Preis", "High" to "Hoch", "Low" to "Tief", "Support" to "Unterstützung", "Resistance" to "Widerstand", "Momentum" to "Momentum", "Moving averages" to "Gleitende Durchschnitte", "Bullish score" to "Aufwärtsscore", "Bearish score" to "Abwärtsscore"
    ),
    "it" to mapOf(
        "Aggressive entry" to "Ingresso aggressivo", "Breakout-confirmation entry" to "Ingresso dopo conferma della rottura", "More conservative entry" to "Ingresso più prudente",
        "Near support; higher risk. Prefer a visible support reaction." to "Vicino al supporto; rischio maggiore. Preferire una reazione visibile del supporto.",
        "Trigger only after a candle closes above resistance; a retest is preferable." to "Attivare solo dopo la chiusura di una candela sopra la resistenza; meglio attendere un retest.",
        "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "Attendere un movimento più forte sopra la resistenza e confermare i volumi; l’ingresso può essere più alto.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "Sono mostrati tutti e tre gli scenari. I livelli usano supporto e resistenza sul grafico a 4 ore. TP1–TP3 sono obiettivi indicativi 1R/2R/3R calcolati dalla distanza dello stop-loss e non sono garantiti.",
        "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "Rischio: questi livelli sono riferimenti analitici, non ordini reali. Gli ingressi su rottura richiedono conferma; gli stop possono subire slippage durante la volatilità.",
        "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "Livelli di trading non disponibili: i dati di supporto/resistenza non sono sufficienti per un piano.",
        "ABOVE" to "SOPRA", "BELOW" to "SOTTO", "Spot" to "Mercato spot", "USDT Futures" to "Futures USDT",
        "Entry / trigger" to "Ingresso / attivazione", "Stop loss (SL)" to "Stop-loss (SL)", "TAKE PROFIT" to "PRESA DI PROFITTO", "Volume" to "Volume", "Price" to "Prezzo", "Change" to "Variazione", "Market cap" to "Capitalizzazione di mercato", "Liquidity" to "Liquidità", "Trend" to "Tendenza", "Buy" to "Compra", "Sell" to "Vendi", "Bullish" to "Rialzista", "Bearish" to "Ribassista", "Timeframe" to "Intervallo temporale", "Last close" to "Ultima chiusura", "Signal" to "Segnale", "History" to "Storico", "Risk/Reward" to "Rischio/rendimento", "Take profit" to "Presa di profitto", "Stop loss" to "Stop-loss", "Entry price" to "Prezzo d’ingresso", "Current price" to "Prezzo attuale", "High" to "Massimo", "Low" to "Minimo", "Support" to "Supporto", "Resistance" to "Resistenza", "Momentum" to "Momentum", "Moving averages" to "Medie mobili", "Bullish score" to "Punteggio rialzista", "Bearish score" to "Punteggio ribassista"
    ),
    "zh" to mapOf(
        "Aggressive entry" to "激进入场", "Breakout-confirmation entry" to "突破确认后入场", "More conservative entry" to "更稳健的入场",
        "Near support; higher risk. Prefer a visible support reaction." to "接近支撑位，风险较高。优先等待支撑位出现明确反应。", "Trigger only after a candle closes above resistance; a retest is preferable." to "仅在K线收于阻力位上方后触发；最好等待回踩确认。", "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "等待价格更有力地突破阻力位并确认成交量；入场价格可能更高。",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "同时显示三种情景。价位依据4小时支撑位和阻力位。TP1–TP3是按止损距离计算的示例目标1R/2R/3R，并非保证结果。", "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "风险提示：这些是分析参考价位，并非实时订单。突破入场需要确认；波动剧烈时止损单可能出现滑点。", "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "交易价位不可用：支撑位/阻力位数据不足以制定计划。",
        "ABOVE" to "高于", "BELOW" to "低于", "Spot" to "现货", "USDT Futures" to "USDT合约", "Entry / trigger" to "入场价 / 触发条件", "Stop loss (SL)" to "止损 (SL)", "TAKE PROFIT" to "止盈", "Volume" to "成交量", "Price" to "价格", "Change" to "涨跌幅", "Market cap" to "市值", "Liquidity" to "流动性", "Trend" to "趋势", "Buy" to "买入", "Sell" to "卖出", "Bullish" to "看涨", "Bearish" to "看跌", "Timeframe" to "时间周期", "Last close" to "最新收盘价", "Signal" to "信号", "History" to "历史", "Risk/Reward" to "风险/回报", "Take profit" to "止盈", "Stop loss" to "止损", "Entry price" to "入场价", "Current price" to "当前价格", "High" to "最高", "Low" to "最低", "Support" to "支撑位", "Resistance" to "阻力位", "Momentum" to "动量", "Moving averages" to "移动平均线", "Bullish score" to "看涨评分", "Bearish score" to "看跌评分"
    ),
    "ja" to mapOf(
        "Aggressive entry" to "積極的なエントリー", "Breakout-confirmation entry" to "ブレイク確認後のエントリー", "More conservative entry" to "より慎重なエントリー",
        "Near support; higher risk. Prefer a visible support reaction." to "サポート付近でリスクは高め。サポートで明確な反発を確認するのが望ましいです。", "Trigger only after a candle closes above resistance; a retest is preferable." to "ローソク足がレジスタンスを上抜けて確定した後にのみ実行し、再テストを待つのが望ましいです。", "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "レジスタンスを明確に上抜け、出来高を確認してから判断します。エントリー価格は高くなる可能性があります。",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "3つのシナリオをまとめて表示します。価格水準は4時間足のサポートとレジスタンスに基づきます。TP1～TP3は損切り幅に基づく1R/2R/3Rの参考目標で、結果を保証するものではありません。", "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "リスク：これらは分析上の参考水準であり、実際の注文ではありません。ブレイクアウトには確認が必要で、相場急変時は損切り注文にスリッページが生じる場合があります。", "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "取引水準を表示できません。サポート／レジスタンスのデータが計画作成に十分ではありません。",
        "ABOVE" to "上回る", "BELOW" to "下回る", "Spot" to "現物", "USDT Futures" to "USDT先物", "Entry / trigger" to "エントリー / 発動条件", "Stop loss (SL)" to "損切り (SL)", "TAKE PROFIT" to "利確", "Volume" to "出来高", "Price" to "価格", "Change" to "変動率", "Market cap" to "時価総額", "Liquidity" to "流動性", "Trend" to "トレンド", "Buy" to "買い", "Sell" to "売り", "Bullish" to "強気", "Bearish" to "弱気", "Timeframe" to "時間足", "Last close" to "直近終値", "Signal" to "シグナル", "History" to "履歴", "Risk/Reward" to "リスク／リワード", "Take profit" to "利確", "Stop loss" to "損切り", "Entry price" to "エントリー価格", "Current price" to "現在価格", "High" to "高値", "Low" to "安値", "Support" to "サポート", "Resistance" to "レジスタンス", "Momentum" to "モメンタム", "Moving averages" to "移動平均線", "Bullish score" to "強気スコア", "Bearish score" to "弱気スコア"
    ),
    "ko" to mapOf(
        "Aggressive entry" to "공격적 진입", "Breakout-confirmation entry" to "돌파 확인 후 진입", "More conservative entry" to "더 보수적인 진입",
        "Near support; higher risk. Prefer a visible support reaction." to "지지선 부근으로 위험이 더 큽니다. 지지선의 뚜렷한 반응을 확인하는 것이 좋습니다.", "Trigger only after a candle closes above resistance; a retest is preferable." to "캔들이 저항선 위에서 마감된 후에만 실행하고, 재테스트를 기다리는 것이 좋습니다.", "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "저항선을 강하게 돌파하고 거래량을 확인하세요. 진입 가격은 더 높을 수 있습니다.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "세 가지 시나리오를 함께 표시합니다. 가격 수준은 4시간봉 지지선과 저항선을 사용합니다. TP1–TP3는 손절 거리 기준의 예시 목표 1R/2R/3R이며 보장된 결과가 아닙니다.", "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "위험 안내: 이 가격은 분석 참고값이며 실제 주문이 아닙니다. 돌파 진입은 확인이 필요하며 변동성이 클 때 손절 주문에 슬리피지가 발생할 수 있습니다.", "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "거래 수준을 사용할 수 없습니다. 지지선/저항선 데이터가 계획을 세우기에 충분하지 않습니다.",
        "ABOVE" to "상회", "BELOW" to "하회", "Spot" to "현물", "USDT Futures" to "USDT 선물", "Entry / trigger" to "진입 / 발동 조건", "Stop loss (SL)" to "손절 (SL)", "TAKE PROFIT" to "익절", "Volume" to "거래량", "Price" to "가격", "Change" to "변동", "Market cap" to "시가총액", "Liquidity" to "유동성", "Trend" to "추세", "Buy" to "매수", "Sell" to "매도", "Bullish" to "강세", "Bearish" to "약세", "Timeframe" to "시간 프레임", "Last close" to "최근 종가", "Signal" to "신호", "History" to "기록", "Risk/Reward" to "위험/보상", "Take profit" to "익절", "Stop loss" to "손절", "Entry price" to "진입 가격", "Current price" to "현재 가격", "High" to "고가", "Low" to "저가", "Support" to "지지선", "Resistance" to "저항선", "Momentum" to "모멘텀", "Moving averages" to "이동평균", "Bullish score" to "상승 점수", "Bearish score" to "하락 점수"
    )
)

private val tradingSectionTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf("TECHNICAL OVERVIEW" to "VUE TECHNIQUE", "Signals across three timeframes" to "Signaux sur trois unités de temps", "Signal interpretation" to "Interprétation des signaux", "Scores are heuristic signals, not calibrated probabilities." to "Les scores sont des indicateurs heuristiques, pas des probabilités calibrées.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "Référence pédagogique uniquement. Les frais, le glissement, le financement, la liquidation et la taille de position ne sont pas modélisés.", "BACKTEST LAB" to "LABORATOIRE DE BACKTEST", "PROJECT RESEARCH" to "RECHERCHE SUR LE PROJET", "Fundamentals & investors" to "Fondamentaux et investisseurs"),
    "ar" to mapOf("TECHNICAL OVERVIEW" to "نظرة عامة فنية", "Signals across three timeframes" to "الإشارات عبر ثلاثة أطر زمنية", "Signal interpretation" to "تفسير الإشارات", "Scores are heuristic signals, not calibrated probabilities." to "الدرجات إشارات تقديرية وليست احتمالات محسوبة بدقة.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "لأغراض تعليمية فقط. لا يشمل الحساب الرسوم والانزلاق والتمويل والتصفية وتحديد حجم الصفقة.", "BACKTEST LAB" to "مختبر الاختبار التاريخي", "PROJECT RESEARCH" to "بحث المشروع", "Fundamentals & investors" to "الأساسيات والمستثمرون"),
    "es" to mapOf("TECHNICAL OVERVIEW" to "RESUMEN TÉCNICO", "Signals across three timeframes" to "Señales en tres marcos temporales", "Signal interpretation" to "Interpretación de señales", "Scores are heuristic signals, not calibrated probabilities." to "Las puntuaciones son señales heurísticas, no probabilidades calibradas.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "Solo referencia educativa. No se modelan comisiones, deslizamiento, financiación, liquidación ni tamaño de posición.", "BACKTEST LAB" to "LABORATORIO DE BACKTEST", "PROJECT RESEARCH" to "INVESTIGACIÓN DEL PROYECTO", "Fundamentals & investors" to "Fundamentos e inversores"),
    "de" to mapOf("TECHNICAL OVERVIEW" to "TECHNISCHER ÜBERBLICK", "Signals across three timeframes" to "Signale über drei Zeitrahmen", "Signal interpretation" to "Signalinterpretation", "Scores are heuristic signals, not calibrated probabilities." to "Die Werte sind heuristische Signale, keine kalibrierten Wahrscheinlichkeiten.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "Nur eine Lernreferenz. Gebühren, Slippage, Finanzierung, Liquidation und Positionsgröße werden nicht modelliert.", "BACKTEST LAB" to "BACKTEST-LABOR", "PROJECT RESEARCH" to "PROJEKTRECHERCHE", "Fundamentals & investors" to "Fundamentaldaten und Investoren"),
    "it" to mapOf("TECHNICAL OVERVIEW" to "PANORAMICA TECNICA", "Signals across three timeframes" to "Segnali su tre intervalli temporali", "Signal interpretation" to "Interpretazione del segnale", "Scores are heuristic signals, not calibrated probabilities." to "I punteggi sono segnali euristici, non probabilità calibrate.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "Solo riferimento didattico. Commissioni, slippage, funding, liquidazione e dimensionamento della posizione non sono modellati.", "BACKTEST LAB" to "LABORATORIO BACKTEST", "PROJECT RESEARCH" to "RICERCA SUL PROGETTO", "Fundamentals & investors" to "Fondamentali e investitori"),
    "zh" to mapOf("TECHNICAL OVERVIEW" to "技术概览", "Signals across three timeframes" to "三个时间周期的信号", "Signal interpretation" to "信号解读", "Scores are heuristic signals, not calibrated probabilities." to "评分是启发式信号，并非经过校准的概率。", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "仅供学习参考。未计入手续费、滑点、资金费用、强平和仓位大小。", "BACKTEST LAB" to "回测实验室", "PROJECT RESEARCH" to "项目研究", "Fundamentals & investors" to "基本面与投资者"),
    "ja" to mapOf("TECHNICAL OVERVIEW" to "テクニカル概要", "Signals across three timeframes" to "3つの時間足のシグナル", "Signal interpretation" to "シグナルの解釈", "Scores are heuristic signals, not calibrated probabilities." to "スコアは経験則に基づくシグナルであり、較正済みの確率ではありません。", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "学習用の基準値です。手数料、スリッページ、資金調達料、清算、ポジションサイズは計算に含まれません。", "BACKTEST LAB" to "バックテストラボ", "PROJECT RESEARCH" to "プロジェクト調査", "Fundamentals & investors" to "ファンダメンタルズと投資家"),
    "ko" to mapOf("TECHNICAL OVERVIEW" to "기술적 분석 개요", "Signals across three timeframes" to "세 가지 시간 프레임의 신호", "Signal interpretation" to "신호 해석", "Scores are heuristic signals, not calibrated probabilities." to "점수는 휴리스틱 신호이며 보정된 확률이 아닙니다.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "교육용 기준값입니다. 수수료, 슬리피지, 펀딩, 청산 및 포지션 규모는 계산하지 않습니다.", "BACKTEST LAB" to "백테스트 실험실", "PROJECT RESEARCH" to "프로젝트 조사", "Fundamentals & investors" to "펀더멘털 및 투자자")
)

private val indicatorTermTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf("EMA" to "EMA (moyenne mobile exponentielle)", "RSI" to "RSI (indice de force relative)", "MACD" to "MACD (convergence/divergence des moyennes mobiles)", "OBV" to "OBV (volume en équilibre)", "Hist" to "Histogramme", "LONG" to "ACHAT", "SHORT" to "VENTE À DÉCOUVERT", "TP1" to "Objectif 1 (TP1)", "TP2" to "Objectif 2 (TP2)", "TP3" to "Objectif 3 (TP3)"),
    "ar" to mapOf("EMA" to "EMA (المتوسط المتحرك الأسي)", "RSI" to "RSI (مؤشر القوة النسبية)", "MACD" to "MACD (تقارب وتباعد المتوسطات المتحركة)", "OBV" to "OBV (حجم التداول التراكمي)", "Hist" to "المدرج التكراري", "LONG" to "شراء", "SHORT" to "بيع على المكشوف", "TP1" to "هدف الربح الأول (TP1)", "TP2" to "هدف الربح الثاني (TP2)", "TP3" to "هدف الربح الثالث (TP3)"),
    "es" to mapOf("EMA" to "EMA (media móvil exponencial)", "RSI" to "RSI (índice de fuerza relativa)", "MACD" to "MACD (convergencia/divergencia de medias móviles)", "OBV" to "OBV (volumen en balance)", "Hist" to "Histograma", "LONG" to "COMPRA", "SHORT" to "VENTA EN CORTO", "TP1" to "Objetivo 1 (TP1)", "TP2" to "Objetivo 2 (TP2)", "TP3" to "Objetivo 3 (TP3)"),
    "de" to mapOf("EMA" to "EMA (exponentieller gleitender Durchschnitt)", "RSI" to "RSI (Relative-Stärke-Index)", "MACD" to "MACD (Konvergenz/Divergenz gleitender Durchschnitte)", "OBV" to "OBV (On-Balance-Volumen)", "Hist" to "Histogramm", "LONG" to "KAUF", "SHORT" to "LEERVERKAUF", "TP1" to "Kursziel 1 (TP1)", "TP2" to "Kursziel 2 (TP2)", "TP3" to "Kursziel 3 (TP3)"),
    "it" to mapOf("EMA" to "EMA (media mobile esponenziale)", "RSI" to "RSI (indice di forza relativa)", "MACD" to "MACD (convergenza/divergenza delle medie mobili)", "OBV" to "OBV (volume cumulativo)", "Hist" to "Istogramma", "LONG" to "ACQUISTO", "SHORT" to "VENDITA ALLO SCOPERTO", "TP1" to "Obiettivo 1 (TP1)", "TP2" to "Obiettivo 2 (TP2)", "TP3" to "Obiettivo 3 (TP3)"),
    "zh" to mapOf("EMA" to "EMA（指数移动平均线）", "RSI" to "RSI（相对强弱指标）", "MACD" to "MACD（移动平均线收敛发散）", "OBV" to "OBV（能量潮指标）", "Hist" to "柱状图", "LONG" to "做多", "SHORT" to "做空", "TP1" to "第一止盈目标（TP1）", "TP2" to "第二止盈目标（TP2）", "TP3" to "第三止盈目标（TP3）"),
    "ja" to mapOf("EMA" to "EMA（指数移動平均線）", "RSI" to "RSI（相対力指数）", "MACD" to "MACD（移動平均収束拡散）", "OBV" to "OBV（オンバランスボリューム）", "Hist" to "ヒストグラム", "LONG" to "買い", "SHORT" to "空売り", "TP1" to "第1利確目標（TP1）", "TP2" to "第2利確目標（TP2）", "TP3" to "第3利確目標（TP3）"),
    "ko" to mapOf("EMA" to "EMA(지수이동평균)", "RSI" to "RSI(상대강도지수)", "MACD" to "MACD(이동평균 수렴확산)", "OBV" to "OBV(누적 거래량 지표)", "Hist" to "히스토그램", "LONG" to "매수", "SHORT" to "공매도", "TP1" to "1차 익절 목표(TP1)", "TP2" to "2차 익절 목표(TP2)", "TP3" to "3차 익절 목표(TP3)")
)

private val setupTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "Biais haussier ; attendez un repli ou un retest avant d’envisager une position acheteuse ou une entrée au comptant.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "Biais baissier ; vente à découvert uniquement après confirmation ; évitez de poursuivre une baisse.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "Signaux mitigés ; attendez une cassure confirmée ou un rejet du support."
    ),
    "ar" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "الاتجاه يميل للصعود؛ انتظر تراجعًا أو إعادة اختبار قبل التفكير في صفقة شراء أو دخول في السوق الفوري.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "الاتجاه يميل للهبوط؛ لا تدخل صفقة بيع على المكشوف إلا بعد التأكيد، وتجنب مطاردة الهبوط.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "الإشارات متضاربة؛ انتظر اختراقًا مؤكدًا أو رفضًا واضحًا لمستوى الدعم."
    ),
    "es" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "Sesgo alcista; espera un retroceso o retesteo antes de considerar una posición larga o una entrada al contado.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "Sesgo bajista; abre cortos solo tras confirmación y evita perseguir la caída.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "Señales mixtas; espera una ruptura confirmada o un rechazo del soporte."
    ),
    "de" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "Aufwärtstendenz; vor einem Long- oder Spot-Einstieg einen Rücksetzer oder Retest abwarten.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "Abwärtstendenz; Short nur nach Bestätigung und nicht einer fallenden Bewegung hinterherlaufen.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "Gemischte Signale; einen bestätigten Ausbruch oder eine Zurückweisung der Unterstützung abwarten."
    ),
    "it" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "Orientamento rialzista; attendere un ritracciamento o un retest prima di valutare una posizione long o un ingresso spot.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "Orientamento ribassista; aprire short solo dopo conferma ed evitare di inseguire il ribasso.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "Segnali contrastanti; attendere una rottura confermata o un rifiuto del supporto."
    ),
    "zh" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "偏多趋势；考虑做多或现货入场前，先等待回调或回踩确认。",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "偏空趋势；确认后再考虑做空，避免追跌。",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "信号混杂；等待有效突破或支撑位拒绝下跌的确认。"
    ),
    "ja" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "強気傾向です。ロングまたは現物でのエントリーを検討する前に、押し目や再テストを待ってください。",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "弱気傾向です。確認後にのみショートを検討し、下落を追いかけないでください。",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "シグナルは混在しています。ブレイクアウトの確認、またはサポートでの反発拒否を待ってください。"
    ),
    "ko" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "상승 우세입니다. 롱 또는 현물 진입을 고려하기 전에 되돌림이나 재테스트를 기다리세요.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "하락 우세입니다. 확인 후에만 숏을 고려하고 하락을 추격하지 마세요.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "신호가 혼재되어 있습니다. 확인된 돌파 또는 지지선 반응을 기다리세요."
    )
)

private fun translateBacktestSummary(text: String, language: String): String? {
    val match = Regex("EMA 9/21 crossover on (.+?) · (\\d+) candles · (\\d+) closed trades · return (.+?) · win rate (.+?) \\(fees/slippage excluded; not a forecast\\)\\.").matchEntire(text) ?: return null
    val tf = match.groupValues[1]
    val candles = match.groupValues[2]
    val trades = match.groupValues[3]
    val returns = match.groupValues[4]
    val winRate = match.groupValues[5]
    return when (language) {
        "fr" -> "Croisement EMA 9/21 sur $tf · $candles bougies · $trades trades clôturés · rendement $returns · taux de réussite $winRate (frais et glissement exclus ; ce n’est pas une prévision)."
        "ar" -> "تقاطع EMA 9/21 على إطار $tf · عدد الشموع $candles · الصفقات المغلقة $trades · العائد $returns · نسبة النجاح $winRate (لا تشمل الرسوم والانزلاق السعري؛ وليست توقعًا)."
        "es" -> "Cruce EMA 9/21 en $tf · $candles velas · $trades operaciones cerradas · rendimiento $returns · tasa de acierto $winRate (sin comisiones ni deslizamiento; no es una previsión)."
        "de" -> "EMA-9/21-Kreuzung auf $tf · $candles Kerzen · $trades geschlossene Trades · Rendite $returns · Trefferquote $winRate (Gebühren und Slippage nicht enthalten; keine Prognose)."
        "it" -> "Incrocio EMA 9/21 su $tf · $candles candele · $trades operazioni chiuse · rendimento $returns · percentuale di successo $winRate (commissioni e slippage esclusi; non è una previsione)."
        "zh" -> "$tf 周期 EMA 9/21 交叉 · $candles 根K线 · $trades 笔已平仓交易 · 回报 $returns · 胜率 $winRate（未计手续费和滑点；不构成预测）。"
        "ja" -> "$tf の EMA 9/21 クロス · ローソク足 $candles 本 · 決済済み取引 $trades 件 · リターン $returns · 勝率 $winRate（手数料とスリッページを除外。予測ではありません）。"
        "ko" -> "$tf EMA 9/21 교차 · 캔들 ${candles}개 · 종료 거래 ${trades}건 · 수익률 $returns · 승률 $winRate (수수료와 슬리피지 제외, 예측이 아닙니다)."
        else -> text
    }
}

private val featureTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf("Price alerts" to "Alertes de prix", "Favorites" to "Favoris", "Movement signals are monitored for recent searches, favorites, and price-alert pairs on both Bitget and Binance." to "Les signaux sont surveillés pour les recherches récentes, les favoris et les paires en alerte sur Bitget et Binance.", "Market information" to "Informations du marché", "Coin news" to "Actualités de la crypto", "Show section" to "Afficher la section", "Hide section" to "Masquer la section", "Add current pair to favorites" to "Ajouter la paire aux favoris", "Remove from favorites" to "Retirer des favoris", "Add price alert" to "Ajouter une alerte de prix", "Alert condition" to "Condition de l’alerte", "When price is above" to "Lorsque le prix dépasse", "When price is below" to "Lorsque le prix passe sous", "Target price" to "Prix cible", "Save" to "Enregistrer", "Edit" to "Modifier", "Delete" to "Supprimer", "Cancel" to "Annuler", "No price alerts yet" to "Aucune alerte de prix", "No favorites yet" to "Aucun favori", "Notifications require permission" to "Les notifications nécessitent une autorisation", "Alert saved" to "Alerte enregistrée", "Price alert triggered" to "Alerte de prix déclenchée", "Spot" to "Spot", "USDT Futures" to "Contrats à terme USDT", "ABOVE" to "AU-DESSUS", "BELOW" to "EN-DESSOUS", "Edit alert" to "Modifier l’alerte", "Recently analyzed" to "Analyses récentes", "Token unlocks" to "Déverrouillages de tokens", "Unlocks are not verified" to "Les déverrouillages ne sont pas vérifiés", "Open unlock sources" to "Consulter les sources de déverrouillage", "Search Tokenomist" to "Rechercher sur Tokenomist", "Search CryptoRank" to "Rechercher sur CryptoRank", "Search official announcements" to "Rechercher les annonces officielles", "Based on available history" to "Selon l’historique disponible", "Historical data is incomplete" to "Les données historiques sont incomplètes", "Date" to "Date", "Quantity" to "Quantité", "% supply" to "% de l’offre", "Time remaining" to "Temps restant", "Recipient" to "Bénéficiaire", "Source" to "Source", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "Aucun calendrier de déverrouillage vérifié dans cette version. Aucune date ni quantité n’est inventée."),
    "ar" to mapOf("Price alerts" to "تنبيهات الأسعار", "Favorites" to "المفضلة", "Movement signals are monitored for recent searches, favorites, and price-alert pairs on both Bitget and Binance." to "تتم مراقبة إشارات الحركة لعمليات البحث الأخيرة والعملات المفضلة وأزواج التنبيه على منصتي Bitget وBinance.", "Market information" to "معلومات السوق", "Coin news" to "أخبار العملة", "Show section" to "إظهار القسم", "Hide section" to "إخفاء القسم", "Add current pair to favorites" to "إضافة الزوج الحالي إلى المفضلة", "Remove from favorites" to "إزالة من المفضلة", "Add price alert" to "إضافة تنبيه سعري", "Alert condition" to "شرط التنبيه", "When price is above" to "عندما يتجاوز السعر", "When price is below" to "عندما ينخفض السعر عن", "Target price" to "السعر المستهدف", "Save" to "حفظ", "Edit" to "تعديل", "Delete" to "حذف", "Cancel" to "إلغاء", "No price alerts yet" to "لا توجد تنبيهات أسعار بعد", "No favorites yet" to "لا توجد عملات مفضلة بعد", "Notifications require permission" to "تتطلب الإشعارات إذنًا", "Alert saved" to "تم حفظ التنبيه", "Price alert triggered" to "تم تفعيل تنبيه السعر", "Spot" to "فوري", "USDT Futures" to "عقود USDT الآجلة", "ABOVE" to "أعلى من", "BELOW" to "أقل من", "Edit alert" to "تعديل التنبيه", "Recently analyzed" to "العملات التي تم تحليلها مؤخرًا", "Token unlocks" to "فتح قفل التوكنات", "Unlocks are not verified" to "بيانات فتح القفل غير مؤكدة", "Open unlock sources" to "فتح مصادر مواعيد فك القفل", "Search Tokenomist" to "البحث في Tokenomist", "Search CryptoRank" to "البحث في CryptoRank", "Search official announcements" to "البحث عن الإعلانات الرسمية", "Based on available history" to "حسب السجل التاريخي المتاح", "Historical data is incomplete" to "البيانات التاريخية غير مكتملة", "Date" to "التاريخ", "Quantity" to "الكمية", "% supply" to "٪ من المعروض", "Time remaining" to "الوقت المتبقي", "Recipient" to "المستفيد", "Source" to "المصدر", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "لا يتوفر جدول فتح قفل موثوق في هذه النسخة. لن نخمن التواريخ أو الكميات."),
    "es" to mapOf("Price alerts" to "Alertas de precio", "Favorites" to "Favoritos", "Market information" to "Información del mercado", "Coin news" to "Noticias de la criptomoneda", "Show section" to "Mostrar sección", "Hide section" to "Ocultar sección", "Add current pair to favorites" to "Añadir el par actual a favoritos", "Remove from favorites" to "Quitar de favoritos", "Add price alert" to "Añadir alerta de precio", "Alert condition" to "Condición de alerta", "When price is above" to "Cuando el precio supere", "When price is below" to "Cuando el precio baje de", "Target price" to "Precio objetivo", "Save" to "Guardar", "Edit" to "Editar", "Delete" to "Eliminar", "Cancel" to "Cancelar", "No price alerts yet" to "Aún no hay alertas", "No favorites yet" to "Aún no hay favoritos", "Notifications require permission" to "Las notificaciones requieren permiso", "Alert saved" to "Alerta guardada", "Price alert triggered" to "Alerta de precio activada", "Spot" to "Spot", "USDT Futures" to "Futuros USDT", "ABOVE" to "POR ENCIMA", "BELOW" to "POR DEBAJO", "Edit alert" to "Editar alerta"),
    "de" to mapOf("Price alerts" to "Preisalarme", "Favorites" to "Favoriten", "Market information" to "Marktinformationen", "Coin news" to "Krypto-Nachrichten", "Show section" to "Bereich anzeigen", "Hide section" to "Bereich ausblenden", "Add current pair to favorites" to "Aktuelles Handelspaar zu Favoriten hinzufügen", "Remove from favorites" to "Aus Favoriten entfernen", "Add price alert" to "Preisalarm hinzufügen", "Alert condition" to "Alarmbedingung", "When price is above" to "Wenn der Preis über", "When price is below" to "Wenn der Preis unter", "Target price" to "Zielpreis", "Save" to "Speichern", "Edit" to "Bearbeiten", "Delete" to "Löschen", "Cancel" to "Abbrechen", "No price alerts yet" to "Noch keine Preisalarme", "No favorites yet" to "Noch keine Favoriten", "Notifications require permission" to "Benachrichtigungen benötigen eine Berechtigung", "Alert saved" to "Alarm gespeichert", "Price alert triggered" to "Preisalarm ausgelöst", "Spot" to "Spot", "USDT Futures" to "USDT-Futures", "ABOVE" to "ÜBER", "BELOW" to "UNTER", "Edit alert" to "Alarm bearbeiten"),
    "it" to mapOf("Price alerts" to "Avvisi di prezzo", "Favorites" to "Preferiti", "Market information" to "Informazioni di mercato", "Coin news" to "Notizie sulla criptovaluta", "Show section" to "Mostra sezione", "Hide section" to "Nascondi sezione", "Add current pair to favorites" to "Aggiungi la coppia ai preferiti", "Remove from favorites" to "Rimuovi dai preferiti", "Add price alert" to "Aggiungi avviso di prezzo", "Alert condition" to "Condizione avviso", "When price is above" to "Quando il prezzo supera", "When price is below" to "Quando il prezzo scende sotto", "Target price" to "Prezzo obiettivo", "Save" to "Salva", "Edit" to "Modifica", "Delete" to "Elimina", "Cancel" to "Annulla", "No price alerts yet" to "Nessun avviso di prezzo", "No favorites yet" to "Nessun preferito", "Notifications require permission" to "Le notifiche richiedono un’autorizzazione", "Alert saved" to "Avviso salvato", "Price alert triggered" to "Avviso di prezzo attivato", "Spot" to "Spot", "USDT Futures" to "Futures USDT", "ABOVE" to "SOPRA", "BELOW" to "SOTTO", "Edit alert" to "Modifica avviso"),
    "zh" to mapOf("Price alerts" to "价格提醒", "Favorites" to "收藏", "Market information" to "市场信息", "Coin news" to "币种新闻", "Show section" to "展开此部分", "Hide section" to "收起此部分", "Add current pair to favorites" to "收藏当前交易对", "Remove from favorites" to "取消收藏", "Add price alert" to "添加价格提醒", "Alert condition" to "提醒条件", "When price is above" to "价格高于时", "When price is below" to "价格低于时", "Target price" to "目标价格", "Save" to "保存", "Edit" to "编辑", "Delete" to "删除", "Cancel" to "取消", "No price alerts yet" to "暂无价格提醒", "No favorites yet" to "暂无收藏", "Notifications require permission" to "通知需要权限", "Alert saved" to "提醒已保存", "Price alert triggered" to "价格提醒已触发", "Spot" to "现货", "USDT Futures" to "USDT合约", "ABOVE" to "高于", "BELOW" to "低于", "Edit alert" to "编辑提醒"),
    "ja" to mapOf("Price alerts" to "価格アラート", "Favorites" to "お気に入り", "Market information" to "市場情報", "Coin news" to "銘柄ニュース", "Show section" to "セクションを表示", "Hide section" to "セクションを折りたたむ", "Add current pair to favorites" to "現在の取引ペアをお気に入りに追加", "Remove from favorites" to "お気に入りから削除", "Add price alert" to "価格アラートを追加", "Alert condition" to "アラート条件", "When price is above" to "価格が次を上回ったとき", "When price is below" to "価格が次を下回ったとき", "Target price" to "目標価格", "Save" to "保存", "Edit" to "編集", "Delete" to "削除", "Cancel" to "キャンセル", "No price alerts yet" to "価格アラートはありません", "No favorites yet" to "お気に入りはありません", "Notifications require permission" to "通知には許可が必要です", "Alert saved" to "アラートを保存しました", "Price alert triggered" to "価格アラートが発動しました", "Spot" to "現物", "USDT Futures" to "USDT先物", "ABOVE" to "上回る", "BELOW" to "下回る", "Edit alert" to "アラートを編集"),
    "ko" to mapOf("Price alerts" to "가격 알림", "Favorites" to "즐겨찾기", "Market information" to "시장 정보", "Coin news" to "코인 뉴스", "Show section" to "섹션 펼치기", "Hide section" to "섹션 접기", "Add current pair to favorites" to "현재 거래쌍 즐겨찾기에 추가", "Remove from favorites" to "즐겨찾기에서 제거", "Add price alert" to "가격 알림 추가", "Alert condition" to "알림 조건", "When price is above" to "가격이 다음보다 높을 때", "When price is below" to "가격이 다음보다 낮을 때", "Target price" to "목표 가격", "Save" to "저장", "Edit" to "수정", "Delete" to "삭제", "Cancel" to "취소", "No price alerts yet" to "가격 알림이 없습니다", "No favorites yet" to "즐겨찾기가 없습니다", "Notifications require permission" to "알림 권한이 필요합니다", "Alert saved" to "알림이 저장되었습니다", "Price alert triggered" to "가격 알림이 발생했습니다", "Spot" to "현물", "USDT Futures" to "USDT 선물", "ABOVE" to "초과", "BELOW" to "미만", "Edit alert" to "알림 수정")
)

private val commonFeatureTextTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf("Run a market analysis to view price information." to "Lancez une analyse du marché pour afficher les informations de prix.", "Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global." to "Les actualités sont filtrées selon leur date et leur pertinence pour la crypto choisie ou le marché global.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente.", "Futures" to "Contrats à terme"),
    "ar" to mapOf("Run a market analysis to view price information." to "ابدأ تحليل السوق لعرض معلومات السعر.", "Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global." to "تُرشّح الأخبار حسب حداثتها ومدى ارتباطها بالعملة المختارة أو بالسوق عمومًا.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "مصادر RSS عامة · العناوين والملخصات للمعلومات فقط وليست إشارات شراء أو بيع.", "Futures" to "العقود الآجلة"),
    "es" to mapOf("Run a market analysis to view price information." to "Ejecuta un análisis de mercado para ver la información de precios.", "Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global." to "Las noticias se filtran por actualidad y relevancia para la criptomoneda elegida o el mercado global.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "Fuentes RSS públicas · los títulos y resúmenes son informativos, no señales de compra/venta.", "Futures" to "Futuros"),
    "de" to mapOf("Run a market analysis to view price information." to "Führe eine Marktanalyse aus, um Preisinformationen anzuzeigen.", "Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global." to "Nachrichten werden nach Aktualität und Relevanz für den ausgewählten Coin oder den Gesamtmarkt gefiltert.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "Öffentliche RSS-Quellen · Titel und Zusammenfassungen dienen der Information und sind keine Kauf-/Verkaufssignale.", "Futures" to "Futures"),
    "it" to mapOf("Run a market analysis to view price information." to "Avvia un’analisi di mercato per visualizzare le informazioni sui prezzi.", "Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global." to "Le notizie sono filtrate per attualità e rilevanza per la criptovaluta scelta o per il mercato globale.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "Fonti RSS pubbliche · titoli e riepiloghi sono informativi, non segnali di acquisto/vendita.", "Futures" to "Futures"),
    "zh" to mapOf("Run a market analysis to view price information." to "请运行市场分析以查看价格信息。", "Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global." to "新闻根据发布时间和与所选币种或整体市场的相关性进行筛选。", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "公开 RSS 来源 · 标题和摘要仅供参考，不构成买卖信号。", "Futures" to "合约"),
    "ja" to mapOf("Run a market analysis to view price information." to "価格情報を表示するには市場分析を実行してください。", "Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global." to "ニュースは新しさと選択した暗号資産または市場全体との関連性で絞り込まれます。", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "公開RSSソース · 見出しと要約は情報提供のみで、売買シグナルではありません。", "Futures" to "先物"),
    "ko" to mapOf("Run a market analysis to view price information." to "가격 정보를 보려면 시장 분석을 실행하세요.", "Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global." to "뉴스는 최신성과 선택한 코인 또는 전체 시장과의 관련성을 기준으로 필터링됩니다.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "공개 RSS 출처 · 제목과 요약은 정보 제공용이며 매수/매도 신호가 아닙니다.", "Futures" to "선물")
)

private val unlockUiTranslations = mapOf(
    "es" to mapOf("Recently analyzed" to "Analizadas recientemente", "Token unlocks" to "Desbloqueos de tokens", "Unlocks are not verified" to "Los desbloqueos no están verificados", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "Esta versión no tiene acceso autenticado a una base completa de desbloqueos. No inventará fechas ni cantidades. Consulta estas fuentes y verifica el token antes de confiar en un calendario.", "Search Tokenomist" to "Buscar en Tokenomist", "Search CryptoRank" to "Buscar en CryptoRank", "Search official announcements" to "Buscar anuncios oficiales", "Date" to "Fecha", "Quantity" to "Cantidad", "% supply" to "% del suministro", "Time remaining" to "Tiempo restante", "Recipient" to "Destinatario", "Source" to "Fuente", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "No hay un calendario de desbloqueos verificado en esta versión. No se inventan fechas ni cantidades."),
    "de" to mapOf("Recently analyzed" to "Zuletzt analysiert", "Token unlocks" to "Token-Freischaltungen", "Unlocks are not verified" to "Freischaltungen sind nicht verifiziert", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "Diese App-Version hat keinen authentifizierten Zugriff auf eine vollständige Token-Freischaltungsdatenbank. Sie erfindet keine Daten oder Mengen. Bitte Quellen öffnen und den Token prüfen.", "Search Tokenomist" to "Tokenomist durchsuchen", "Search CryptoRank" to "CryptoRank durchsuchen", "Search official announcements" to "Offizielle Ankündigungen suchen", "Date" to "Datum", "Quantity" to "Menge", "% supply" to "% des Angebots", "Time remaining" to "Verbleibende Zeit", "Recipient" to "Empfänger", "Source" to "Quelle", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "In dieser Version ist kein verifizierter Freischaltungsplan verfügbar. Daten und Mengen werden nicht erfunden."),
    "it" to mapOf("Recently analyzed" to "Analizzate di recente", "Token unlocks" to "Sblocco dei token", "Unlocks are not verified" to "Gli sblocchi non sono verificati", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "Questa versione non ha accesso autenticato a un database completo degli sblocchi. Non inventa date o quantità. Apri le fonti e verifica il token prima di fare affidamento sul calendario.", "Search Tokenomist" to "Cerca su Tokenomist", "Search CryptoRank" to "Cerca su CryptoRank", "Search official announcements" to "Cerca annunci ufficiali", "Date" to "Data", "Quantity" to "Quantità", "% supply" to "% dell’offerta", "Time remaining" to "Tempo rimanente", "Recipient" to "Destinatario", "Source" to "Fonte", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "In questa versione non è disponibile un calendario di sblocco verificato. Date e quantità non vengono inventate."),
    "zh" to mapOf("Recently analyzed" to "最近分析", "Token unlocks" to "代币解锁", "Unlocks are not verified" to "解锁信息尚未验证", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "此版本无法通过认证访问完整的代币解锁数据集，因此不会编造日期或数量。请打开来源并核实代币后再参考解锁计划。", "Search Tokenomist" to "搜索 Tokenomist", "Search CryptoRank" to "搜索 CryptoRank", "Search official announcements" to "搜索官方公告", "Date" to "日期", "Quantity" to "数量", "% supply" to "占供应量", "Time remaining" to "剩余时间", "Recipient" to "接收方", "Source" to "来源", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "此版本没有经过验证的解锁计划，不会猜测日期或数量。"),
    "ja" to mapOf("Recently analyzed" to "最近分析した銘柄", "Token unlocks" to "トークンのロック解除", "Unlocks are not verified" to "解除情報は未検証です", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "このバージョンは包括的なロック解除データベースへの認証アクセスがないため、日付や数量を捏造しません。情報源を開き、対象トークンを確認してください。", "Search Tokenomist" to "Tokenomistを検索", "Search CryptoRank" to "CryptoRankを検索", "Search official announcements" to "公式発表を検索", "Date" to "日付", "Quantity" to "数量", "% supply" to "供給量比", "Time remaining" to "残り時間", "Recipient" to "受取先", "Source" to "情報源", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "このバージョンには検証済みの解除予定がありません。日付や数量は推測しません。"),
    "ko" to mapOf("Recently analyzed" to "최근 분석한 코인", "Token unlocks" to "토큰 언락", "Unlocks are not verified" to "언락 정보가 검증되지 않았습니다", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "이 앱 버전은 종합 토큰 언락 데이터에 인증된 접근 권한이 없어 날짜나 수량을 만들어내지 않습니다. 출처를 열어 토큰을 확인하세요.", "Search Tokenomist" to "Tokenomist 검색", "Search CryptoRank" to "CryptoRank 검색", "Search official announcements" to "공식 공지 검색", "Date" to "날짜", "Quantity" to "수량", "% supply" to "공급량 비율", "Time remaining" to "남은 시간", "Recipient" to "수령자", "Source" to "출처", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "이 버전에는 검증된 언락 일정이 없습니다. 날짜나 수량을 추측하지 않습니다.")
)

private val alertStateTranslations: Map<String, Map<String, String>> = mapOf(
    "en" to mapOf("Deactivated" to "Deactivated", "Activate" to "Activate", "Active" to "Active"),
    "fr" to mapOf("Deactivated" to "A été désactivée", "Activate" to "Activer", "Active" to "Active"),
    "ar" to mapOf("Deactivated" to "تم تعطيله", "Activate" to "إعادة التنشيط", "Active" to "نشط"),
    "es" to mapOf("Deactivated" to "Desactivada", "Activate" to "Activar", "Active" to "Activa"),
    "de" to mapOf("Deactivated" to "Deaktiviert", "Activate" to "Aktivieren", "Active" to "Aktiv"),
    "it" to mapOf("Deactivated" to "Disattivata", "Activate" to "Riattiva", "Active" to "Attiva"),
    "zh" to mapOf("Deactivated" to "已停用", "Activate" to "重新启用", "Active" to "已启用"),
    "ja" to mapOf("Deactivated" to "無効化済み", "Activate" to "再度有効にする", "Active" to "有効"),
    "ko" to mapOf("Deactivated" to "비활성화됨", "Activate" to "다시 활성화", "Active" to "활성"),
)

private fun tr(text: String, language: String): String {
    alertStateTranslations[language]?.get(text)?.let { return it }
    unlockUiTranslations[language]?.get(text)?.let { return it }
    commonFeatureTextTranslations[language]?.get(text)?.let { return it }
    featureTranslations[language]?.get(text)?.let { return it }
    translateBacktestSummary(text, language)?.let { return it }

    setupTranslations[language]?.get(text)?.let { return it }
    tradingSectionTranslations[language]?.get(text)?.let { return it }
    uiTranslations[language]?.get(text)?.let { return it }
    tradingTermTranslations[language]?.get(text)?.let { return it }
    // Translate common trading terms even when embedded in dynamic UI text.
    var result = text
    val terms = (tradingTermTranslations[language].orEmpty() + indicatorTermTranslations[language].orEmpty()).entries.sortedByDescending { it.key.length }
    for ((source, target) in terms) {
        result = result.replace(Regex("(?i)${Regex.escape(source)}")) { match ->
            val original = match.value
            when {
                original == original.uppercase(Locale.ROOT) -> target.uppercase(Locale.ROOT)
                original.firstOrNull()?.isUpperCase() == true -> target.replaceFirstChar { it.uppercase(Locale.ROOT) }
                else -> target
            }
        }
    }
    if (language != "fr" && language != "en") {
        if (result == "ACTUALITÉ") result = when (language) {
            "ar" -> "الأخبار"; "es" -> "NOTICIAS"; "de" -> "NACHRICHTEN"; "it" -> "NOTIZIE"; "zh" -> "新闻"; "ja" -> "ニュース"; "ko" -> "뉴스"; else -> result
        }
        if (result == "Publié il y a moins de 7 jours. Cette information peut influencer le marché, mais son impact sur le prix reste incertain.") result = when (language) {
            "ar" -> "نُشر خلال آخر 7 أيام. قد تؤثر هذه المعلومة في السوق، لكن أثرها على السعر غير مؤكد.";
            "es" -> "Publicado en los últimos 7 días. Esta información puede influir en el mercado, pero su impacto en el precio es incierto.";
            "de" -> "Vor weniger als 7 Tagen veröffentlicht. Diese Information kann den Markt beeinflussen, ihre Preiswirkung ist jedoch ungewiss.";
            "it" -> "Pubblicato negli ultimi 7 giorni. Questa informazione può influenzare il mercato, ma l’impatto sul prezzo è incerto.";
            "zh" -> "发布于最近7天内。这条信息可能影响市场，但对价格的影响尚不确定。";
            "ja" -> "過去7日以内に公開。この情報は市場に影響する可能性がありますが、価格への影響は不確かです。";
            "ko" -> "최근 7일 이내에 게시되었습니다. 시장에 영향을 줄 수 있지만 가격에 미치는 영향은 불확실합니다."; else -> result
        }
        val frenchNews = "Marché crypto · "
        if (result.startsWith(frenchNews)) {
            val coinAndPeriod = result.removePrefix(frenchNews)
            val period = when (language) {
                "ar" -> "سوق العملات الرقمية · "
                "es" -> "Mercado cripto · "
                "de" -> "Kryptomarkt · "
                "it" -> "Mercato crypto · "
                "zh" -> "加密市场 · "
                "ja" -> "暗号資産市場 · "
                "ko" -> "암호화폐 시장 · "
                else -> frenchNews
            }
            result = period + coinAndPeriod.replace("7 derniers jours", when (language) {
                "ar" -> "آخر 7 أيام"; "es" -> "últimos 7 días"; "de" -> "letzte 7 Tage"; "it" -> "ultimi 7 giorni"; "zh" -> "最近7天"; "ja" -> "過去7日間"; "ko" -> "최근 7일"; else -> "7 derniers jours"
            })
        }
        if (result == "Lancez l’analyse pour charger les actualités récentes.") result = when (language) {
            "ar" -> "ابدأ التحليل لتحميل آخر الأخبار."; "es" -> "Inicia el análisis para cargar las noticias recientes."; "de" -> "Starte die Analyse, um aktuelle Nachrichten zu laden."; "it" -> "Avvia l’analisi per caricare le notizie recenti."; "zh" -> "请先运行分析以加载最新资讯。"; "ja" -> "最新ニュースを読み込むには分析を開始してください。"; "ko" -> "최신 뉴스를 불러오려면 분석을 시작하세요."; else -> result
        }
    }
    return result
}
private fun localeForAppLanguage(language: String): Locale = when (language) {
    "zh" -> Locale.SIMPLIFIED_CHINESE
    "ja" -> Locale.JAPANESE
    "ar" -> Locale("ar")
    else -> Locale(language)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Block screenshots, screen recording, and the app preview in Recents.
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            val darkScheme = darkColorScheme(
                primary = Color(0xFF5EEAD4),
                onPrimary = Color(0xFF062A2A),
                secondary = Color(0xFFA78BFA),
                tertiary = Color(0xFF60A5FA),
                background = Color(0xFF080D1B),
                surface = Color(0xFF111A2E),
                surfaceVariant = Color(0xFF1B2942),
                onBackground = Color(0xFFEAF2FF),
                onSurface = Color(0xFFEAF2FF),
                onSurfaceVariant = Color(0xFFB7C5DA),
                error = Color(0xFFFF718B)
            )
            MaterialTheme(colorScheme = darkScheme) { ActivationGate { authorizeAnalysis -> AnalyzerApp(authorizeAnalysis) } }
        }
    }
}

data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)
data class IndicatorRow(val timeframe: String, val price: Double, val emas: Map<Int, Double>, val obv: Double, val macd: Double, val signal: Double, val hist: Double, val upProbability: Int, val downProbability: Int, val support: Double, val resistance: Double, val setup: String)

data class TradePlan(
    val title: String,
    val description: String,
    val entry: Double,
    val stopLoss: Double,
    val tp1: Double,
    val tp2: Double,
    val tp3: Double
)

/** Builds three long/Spot planning scenarios from latest price and 4H support/resistance. */
private fun buildTradePlans(currentPrice: Double, row: IndicatorRow): List<TradePlan> {
    val support = row.support
    val resistance = row.resistance
    if (!currentPrice.isFinite() || currentPrice <= 0.0 ||
        !support.isFinite() || !resistance.isFinite() || support <= 0.0 || resistance <= support
    ) return emptyList()

    val aggressiveEntry = if (currentPrice > support) support + (currentPrice - support) * 0.20 else currentPrice
    val confirmedEntry = max(currentPrice, resistance * 1.002)
    val conservativeEntry = max(currentPrice, resistance * 1.008)

    fun plan(title: String, description: String, entry: Double, proposedStop: Double): TradePlan {
        val stop = proposedStop.coerceIn(entry * 0.50, entry * 0.999)
        val risk = (entry - stop).coerceAtLeast(entry * 0.001)
        return TradePlan(title, description, entry, stop, entry + risk, entry + risk * 2.0, entry + risk * 3.0)
    }

    return listOf(
        plan("1. Aggressive entry", "Near support; higher risk. Prefer a visible support reaction.", aggressiveEntry, min(support * 0.995, aggressiveEntry * 0.985)),
        plan("2. Breakout-confirmation entry", "Trigger only after a candle closes above resistance; a retest is preferable.", confirmedEntry, min(resistance * 0.99, confirmedEntry * 0.985)),
        plan("3. More conservative entry", "Wait for a stronger move above resistance and confirm volume; entry may be higher.", conservativeEntry, min(resistance * 0.99, conservativeEntry * 0.985))
    )
}

private val client = OkHttpClient.Builder().connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS).readTimeout(10, java.util.concurrent.TimeUnit.SECONDS).build()

data class MarketNews(
    val title: String,
    val summary: String,
    val publishedAt: Long,
    val source: String,
    val url: String
)

private data class NewsFeed(val url: String, val source: String)
private val newsFeeds = listOf(
    NewsFeed("https://www.coindesk.com/arc/outboundfeeds/rss/", "CoinDesk"),
    NewsFeed("https://cointelegraph.com/rss", "Cointelegraph")
)

private fun parseNewsDate(value: String): Long? {
    val raw = value.trim()
    if (raw.isBlank()) return null
    try { return Instant.parse(raw).toEpochMilli() } catch (_: Exception) {}
    try { return OffsetDateTime.parse(raw).toInstant().toEpochMilli() } catch (_: Exception) {}
    try { return ZonedDateTime.parse(raw).toInstant().toEpochMilli() } catch (_: Exception) {}
    val patterns = listOf("EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm Z", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd'T'HH:mm:ss.SSSX")
    for (pattern in patterns) {
        try {
            val format = SimpleDateFormat(pattern, Locale.US).apply { isLenient = true; timeZone = TimeZone.getTimeZone("UTC") }
            return format.parse(raw)?.time
        } catch (_: Exception) {}
    }
    return null
}

private fun cleanNewsText(raw: String): String = Html.fromHtml(raw, Html.FROM_HTML_MODE_LEGACY).toString()
    .replace(Regex("\\s+"), " ").trim()

private fun parseRssFeed(xml: String, source: String): List<MarketNews> {
    val parser = Xml.newPullParser()
    parser.setInput(StringReader(xml))
    val output = mutableListOf<MarketNews>()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        if (event == XmlPullParser.START_TAG && parser.name.substringAfter(':') in setOf("item", "entry")) {
            var title = ""; var summary = ""; var date = ""; var link = ""
            val itemTag = parser.name
            var depth = 1
            while (depth > 0) {
                event = parser.next()
                when (event) {
                    XmlPullParser.START_TAG -> {
                        depth++
                        val tag = parser.name.substringAfter(':').lowercase(Locale.ROOT)
                        if (tag == "link") {
                            val href = parser.getAttributeValue(null, "href")
                            if (!href.isNullOrBlank()) link = href
                            else { val t = try { parser.nextText() } catch (_: Exception) { "" }; if (t.isNotBlank()) link = t; depth-- }
                        } else if (tag in setOf("title", "description", "summary", "encoded", "pubdate", "published", "updated", "date")) {
                            val value = try { parser.nextText() } catch (_: Exception) { "" }
                            when (tag) {
                                "title" -> if (title.isBlank()) title = value
                                "description", "summary", "encoded" -> if (summary.isBlank() || tag == "encoded") summary = value
                                "pubdate", "published", "updated", "date" -> if (date.isBlank()) date = value
                            }
                            depth--
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        depth--
                        if (depth == 0 && parser.name == itemTag) break
                    }
                }
            }
            val timestamp = parseNewsDate(date)
            val cleanedTitle = cleanNewsText(title)
            val cleanedSummary = cleanNewsText(summary)
            if (timestamp != null && cleanedTitle.isNotBlank()) output.add(MarketNews(cleanedTitle, cleanedSummary, timestamp, source, link))
        }
        event = parser.next()
    }
    return output
}

private fun loadRecentNews(symbol: String): List<MarketNews> {
    val now = System.currentTimeMillis()
    val sevenDays = 7L * 24L * 60L * 60L * 1000L
    val token = symbol.uppercase(Locale.ROOT).removeSuffix("USDT")
    val tokenAliases = when (token) {
        "BTC" -> listOf("bitcoin", "btc")
        "ETH" -> listOf("ethereum", "ether", "eth")
        "SOL" -> listOf("solana", "sol")
        "XRP" -> listOf("xrp", "ripple")
        "BNB" -> listOf("bnb", "binance coin")
        "DOGE" -> listOf("dogecoin", "doge")
        else -> listOf(token.lowercase(Locale.ROOT))
    }.filter { it.length >= 2 }
    val marketKeywords = listOf("crypto", "cryptocurrency", "bitcoin", "ethereum", "market", "etf", "federal reserve", "fed ", "interest rate", "inflation", "sec ", "regulation", "exchange", "stablecoin", "liquidation", "hack", "exploit", "tariff", "trading volume")
    val all = mutableListOf<MarketNews>()
    for (feed in newsFeeds) {
        try {
            val request = Request.Builder().url(feed.url).header("User-Agent", "CryptoAnalyserByErrZhr/1.0").get().build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val xml = response.body?.string().orEmpty()
                    all.addAll(parseRssFeed(xml, feed.source))
                }
            }
        } catch (_: Exception) { /* The other feed may still be available. */ }
    }
    val fresh = all.distinctBy { it.url.ifBlank { it.title } }
        .filter { it.publishedAt in (now - sevenDays)..(now + 10L * 60L * 1000L) }
    val coinSpecific = fresh.filter { item ->
        val text = (item.title + " " + item.summary).lowercase(Locale.ROOT)
        tokenAliases.any { alias -> if (alias.length <= 3) Regex("(^|[^a-z0-9])" + Regex.escape(alias) + "([^a-z0-9]|$)").containsMatchIn(text) else text.contains(alias) }
    }
    val broadMarket = fresh.filter { item ->
        val text = (item.title + " " + item.summary).lowercase(Locale.ROOT)
        marketKeywords.any { text.contains(it) }
    }
    return (coinSpecific.sortedByDescending { it.publishedAt } + broadMarket.sortedByDescending { it.publishedAt })
        .distinctBy { it.url.ifBlank { it.title } }.take(4)
}

/** Accepts base symbols (BTC), concatenated pairs (BTCUSDT), and separated pairs (BTC/USDT or BTC-USDT). */
private fun normalizeUsdtSymbol(input: String): String {
    val cleaned = input.trim().uppercase()
        .replace("/", "")
        .replace("-", "")
        .replace("_", "")
        .replace(" ", "")
    if (cleaned.isBlank()) throw IllegalArgumentException("Enter a coin symbol, e.g. BTC, BTCUSDT or AIAV/USDT.")
    val pair = if (cleaned.endsWith("USDT")) cleaned else "${cleaned}USDT"
    if (!pair.matches(Regex("[A-Z0-9]{2,20}USDT"))) {
        throw IllegalArgumentException("Invalid symbol. Enter a coin like BTC, BTCUSDT or AIAV/USDT.")
    }
    return pair
}

private fun loadListedUsdtSymbols(market: String, platform: String): List<String> {
    if (platform == "Binance") {
        val url = if (market == "Spot") "https://api.binance.com/api/v3/exchangeInfo" else "https://fapi.binance.com/fapi/v1/exchangeInfo"
        val root = getJson(url)
        val data = root.optJSONArray("symbols") ?: JSONArray()
        return (0 until data.length()).mapNotNull { i ->
            val item = data.optJSONObject(i) ?: return@mapNotNull null
            val pair = item.optString("symbol").uppercase()
            val quote = item.optString(if (market == "Spot") "quoteAsset" else "quoteAsset").uppercase()
            val status = item.optString("status")
            if (pair.endsWith("USDT") && quote == "USDT" && status == "TRADING" && (market == "Spot" || item.optString("contractType") == "PERPETUAL")) pair else null
        }.sorted()
    }
    val url = if (market == "Spot") {
        "https://api.bitget.com/api/v2/spot/public/symbols"
    } else {
        "https://api.bitget.com/api/v2/mix/market/contracts?productType=USDT-FUTURES"
    }
    val root = getJson(url)
    val data = root.optJSONArray("data") ?: JSONArray()
    val symbols = linkedSetOf<String>()
    for (i in 0 until data.length()) {
        val item = data.optJSONObject(i) ?: continue
        val pair = item.optString("symbol").uppercase()
        val quote = item.optString("quoteCoin", "USDT").uppercase()
        val status = item.optString("status", item.optString("symbolStatus", "online")).lowercase()
        if (pair.endsWith("USDT") && quote == "USDT" && status !in setOf("offline", "gray", "delisted", "halt")) {
            symbols.add(pair)
        }
    }
    return symbols.sorted()
}

private fun marketTickerUrl(symbol: String, market: String, platform: String): String = when (platform) {
    "Binance" -> if (market == "Spot") "https://api.binance.com/api/v3/ticker/24hr?symbol=$symbol" else "https://fapi.binance.com/fapi/v1/ticker/24hr?symbol=$symbol"
    else -> if (market == "Spot") "https://api.bitget.com/api/v2/spot/market/tickers?symbol=$symbol" else "https://api.bitget.com/api/v2/mix/market/ticker?productType=USDT-FUTURES&symbol=$symbol"
}

private fun marketCandlesUrl(symbol: String, market: String, platform: String, granularity: String, limit: Int): String {
    if (platform == "Binance") {
        val interval = when (granularity.lowercase()) {
            "15min", "15m" -> "15m"
            "1h" -> "1h"
            "4h" -> "4h"
            "1day", "1d" -> "1d"
            "1m" -> "1M"
            else -> granularity
        }
        val base = if (market == "Spot") "https://api.binance.com/api/v3/klines" else "https://fapi.binance.com/fapi/v1/klines"
        return "$base?symbol=$symbol&interval=$interval&limit=$limit"
    }
    return if (market == "Spot") {
        "https://api.bitget.com/api/v2/spot/market/candles?symbol=$symbol&granularity=${spotV2Granularity(granularity)}&limit=$limit"
    } else {
        "https://api.bitget.com/api/v2/mix/market/candles?symbol=$symbol&granularity=$granularity&productType=USDT-FUTURES&limit=$limit"
    }
}

private fun parseBinanceCandles(url: String): List<Candle> {
    val request = Request.Builder().url(url).get().build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw Exception("Binance HTTP ${response.code}")
        val data = JSONArray(response.body?.string() ?: "[]")
        val result = mutableListOf<Candle>()
        for (i in 0 until data.length()) {
            val a = data.optJSONArray(i) ?: continue
            if (a.length() < 6) continue
            result.add(Candle(a.optLong(0), a.optString(1).toDoubleOrNull() ?: 0.0, a.optString(2).toDoubleOrNull() ?: 0.0, a.optString(3).toDoubleOrNull() ?: 0.0, a.optString(4).toDoubleOrNull() ?: 0.0, a.optString(5).toDoubleOrNull() ?: 0.0))
        }
        return result.filter { it.close > 0.0 }.sortedBy { it.time }
    }
}

private fun loadMarketCandles(symbol: String, market: String, platform: String, granularity: String, limit: Int): List<Candle> {
    val url = marketCandlesUrl(symbol, market, platform, granularity, limit)
    return if (platform == "Binance") parseBinanceCandles(url) else parseCandles(getJson(url))
}

private fun getJson(url: String): JSONObject {
    val request = Request.Builder().url(url).get().build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw Exception("Bitget HTTP ${response.code}")
        val root = JSONObject(response.body?.string() ?: "{}")
        val apiCode = root.optString("code", "00000")
        if (apiCode.isNotBlank() && apiCode != "00000") {
            throw Exception("Bitget API error $apiCode: ${root.optString("msg", "unknown error")}")
        }
        return root
    }
}
private fun parseCandles(root: JSONObject): List<Candle> {
    val data = root.optJSONArray("data") ?: JSONArray()
    val result = mutableListOf<Candle>()
    for (i in 0 until data.length()) {
        val a = data.optJSONArray(i) ?: continue
        if (a.length() < 6) continue
        result.add(Candle(a.optString(0).toLongOrNull() ?: 0L, a.optString(1).toDoubleOrNull() ?: 0.0, a.optString(2).toDoubleOrNull() ?: 0.0, a.optString(3).toDoubleOrNull() ?: 0.0, a.optString(4).toDoubleOrNull() ?: 0.0, a.optString(5).toDoubleOrNull() ?: 0.0))
    }
    return result.filter { it.close > 0.0 }.sortedBy { it.time }
}

private data class PriceExtremes(
    val allTimeHigh: Double,
    val allTimeLow: Double,
    val high24h: Double,
    val low24h: Double,
    val historyComplete: Boolean,
    val last24hComplete: Boolean
)

private fun spotV2Granularity(granularity: String): String = when (granularity.uppercase()) {
    // Bitget v2 Spot REST uses lowercase hour values and "1day" (not 1H/4H/1D).
    "1H" -> "1h"
    "4H" -> "4h"
    "1D" -> "1day"
    else -> granularity
}

private fun historyCandlesUrl(symbol: String, isSpot: Boolean, granularity: String, endTime: Long): String {
    return if (isSpot) {
        val spotGranularity = spotV2Granularity(granularity)
        "https://api.bitget.com/api/v2/spot/market/history-candles?symbol=$symbol&granularity=$spotGranularity&endTime=$endTime&limit=200"
    } else {
        "https://api.bitget.com/api/v2/mix/market/history-candles?productType=USDT-FUTURES&symbol=$symbol&granularity=$granularity&endTime=$endTime&limit=200"
    }
}

/**
 * Uses Bitget's public ticker statistics for the rolling 24-hour high/low.
 * Bitget's ticker endpoints do not expose a reliable all-time-high/all-time-low field,
 * so ATH/ATL are deliberately left unavailable rather than inferred from a partial candle scan.
 */
private fun loadPriceExtremesFromTicker(ticker: JSONObject): PriceExtremes {
    fun number(vararg keys: String): Double {
        for (key in keys) {
            val value = ticker.optString(key, "").toDoubleOrNull()
            if (value != null && value.isFinite() && value > 0.0) return value
        }
        return 0.0
    }
    return PriceExtremes(
        allTimeHigh = 0.0,
        allTimeLow = 0.0,
        high24h = number("high24h", "high24H", "high24Hour"),
        low24h = number("low24h", "low24H", "low24Hour"),
        historyComplete = false,
        last24hComplete = true
    )
}

/** Scans daily historical candles backwards for the selected Bitget market/instrument.
 * A bounded scan prevents endless loops; completeness is only true when the API indicates
 * that no older candles remain. Never substitutes a partial scan for a true all-time value. */
private fun loadAllTimeExtremes(symbol: String, isSpot: Boolean, ticker: JSONObject): PriceExtremes {
    val tickerValues = loadPriceExtremesFromTicker(ticker)
    var endTime = System.currentTimeMillis()
    var oldestSeen = Long.MAX_VALUE
    var highest = 0.0
    var lowest = Double.POSITIVE_INFINITY
    var pages = 0
    var complete = false
    while (pages < 120) {
        val url = historyCandlesUrl(symbol, isSpot, if (isSpot) "1D" else "1D", endTime)
        val batch = parseCandles(getJson(url))
        if (batch.isEmpty()) { complete = true; break }
        val oldest = batch.minOf { it.time }
        if (oldest >= oldestSeen) break
        oldestSeen = oldest
        batch.forEach { c ->
            if (c.high > 0.0 && c.high.isFinite()) highest = max(highest, c.high)
            if (c.low > 0.0 && c.low.isFinite()) lowest = min(lowest, c.low)
        }
        pages++
        if (batch.size < 200) { complete = true; break }
        endTime = oldest - 1L
    }
    val valid = highest > 0.0 && lowest.isFinite() && lowest > 0.0
    return tickerValues.copy(
        allTimeHigh = if (valid) highest else 0.0,
        allTimeLow = if (valid) lowest else 0.0,
        historyComplete = complete && valid
    )
}

private fun ema(values: List<Double>, period: Int): Double {
    if (values.isEmpty()) return 0.0
    val alpha = 2.0 / (period + 1.0)
    var result = values.take(min(period, values.size)).average()
    for (v in values.drop(min(period, values.size))) result = alpha * v + (1 - alpha) * result
    return result
}
private fun analyze(candles: List<Candle>, tf: String): IndicatorRow {
    val closes = candles.map { it.close }
    val price = closes.last()
    val emas = listOf(9,14,21,50,100,200).associateWith { ema(closes, it) }
    var obv = 0.0
    for (i in 1 until candles.size) obv += when { candles[i].close > candles[i-1].close -> candles[i].volume; candles[i].close < candles[i-1].close -> -candles[i].volume; else -> 0.0 }
    val macdSeries = mutableListOf<Double>()
    for (i in closes.indices) macdSeries.add(ema(closes.take(i + 1), 12) - ema(closes.take(i + 1), 26))
    val macd = macdSeries.lastOrNull() ?: 0.0
    val signal = ema(macdSeries, 9)
    val hist = macd - signal
    val votes = (if (price > emas.getValue(9)) 1 else -1) + (if (price > emas.getValue(21)) 1 else -1) + (if (price > emas.getValue(50)) 1 else -1) + (if (emas.getValue(9) > emas.getValue(21)) 1 else -1) + (if (hist > 0) 1 else -1) + (if (obv > 0) 1 else -1)
    val up = (50 + votes * 7).coerceIn(8, 92)
    val lows = candles.takeLast(30).map { it.low }
    val highs = candles.takeLast(30).map { it.high }
    val support = lows.minOrNull() ?: price
    val resistance = highs.maxOrNull() ?: price
    val setup = when {
        price > emas.getValue(50) && hist > 0 -> "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry."
        price < emas.getValue(50) && hist < 0 -> "Bearish bias; SHORT only after confirmation; avoid chasing a drop."
        else -> "Mixed signals; wait for a confirmed breakout or support rejection."
    }
    return IndicatorRow(tf, price, emas, obv, macd, signal, hist, up, 100-up, support, resistance, setup)
}

@Composable
private fun CandleChart(candles: List<Candle>, high24h: Double, low24h: Double, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.background(Color(0xFF0B1220), RoundedCornerShape(12.dp)).padding(8.dp)) {
        if (candles.isEmpty()) return@Canvas
        val visible = candles.takeLast(60)
        val candleMin = visible.minOf { it.low }
        val candleMax = visible.maxOf { it.high }
        val minPrice = if (low24h > 0.0) minOf(candleMin, low24h) else candleMin
        val maxPrice = if (high24h > 0.0) maxOf(candleMax, high24h) else candleMax
        val range = (maxPrice - minPrice).takeIf { it > 0.0 } ?: (maxPrice * 0.01).coerceAtLeast(0.00000001)
        val candleWidth = (size.width / visible.size * 0.62f).coerceAtLeast(2f)
        val step = size.width / visible.size
        visible.forEachIndexed { index, candle ->
            val x = step * index + step / 2f
            fun y(value: Double) = size.height - (((value - minPrice) / range).toFloat() * size.height)
            val rising = candle.close >= candle.open
            val color = if (rising) Color(0xFF22C55E) else Color(0xFFEF4444)
            drawLine(color, Offset(x, y(candle.high)), Offset(x, y(candle.low)), strokeWidth = 1.5f)
            val top = minOf(y(candle.open), y(candle.close))
            val bottom = maxOf(y(candle.open), y(candle.close))
            drawRect(color, topLeft = Offset(x - candleWidth / 2f, top), size = androidx.compose.ui.geometry.Size(candleWidth, (bottom - top).coerceAtLeast(1.5f)))
        }
        fun yLevel(value: Double) = size.height - (((value - minPrice) / range).toFloat() * size.height)
        fun dashedLevel(value: Double, color: Color) {
            if (value <= 0.0 || !value.isFinite()) return
            val y = yLevel(value)
            var x = 0f
            while (x < size.width) {
                drawLine(color, Offset(x, y), Offset((x + 7f).coerceAtMost(size.width), y), strokeWidth = 2f)
                x += 12f
            }
        }
        // Rolling 24-hour levels stay the same when the chart timeframe changes.
        dashedLevel(high24h, Color(0xFF5EEAD4))
        dashedLevel(low24h, Color(0xFFFF9EB5))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzerApp(onBeforeAnalysis: suspend () -> Boolean) {
    val context = LocalContext.current
    val preferences = remember(context) { context.getSharedPreferences("cryptoanalyser_preferences", android.content.Context.MODE_PRIVATE) }
    var symbol by remember { mutableStateOf("BTCUSDT") }
    var listedSymbols by remember { mutableStateOf<List<String>>(emptyList()) }
    var showSuggestions by remember { mutableStateOf(false) }
    var market by remember { mutableStateOf("Spot") }
    var platform by remember { mutableStateOf(preferences.getString("market_platform", "Bitget") ?: "Bitget") }
    var showPlatformMenu by remember { mutableStateOf(false) }
    var showInlineLanguageMenu by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var price by remember { mutableStateOf<Double?>(null) }
    var extremes by remember { mutableStateOf<PriceExtremes?>(null) }
    var chartCandles by remember { mutableStateOf<List<Candle>>(emptyList()) }
    var chartTimeframe by remember { mutableStateOf("15m") }
    var chartLoading by remember { mutableStateOf(false) }
    var rows by remember { mutableStateOf<List<IndicatorRow>>(emptyList()) }
    var backtest by remember { mutableStateOf("") }
    var news by remember { mutableStateOf<List<MarketNews>>(emptyList()) }
    var newsLoading by remember { mutableStateOf(false) }
    var newsError by remember { mutableStateOf("") }
    var selectedNews by remember { mutableStateOf<MarketNews?>(null) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var marketInfoExpanded by remember { mutableStateOf(false) }
    var newsExpanded by remember { mutableStateOf(false) }
    var researchExpanded by remember { mutableStateOf(true) }
    var researchTopic by remember { mutableStateOf("") }
    var researchWebUrl by remember { mutableStateOf("") }
    var researchWebTitle by remember { mutableStateOf("") }
    var alertsExpanded by remember { mutableStateOf(false) }
    var recentSymbols by remember { mutableStateOf<List<String>>(emptyList()) }
    var favoriteSymbols by remember { mutableStateOf<List<String>>(emptyList()) }
    var unlocksExpanded by remember { mutableStateOf(false) }
    var priceAlerts by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var editingAlertId by remember { mutableStateOf<Long?>(null) }
    var alertSymbol by remember { mutableStateOf("BTCUSDT") }
    var alertTarget by remember { mutableStateOf("") }
    var alertDirection by remember { mutableStateOf("ABOVE") }
    var alertMarket by remember { mutableStateOf("Spot") }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        recentSymbols = try { val a = JSONArray(preferences.getString("recent_symbols", "[]")); (0 until minOf(a.length(), 50)).mapNotNull { a.optString(it).takeIf(String::isNotBlank) } } catch (_: Exception) { emptyList() }
        favoriteSymbols = try { val a = JSONArray(preferences.getString("favorite_symbols", "[]")); (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) } } catch (_: Exception) { emptyList() }
        priceAlerts = try { val a = JSONArray(preferences.getString("price_alerts", "[]")); (0 until a.length()).mapNotNull { a.optJSONObject(it) } } catch (_: Exception) { emptyList() }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val request = PeriodicWorkRequestBuilder<PriceAlertWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("crypto_price_alert_monitor", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
    var voiceGender by remember { mutableStateOf(preferences.getString("summary_voice_gender", "female") ?: "female") }
    var appLanguage by remember { mutableStateOf(preferences.getString("app_language", "en") ?: "en") }
    var showLanguageMenu by remember { mutableStateOf(false) }
    var speechWordOffset by remember { mutableIntStateOf(0) }
    var speechEngine by remember { mutableStateOf<TextToSpeech?>(null) }
    var speechReady by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    DisposableEffect(context) {
        val engine = TextToSpeech(context) { status ->
            speechReady = status == TextToSpeech.SUCCESS
        }
        speechEngine = engine
        onDispose {
            engine.stop()
            engine.shutdown()
            speechEngine = null
            speechReady = false
        }
    }
    LaunchedEffect(speechReady, voiceGender, appLanguage) {
        val engine = speechEngine
        if (speechReady && engine != null) {
            val locale = localeForAppLanguage(appLanguage)
            engine.language = locale
            // Match gender as a complete voice-name token. A substring search for "male"
            // also matches "female", which caused the Man option to select a woman's voice.
            val genderWords = if (voiceGender == "male") {
                setOf("male", "man", "masculine", "homme", "masculin")
            } else {
                setOf("female", "woman", "feminine", "femme", "féminin")
            }
            val available = try { engine.voices?.toList().orEmpty() } catch (_: Exception) { emptyList() }
            fun genderTokens(name: String): Set<String> = name.lowercase(Locale.ROOT)
                .split(Regex("[^\\p{L}]+"))
                .filter { it.isNotBlank() }
                .toSet()
            val matching = available
                .filter { it.locale.language == locale.language }
                .firstOrNull { voice -> genderTokens(voice.name).any { it in genderWords } }
                ?: available.firstOrNull { it.locale.language == locale.language && !it.name.contains("network", ignoreCase = true) }
            if (matching != null) {
                try { engine.voice = matching } catch (_: Exception) { /* Use the engine's default voice. */ }
            }
        }
    }
    val spokenSummary = remember(price, symbol, rows, appLanguage) {
        if (rows.isEmpty()) when (appLanguage) {
            "fr" -> "Lancez une analyse du marché pour écouter le résumé."
            "ar" -> "ابدأ تحليل السوق للاستماع إلى الملخص."
            "es" -> "Analiza el mercado primero para escuchar el resumen."
            "de" -> "Führen Sie zuerst eine Marktanalyse durch, um die Zusammenfassung zu hören."
            "it" -> "Esegui prima un'analisi del mercato per ascoltare il riepilogo."
            "zh" -> "请先运行市场分析以收听摘要。"
            "ja" -> "要約を聞くには先に市場分析を実行してください。"
            "ko" -> "요약을 들으려면 먼저 시장 분석을 실행하세요."
            else -> "Run a market analysis first to hear the summary."
        } else buildString {
            when (appLanguage) {
                "fr" -> append("Résumé du marché pour ").append(symbol).append(". ")
                "ar" -> append("ملخص السوق للزوج ").append(symbol).append(". ")
                "es" -> append("Resumen del mercado para ").append(symbol).append(". ")
                "de" -> append("Marktübersicht für ").append(symbol).append(". ")
                "it" -> append("Riepilogo del mercato per ").append(symbol).append(". ")
                "zh" -> append("市场摘要：").append(symbol).append("。")
                "ja" -> append("市場概要：").append(symbol).append("。")
                "ko" -> append("시장 요약: ").append(symbol).append(". ")
                else -> append("Market summary for ").append(symbol).append(". ")
            }
            price?.let { value ->
                when (appLanguage) {
                    "fr" -> append("Prix actuel : ")
                    "ar" -> append("السعر الحالي: ")
                    "es" -> append("Precio actual: ")
                    "de" -> append("Aktueller Preis: ")
                    "it" -> append("Prezzo attuale: ")
                    "zh" -> append("当前价格：")
                    "ja" -> append("現在価格：")
                    "ko" -> append("현재 가격: ")
                    else -> append("Current price: ")
                }
                append(symbol.replace("USDT", "").replace("USDC", "").replace("USD", "").trim()).append(" ").append(fmt(value)).append(" USDT. ")
            }
            rows.forEach { row ->
                when (appLanguage) {
                    "fr" -> append(row.timeframe).append(". Score haussier ").append(row.upProbability).append(" %, score baissier ").append(row.downProbability).append(" %. Support ").append(fmt(row.support)).append(". Résistance ").append(fmt(row.resistance)).append(". ")
                    "ar" -> append("الإطار الزمني ").append(row.timeframe).append(". نسبة الاتجاه الصاعد ").append(row.upProbability).append(" بالمئة، والهابط ").append(row.downProbability).append(" بالمئة. الدعم ").append(fmt(row.support)).append(". المقاومة ").append(fmt(row.resistance)).append(". ")
                    "es" -> append("Marco temporal ").append(row.timeframe).append(". Puntuación alcista ").append(row.upProbability).append(" por ciento y bajista ").append(row.downProbability).append(" por ciento. Soporte ").append(fmt(row.support)).append(". Resistencia ").append(fmt(row.resistance)).append(". ")
                    "de" -> append("Zeitrahmen ").append(row.timeframe).append(". Aufwärtswert ").append(row.upProbability).append(" Prozent, Abwärtswert ").append(row.downProbability).append(" Prozent. Unterstützung ").append(fmt(row.support)).append(". Widerstand ").append(fmt(row.resistance)).append(". ")
                    "it" -> append("Intervallo ").append(row.timeframe).append(". Punteggio rialzista ").append(row.upProbability).append(" per cento e ribassista ").append(row.downProbability).append(" per cento. Supporto ").append(fmt(row.support)).append(". Resistenza ").append(fmt(row.resistance)).append(". ")
                    "zh" -> append("周期").append(row.timeframe).append("。看涨评分").append(row.upProbability).append("%，看跌评分").append(row.downProbability).append("%。支撑位").append(fmt(row.support)).append("，阻力位").append(fmt(row.resistance)).append("。")
                    "ja" -> append("時間足").append(row.timeframe).append("。強気スコア").append(row.upProbability).append("%、弱気スコア").append(row.downProbability).append("%。サポート").append(fmt(row.support)).append("。レジスタンス").append(fmt(row.resistance)).append("。")
                    "ko" -> append("시간대 ").append(row.timeframe).append(". 상승 점수 ").append(row.upProbability).append("%, 하락 점수 ").append(row.downProbability).append("%. 지지선 ").append(fmt(row.support)).append(". 저항선 ").append(fmt(row.resistance)).append(". ")
                    else -> append(row.timeframe).append(" timeframe. Bullish score ").append(row.upProbability).append(" percent, bearish score ").append(row.downProbability).append(" percent. Support ").append(fmt(row.support)).append(". Resistance ").append(fmt(row.resistance)).append(". ")
                }
                if (appLanguage == "en") append(row.setup).append(". ")
            }
            append(when (appLanguage) {
                "fr" -> "Ces indicateurs sont des estimations, pas des prédictions garanties ni des conseils financiers."
                "ar" -> "هذه المؤشرات تقديرية وليست تنبؤات مضمونة أو نصيحة مالية."
                "es" -> "Estos indicadores son estimaciones, no predicciones garantizadas ni asesoramiento financiero."
                "de" -> "Diese Indikatoren sind Schätzungen, keine garantierten Vorhersagen oder Finanzberatung."
                "it" -> "Questi indicatori sono stime, non previsioni garantite né consulenza finanziaria."
                "zh" -> "这些指标仅为估算，并非保证的预测或财务建议。"
                "ja" -> "これらの指標は推定値であり、保証された予測や金融助言ではありません。"
                "ko" -> "이 지표는 추정치이며 보장된 예측이나 금융 조언이 아닙니다."
                else -> "These indicators are estimates, not guaranteed predictions or financial advice."
            })
        }
    }

    fun speakFromWord(wordOffset: Int) {
        val engine = speechEngine ?: return
        if (!speechReady) return
        val tokens = spokenSummary.split(Regex("\\s+"))
        val start = wordOffset.coerceIn(0, max(0, tokens.size - 1))
        speechWordOffset = start
        engine.stop()
        // Use a lower pitch for the male option even when the installed TTS engine
        // does not expose a voice explicitly labelled as male for this language.
        try {
            engine.setPitch(if (voiceGender == "male") 0.78f else 1.0f)
            engine.setSpeechRate(1.0f)
        } catch (_: Exception) { /* Keep the TTS engine's defaults if unsupported. */ }
        engine.speak(tokens.drop(start).joinToString(" "), TextToSpeech.QUEUE_FLUSH, null, "cryptoanalyser-summary-$start")
    }
    LaunchedEffect(market, platform) {
        listedSymbols = withContext(Dispatchers.IO) {
            try {
                loadListedUsdtSymbols(market, platform)
            } catch (_: Exception) {
                // Keep the input usable if Bitget's symbol-list endpoint is temporarily unavailable.
                listOf("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "BNBUSDT", "DOGEUSDT", "AIAVUSDT")
            }
        }
    }
    LaunchedEffect(symbol, market, platform, chartTimeframe, price) {
        if (price == null) {
            chartCandles = emptyList()
        } else {
            chartLoading = true
            chartCandles = emptyList()
            val chartSymbol = symbol.trim().uppercase(Locale.ROOT).replace("/", "").replace("-", "").replace("_", "").replace(" ", "")
            val granularity = when (chartTimeframe) {
                "15m" -> if (platform == "Binance") "15m" else if (market == "Spot") "15min" else "15m"
                "1H" -> if (market == "Spot") "1h" else "1H"
                "4H" -> if (market == "Spot") "4h" else "4H"
                "1D" -> if (market == "Spot") "1day" else "1D"
                else -> "1M"
            }
            try {
                val candles = withContext(Dispatchers.IO) {
                    loadMarketCandles(chartSymbol, market, platform, granularity, 100)
                }
                chartCandles = candles
            } catch (_: Exception) {
                chartCandles = emptyList()
            } finally {
                chartLoading = false
            }
        }
    }
    val cleanedQuery = symbol.trim().uppercase().replace("/", "").replace("-", "").replace("_", "").replace(" ", "")
    val suggestionQuery = cleanedQuery.removeSuffix("USDT")
    val filteredSuggestions = remember(listedSymbols, cleanedQuery, showSuggestions) {
        if (!showSuggestions || suggestionQuery.isBlank()) emptyList()
        else listedSymbols.filter { pair ->
            pair.startsWith(cleanedQuery) || pair.removeSuffix("USDT").startsWith(suggestionQuery)
        }.take(8)
    }
    val tfMap = listOf("1H" to "1H", "4H" to "4H", "1D" to "1D")
    val tradePlans = remember(price, rows) { val anchor = rows.firstOrNull { it.timeframe == "4H" }; if (price != null && anchor != null) buildTradePlans(price!!, anchor) else emptyList() }

    fun runAnalysis() {
        val clean = try {
            normalizeUsdtSymbol(symbol)
        } catch (e: IllegalArgumentException) {
            error = e.message ?: "Enter a valid coin symbol, e.g. BTC or BTCUSDT."
            return
        }
        symbol = clean
        loading = true; error = ""; rows = emptyList(); backtest = ""; extremes = null
        scope.launch {
            // The server must authorize every analysis request before any coin data is fetched.
            if (!onBeforeAnalysis()) {
                loading = false
                error = "License verification failed. No market data was loaded."
                return@launch
            }
            recentSymbols = (listOf(clean) + recentSymbols.filterNot { it == clean }).take(50)
            preferences.edit().putString("recent_symbols", JSONArray().apply { recentSymbols.forEach { put(it) } }.toString()).apply()
            newsLoading = true; newsError = ""; news = emptyList()
            scope.launch {
                val result = withContext(Dispatchers.IO) { loadRecentNews(clean) }
                news = result
                newsLoading = false
                if (result.isEmpty()) newsError = "Aucune actualité vérifiée disponible sur les 7 derniers jours. Réessayez plus tard."
            }
            try {
                val result = withContext(Dispatchers.IO) {
                    val isSpot = market == "Spot"
                    val tickerRoot = getJson(marketTickerUrl(clean, market, platform))
                    val tickerData = tickerRoot.optJSONArray("data")
                    val ticker = if (platform == "Binance") tickerRoot else if (tickerData != null && tickerData.length() > 0) tickerData.optJSONObject(0) ?: JSONObject() else tickerRoot.optJSONObject("data") ?: JSONObject()
                    val currentPrice = ticker.optString(if (platform == "Binance") "lastPrice" else "lastPr", ticker.optString("last", "")).toDoubleOrNull() ?: 0.0
                    val priceExtremes = if (platform == "Binance") PriceExtremes(0.0, 0.0, ticker.optString("highPrice").toDoubleOrNull() ?: 0.0, ticker.optString("lowPrice").toDoubleOrNull() ?: 0.0, false, true) else loadAllTimeExtremes(clean, isSpot, ticker)
                    val analyzed = mutableListOf<IndicatorRow>()
                    val candleSets = mutableListOf<Pair<String, List<Candle>>>()
                    for ((label, granularity) in tfMap) {
                        val candles = loadMarketCandles(clean, market, platform, granularity, 200)
                        if (candles.size < 30) throw Exception("$platform returned insufficient $label candles for $clean on $market. Check that this USDT pair is listed on the selected platform and market.")
                        candleSets.add(label to candles)
                        analyzed.add(analyze(candles, label))
                    }
                    val hourly = candleSets.first().second
                    // Simple educational EMA(9)/EMA(21) crossover backtest, one position at a time, close-to-close, fees excluded.
                    var cash = 1.0; var held = false; var entry = 0.0; var trades = 0; var wins = 0
                    for (i in 25 until hourly.size) {
                        val cs = hourly.take(i + 1).map { it.close }
                        val fast = ema(cs, 9); val slow = ema(cs, 21); val prevFast = ema(cs.dropLast(1), 9); val prevSlow = ema(cs.dropLast(1), 21)
                        if (!held && prevFast <= prevSlow && fast > slow) { held = true; entry = hourly[i].close }
                        else if (held && prevFast >= prevSlow && fast < slow) { val r = hourly[i].close / entry; cash *= r; trades++; if (r > 1) wins++; held = false }
                    }
                    if (held) { val r = hourly.last().close / entry; cash *= r; trades++; if (r > 1) wins++ }
                    Triple(currentPrice, analyzed, "EMA 9/21 crossover on 1H · ${hourly.size} candles · $trades closed trades · return ${(cash - 1) * 100.0}% · win rate ${if (trades > 0) wins * 100 / trades else 0}% (fees/slippage excluded; not a forecast)." to priceExtremes)
                }
                price = result.first.takeIf { it > 0.0 }; rows = result.second; backtest = result.third.first; extremes = result.third.second
                if (price == null) error = "Candles loaded, but $platform did not return a usable ticker price."
            } catch (e: Exception) { error = e.message ?: "Could not load market data. Check your connection, platform, and symbol." }
            finally { loading = false }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides if (appLanguage == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr) {
    Scaffold(
        containerColor = Color(0xFF080D1B),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier.size(38.dp).background(
                                Brush.linearGradient(listOf(Color(0xFF5EEAD4), Color(0xFF60A5FA), Color(0xFFA78BFA))),
                                RoundedCornerShape(13.dp)
                            ), contentAlignment = Alignment.Center
                        ) { Text(tr("₿", appLanguage), color = Color(0xFF07111F), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge) }
                        Column {
                            Text(tr("CRYPTOANALYSER-BY ERRZHR", appLanguage), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, letterSpacing = 1.2.sp)
                            Text(tr("PUBLIC MARKET DATA · BITGET API", appLanguage), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 0.7.sp)
                        }
                    }
                },
                actions = {
                    Box {
                        TextButton(onClick = { showLanguageMenu = true }) { Text("🌐 ${appLanguages.firstOrNull { it.first == appLanguage }?.second ?: "English"}", color = Color(0xFF5EEAD4)) }
                        DropdownMenu(expanded = showLanguageMenu, onDismissRequest = { showLanguageMenu = false }) {
                            appLanguages.forEach { (code, label) ->
                                DropdownMenuItem(text = { Text(label) }, onClick = {
                                    appLanguage = code
                                    preferences.edit().putString("app_language", code).apply()
                                    showLanguageMenu = false
                                    speechWordOffset = 0
                                    speechEngine?.stop()
                                })
                            }
                        }
                    }
                    TextButton(onClick = { showPrivacyDialog = true }) { Text(tr("PRIVACY", appLanguage), color = Color(0xFF5EEAD4)) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF080D1B))
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).background(Color(0xFF080D1B)).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp)
        ) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().background(
                        Brush.linearGradient(listOf(Color(0xFF172E4A), Color(0xFF202047), Color(0xFF122C35))),
                        RoundedCornerShape(24.dp)
                    ).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(tr("YOUR MARKET,\nCLEARER.", appLanguage), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = Color.White, lineHeight = 34.sp)
                    Text(tr("Technical signals and multi-timeframe insights in one place.", appLanguage), style = MaterialTheme.typography.bodyMedium, color = Color(0xFFD1DEF2))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(Color(0xFF5EEAD4), RoundedCornerShape(50)))
                        Text("${platform.uppercase(Locale.ROOT)} · ${tr("PUBLIC MARKET DATA", appLanguage)}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF5EEAD4), fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tr("ANALYZE A MARKET", appLanguage), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(tr("Choose a pair and market type", appLanguage), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(tr("01", appLanguage), color = Color(0xFFA78BFA), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) {
                                OutlinedButton(onClick = { showPlatformMenu = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                    Text("🏦 ${tr("PLATFORM", appLanguage)}: $platform", maxLines = 1)
                                    Spacer(Modifier.width(4.dp)); Text("⌄")
                                }
                                DropdownMenu(expanded = showPlatformMenu, onDismissRequest = { showPlatformMenu = false }) {
                                    listOf("Bitget", "Binance").forEach { option ->
                                        DropdownMenuItem(text = { Text(option) }, onClick = {
                                            platform = option
                                            preferences.edit().putString("market_platform", option).apply()
                                            showPlatformMenu = false
                                            price = null; rows = emptyList(); extremes = null; chartCandles = emptyList(); error = ""
                                        })
                                    }
                                }
                            }
                            Box(Modifier.weight(1f)) {
                                OutlinedButton(onClick = { showInlineLanguageMenu = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                    Text("🌐 ${appLanguages.firstOrNull { it.first == appLanguage }?.second ?: "English"}", maxLines = 1)
                                    Spacer(Modifier.width(2.dp)); Text("⌄")
                                }
                                DropdownMenu(expanded = showInlineLanguageMenu, onDismissRequest = { showInlineLanguageMenu = false }) {
                                    appLanguages.forEach { (code, label) ->
                                        DropdownMenuItem(text = { Text(label) }, onClick = {
                                            appLanguage = code
                                            preferences.edit().putString("app_language", code).apply()
                                            showInlineLanguageMenu = false
                                        })
                                    }
                                }
                            }
                        }
                        ExposedDropdownMenuBox(
                            expanded = filteredSuggestions.isNotEmpty(),
                            onExpandedChange = { showSuggestions = it }
                        ) {
                            OutlinedTextField(
                                value = symbol,
                                onValueChange = { symbol = it.uppercase(); showSuggestions = true },
                                label = { Text(tr("Coin or trading pair", appLanguage)) },
                                placeholder = { Text(tr("Type BTC, ETH, AI…", appLanguage)) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().menuAnchor(),
                                shape = RoundedCornerShape(15.dp),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = filteredSuggestions.isNotEmpty()) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF5EEAD4),
                                    unfocusedBorderColor = Color(0xFF34445F),
                                    focusedLabelColor = Color(0xFF5EEAD4),
                                    cursorColor = Color(0xFF5EEAD4)
                                )
                            )
                            ExposedDropdownMenu(
                                expanded = filteredSuggestions.isNotEmpty(),
                                onDismissRequest = { showSuggestions = false }
                            ) {
                                filteredSuggestions.forEach { pair ->
                                    DropdownMenuItem(
                                        text = {
                                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text(pair, fontWeight = FontWeight.Bold)
                                                Text("${pair.removeSuffix("USDT")} · ${tr(if (market == "Spot") "Spot" else "USDT Futures", appLanguage)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        },
                                        onClick = { symbol = pair; showSuggestions = false },
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                        Text(tr("MARKET TYPE", appLanguage), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            FilterChip(
                                selected = market == "Spot", onClick = { market = "Spot" },
                                label = { Text(tr("Spot", appLanguage)) }, leadingIcon = { Text(tr("●", appLanguage), color = if (market == "Spot") Color(0xFF5EEAD4) else Color.Gray) },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp)
                            )
                            FilterChip(
                                selected = market == "Futures", onClick = { market = "Futures" },
                                label = { Text(tr("USDT Futures", appLanguage)) }, leadingIcon = { Text(tr("↗", appLanguage), color = if (market == "Futures") Color(0xFFA78BFA) else Color.Gray) },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp)
                            )
                        }
                        val cleanFavoritePair = symbol.trim().uppercase(Locale.ROOT).replace("/", "").replace("-", "").replace("_", "").replace(" ", "").let { if (it.isBlank()) "" else if (it.endsWith("USDT")) it else "${it}USDT" }
                        OutlinedButton(
                            onClick = {
                                if (cleanFavoritePair.matches(Regex("[A-Z0-9]{3,30}USDT"))) {
                                    favoriteSymbols = if (favoriteSymbols.contains(cleanFavoritePair)) favoriteSymbols.filterNot { it == cleanFavoritePair } else (favoriteSymbols + cleanFavoritePair).distinct().take(100)
                                    preferences.edit().putString("favorite_symbols", JSONArray().apply { favoriteSymbols.forEach { put(it) } }.toString()).apply()
                                }
                            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (favoriteSymbols.contains(cleanFavoritePair)) "★  ${tr("Remove from favorites", appLanguage)}" else "☆  ${tr("Add current pair to favorites", appLanguage)}")
                        }
                        Button(
                            onClick = { runAnalysis() }, enabled = !loading,
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(15.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5EEAD4), contentColor = Color(0xFF062A2A))
                        ) {
                            if (loading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF062A2A))
                                Spacer(Modifier.width(10.dp)); Text(tr("ANALYZING MARKET…", appLanguage), fontWeight = FontWeight.Bold)
                            } else { Text(tr("✦  ANALYZE MARKET", appLanguage), fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp) }
                        }
                    }
                }
            }
            if (loading) item {
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFF5EEAD4), trackColor = Color(0xFF24324B))
            }
            if (error.isNotBlank()) item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF3A1C2B))) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                        Text(tr("!", appLanguage), color = Color(0xFFFF718B), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                        Text(tr(error, appLanguage), color = Color(0xFFFFD9E0), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tr("PRICE CHART · CANDLESTICKS", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("${symbol} · ${tr(market, appLanguage)}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                            if (chartLoading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFF5EEAD4))
                        }
                        if (chartCandles.isNotEmpty()) {
                            CandleChart(candles = chartCandles, high24h = extremes?.high24h ?: 0.0, low24h = extremes?.low24h ?: 0.0, modifier = Modifier.fillMaxWidth().height(190.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Column(Modifier.weight(1f).background(Color(0xFF123A38), RoundedCornerShape(12.dp)).padding(10.dp)) {
                                    Text(tr("24H HIGH", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(if ((extremes?.high24h ?: 0.0) > 0.0) fmt(extremes!!.high24h) else tr("Unavailable", appLanguage), color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column(Modifier.weight(1f).background(Color(0xFF382338), RoundedCornerShape(12.dp)).padding(10.dp)) {
                                    Text(tr("24H LOW", appLanguage), color = Color(0xFFFF9EB5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(if ((extremes?.low24h ?: 0.0) > 0.0) fmt(extremes!!.low24h) else tr("Unavailable", appLanguage), color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            Text(tr(if (price == null) "Run analysis to load the price chart." else "Candlestick data is unavailable for this pair and timeframe.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("15m" to "15 minutes", "1H" to "1 hour", "4H" to "4 hours", "1D" to "1 day", "1M" to "1 month").forEach { (key, label) ->
                                val active = chartTimeframe == key
                                FilterChip(
                                    selected = active,
                                    onClick = { chartTimeframe = key },
                                    label = { Text(tr(label, appLanguage), maxLines = 1, style = MaterialTheme.typography.labelSmall) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF22C55E), selectedLabelColor = Color(0xFF062A17)),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { if (!alertsExpanded && editingAlertId == null) alertSymbol = symbol; alertsExpanded = !alertsExpanded }, verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("Price alerts", appLanguage), modifier = Modifier.weight(1f), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(if (alertsExpanded) "⌃" else "⌄", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall)
                        }
                        if (alertsExpanded) {
                            Text(tr(if (editingAlertId != null) "Edit alert" else "Add price alert", appLanguage), color = Color(0xFF9BAAC2), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(value = alertSymbol, onValueChange = { alertSymbol = it.uppercase(Locale.ROOT) }, label = { Text(tr("Coin or trading pair", appLanguage)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(value = alertTarget, onValueChange = { alertTarget = it }, label = { Text(tr("Target price", appLanguage)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                FilterChip(selected = alertDirection == "ABOVE", onClick = { alertDirection = "ABOVE" }, label = { Text(tr("When price is above", appLanguage)) }, modifier = Modifier.weight(1f))
                                FilterChip(selected = alertDirection == "BELOW", onClick = { alertDirection = "BELOW" }, label = { Text(tr("When price is below", appLanguage)) }, modifier = Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                FilterChip(selected = alertMarket == "Spot", onClick = { alertMarket = "Spot" }, label = { Text(tr("Spot", appLanguage)) }, modifier = Modifier.weight(1f))
                                FilterChip(selected = alertMarket == "Futures", onClick = { alertMarket = "Futures" }, label = { Text(tr("USDT Futures", appLanguage)) }, modifier = Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(onClick = {
                                    val clean = alertSymbol.trim().uppercase(Locale.ROOT).replace("/", "").replace("-", "").replace("_", "").replace(" ", "").let { if (it.endsWith("USDT")) it else "${it}USDT" }
                                    val target = alertTarget.toDoubleOrNull()
                                    if (clean.matches(Regex("[A-Z0-9]{3,30}USDT")) && target != null && target > 0.0) {
                                        val id = editingAlertId ?: System.currentTimeMillis()
                                        val obj = JSONObject().put("id", id).put("symbol", clean).put("market", alertMarket).put("target", target).put("direction", alertDirection).put("triggered", false)
                                        val next = priceAlerts.filterNot { it.optLong("id") == id } + obj
                                        priceAlerts = next
                                        val arr = JSONArray(); next.forEach { arr.put(it) }
                                        preferences.edit().putString("price_alerts", arr.toString()).apply()
                                        editingAlertId = null; alertSymbol = symbol; alertTarget = ""
                                        val request = PeriodicWorkRequestBuilder<PriceAlertWorker>(15, TimeUnit.MINUTES).build()
                                        WorkManager.getInstance(context).enqueueUniquePeriodicWork("crypto_price_alert_monitor", ExistingPeriodicWorkPolicy.UPDATE, request)
                                    }
                                }, modifier = Modifier.weight(1f)) { Text(tr("Save", appLanguage)) }
                                OutlinedButton(onClick = { editingAlertId = null; alertSymbol = symbol; alertTarget = "" }, modifier = Modifier.weight(1f)) { Text(tr("Cancel", appLanguage)) }
                            }
                            if (priceAlerts.isEmpty()) Text(tr("No price alerts yet", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            priceAlerts.forEach { alert ->
                                HorizontalDivider(color = Color(0xFF283650))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("${alert.optString("symbol")} · ${fmt(alert.optDouble("target"))} USDT", color = Color.White, fontWeight = FontWeight.SemiBold)
                                        Text("${tr(alert.optString("direction"), appLanguage)} · ${tr(alert.optString("market"), appLanguage)}", color = Color(0xFF9BAAC2), style = MaterialTheme.typography.bodySmall)
                                        if (alert.optBoolean("triggered")) {
                                            Text(tr("Deactivated", appLanguage), color = Color(0xFFFBBF24), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                        } else {
                                            Text(tr("Active", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                    if (alert.optBoolean("triggered")) {
                                        TextButton(onClick = {
                                            val updatedAlert = JSONObject(alert.toString()).put("triggered", false)
                                            val next = priceAlerts.map { if (it.optLong("id") == alert.optLong("id")) updatedAlert else it }
                                            priceAlerts = next
                                            val arr = JSONArray(); next.forEach { arr.put(it) }
                                            preferences.edit().putString("price_alerts", arr.toString()).apply()
                                            val request = PeriodicWorkRequestBuilder<PriceAlertWorker>(15, TimeUnit.MINUTES).build()
                                            WorkManager.getInstance(context).enqueueUniquePeriodicWork("crypto_price_alert_monitor", ExistingPeriodicWorkPolicy.UPDATE, request)
                                        }) { Text(tr("Activate", appLanguage)) }
                                    }
                                    TextButton(onClick = {
                                        editingAlertId = alert.optLong("id"); alertSymbol = alert.optString("symbol"); alertTarget = alert.optDouble("target").toString(); alertDirection = alert.optString("direction", "ABOVE"); alertMarket = alert.optString("market", "Spot"); alertsExpanded = true
                                    }) { Text(tr("Edit", appLanguage)) }
                                    TextButton(onClick = {
                                        val next = priceAlerts.filterNot { it.optLong("id") == alert.optLong("id") }; priceAlerts = next
                                        val arr = JSONArray(); next.forEach { arr.put(it) }; preferences.edit().putString("price_alerts", arr.toString()).apply()
                                    }) { Text(tr("Delete", appLanguage)) }
                                }
                            }
                        }
                    }
                }
            }
            if (recentSymbols.isNotEmpty()) item {
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("Recently analyzed", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            recentSymbols.take(3).forEach { recent ->
                                TextButton(onClick = { symbol = recent; showSuggestions = false; runAnalysis() }) {
                                    Text(recent, color = Color(0xFF93C5FD), textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline)
                                }
                            }
                        }
                    }
                }
            }
            if (favoriteSymbols.isNotEmpty()) item {
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("Favorites", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            favoriteSymbols.forEach { favorite ->
                                AssistChip(
                                    onClick = { symbol = favorite; showSuggestions = false; runAnalysis() },
                                    label = { Text("★ $favorite") },
                                    trailingIcon = {
                                        Text("×", modifier = Modifier.clickable {
                                            favoriteSymbols = favoriteSymbols.filterNot { it == favorite }
                                            preferences.edit().putString("favorite_symbols", JSONArray().apply { favoriteSymbols.forEach { put(it) } }.toString()).apply()
                                        })
                                    }
                                )
                            }
                        }
                        Text(tr("Movement signals are monitored for recent searches, favorites, and price-alert pairs on both Bitget and Binance.", appLanguage), color = Color(0xFF9BAAC2), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF102B30))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { marketInfoExpanded = !marketInfoExpanded }, verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("Market information", appLanguage), modifier = Modifier.weight(1f), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(if (marketInfoExpanded) "⌃" else "⌄", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall)
                        }
                        if (marketInfoExpanded && price != null) {
                            HorizontalDivider(color = Color(0xFF285052))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(tr("LIVE PRICE", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                                Spacer(Modifier.weight(1f))
                                Text(market.uppercase(), color = Color(0xFFB8C7E3), style = MaterialTheme.typography.labelSmall)
                            }
                            val baseSymbol = symbol.trim().uppercase(Locale.ROOT)
                                .replace("/", "").replace("-", "").replace("_", "").replace(" ", "")
                                .let { pair -> listOf("USDT", "USDC", "USD", "BTC", "ETH").firstOrNull { pair.endsWith(it) && pair.length > it.length }?.let { pair.removeSuffix(it) } ?: pair }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Box(
                                    modifier = Modifier.size(38.dp).background(Color(0xFF1B4148), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(baseSymbol.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                                    AsyncImage(
                                        model = "https://assets.coincap.io/assets/icons/${baseSymbol.lowercase(Locale.ROOT)}@2x.png",
                                        contentDescription = "$baseSymbol coin logo",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.fillMaxSize().padding(2.dp)
                                    )
                                }
                                Text("$baseSymbol  ${fmt(price!!)} USDT", modifier = Modifier.weight(1f), style = MaterialTheme.typography.headlineLarge, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, softWrap = false)
                            }
                            Text("${tr("Live public market data", appLanguage)} · $platform", color = Color(0xFFB8D8D5), style = MaterialTheme.typography.bodySmall)
                        } else if (marketInfoExpanded && price == null) {
                            Text(tr("Run a market analysis to view price information.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { newsExpanded = !newsExpanded }, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tr("Coin news", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                                Text(tr("Marché crypto · ${symbol.removeSuffix("USDT")} · 7 derniers jours", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                            Text(if (newsExpanded) "⌃" else "⌄", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall)
                        }
                        if (newsExpanded) {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2440)), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(Modifier.fillMaxWidth().clickable { researchExpanded = !researchExpanded }, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(tr("COIN RESEARCH REPORT", appLanguage), color = Color(0xFFC4B5FD), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall)
                                        Text("${symbol.removeSuffix("USDT")} · ${tr("Summary and source checks", appLanguage)}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text(if (researchExpanded) "⌃" else "⌄", color = Color(0xFFC4B5FD), style = MaterialTheme.typography.headlineSmall)
                                }
                                if (researchExpanded) {
                                    Text(tr("The report separates verified facts from claims that still need checking. Forecasts are scenarios, not guarantees. Data not found is marked unknown instead of being invented.", appLanguage), color = Color(0xFFE2DDFB), style = MaterialTheme.typography.bodySmall)
                                    val researchSections = listOf(
                                        "Project identity and utility" to "project utility",
                                        "Launch and first market data" to "launch listing history",
                                        "Investors and funding" to "investors funding rounds amounts dates",
                                        "Token unlock schedule" to "token unlock vesting schedule",
                                        "Adoption and partnerships" to "adoption partnerships official announcement",
                                        "Price scenarios: 1 month to 5 years" to "price forecast risks scenarios"
                                    )
                                    researchSections.forEach { (title, query) ->
                                        Column {
                                            Row(Modifier.fillMaxWidth().clickable { researchTopic = if (researchTopic == title) "" else title }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Text(tr(title, appLanguage), modifier = Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                                Text(if (researchTopic == title) "⌃" else "⌄", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium)
                                            }
                                            if (researchTopic == title) {
                                                Text(tr("No claim is treated as confirmed unless a reliable source supports it. Check the selected coin name and ticker to avoid confusing projects with similar symbols.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                                OutlinedButton(onClick = {
                                                    researchWebTitle = tr(title, appLanguage)
                                                    researchWebUrl = "https://www.google.com/search?q=" + android.net.Uri.encode("${symbol.removeSuffix("USDT")} crypto $query official source")
                                                }, modifier = Modifier.fillMaxWidth()) { Text(tr("Search sources inside app", appLanguage)) }
                                            }
                                            HorizontalDivider(color = Color(0xFF303A56))
                                        }
                                    }
                                    Text(tr("Source access depends on public availability. Private groups and some social-platform posts cannot be searched automatically; missing data is not proof that no information exists.", appLanguage), color = Color(0xFF9AA9C3), style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                        Text(tr("Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        if (newsLoading) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFF5EEAD4))
                                Text(tr("Chargement des actualités récentes…", appLanguage), color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodySmall)
                            }
                        } else if (news.isEmpty()) {
                            Text(tr(newsError.ifBlank { "Lancez l’analyse pour charger les actualités récentes." }, appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        } else {
                            news.forEachIndexed { index, item ->
                                HorizontalDivider(color = Color(0xFF283650))
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable { selectedNews = item }.padding(vertical = 5.dp),
                                    verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                        Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                                        Text("${item.source} · ${java.text.SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(item.publishedAt))}", color = Color(0xFF8FA2BE), style = MaterialTheme.typography.labelSmall)
                                    }
                                    Text(tr("›", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall)
                                }
                            }
                        }
                        Text(tr("Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente.", appLanguage), color = Color(0xFF73839D), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            if (extremes != null && marketInfoExpanded) item {
                val e = extremes!!
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tr("PRICE RANGE", appLanguage), color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Text(tr("${symbol} · ${market}", appLanguage), color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Text(tr("HIGH / LOW", appLanguage), color = Color(0xFF9BAAC2), style = MaterialTheme.typography.labelSmall)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f).background(Color(0xFF123A38), RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(tr("ALL-TIME HIGH", appLanguage), color = Color(0xFF8CEBDD), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(if (e.allTimeHigh > 0) fmt(e.allTimeHigh) else "Unavailable", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                            }
                            Column(Modifier.weight(1f).background(Color(0xFF382338), RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(tr("ALL-TIME LOW", appLanguage), color = Color(0xFFFFB5C5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(if (e.allTimeLow > 0) fmt(e.allTimeLow) else "Unavailable", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f).background(Color(0xFF182A3D), RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(tr("24H HIGH", appLanguage), color = Color(0xFF60A5FA), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(if (e.high24h > 0) fmt(e.high24h) else "Unavailable", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Column(Modifier.weight(1f).background(Color(0xFF382A25), RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(tr("24H LOW", appLanguage), color = Color(0xFFFFC078), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(if (e.low24h > 0) fmt(e.low24h) else "Unavailable", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(if (platform == "Binance") "24H high/low come from Binance ticker statistics. ATH/ATL are not reported unless a complete historical scan can verify them." else tr("24H high/low come from Bitget ticker statistics. ATH/ATL are calculated from paginated daily historical candles for this exact market and instrument. If the historical scan cannot confirm completeness, the displayed values are based only on available history.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { unlocksExpanded = !unlocksExpanded }, verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("Token unlocks", appLanguage), modifier = Modifier.weight(1f), color = Color(0xFFA78BFA), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(if (unlocksExpanded) "⌃" else "⌄", color = Color(0xFFA78BFA), style = MaterialTheme.typography.headlineSmall)
                        }
                        if (unlocksExpanded) {
                            Text(tr("Unlocks are not verified", appLanguage), color = Color(0xFFFFC078), fontWeight = FontWeight.SemiBold)
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                listOf("Date", "Quantity", "% supply", "Time remaining", "Recipient", "Source").forEach { heading ->
                                    Text(tr(heading, appLanguage), color = Color(0xFF93C5FD), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(tr("No verified unlock schedule available in this app build. No dates or quantities are being guessed.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            Text(tr("This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick = { researchWebTitle = "Tokenomist · ${symbol.removeSuffix("USDT")}"; researchWebUrl = "https://tokenomist.ai/search?q=${android.net.Uri.encode(symbol.removeSuffix("USDT"))}" }, modifier = Modifier.fillMaxWidth()) { Text(tr("Search Tokenomist", appLanguage)) }
                            OutlinedButton(onClick = { researchWebTitle = "CryptoRank · ${symbol.removeSuffix("USDT")}"; researchWebUrl = "https://cryptorank.io/price/${symbol.removeSuffix("USDT").lowercase(Locale.ROOT)}/vesting" }, modifier = Modifier.fillMaxWidth()) { Text(tr("Search CryptoRank", appLanguage)) }
                            OutlinedButton(onClick = { researchWebTitle = tr("Search official announcements", appLanguage); researchWebUrl = "https://www.google.com/search?q=" + android.net.Uri.encode("${symbol.removeSuffix("USDT")} token unlock official announcement") }, modifier = Modifier.fillMaxWidth()) { Text(tr("Search official announcements", appLanguage)) }
                        }
                    }
                }
            }
            if (rows.isNotEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF16263D))) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(tr("LISTEN TO THE SUMMARY", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                            Text(tr("Choose a voice, then tap the speaker button. Voice availability depends on the text-to-speech engine installed on your phone.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                FilterChip(
                                    selected = voiceGender == "female",
                                    onClick = {
                                        voiceGender = "female"
                                        preferences.edit().putString("summary_voice_gender", "female").apply()
                                    },
                                    label = { Text(tr("👩  Woman", appLanguage), fontSize = 16.sp) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                FilterChip(
                                    selected = voiceGender == "male",
                                    onClick = {
                                        voiceGender = "male"
                                        preferences.edit().putString("summary_voice_gender", "male").apply()
                                    },
                                    label = { Text(tr("👨  Man", appLanguage), fontSize = 16.sp) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(14.dp)
                                )
                            }
                            Button(
                                onClick = {
                                    val engine = speechEngine
                                    if (speechReady && engine != null) {
                                        speakFromWord(0)
                                    }
                                },
                                enabled = speechReady,
                                modifier = Modifier.fillMaxWidth().height(50.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5EEAD4), contentColor = Color(0xFF062A2A))
                            ) {
                                Text(if (speechReady) tr("🔊  HEAR SUMMARY", appLanguage) else tr("Preparing voice…", appLanguage), fontWeight = FontWeight.ExtraBold)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick = { speechEngine?.stop() }, enabled = speechReady, modifier = Modifier.weight(1f)) { Text(tr("Stop", appLanguage)) }
                                OutlinedButton(onClick = { speakFromWord(speechWordOffset - 12) }, enabled = speechReady, modifier = Modifier.weight(1f)) { Text(tr("−5 sec", appLanguage)) }
                                OutlinedButton(onClick = { speakFromWord(speechWordOffset + 12) }, enabled = speechReady, modifier = Modifier.weight(1f)) { Text(tr("+5 sec", appLanguage)) }
                                OutlinedButton(onClick = { speakFromWord(0) }, enabled = speechReady, modifier = Modifier.weight(1f)) { Text(tr("Restart", appLanguage)) }
                            }
                        }
                    }
                }
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF13243A))
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(tr("ENTRY PLAN · AUTOMATIC", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                            Text(
                                tr("All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes.", appLanguage),
                                color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall
                            )
                            if (tradePlans.isEmpty()) {
                                Text(tr("Trade levels unavailable: support/resistance data is not valid enough to build a plan.", appLanguage), color = Color(0xFFFFC078), style = MaterialTheme.typography.bodyMedium)
                            } else {
                                tradePlans.forEachIndexed { index, plan ->
                                    val accent = when (index) {
                                        0 -> Color(0xFFFFC078)
                                        1 -> Color(0xFF5EEAD4)
                                        else -> Color(0xFFA78BFA)
                                    }
                                    Column(
                                        Modifier.fillMaxWidth().background(Color(0xFF0B1424), RoundedCornerShape(15.dp)).padding(13.dp),
                                        verticalArrangement = Arrangement.spacedBy(7.dp)
                                    ) {
                                        Text(tr(plan.title, appLanguage), color = accent, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.ExtraBold)
                                        Text(tr(plan.description, appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(tr("Entry / trigger", appLanguage), modifier = Modifier.weight(1f), color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodyMedium)
                                            Text(fmt(plan.entry), color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(tr("Stop loss (SL)", appLanguage), modifier = Modifier.weight(1f), color = Color(0xFFFF9EB5), style = MaterialTheme.typography.bodyMedium)
                                            Text(fmt(plan.stopLoss), color = Color(0xFFFF9EB5), fontWeight = FontWeight.Bold)
                                        }
                                        HorizontalDivider(color = Color(0xFF283650))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(tr("TP1 · 1:1", appLanguage), modifier = Modifier.weight(1f), color = Color(0xFF8CEBDD), style = MaterialTheme.typography.bodySmall)
                                            Text(fmt(plan.tp1), color = Color(0xFF8CEBDD), fontWeight = FontWeight.Bold)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(tr("TP2 · 1:2", appLanguage), modifier = Modifier.weight(1f), color = Color(0xFF8CEBDD), style = MaterialTheme.typography.bodySmall)
                                            Text(fmt(plan.tp2), color = Color(0xFF8CEBDD), fontWeight = FontWeight.Bold)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(tr("TP3 · 1:3", appLanguage), modifier = Modifier.weight(1f), color = Color(0xFF8CEBDD), style = MaterialTheme.typography.bodySmall)
                                            Text(fmt(plan.tp3), color = Color(0xFF8CEBDD), fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                            Text(
                                tr("Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility.", appLanguage),
                                color = Color(0xFFFFC078), style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tr("TECHNICAL OVERVIEW", appLanguage), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                            Text(tr("Signals across three timeframes", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(tr("02", appLanguage), color = Color(0xFF60A5FA), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                    }
                }
                items(rows) { r ->
                    val bullish = r.upProbability >= r.downProbability
                    Card(shape = RoundedCornerShape(21.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.background(if (bullish) Color(0xFF123A38) else Color(0xFF3B2436), RoundedCornerShape(11.dp)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                                    Text(r.timeframe, color = if (bullish) Color(0xFF5EEAD4) else Color(0xFFFF9EB5), fontWeight = FontWeight.ExtraBold)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(tr("${r.timeframe} timeframe", appLanguage), fontWeight = FontWeight.Bold)
                                    Text(tr("Last close: ${fmt(r.price)}", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.weight(1f).background(Color(0xFF123A38), RoundedCornerShape(14.dp)).padding(12.dp)) {
                                    Text(tr("BULLISH SCORE", appLanguage), color = Color(0xFF8CEBDD), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(tr("${r.upProbability}%", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                }
                                Column(Modifier.weight(1f).background(Color(0xFF382338), RoundedCornerShape(14.dp)).padding(12.dp)) {
                                    Text(tr("BEARISH SCORE", appLanguage), color = Color(0xFFFFB5C5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(tr("${r.downProbability}%", appLanguage), color = Color(0xFFFF8BA6), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                }
                            }
                            Text(tr("MOVING AVERAGES", appLanguage), color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                            Column(Modifier.horizontalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                r.emas.forEach { (period, value) ->
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 10.dp)) {
                                        Text(tr("EMA $period", appLanguage), modifier = Modifier.width(70.dp), color = Color(0xFFC7D2E7), style = MaterialTheme.typography.bodySmall)
                                        Text(fmt(value), color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                        Spacer(Modifier.width(8.dp))
                                        Text(tr(if (r.price >= value) "ABOVE" else "BELOW", appLanguage), color = if (r.price >= value) Color(0xFF5EEAD4) else Color(0xFFFF9EB5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            HorizontalDivider(color = Color(0xFF283650))
                            Text(tr("MOMENTUM", appLanguage), color = Color(0xFF60A5FA), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                            Text(tr("OBV: ${fmt(r.obv)}", appLanguage), color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodySmall)
                            Text(tr("MACD ${fmt(r.macd)}   ·   Signal ${fmt(r.signal)}   ·   Hist ${fmt(r.hist)}", appLanguage), color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.weight(1f).background(Color(0xFF182A3D), RoundedCornerShape(12.dp)).padding(11.dp)) {
                                    Text(tr("SUPPORT", appLanguage), color = Color(0xFF60A5FA), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(fmt(r.support), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                }
                                Column(Modifier.weight(1f).background(Color(0xFF382A25), RoundedCornerShape(12.dp)).padding(11.dp)) {
                                    Text(tr("RESISTANCE", appLanguage), color = Color(0xFFFFC078), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(fmt(r.resistance), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Text(tr("Signal interpretation", appLanguage), color = Color(0xFFA78BFA), fontWeight = FontWeight.Bold)
                            Text(tr(r.setup, appLanguage), color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodyMedium)
                            Text(tr("Scores are heuristic signals, not calibrated probabilities.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF18233A))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(tr("BACKTEST LAB", appLanguage), color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text(tr("EMA 9/21 crossover", appLanguage), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(tr(backtest, appLanguage), color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodyMedium)
                            Text(tr("Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF211D3D))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(tr("PROJECT RESEARCH", appLanguage), color = Color(0xFFC4B5FD), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text(tr("Fundamentals & investors", appLanguage), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(tr("This version does not automatically verify investors, partnerships, token unlocks or fundamentals. Check primary sources and classify claims as verified, unverified or unknown.", appLanguage), color = Color(0xFFE2DDFB), style = MaterialTheme.typography.bodyMedium)
                            Text(tr("Search: ${symbol} crypto investors funding official", appLanguage), color = Color(0xFFA78BFA), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Text(tr("RISK NOTICE  ·  Scores are rule-based heuristics, not predictions or guarantees. Futures trading can cause rapid losses. Never trade from this screen alone.", appLanguage), color = Color(0xFF9BAAC2), style = MaterialTheme.typography.bodySmall)
            }
            item {
                Text(tr("DATA PRIVACY  ·  Public market data only. No exchange account connection or order execution. Network providers may process technical connection data such as IP address.", appLanguage), color = Color(0xFF73839D), style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        if (showPrivacyDialog) {
            AlertDialog(
                onDismissRequest = { showPrivacyDialog = false },
                title = { Text(tr("PRIVACY & RISK DISCLOSURE", appLanguage), color = Color(0xFF5EEAD4), fontWeight = FontWeight.ExtraBold) },
                text = {
                    Column(
                        modifier = Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(tr("What this app does", appLanguage), fontWeight = FontWeight.Bold, color = Color.White)
                        Text(tr("CryptoAnalyser-by ErrZhr displays public market prices and historical candles from Bitget, and recent headlines from public RSS feeds. It does not connect to an exchange account, request API keys, place orders, hold funds, or operate a wallet.", appLanguage), color = Color(0xFFD9E4F5))
                        Text(tr("Network and privacy", appLanguage), fontWeight = FontWeight.Bold, color = Color.White)
                        Text(tr("The app does not ask for your name, email address, contacts, camera, microphone, or precise location. To retrieve market and news data, it sends network requests to Bitget and the listed news-feed providers. Those providers may process technical connection data, such as your IP address, under their own privacy policies. The app itself does not create a user account or sell personal data.", appLanguage), color = Color(0xFFD9E4F5))
                        Text(tr("Financial risk", appLanguage), fontWeight = FontWeight.Bold, color = Color.White)
                        Text(tr("Indicators, scores, historical ranges, and backtests are informational estimates, not personalized financial advice or guarantees. Data may be delayed, incomplete, or incorrect. Crypto assets and futures are high risk; you are responsible for your decisions and possible losses.", appLanguage), color = Color(0xFFD9E4F5))
                        Text(tr("Third-party services", appLanguage), fontWeight = FontWeight.Bold, color = Color.White)
                        Text(tr("Bitget, CoinDesk, and Cointelegraph are independent services. This app is not an official Bitget product and does not imply endorsement by those providers. Their service and privacy terms apply to their respective endpoints.", appLanguage), color = Color(0xFFD9E4F5))
                        Text(tr("For publication, the developer must host a public privacy policy URL and ensure the Google Play Data safety form accurately matches the app and its providers.", appLanguage), color = Color(0xFFFFD18A), fontWeight = FontWeight.Medium)
                    }
                },
                confirmButton = { TextButton(onClick = { showPrivacyDialog = false }) { Text(tr("Close", appLanguage), color = Color(0xFF5EEAD4)) } },
                containerColor = Color(0xFF111A2E),
                titleContentColor = Color.White,
                textContentColor = Color.White
            )
        }
        if (researchWebUrl.isNotBlank()) {
            AlertDialog(
                onDismissRequest = { researchWebUrl = "" },
                title = { Text(researchWebTitle, color = Color(0xFF5EEAD4), fontWeight = FontWeight.Bold) },
                text = {
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().height(480.dp),
                        factory = { ctx -> WebView(ctx).apply { webViewClient = WebViewClient(); settings.javaScriptEnabled = false; settings.domStorageEnabled = true; loadUrl(researchWebUrl) } },
                        update = { view -> if (view.url != researchWebUrl) view.loadUrl(researchWebUrl) }
                    )
                },
                confirmButton = { TextButton(onClick = { researchWebUrl = "" }) { Text(tr("Close", appLanguage), color = Color(0xFF5EEAD4)) } },
                containerColor = Color(0xFF111A2E)
            )
        }
        if (selectedNews != null) {
            val article = selectedNews!!
            AlertDialog(
                onDismissRequest = { selectedNews = null },
                title = { Text(tr("ACTUALITÉ", appLanguage), color = Color(0xFF5EEAD4), fontWeight = FontWeight.ExtraBold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text(article.title, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("${article.source} · ${java.text.SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(article.publishedAt))}", color = Color(0xFF8FA2BE), style = MaterialTheme.typography.labelSmall)
                        val detail = article.summary.ifBlank { "Le flux RSS fournit le titre et la date, mais pas de résumé détaillé pour cet article." }
                        Text(detail.take(480), color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodyMedium, maxLines = 4)
                        Text(tr("Publié il y a moins de 7 jours. Cette information peut influencer le marché, mais son impact sur le prix reste incertain.", appLanguage), color = Color(0xFF8FA2BE), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    }
                },
                confirmButton = { TextButton(onClick = { selectedNews = null }) { Text(tr("Fermer", appLanguage), color = Color(0xFF5EEAD4)) } },
                containerColor = Color(0xFF111A2E),
                titleContentColor = Color.White,
                textContentColor = Color.White
            )
        }
    }
    }
}
private fun fmt(v: Double): String = if (!v.isFinite()) "—" else String.format(java.util.Locale.US, "%.8f", v).trimEnd('0').trimEnd('.')
