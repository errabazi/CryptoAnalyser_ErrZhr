# CryptoAnalyser-by ErrZhr (Android)

Kotlin + Jetpack Compose Android project for educational cryptocurrency market analysis using public Bitget endpoints.

## Features
- Bitget Spot and USDT Futures public market data.
- Coin-pair autocomplete, EMA/OBV/MACD indicators, support/resistance, historical extremes and an educational EMA crossover backtest.
- Recent crypto news from public CoinDesk and Cointelegraph RSS feeds, limited to four items from the last seven days.
- `FLAG_SECURE`, portrait orientation, non-resizable activity declaration, disabled app backup, and HTTPS-only network traffic.
- In-app privacy and financial-risk disclosure.

## Build locally
Open this folder in Android Studio with JDK 17 and Android SDK Platform 36 installed. Let Gradle sync, then run `lintDebug` and `assembleDebug`. CI uses Gradle 8.11.1 and builds a debug APK.

## Before publishing
Read `PLAY_STORE_RELEASE_CHECKLIST.md` and `PRIVACY_POLICY.md`. The package ID `com.example.cryptoanalyzer` is a placeholder and must be changed before the first Play release. Host the completed privacy policy at a public HTTPS URL, fill in the real developer contact email, complete the Data safety and Financial features declarations, sign a release AAB, and configure Play App Signing. Enable Protected with Play / Automatic protection in Play Console if available.

**No guarantee of Google Play approval is possible from source changes alone.** The app has not been built in this environment; CI must pass and the app must be tested before release. The app provides market information only and is not an official Bitget product.
