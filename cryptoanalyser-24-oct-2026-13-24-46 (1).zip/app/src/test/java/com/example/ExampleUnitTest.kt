package com.example

import com.example.data.CryptoMarketRepository
import com.example.domain.TechnicalAnalysisEngine
import com.example.model.DirectionFilter
import com.example.model.ExchangePlatform
import com.example.model.MarketMode
import com.example.model.Timeframe
import com.example.model.TradeDirection
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    private val repository = CryptoMarketRepository()

    @Test
    fun immediateEntry_isStrictlyLogical_forAllFeaturedPairsAndDirections() {
        for (symbol in repository.featuredPairs) {
            for (tf in Timeframe.entries) {
                val candles = repository.generateCalibratedCandles(symbol, tf)

                // 1. Test LONG Immediate Entry, Pullback, and Breakout-Retest
                val longAnalysis = TechnicalAnalysisEngine.analyzeCandles(
                    symbol = symbol,
                    exchange = ExchangePlatform.BITGET,
                    marketMode = MarketMode.FUTURES_USDT,
                    timeframe = tf,
                    candles = candles,
                    directionFilter = DirectionFilter.FORCE_LONG
                )

                for (plan in listOf(
                    longAnalysis.immediateEntryPlan,
                    longAnalysis.pullbackEntryPlan,
                    longAnalysis.breakoutRetestPlan
                )) {
                    assertTrue(
                        "LONG plan ${plan.type} for $symbol must have SL < Entry < TP1 < TP2, got SL=${plan.stopLoss}, Entry=${plan.entryPrice}, TP1=${plan.tp1}, TP2=${plan.tp2}",
                        plan.stopLoss < plan.entryPrice &&
                            plan.entryPrice < plan.tp1 &&
                            plan.tp1 < plan.tp2 &&
                            plan.tp2 < plan.tp3 &&
                            plan.isStrictlyLogical
                    )
                    assertTrue(
                        "LONG plan ${plan.type} for $symbol must have R:R >= 1.5 on TP1 and >= 2.7 on TP2",
                        plan.riskRewardTp1 >= 1.5 && plan.riskRewardTp2 >= 2.7
                    )
                }

                // 2. Test SHORT Immediate Entry, Pullback, and Breakout-Retest
                val shortAnalysis = TechnicalAnalysisEngine.analyzeCandles(
                    symbol = symbol,
                    exchange = ExchangePlatform.BITGET,
                    marketMode = MarketMode.FUTURES_USDT,
                    timeframe = tf,
                    candles = candles,
                    directionFilter = DirectionFilter.FORCE_SHORT
                )

                for (plan in listOf(
                    shortAnalysis.immediateEntryPlan,
                    shortAnalysis.pullbackEntryPlan,
                    shortAnalysis.breakoutRetestPlan
                )) {
                    assertTrue(
                        "SHORT plan ${plan.type} for $symbol must have SL > Entry > TP1 > TP2 > 0, got SL=${plan.stopLoss}, Entry=${plan.entryPrice}, TP1=${plan.tp1}, TP2=${plan.tp2}",
                        plan.stopLoss > plan.entryPrice &&
                            plan.entryPrice > plan.tp1 &&
                            plan.tp1 > plan.tp2 &&
                            plan.tp2 > plan.tp3 &&
                            plan.tp3 > 0.0 &&
                            plan.isStrictlyLogical
                    )
                    assertTrue(
                        "SHORT plan ${plan.type} for $symbol must have R:R >= 1.5 on TP1 and >= 2.7 on TP2",
                        plan.riskRewardTp1 >= 1.5 && plan.riskRewardTp2 >= 2.7
                    )
                }
            }
        }
    }
}
