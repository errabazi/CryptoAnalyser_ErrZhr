package com.example.model

import java.util.Locale
import kotlin.math.abs

enum class AppLanguage(val code: String, val label: String) {
    FR("fr", "Français"),
    AR("ar", "العربية"),
    EN("en", "English")
}

enum class ExchangePlatform(val displayName: String, val badgeColorHex: Long) {
    BITGET("Bitget", 0xFF00DBE8),
    BINANCE("Binance", 0xFFF3BA2F),
    BYBIT("Bybit", 0xFFFFB800),
    OKX("OKX", 0xFF9FDBE4)
}

enum class MarketMode(val labelFr: String, val labelAr: String, val labelEn: String) {
    SPOT("Spot (Comptant)", "فوري (Spot)", "Spot"),
    FUTURES_USDT("Futures USDT", "عقود USDT الدائمة", "USDT Futures");

    fun label(lang: AppLanguage): String = when (lang) {
        AppLanguage.FR -> labelFr
        AppLanguage.AR -> labelAr
        AppLanguage.EN -> labelEn
    }
}

enum class TradeDirection(
    val labelFr: String,
    val labelAr: String,
    val labelEn: String
) {
    LONG("LONG (Achat Sûr)", "شراء (Long)", "LONG (Buy)"),
    SHORT("SHORT (Vente Sûre)", "بيع (Short)", "SHORT (Sell)");

    fun label(lang: AppLanguage): String = when (lang) {
        AppLanguage.FR -> labelFr
        AppLanguage.AR -> labelAr
        AppLanguage.EN -> labelEn
    }
}

enum class DirectionFilter(
    val labelFr: String,
    val labelAr: String,
    val labelEn: String
) {
    AUTO_CONFLUENCE("Auto (100% Logique)", "تلقائي (حسب المؤشرات)", "Auto (Confluence)"),
    FORCE_LONG("Forcer LONG", "شراء Long", "Force LONG"),
    FORCE_SHORT("Forcer SHORT", "بيع Short", "Force SHORT");

    fun label(lang: AppLanguage): String = when (lang) {
        AppLanguage.FR -> labelFr
        AppLanguage.AR -> labelAr
        AppLanguage.EN -> labelEn
    }
}

enum class Timeframe(
    val label: String,
    val bitgetGranularitySpot: String,
    val bitgetGranularityFutures: String,
    val binanceInterval: String
) {
    TF_15M("15m", "15min", "15m", "15m"),
    TF_1H("1H", "1h", "1H", "1h"),
    TF_4H("4H", "4h", "4H", "4h"),
    TF_1D("1D", "1day", "1D", "1d")
}

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

enum class EntryPlanType {
    IMMEDIATE_SAFE_100,
    PULLBACK,
    BREAKOUT_RETEST
}

data class IndicatorVote(
    val id: String,
    val nameFr: String,
    val nameAr: String,
    val nameEn: String,
    val formattedValue: String,
    val signalDirection: TradeDirection?, // null = neutral
    val strengthScore: Int, // 0..100
    val detailFr: String,
    val detailAr: String,
    val detailEn: String
) {
    fun name(lang: AppLanguage): String = when (lang) {
        AppLanguage.FR -> nameFr
        AppLanguage.AR -> nameAr
        AppLanguage.EN -> nameEn
    }

    fun detail(lang: AppLanguage): String = when (lang) {
        AppLanguage.FR -> detailFr
        AppLanguage.AR -> detailAr
        AppLanguage.EN -> detailEn
    }
}

data class IndicatorSnapshot(
    val symbol: String,
    val exchange: ExchangePlatform,
    val marketMode: MarketMode,
    val timeframe: Timeframe,
    val currentPrice: Double,
    val priceChange24hPct: Double,
    val high24h: Double,
    val low24h: Double,
    val volume24hUsdt: Double,
    val ema9: Double,
    val ema21: Double,
    val ema50: Double,
    val ema200: Double,
    val rsi14: Double,
    val rsiAvg14: Double,
    val macdLine: Double,
    val signalLine: Double,
    val macdHistogram: Double,
    val supertrendValue: Double,
    val supertrendBullish: Boolean,
    val atr14: Double,
    val atrPct: Double,
    val vwap: Double,
    val bollingerUpper: Double,
    val bollingerMid: Double,
    val bollingerLower: Double,
    val obv: Double,
    val obvSlopeBullish: Boolean,
    val rvol: Double,
    val buyPressurePct: Double,
    val volumeConfirmed: Boolean,
    val nearestSupport: Double,
    val majorSupport: Double,
    val nearestResistance: Double,
    val majorResistance: Double
)

data class EntryPlan(
    val type: EntryPlanType,
    val direction: TradeDirection,
    val entryPrice: Double,
    val safeEntryZoneLow: Double,
    val safeEntryZoneHigh: Double,
    val stopLoss: Double,
    val tp1: Double,
    val tp2: Double,
    val tp3: Double,
    val riskRewardTp1: Double,
    val riskRewardTp2: Double,
    val slPct: Double,
    val tp1Pct: Double,
    val tp2Pct: Double,
    val confidenceScore: Int, // 0..100%
    val isStrictlyLogical: Boolean,
    val logicalInequalityProof: String,
    val titleFr: String,
    val titleAr: String,
    val titleEn: String,
    val subtitleFr: String,
    val subtitleAr: String,
    val subtitleEn: String,
    val logicReasoningFr: String,
    val logicReasoningAr: String,
    val logicReasoningEn: String
) {
    fun title(lang: AppLanguage): String = when (lang) {
        AppLanguage.FR -> titleFr
        AppLanguage.AR -> titleAr
        AppLanguage.EN -> titleEn
    }

    fun subtitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.FR -> subtitleFr
        AppLanguage.AR -> subtitleAr
        AppLanguage.EN -> subtitleEn
    }

    fun reasoning(lang: AppLanguage): String = when (lang) {
        AppLanguage.FR -> logicReasoningFr
        AppLanguage.AR -> logicReasoningAr
        AppLanguage.EN -> logicReasoningEn
    }
}

data class FullAnalysisResult(
    val snapshot: IndicatorSnapshot,
    val candles: List<Candle>,
    val macdSeries: List<Triple<Double, Double, Double>>, // macd, signal, hist
    val recommendedDirection: TradeDirection,
    val activeDirection: TradeDirection,
    val globalConfluenceScore: Int, // 0..100%
    val indicatorVotes: List<IndicatorVote>,
    val immediateEntryPlan: EntryPlan,
    val pullbackEntryPlan: EntryPlan,
    val breakoutRetestPlan: EntryPlan,
    val isLiveNetworkData: Boolean,
    val timestampLabel: String
)

data class MarketAlertItem(
    val id: String,
    val symbol: String,
    val exchange: ExchangePlatform,
    val price: Double,
    val change24hPct: Double,
    val recentImpulsePct: Double,
    val rvol: Double,
    val direction: TradeDirection,
    val confidenceScore: Int,
    val immediateSafeEntry: Double,
    val stopLoss: Double,
    val tp1: Double,
    val tp2: Double,
    val timeAgoLabel: String,
    val headlineFr: String,
    val headlineAr: String,
    val headlineEn: String
) {
    fun headline(lang: AppLanguage): String = when (lang) {
        AppLanguage.FR -> headlineFr
        AppLanguage.AR -> headlineAr
        AppLanguage.EN -> headlineEn
    }
}

data class LiveCryptoAsset(
    val symbol: String,
    val baseAsset: String,
    val name: String,
    val exchange: ExchangePlatform,
    val currentPrice: Double,
    val change24hPct: Double,
    val volume24hUsdt: Double,
    val sparkline: List<Double>,
    val trendDirection: TradeDirection,
    val confluenceScore: Int,
    val safeImmediateEntry: Double,
    val stopLoss: Double,
    val tp1: Double,
    val tp2: Double,
    val isLiveNetwork: Boolean
)

data class PreMoveEarlyAlert(
    val id: String,
    val symbol: String,
    val exchange: ExchangePlatform,
    val direction: TradeDirection, // LONG = Hausse Forte, SHORT = Baisse Forte
    val currentPrice: Double,
    val safeImmediateEntry: Double,
    val stopLoss: Double,
    val tp1: Double,
    val tp2: Double,
    val expectedMovePct: Double,
    val probabilityPct: Int,
    val rvol: Double,
    val buyPressurePct: Double,
    val leadSecondsRemaining: Int = 60, // 60 seconds (1 minute) advance warning
    val triggerReasonsFr: String,
    val triggerReasonsAr: String,
    val triggerReasonsEn: String,
    val detectedAtTime: String
) {
    fun triggerReason(lang: AppLanguage): String = when (lang) {
        AppLanguage.FR -> triggerReasonsFr
        AppLanguage.AR -> triggerReasonsAr
        AppLanguage.EN -> triggerReasonsEn
    }
}

object CryptoPriceFormatter {
    fun formatPrice(price: Double): String {
        val absVal = abs(price)
        return when {
            absVal == 0.0 -> "0.00"
            absVal >= 1000.0 -> String.format(Locale.US, "%.2f", price)
            absVal >= 10.0 -> String.format(Locale.US, "%.3f", price)
            absVal >= 1.0 -> String.format(Locale.US, "%.4f", price)
            absVal >= 0.01 -> String.format(Locale.US, "%.6f", price)
            else -> String.format(Locale.US, "%.8f", price)
        }
    }

    fun formatSignedPct(pct: Double): String {
        val sign = if (pct >= 0) "+" else ""
        return "$sign${String.format(Locale.US, "%.2f", pct)}%"
    }

    fun formatCompactVolume(vol: Double): String {
        val absVol = abs(vol)
        val sign = if (vol < 0) "-" else "+"
        return when {
            absVol >= 1_000_000_000.0 -> "${sign}${String.format(Locale.US, "%.2fB", absVol / 1_000_000_000.0)}"
            absVol >= 1_000_000.0 -> "${sign}${String.format(Locale.US, "%.2fM", absVol / 1_000_000.0)}"
            absVol >= 1_000.0 -> "${sign}${String.format(Locale.US, "%.1fK", absVol / 1_000.0)}"
            else -> "${sign}${String.format(Locale.US, "%.0f", absVol)}"
        }
    }
}
