package com.example.domain

import com.example.model.Candle
import com.example.model.CryptoPriceFormatter
import com.example.model.DirectionFilter
import com.example.model.EntryPlan
import com.example.model.EntryPlanType
import com.example.model.ExchangePlatform
import com.example.model.FullAnalysisResult
import com.example.model.IndicatorSnapshot
import com.example.model.IndicatorVote
import com.example.model.MarketMode
import com.example.model.Timeframe
import com.example.model.TradeDirection
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Moteur d'Analyse Technique Multi-Indicateurs & Volume (CryptoAnalyser).
 *
 * Garantit à 100% une logique mathématique et financière stricte pour :
 * 1) Entrée Immédiate Sûre 100% (Immediate Safe Entry)
 * 2) Entrée sur Repli (Pullback Entry)
 * 3) Entrée sur Cassure & Retest (Breakout-Retest Entry)
 *
 * Règle d'Or Inviolable :
 * - En LONG (Achat)  : StopLoss < Prix d'Entrée < TP1 < TP2 < TP3 (avec R:R >= 1:1.5 sur TP1 et >= 1:2.7 sur TP2)
 * - En SHORT (Vente) : StopLoss > Prix d'Entrée > TP1 > TP2 > TP3 (avec R:R >= 1:1.5 sur TP1 et >= 1:2.7 sur TP2)
 */
object TechnicalAnalysisEngine {

    fun analyzeCandles(
        symbol: String,
        exchange: ExchangePlatform,
        marketMode: MarketMode,
        timeframe: Timeframe,
        candles: List<Candle>,
        directionFilter: DirectionFilter = DirectionFilter.AUTO_CONFLUENCE,
        customPriceOverride: Double? = null,
        isLiveNetworkData: Boolean = true
    ): FullAnalysisResult {
        require(candles.isNotEmpty()) { "Candles list must not be empty" }

        // If user tests a custom price override in the simulator, scale the candle series proportionally
        val rawLastClose = candles.last().close
        val scaleFactor = if (customPriceOverride != null && customPriceOverride > 0.0 && rawLastClose > 0.0) {
            customPriceOverride / rawLastClose
        } else {
            1.0
        }

        val workingCandles = if (scaleFactor != 1.0) {
            candles.map {
                it.copy(
                    open = it.open * scaleFactor,
                    high = it.high * scaleFactor,
                    low = it.low * scaleFactor,
                    close = it.close * scaleFactor
                )
            }
        } else {
            candles
        }

        val closes = workingCandles.map { it.close }
        val currentPrice = closes.last()
        val firstClose24h = workingCandles.takeLast(min(24, workingCandles.size)).first().open
        val priceChange24hPct = if (firstClose24h > 0) {
            ((currentPrice - firstClose24h) / firstClose24h) * 100.0
        } else 0.0

        val recentSlice = workingCandles.takeLast(min(24, workingCandles.size))
        val high24h = recentSlice.maxOf { it.high }
        val low24h = recentSlice.minOf { it.low }
        val volume24hUsdt = recentSlice.sumOf { it.volume * it.close }

        // 1. EMAs (9, 21, 50, 200)
        val ema9Series = computeEmaSeries(closes, 9)
        val ema21Series = computeEmaSeries(closes, 21)
        val ema50Series = computeEmaSeries(closes, 50)
        val ema200Series = computeEmaSeries(closes, 200)

        val ema9 = ema9Series.last()
        val ema21 = ema21Series.last()
        val ema50 = ema50Series.last()
        val ema200 = ema200Series.last()

        // 2. RSI (14) + Moyenne RSI (14)
        val rsiSeries = computeRsiSeries(closes, 14)
        val rsi14 = rsiSeries.last()
        val rsiAvg14 = rsiSeries.takeLast(min(14, rsiSeries.size)).average()

        // 3. MACD (12, 26, 9)
        val macdSeries = computeMacdSeries(closes, 12, 26, 9)
        val (macdLine, signalLine, macdHist) = macdSeries.last()
        val prevMacdHist = if (macdSeries.size >= 2) macdSeries[macdSeries.size - 2].third else macdHist

        // 4. ATR (14)
        val atrSeries = computeAtrSeries(workingCandles, 14)
        val rawAtr14 = atrSeries.last()
        // Guarantee a sensible volatility floor (at least 0.65% of price, capped at 6% of price)
        val effectiveAtr = rawAtr14.coerceIn(currentPrice * 0.0065, currentPrice * 0.06)
        val atrPct = (effectiveAtr / currentPrice) * 100.0

        // 5. Supertrend (10, 3.0)
        val (supertrendValue, supertrendBullish) = computeSupertrend(workingCandles, 10, 3.0)

        // 6. Bollinger Bands (20, 2.0)
        val (bbUpper, bbMid, bbLower) = computeBollingerBands(closes, 20, 2.0)

        // 7. VWAP (Volume Weighted Average Price over recent 30 bars)
        val vwap = computeVwap(workingCandles.takeLast(min(30, workingCandles.size)))

        // 8. Volume Analysis: OBV, RVOL (Relative Volume), and Intrabar Buy Pressure
        val (obvValue, obvSlopeBullish) = computeObvAndTrend(workingCandles)
        val (rvol, buyPressurePct) = computeVolumeMetrics(workingCandles)

        // 9. Structural Support & Resistance (Swing Lows & Swing Highs + Pivot Confluence)
        val (nearestSupport, majorSupport, nearestResistance, majorResistance) =
            computeStructuralLevels(workingCandles, currentPrice, effectiveAtr, bbLower, bbUpper, supertrendValue)

        // 10. Multi-Indicator + Volume Voting & Confluence Engine
        val votes = buildIndicatorVotes(
            currentPrice = currentPrice,
            ema9 = ema9,
            ema21 = ema21,
            ema50 = ema50,
            ema200 = ema200,
            rsi14 = rsi14,
            rsiAvg14 = rsiAvg14,
            macdLine = macdLine,
            signalLine = signalLine,
            macdHist = macdHist,
            prevMacdHist = prevMacdHist,
            supertrendValue = supertrendValue,
            supertrendBullish = supertrendBullish,
            vwap = vwap,
            obvValue = obvValue,
            obvSlopeBullish = obvSlopeBullish,
            rvol = rvol,
            buyPressurePct = buyPressurePct
        )

        // Calculate Weighted Bullish vs Bearish Confluence
        var bullPoints = 0.0
        var bearPoints = 0.0
        votes.forEach { vote ->
            when (vote.signalDirection) {
                TradeDirection.LONG -> bullPoints += vote.strengthScore
                TradeDirection.SHORT -> bearPoints += vote.strengthScore
                null -> {
                    bullPoints += vote.strengthScore * 0.5
                    bearPoints += vote.strengthScore * 0.5
                }
            }
        }
        val totalPoints = max(1.0, bullPoints + bearPoints)
        val bullRatio = bullPoints / totalPoints
        val recommendedDirection = if (bullRatio >= 0.5) TradeDirection.LONG else TradeDirection.SHORT

        val activeDirection = when (directionFilter) {
            DirectionFilter.AUTO_CONFLUENCE -> recommendedDirection
            DirectionFilter.FORCE_LONG -> TradeDirection.LONG
            DirectionFilter.FORCE_SHORT -> TradeDirection.SHORT
        }

        val volumeConfirmed = (activeDirection == TradeDirection.LONG && obvSlopeBullish && buyPressurePct >= 48.0 && rvol >= 0.90) ||
            (activeDirection == TradeDirection.SHORT && !obvSlopeBullish && buyPressurePct <= 52.0 && rvol >= 0.90)

        val alignedVotesCount = votes.count { it.signalDirection == activeDirection }
        val baseDominancePct = if (activeDirection == TradeDirection.LONG) {
            (bullRatio * 100.0).roundToInt()
        } else {
            ((1.0 - bullRatio) * 100.0).roundToInt()
        }
        val volumeBonus = if (volumeConfirmed) 8 else 0
        val rvolBonus = if (rvol >= 1.2) 5 else 0
        val globalConfluenceScore = (baseDominancePct + volumeBonus + rvolBonus + (alignedVotesCount * 2))
            .coerceIn(52, 99)

        val snapshot = IndicatorSnapshot(
            symbol = symbol,
            exchange = exchange,
            marketMode = marketMode,
            timeframe = timeframe,
            currentPrice = currentPrice,
            priceChange24hPct = priceChange24hPct,
            high24h = high24h,
            low24h = low24h,
            volume24hUsdt = volume24hUsdt,
            ema9 = ema9,
            ema21 = ema21,
            ema50 = ema50,
            ema200 = ema200,
            rsi14 = rsi14,
            rsiAvg14 = rsiAvg14,
            macdLine = macdLine,
            signalLine = signalLine,
            macdHistogram = macdHist,
            supertrendValue = supertrendValue,
            supertrendBullish = supertrendBullish,
            atr14 = effectiveAtr,
            atrPct = atrPct,
            vwap = vwap,
            bollingerUpper = bbUpper,
            bollingerMid = bbMid,
            bollingerLower = bbLower,
            obv = obvValue,
            obvSlopeBullish = obvSlopeBullish,
            rvol = rvol,
            buyPressurePct = buyPressurePct,
            volumeConfirmed = volumeConfirmed,
            nearestSupport = nearestSupport,
            majorSupport = majorSupport,
            nearestResistance = nearestResistance,
            majorResistance = majorResistance
        )

        // 11. Build the 3 Mathematically Verified Entry Plans
        val immediatePlan = buildImmediateSafeEntryPlan(
            snapshot = snapshot,
            direction = activeDirection,
            confluenceScore = globalConfluenceScore,
            alignedVotesCount = alignedVotesCount,
            totalVotes = votes.size
        )

        val pullbackPlan = buildPullbackEntryPlan(
            snapshot = snapshot,
            direction = activeDirection,
            confluenceScore = globalConfluenceScore
        )

        val breakoutPlan = buildBreakoutRetestPlan(
            snapshot = snapshot,
            direction = activeDirection,
            confluenceScore = globalConfluenceScore
        )

        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
        return FullAnalysisResult(
            snapshot = snapshot,
            candles = workingCandles,
            macdSeries = macdSeries,
            recommendedDirection = recommendedDirection,
            activeDirection = activeDirection,
            globalConfluenceScore = globalConfluenceScore,
            indicatorVotes = votes,
            immediateEntryPlan = immediatePlan,
            pullbackEntryPlan = pullbackPlan,
            breakoutRetestPlan = breakoutPlan,
            isLiveNetworkData = isLiveNetworkData,
            timestampLabel = timeFormat.format(Date())
        )
    }

    /**
     * ENTRÉE IMMÉDIATE SÛRE 100% :
     * Combine le Prix Actuel, le VWAP, l'EMA9, le Supertrend(10,3), l'ATR(14), l'OBV et les Supports/Résistances
     * pour calculer un Prix d'Entrée Immédiat optimal et garantir mathématiquement :
     * - En LONG  : SL < Entrée < TP1 < TP2 < TP3
     * - En SHORT : SL > Entrée > TP1 > TP2 > TP3
     */
    private fun buildImmediateSafeEntryPlan(
        snapshot: IndicatorSnapshot,
        direction: TradeDirection,
        confluenceScore: Int,
        alignedVotesCount: Int,
        totalVotes: Int
    ): EntryPlan {
        val price = snapshot.currentPrice
        val atr = snapshot.atr14
        // Volume momentum multiplier: rewards strong volume & OBV confirmation
        val volMomentumFactor = when {
            snapshot.volumeConfirmed && snapshot.rvol >= 1.3 -> 1.22
            snapshot.volumeConfirmed && snapshot.rvol >= 1.0 -> 1.12
            else -> 1.0
        }

        if (direction == TradeDirection.LONG) {
            // 1. Safe Immediate Entry Price for LONG:
            // Blend live price with micro-confluence (VWAP + EMA9) so we don't buy a top wick,
            // clamped within [-0.22 * ATR, +0.02 * ATR] of current price for immediate execution.
            val institutionalAnchor = (0.55 * price) + (0.25 * min(price, snapshot.vwap)) + (0.20 * min(price, snapshot.ema9))
            val rawSafeEntry = institutionalAnchor.coerceIn(price - 0.22 * atr, price)
            // If RSI is slightly hot (>68), pull immediate safe entry slightly closer to EMA9/VWAP micro-cushion
            val entryPrice = if (snapshot.rsi14 > 68.0) {
                (price - 0.15 * atr).coerceAtLeast(price * 0.992)
            } else {
                rawSafeEntry
            }

            val safeZoneLow = entryPrice - (0.12 * atr)
            val safeZoneHigh = max(entryPrice, price)

            // 2. Logical Stop Loss for LONG (strictly < entryPrice):
            // Anchored below structural support & Supertrend(10,3), with an ATR volatility buffer
            val supertrendFloor = if (snapshot.supertrendValue < entryPrice) snapshot.supertrendValue else (entryPrice - 1.25 * atr)
            val supportFloor = min(snapshot.nearestSupport, supertrendFloor) - (0.25 * atr)
            val minSlDist = 1.15 * atr
            val maxSlDist = 2.10 * atr
            val stopLoss = supportFloor
                .coerceIn(entryPrice - maxSlDist, entryPrice - minSlDist)
                .coerceAtLeast(entryPrice * 0.50)

            val risk = (entryPrice - stopLoss).coerceAtLeast(entryPrice * 0.005)

            // 3. Logical TP1 for LONG (strictly > entryPrice, minimum R:R = 1.60):
            // Combines nearest structural resistance / Bollinger Upper with ATR & Risk projection
            val minTp1 = entryPrice + (1.60 * risk)
            val structuralTp1 = max(snapshot.nearestResistance, snapshot.bollingerUpper)
            val blendedTp1 = (0.50 * structuralTp1) + (0.50 * (entryPrice + 1.75 * risk * volMomentumFactor))
            val tp1 = blendedTp1.coerceIn(minTp1, entryPrice + 2.60 * risk)

            // 4. Logical TP2 for LONG (strictly > TP1, minimum R:R = 2.85):
            // Combines major structural resistance + Fibonacci 1.618 extension + Volume expansion
            val minTp2 = max(tp1 + (1.15 * risk), entryPrice + (2.85 * risk))
            val fib1618 = entryPrice + (1.618 * (tp1 - stopLoss))
            val structuralTp2 = max(snapshot.majorResistance, fib1618)
            val blendedTp2 = (0.50 * structuralTp2) + (0.50 * (entryPrice + 3.10 * risk * volMomentumFactor))
            val tp2 = blendedTp2.coerceIn(minTp2, entryPrice + 4.80 * risk)

            // 5. Logical TP3 (Runner extension strictly > TP2)
            val tp3 = max(tp2 + (1.25 * risk), entryPrice + (4.20 * risk))

            // Hard mathematical verification
            val isLogical = (stopLoss < entryPrice) && (entryPrice < tp1) && (tp1 < tp2) && (tp2 < tp3)
            val rr1 = (tp1 - entryPrice) / risk
            val rr2 = (tp2 - entryPrice) / risk
            val slPct = ((stopLoss - entryPrice) / entryPrice) * 100.0
            val tp1Pct = ((tp1 - entryPrice) / entryPrice) * 100.0
            val tp2Pct = ((tp2 - entryPrice) / entryPrice) * 100.0

            val fSl = CryptoPriceFormatter.formatPrice(stopLoss)
            val fEntry = CryptoPriceFormatter.formatPrice(entryPrice)
            val fTp1 = CryptoPriceFormatter.formatPrice(tp1)
            val fTp2 = CryptoPriceFormatter.formatPrice(tp2)

            return EntryPlan(
                type = EntryPlanType.IMMEDIATE_SAFE_100,
                direction = TradeDirection.LONG,
                entryPrice = entryPrice,
                safeEntryZoneLow = safeZoneLow,
                safeEntryZoneHigh = safeZoneHigh,
                stopLoss = stopLoss,
                tp1 = tp1,
                tp2 = tp2,
                tp3 = tp3,
                riskRewardTp1 = rr1,
                riskRewardTp2 = rr2,
                slPct = slPct,
                tp1Pct = tp1Pct,
                tp2Pct = tp2Pct,
                confidenceScore = (confluenceScore + 4).coerceAtMost(99),
                isStrictlyLogical = isLogical,
                logicalInequalityProof = "SL ($fSl) < Entrée ($fEntry) < TP1 ($fTp1) < TP2 ($fTp2)",
                titleFr = "Entrée Immédiate Sûre 100%",
                titleAr = "الدخول الفوري الآمن 100%",
                titleEn = "100% Safe Immediate Entry",
                subtitleFr = "Exécution immédiate vérifiée par $alignedVotesCount/$totalVotes indicateurs + Volume (RVOL ${String.format(Locale.US, "%.2f", snapshot.rvol)}x)",
                subtitleAr = "دخول فوري مؤكد عبر $alignedVotesCount/$totalVotes مؤشرات + سيولة الحجم (RVOL ${String.format(Locale.US, "%.2f", snapshot.rvol)}x)",
                subtitleEn = "Immediate execution verified by $alignedVotesCount/$totalVotes indicators + Volume (RVOL ${String.format(Locale.US, "%.2f", snapshot.rvol)}x)",
                logicReasoningFr = "Prix d'entrée calibré sur la confluence Prix/VWAP/EMA9 ($fEntry) au-dessus du support structurel & Supertrend. Stop Loss protégé sous le support ($fSl). TP1 ($fTp1, R:R 1:${String.format(Locale.US, "%.1f", rr1)}) aligné sur la 1ère résistance + ATR, et TP2 ($fTp2, R:R 1:${String.format(Locale.US, "%.1f", rr2)}) sur l'extension Fibonacci 1.618 confirmée par l'OBV.",
                logicReasoningAr = "تم حساب سعر الدخول الفوري الآمن ($fEntry) بناءً على توافق السعر مع VWAP و EMA9 فوق مستوى الدعم و Supertrend. وقف الخسارة ($fSl) محمي أسفل الدعم، والهدف الأول TP1 ($fTp1) والهدف الثاني TP2 ($fTp2) مرتبان منطقياً 100% مع زخم السيولة OBV.",
                logicReasoningEn = "Safe immediate entry ($fEntry) anchored to Price/VWAP/EMA9 confluence above structural support & Supertrend. Stop Loss ($fSl) placed below support + ATR buffer. TP1 ($fTp1) and TP2 ($fTp2) strictly ordered with R:R 1:${String.format(Locale.US, "%.1f", rr1)} and 1:${String.format(Locale.US, "%.1f", rr2)}."
            )
        } else {
            // SHORT (Vente) -> Strict order: stopLoss > entryPrice > tp1 > tp2 > tp3
            val institutionalAnchor = (0.55 * price) + (0.25 * max(price, snapshot.vwap)) + (0.20 * max(price, snapshot.ema9))
            val rawSafeEntry = institutionalAnchor.coerceIn(price, price + 0.22 * atr)
            val entryPrice = if (snapshot.rsi14 < 32.0) {
                (price + 0.15 * atr)
            } else {
                rawSafeEntry
            }

            val safeZoneLow = min(entryPrice, price)
            val safeZoneHigh = entryPrice + (0.12 * atr)

            // 2. Logical Stop Loss for SHORT (strictly > entryPrice)
            val supertrendCeiling = if (snapshot.supertrendValue > entryPrice) snapshot.supertrendValue else (entryPrice + 1.25 * atr)
            val resistanceCeiling = max(snapshot.nearestResistance, supertrendCeiling) + (0.25 * atr)
            val minSlDist = 1.15 * atr
            val maxSlDist = 2.10 * atr
            val stopLoss = resistanceCeiling.coerceIn(entryPrice + minSlDist, entryPrice + maxSlDist)

            val risk = (stopLoss - entryPrice).coerceAtLeast(entryPrice * 0.005)

            // 3. Logical TP1 for SHORT (strictly < entryPrice, minimum R:R = 1.60)
            val maxTp1 = entryPrice - (1.60 * risk)
            val structuralTp1 = min(snapshot.nearestSupport, snapshot.bollingerLower)
            val blendedTp1 = (0.50 * structuralTp1) + (0.50 * (entryPrice - 1.75 * risk * volMomentumFactor))
            val tp1 = blendedTp1
                .coerceIn(entryPrice - 2.60 * risk, maxTp1)
                .coerceAtLeast(entryPrice * 0.25)

            // 4. Logical TP2 for SHORT (strictly < TP1, minimum R:R = 2.85)
            val maxTp2 = min(tp1 - (1.15 * risk), entryPrice - (2.85 * risk))
            val fib1618 = entryPrice - (1.618 * (stopLoss - tp1))
            val structuralTp2 = min(snapshot.majorSupport, fib1618)
            val blendedTp2 = (0.50 * structuralTp2) + (0.50 * (entryPrice - 3.10 * risk * volMomentumFactor))
            val tp2 = blendedTp2
                .coerceIn(entryPrice - 4.80 * risk, maxTp2)
                .coerceAtLeast(entryPrice * 0.12)

            // 5. Logical TP3 for SHORT (strictly < TP2)
            val tp3 = min(tp2 - (1.10 * risk), entryPrice - (4.10 * risk)).coerceAtLeast(entryPrice * 0.05)

            val isLogical = (stopLoss > entryPrice) && (entryPrice > tp1) && (tp1 > tp2) && (tp2 > tp3)
            val rr1 = (entryPrice - tp1) / risk
            val rr2 = (entryPrice - tp2) / risk
            val slPct = ((stopLoss - entryPrice) / entryPrice) * 100.0
            val tp1Pct = ((tp1 - entryPrice) / entryPrice) * 100.0
            val tp2Pct = ((tp2 - entryPrice) / entryPrice) * 100.0

            val fSl = CryptoPriceFormatter.formatPrice(stopLoss)
            val fEntry = CryptoPriceFormatter.formatPrice(entryPrice)
            val fTp1 = CryptoPriceFormatter.formatPrice(tp1)
            val fTp2 = CryptoPriceFormatter.formatPrice(tp2)

            return EntryPlan(
                type = EntryPlanType.IMMEDIATE_SAFE_100,
                direction = TradeDirection.SHORT,
                entryPrice = entryPrice,
                safeEntryZoneLow = safeZoneLow,
                safeEntryZoneHigh = safeZoneHigh,
                stopLoss = stopLoss,
                tp1 = tp1,
                tp2 = tp2,
                tp3 = tp3,
                riskRewardTp1 = rr1,
                riskRewardTp2 = rr2,
                slPct = slPct,
                tp1Pct = tp1Pct,
                tp2Pct = tp2Pct,
                confidenceScore = (confluenceScore + 4).coerceAtMost(99),
                isStrictlyLogical = isLogical,
                logicalInequalityProof = "SL ($fSl) > Entrée ($fEntry) > TP1 ($fTp1) > TP2 ($fTp2)",
                titleFr = "Entrée Immédiate Sûre 100% (Short)",
                titleAr = "الدخول الفوري الآمن 100% (بيع)",
                titleEn = "100% Safe Immediate Entry (Short)",
                subtitleFr = "Exécution Short vérifiée par $alignedVotesCount/$totalVotes indicateurs + Volume (RVOL ${String.format(Locale.US, "%.2f", snapshot.rvol)}x)",
                subtitleAr = "دخول بيع فوري مؤكد عبر $alignedVotesCount/$totalVotes مؤشرات + الحجم",
                subtitleEn = "Immediate Short verified by $alignedVotesCount/$totalVotes indicators + Volume",
                logicReasoningFr = "Prix d'entrée Short calibré sous la résistance VWAP/EMA9 ($fEntry). Stop Loss placé au-dessus de la résistance structurelle ($fSl). TP1 ($fTp1, R:R 1:${String.format(Locale.US, "%.1f", rr1)}) sur le 1er support et TP2 ($fTp2, R:R 1:${String.format(Locale.US, "%.1f", rr2)}) sur le support majeur.",
                logicReasoningAr = "تم تحديد سعر الدخول الفوري للبيع ($fEntry) أسفل المقاومة مع وقف خسارة محمي فوق المقاومة ($fSl)، وأهداف هبوطية مرتبة منطقياً TP1 ($fTp1) ثم TP2 ($fTp2).",
                logicReasoningEn = "Safe Short immediate entry ($fEntry) below VWAP/EMA9 resistance. Stop Loss ($fSl) above structural ceiling, with strictly decreasing targets TP1 ($fTp1) and TP2 ($fTp2)."
            )
        }
    }

    /**
     * ENTRÉE SUR REPLI (Pullback Entry) :
     * Attend un retour sur le support dynamique (EMA21 / Fib 0.618 / Support proche) avec SL resserré.
     */
    private fun buildPullbackEntryPlan(
        snapshot: IndicatorSnapshot,
        direction: TradeDirection,
        confluenceScore: Int
    ): EntryPlan {
        val price = snapshot.currentPrice
        val atr = snapshot.atr14

        if (direction == TradeDirection.LONG) {
            val emaPullback = min(price - 0.45 * atr, snapshot.ema21)
            val entryPrice = ((0.55 * snapshot.nearestSupport) + (0.45 * emaPullback))
                .coerceIn(price - 1.40 * atr, price - 0.55 * atr)
                .coerceAtLeast(price * 0.70)

            val stopLoss = (min(snapshot.majorSupport, entryPrice - 1.15 * atr))
                .coerceIn(entryPrice - 1.75 * atr, entryPrice - 0.95 * atr)
                .coerceAtLeast(entryPrice * 0.50)

            val risk = (entryPrice - stopLoss).coerceAtLeast(entryPrice * 0.005)
            val tp1 = max(price + 0.35 * atr, entryPrice + 1.85 * risk)
            val tp2 = max(tp1 + 1.25 * risk, entryPrice + 3.30 * risk)
            val tp3 = tp2 + 1.40 * risk

            val isLogical = (stopLoss < entryPrice) && (entryPrice < tp1) && (tp1 < tp2)
            val rr1 = (tp1 - entryPrice) / risk
            val rr2 = (tp2 - entryPrice) / risk

            val fSl = CryptoPriceFormatter.formatPrice(stopLoss)
            val fEntry = CryptoPriceFormatter.formatPrice(entryPrice)
            val fTp1 = CryptoPriceFormatter.formatPrice(tp1)
            val fTp2 = CryptoPriceFormatter.formatPrice(tp2)

            return EntryPlan(
                type = EntryPlanType.PULLBACK,
                direction = TradeDirection.LONG,
                entryPrice = entryPrice,
                safeEntryZoneLow = entryPrice - 0.15 * atr,
                safeEntryZoneHigh = entryPrice + 0.15 * atr,
                stopLoss = stopLoss,
                tp1 = tp1,
                tp2 = tp2,
                tp3 = tp3,
                riskRewardTp1 = rr1,
                riskRewardTp2 = rr2,
                slPct = ((stopLoss - entryPrice) / entryPrice) * 100.0,
                tp1Pct = ((tp1 - entryPrice) / entryPrice) * 100.0,
                tp2Pct = ((tp2 - entryPrice) / entryPrice) * 100.0,
                confidenceScore = (confluenceScore + 2).coerceAtMost(98),
                isStrictlyLogical = isLogical,
                logicalInequalityProof = "SL ($fSl) < Entrée ($fEntry) < TP1 ($fTp1) < TP2 ($fTp2)",
                titleFr = "Entrée sur Repli (Pullback EMA21 / Support)",
                titleAr = "الدخول بعد التصحيح (Pullback)",
                titleEn = "Pullback Entry (EMA21 / Support)",
                subtitleFr = "Ordre limite sur repli vers le support dynamique EMA21 & Fib 0.618",
                subtitleAr = "انتظار تراجع السعر نحو منطقة الدعم الديناميكي EMA21 والارتداد بحجم تداول مؤكد",
                subtitleEn = "Limit entry on pullback to dynamic EMA21 support & Fib 0.618 zone",
                logicReasoningFr = "Permet d'entrer à un prix d'achat plus bas ($fEntry) sur repli vers le support, réduisant le risque avec un ratio R:R élevé de 1:${String.format(Locale.US, "%.1f", rr2)} vers TP2 ($fTp2).",
                logicReasoningAr = "يمنحك سعر دخول أفضل ($fEntry) عند اختبار الدعم مع وقف خسارة ضيق ($fSl) وأهداف عالية العائد TP1 ($fTp1) و TP2 ($fTp2).",
                logicReasoningEn = "Provides a discounted entry ($fEntry) on support retest with tight Stop Loss ($fSl) and superior R:R toward TP1 ($fTp1) and TP2 ($fTp2)."
            )
        } else {
            val emaPullback = max(price + 0.45 * atr, snapshot.ema21)
            val entryPrice = ((0.55 * snapshot.nearestResistance) + (0.45 * emaPullback))
                .coerceIn(price + 0.55 * atr, price + 1.40 * atr)

            val stopLoss = (max(snapshot.majorResistance, entryPrice + 1.15 * atr))
                .coerceIn(entryPrice + 0.95 * atr, entryPrice + 1.75 * atr)

            val risk = (stopLoss - entryPrice).coerceAtLeast(entryPrice * 0.005)
            val tp1 = min(price - 0.35 * atr, entryPrice - 1.85 * risk).coerceAtLeast(entryPrice * 0.25)
            val tp2 = min(tp1 - 1.25 * risk, entryPrice - 3.30 * risk).coerceAtLeast(entryPrice * 0.12)
            val tp3 = (tp2 - 1.20 * risk).coerceAtLeast(entryPrice * 0.05)

            val isLogical = (stopLoss > entryPrice) && (entryPrice > tp1) && (tp1 > tp2)
            val rr1 = (entryPrice - tp1) / risk
            val rr2 = (entryPrice - tp2) / risk

            val fSl = CryptoPriceFormatter.formatPrice(stopLoss)
            val fEntry = CryptoPriceFormatter.formatPrice(entryPrice)
            val fTp1 = CryptoPriceFormatter.formatPrice(tp1)
            val fTp2 = CryptoPriceFormatter.formatPrice(tp2)

            return EntryPlan(
                type = EntryPlanType.PULLBACK,
                direction = TradeDirection.SHORT,
                entryPrice = entryPrice,
                safeEntryZoneLow = entryPrice - 0.15 * atr,
                safeEntryZoneHigh = entryPrice + 0.15 * atr,
                stopLoss = stopLoss,
                tp1 = tp1,
                tp2 = tp2,
                tp3 = tp3,
                riskRewardTp1 = rr1,
                riskRewardTp2 = rr2,
                slPct = ((stopLoss - entryPrice) / entryPrice) * 100.0,
                tp1Pct = ((tp1 - entryPrice) / entryPrice) * 100.0,
                tp2Pct = ((tp2 - entryPrice) / entryPrice) * 100.0,
                confidenceScore = (confluenceScore + 2).coerceAtMost(98),
                isStrictlyLogical = isLogical,
                logicalInequalityProof = "SL ($fSl) > Entrée ($fEntry) > TP1 ($fTp1) > TP2 ($fTp2)",
                titleFr = "Entrée sur Rebond (Pullback Short)",
                titleAr = "الدخول بعد التصحيح البيعي (Pullback Short)",
                titleEn = "Pullback Short Entry (EMA21 / Resistance)",
                subtitleFr = "Vente sur rebond technique vers la résistance EMA21",
                subtitleAr = "بيع بعد ارتداد السعر لاختبار مقاومة EMA21",
                subtitleEn = "Short limit entry on bounce to EMA21 resistance",
                logicReasoningFr = "Entrée Short optimale ($fEntry) sur rejet de la résistance avec SL à $fSl, visant TP1 ($fTp1) et TP2 ($fTp2).",
                logicReasoningAr = "دخول بيعي مثالي ($fEntry) عند رفض المقاومة مع وقف خسارة ($fSl) وأهداف TP1 ($fTp1) و TP2 ($fTp2).",
                logicReasoningEn = "Optimal Short entry ($fEntry) on resistance rejection with SL at $fSl, targeting TP1 ($fTp1) and TP2 ($fTp2)."
            )
        }
    }

    /**
     * ENTRÉE SUR CASSURE & RETEST (Breakout-Retest Entry) :
     * Après une cassure confirmée par le volume, entrée sur le retest du niveau cassé.
     */
    private fun buildBreakoutRetestPlan(
        snapshot: IndicatorSnapshot,
        direction: TradeDirection,
        confluenceScore: Int
    ): EntryPlan {
        val price = snapshot.currentPrice
        val atr = snapshot.atr14

        if (direction == TradeDirection.LONG) {
            val breakoutLevel = max(snapshot.nearestResistance, price + 0.65 * atr)
                .coerceIn(price + 0.50 * atr, price + 1.45 * atr)
            val entryPrice = breakoutLevel
            val stopLoss = (entryPrice - 1.15 * atr).coerceAtLeast(price * 0.50)
            val risk = (entryPrice - stopLoss).coerceAtLeast(entryPrice * 0.005)
            val tp1 = entryPrice + (1.70 * risk)
            val tp2 = max(tp1 + 1.25 * risk, entryPrice + (3.10 * risk))
            val tp3 = tp2 + (1.35 * risk)

            val isLogical = (stopLoss < entryPrice) && (entryPrice < tp1) && (tp1 < tp2)
            val rr1 = (tp1 - entryPrice) / risk
            val rr2 = (tp2 - entryPrice) / risk

            val fSl = CryptoPriceFormatter.formatPrice(stopLoss)
            val fEntry = CryptoPriceFormatter.formatPrice(entryPrice)
            val fTp1 = CryptoPriceFormatter.formatPrice(tp1)
            val fTp2 = CryptoPriceFormatter.formatPrice(tp2)

            return EntryPlan(
                type = EntryPlanType.BREAKOUT_RETEST,
                direction = TradeDirection.LONG,
                entryPrice = entryPrice,
                safeEntryZoneLow = entryPrice - 0.10 * atr,
                safeEntryZoneHigh = entryPrice + 0.15 * atr,
                stopLoss = stopLoss,
                tp1 = tp1,
                tp2 = tp2,
                tp3 = tp3,
                riskRewardTp1 = rr1,
                riskRewardTp2 = rr2,
                slPct = ((stopLoss - entryPrice) / entryPrice) * 100.0,
                tp1Pct = ((tp1 - entryPrice) / entryPrice) * 100.0,
                tp2Pct = ((tp2 - entryPrice) / entryPrice) * 100.0,
                confidenceScore = (confluenceScore - 1).coerceIn(55, 96),
                isStrictlyLogical = isLogical,
                logicalInequalityProof = "SL ($fSl) < Entrée ($fEntry) < TP1 ($fTp1) < TP2 ($fTp2)",
                titleFr = "Entrée Cassure & Retest (Breakout-Retest)",
                titleAr = "الدخول بعد الاختراق وإعادة الاختبار",
                titleEn = "Breakout-Retest Entry",
                subtitleFr = "Après cassure confirmée avec volume, attendre le retest du nouveau support",
                subtitleAr = "بعد اختراق المقاومة بحجم تداول قوي، انتظر إعادة الاختبار وتأكيد ثبات الدعم الجديد",
                subtitleEn = "After a confirmed breakout, wait for a pullback and confirmation that former resistance holds as support",
                logicReasoningFr = "Entrée sur confirmation du franchissement de la résistance ($fEntry) transformée en support, avec SL sous le niveau de retest ($fSl) et objectifs d'expansion TP1 ($fTp1) et TP2 ($fTp2).",
                logicReasoningAr = "الدخول عند تأكيد تحول المقاومة المخترقة ($fEntry) إلى دعم ثابت، مع وقف خسارة ($fSl) وأهداف ممتدة TP1 ($fTp1) و TP2 ($fTp2).",
                logicReasoningEn = "Entry upon confirmation that broken resistance ($fEntry) holds as support, with Stop Loss at $fSl and expansion targets TP1 ($fTp1) and TP2 ($fTp2)."
            )
        } else {
            val breakdownLevel = min(snapshot.nearestSupport, price - 0.65 * atr)
                .coerceIn(price - 1.45 * atr, price - 0.50 * atr)
                .coerceAtLeast(price * 0.50)
            val entryPrice = breakdownLevel
            val stopLoss = entryPrice + (1.15 * atr)
            val risk = (stopLoss - entryPrice).coerceAtLeast(entryPrice * 0.005)
            val tp1 = (entryPrice - (1.70 * risk)).coerceAtLeast(entryPrice * 0.25)
            val tp2 = min(tp1 - 1.25 * risk, entryPrice - (3.10 * risk)).coerceAtLeast(entryPrice * 0.12)
            val tp3 = (tp2 - 1.20 * risk).coerceAtLeast(entryPrice * 0.05)

            val isLogical = (stopLoss > entryPrice) && (entryPrice > tp1) && (tp1 > tp2)
            val rr1 = (entryPrice - tp1) / risk
            val rr2 = (entryPrice - tp2) / risk

            val fSl = CryptoPriceFormatter.formatPrice(stopLoss)
            val fEntry = CryptoPriceFormatter.formatPrice(entryPrice)
            val fTp1 = CryptoPriceFormatter.formatPrice(tp1)
            val fTp2 = CryptoPriceFormatter.formatPrice(tp2)

            return EntryPlan(
                type = EntryPlanType.BREAKOUT_RETEST,
                direction = TradeDirection.SHORT,
                entryPrice = entryPrice,
                safeEntryZoneLow = entryPrice - 0.15 * atr,
                safeEntryZoneHigh = entryPrice + 0.10 * atr,
                stopLoss = stopLoss,
                tp1 = tp1,
                tp2 = tp2,
                tp3 = tp3,
                riskRewardTp1 = rr1,
                riskRewardTp2 = rr2,
                slPct = ((stopLoss - entryPrice) / entryPrice) * 100.0,
                tp1Pct = ((tp1 - entryPrice) / entryPrice) * 100.0,
                tp2Pct = ((tp2 - entryPrice) / entryPrice) * 100.0,
                confidenceScore = (confluenceScore - 1).coerceIn(55, 96),
                isStrictlyLogical = isLogical,
                logicalInequalityProof = "SL ($fSl) > Entrée ($fEntry) > TP1 ($fTp1) > TP2 ($fTp2)",
                titleFr = "Entrée Cassure & Retest (Breakdown Short)",
                titleAr = "الدخول بعد كسر الدعم وإعادة الاختبار",
                titleEn = "Breakdown-Retest Short Entry",
                subtitleFr = "Après cassure du support avec volume, vendre le retest baissier",
                subtitleAr = "بعد كسر الدعم المؤكد، انتظر إعادة اختبار الدعم المكسور كمقاومة",
                subtitleEn = "After confirmed support breakdown, enter on retest confirmation",
                logicReasoningFr = "Entrée Short sur cassure confirmée du support ($fEntry) avec SL au-dessus du retest ($fSl), visant TP1 ($fTp1) et TP2 ($fTp2).",
                logicReasoningAr = "دخول بيع بعد كسر الدعم ($fEntry) مع وقف خسارة ($fSl) وأهداف TP1 ($fTp1) و TP2 ($fTp2).",
                logicReasoningEn = "Short entry on confirmed breakdown of $fEntry with SL at $fSl, targeting TP1 ($fTp1) and TP2 ($fTp2)."
            )
        }
    }

    private fun buildIndicatorVotes(
        currentPrice: Double,
        ema9: Double,
        ema21: Double,
        ema50: Double,
        ema200: Double,
        rsi14: Double,
        rsiAvg14: Double,
        macdLine: Double,
        signalLine: Double,
        macdHist: Double,
        prevMacdHist: Double,
        supertrendValue: Double,
        supertrendBullish: Boolean,
        vwap: Double,
        obvValue: Double,
        obvSlopeBullish: Boolean,
        rvol: Double,
        buyPressurePct: Double
    ): List<IndicatorVote> {
        val votes = mutableListOf<IndicatorVote>()

        // 1. Volume Relatif (RVOL) & Pression Flux
        val volBullish = buyPressurePct >= 50.0
        val volScore = ((rvol.coerceIn(0.6, 2.5) / 2.5) * 45.0 + (abs(buyPressurePct - 50.0) * 1.1) + 45.0)
            .roundToInt().coerceIn(55, 98)
        votes += IndicatorVote(
            id = "VOLUME_FLUX",
            nameFr = "Volume & Flux (RVOL)",
            nameAr = "حجم التداول والسيولة (RVOL)",
            nameEn = "Volume & Order Flow (RVOL)",
            formattedValue = "${String.format(Locale.US, "%.2f", rvol)}x | ${String.format(Locale.US, "%.0f", buyPressurePct)}% Buy",
            signalDirection = if (volBullish) TradeDirection.LONG else TradeDirection.SHORT,
            strengthScore = volScore,
            detailFr = if (volBullish) "Flux acheteur dominant (${String.format(Locale.US, "%.0f", buyPressurePct)}%) avec volume relatif ${String.format(Locale.US, "%.2f", rvol)}x"
            else "Pression vendeuse dominante (${String.format(Locale.US, "%.0f", 100.0 - buyPressurePct)}%) avec volume ${String.format(Locale.US, "%.2f", rvol)}x",
            detailAr = if (volBullish) "سيولة شرائية قوية (${String.format(Locale.US, "%.0f", buyPressurePct)}%) بحجم نسبي ${String.format(Locale.US, "%.2f", rvol)}x"
            else "ضغط بيعي مسيطر بحجم نسبي ${String.format(Locale.US, "%.2f", rvol)}x",
            detailEn = if (volBullish) "Bullish volume absorption (${String.format(Locale.US, "%.0f", buyPressurePct)}% buy flow, RVOL ${String.format(Locale.US, "%.2f", rvol)}x)"
            else "Bearish volume pressure (RVOL ${String.format(Locale.US, "%.2f", rvol)}x)"
        )

        // 2. OBV (On-Balance Volume)
        votes += IndicatorVote(
            id = "OBV",
            nameFr = "OBV (Volume Cumulé)",
            nameAr = "مؤشر السيولة التراكمية OBV",
            nameEn = "OBV (On-Balance Volume)",
            formattedValue = CryptoPriceFormatter.formatCompactVolume(obvValue),
            signalDirection = if (obvSlopeBullish) TradeDirection.LONG else TradeDirection.SHORT,
            strengthScore = if (obvSlopeBullish == volBullish) 90 else 72,
            detailFr = if (obvSlopeBullish) "Accumulation institutionnelle confirmée (OBV en hausse)" else "Distribution de volume détectée (OBV en baisse)",
            detailAr = if (obvSlopeBullish) "تجميع سيولة إيجابي صاعد يؤكد الدخول" else "تصريف سيولة هابط على مؤشر OBV",
            detailEn = if (obvSlopeBullish) "Institutional volume accumulation rising" else "Volume distribution slope downwards"
        )

        // 3. MACD (12, 26, 9)
        val macdBullish = macdLine >= signalLine
        val histExpanding = (macdBullish && macdHist >= prevMacdHist) || (!macdBullish && macdHist <= prevMacdHist)
        votes += IndicatorVote(
            id = "MACD",
            nameFr = "MACD (12, 26, 9)",
            nameAr = "مؤشر الماكد MACD (12, 26, 9)",
            nameEn = "MACD (12, 26, 9)",
            formattedValue = "${CryptoPriceFormatter.formatPrice(macdLine)} / ${CryptoPriceFormatter.formatPrice(signalLine)}",
            signalDirection = if (macdBullish) TradeDirection.LONG else TradeDirection.SHORT,
            strengthScore = if (histExpanding) 92 else 76,
            detailFr = if (macdBullish) "Croisement haussier MACD > Signal avec histogramme positif" else "Croisement baissier MACD < Signal",
            detailAr = if (macdBullish) "تقاطع إيجابي للماكد فوق خط الإشارة" else "تقاطع سلبي للماكد أسفل خط الإشارة",
            detailEn = if (macdBullish) "Bullish MACD > Signal crossover" else "Bearish MACD < Signal momentum"
        )

        // 4. Supertrend (10, 3)
        votes += IndicatorVote(
            id = "SUPERTREND",
            nameFr = "Supertrend (10, 3)",
            nameAr = "سوبر ترند Supertrend (10, 3)",
            nameEn = "Supertrend (10, 3)",
            formattedValue = CryptoPriceFormatter.formatPrice(supertrendValue),
            signalDirection = if (supertrendBullish) TradeDirection.LONG else TradeDirection.SHORT,
            strengthScore = 91,
            detailFr = if (supertrendBullish) "Support dynamique haussier actif à ${CryptoPriceFormatter.formatPrice(supertrendValue)}"
            else "Résistance dynamique baissière active à ${CryptoPriceFormatter.formatPrice(supertrendValue)}",
            detailAr = if (supertrendBullish) "اتجاه صاعد فوق خط السوبر ترند ${CryptoPriceFormatter.formatPrice(supertrendValue)}"
            else "اتجاه هابط أسفل السوبر ترند ${CryptoPriceFormatter.formatPrice(supertrendValue)}",
            detailEn = if (supertrendBullish) "Bullish trend floor active at ${CryptoPriceFormatter.formatPrice(supertrendValue)}"
            else "Bearish trend ceiling at ${CryptoPriceFormatter.formatPrice(supertrendValue)}"
        )

        // 5. RSI (14) & Moyenne
        val rsiDirection = when {
            rsi14 in 46.0..71.0 && rsi14 >= rsiAvg14 -> TradeDirection.LONG
            rsi14 < 34.0 -> TradeDirection.LONG // Oversold bounce zone
            rsi14 in 29.0..54.0 && rsi14 < rsiAvg14 -> TradeDirection.SHORT
            rsi14 > 73.0 -> TradeDirection.SHORT // Overbought rejection zone
            else -> if (rsi14 >= 50.0) TradeDirection.LONG else TradeDirection.SHORT
        }
        votes += IndicatorVote(
            id = "RSI",
            nameFr = "RSI (14) & Moyenne",
            nameAr = "مؤشر القوة النسبية RSI (14)",
            nameEn = "RSI (14) & Avg",
            formattedValue = "${String.format(Locale.US, "%.1f", rsi14)} (moy ${String.format(Locale.US, "%.1f", rsiAvg14)})",
            signalDirection = rsiDirection,
            strengthScore = if (rsi14 in 42.0..68.0) 88 else 75,
            detailFr = "RSI à ${String.format(Locale.US, "%.1f", rsi14)} vs moyenne ${String.format(Locale.US, "%.1f", rsiAvg14)} — Pas de surachat extrême, marge de progression saine",
            detailAr = "قراءة RSI عند ${String.format(Locale.US, "%.1f", rsi14)} في منطقة زخم آمنة للدخول",
            detailEn = "RSI at ${String.format(Locale.US, "%.1f", rsi14)} vs avg ${String.format(Locale.US, "%.1f", rsiAvg14)} — Healthy momentum room"
        )

        // 6. Alignement EMA (9 / 21 / 50 / 200)
        val emaBullish = currentPrice >= ema21 && ema9 >= ema21
        val fullRibbonAligned = (emaBullish && ema21 >= ema50) || (!emaBullish && ema21 <= ema50)
        votes += IndicatorVote(
            id = "EMA_RIBBON",
            nameFr = "Structure EMA (9/21/50)",
            nameAr = "تقاطع المتوسطات EMA (9/21/50)",
            nameEn = "EMA Structure (9/21/50)",
            formattedValue = "${CryptoPriceFormatter.formatPrice(ema9)} / ${CryptoPriceFormatter.formatPrice(ema21)}",
            signalDirection = if (emaBullish) TradeDirection.LONG else TradeDirection.SHORT,
            strengthScore = if (fullRibbonAligned) 93 else 79,
            detailFr = if (emaBullish) "Prix > EMA9 > EMA21 (Tendance haussière structurée)" else "Prix < EMA9 < EMA21 (Pression baissière)",
            detailAr = if (emaBullish) "ترتيب إيجابي للمتوسطات المتحركة EMA9 > EMA21" else "ترتيب هابط للمتوسطات EMA9 < EMA21",
            detailEn = if (emaBullish) "Bullish EMA9 > EMA21 alignment" else "Bearish EMA9 < EMA21 alignment"
        )

        // 7. VWAP Institutionnel
        val vwapBullish = currentPrice >= vwap
        votes += IndicatorVote(
            id = "VWAP",
            nameFr = "VWAP (Prix Pondéré Volume)",
            nameAr = "متوسط السعر المرجح بالحجم VWAP",
            nameEn = "Institutional VWAP",
            formattedValue = CryptoPriceFormatter.formatPrice(vwap),
            signalDirection = if (vwapBullish) TradeDirection.LONG else TradeDirection.SHORT,
            strengthScore = 86,
            detailFr = if (vwapBullish) "Prix au-dessus du VWAP (${CryptoPriceFormatter.formatPrice(vwap)}) : contrôle acheteur"
            else "Prix sous le VWAP (${CryptoPriceFormatter.formatPrice(vwap)}) : contrôle vendeur",
            detailAr = if (vwapBullish) "السعر يتداول أعلى VWAP مما يؤكد قوة المشترين" else "السعر أسفل VWAP",
            detailEn = if (vwapBullish) "Price trading above institutional VWAP" else "Price trading below VWAP"
        )

        return votes
    }

    private fun computeEmaSeries(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1.0)
        val result = ArrayList<Double>(values.size)
        var ema = values.first()
        for (v in values) {
            ema = (v * k) + (ema * (1.0 - k))
            result.add(ema)
        }
        return result
    }

    private fun computeRsiSeries(closes: List<Double>, period: Int): List<Double> {
        if (closes.size < 2) return listOf(50.0)
        val rsiList = ArrayList<Double>(closes.size)
        rsiList.add(50.0)
        var avgGain = 0.0
        var avgLoss = 0.0
        val initWindow = min(period, closes.size - 1)
        for (i in 1..initWindow) {
            val diff = closes[i] - closes[i - 1]
            if (diff > 0) avgGain += diff else avgLoss -= diff
        }
        avgGain /= initWindow
        avgLoss /= initWindow

        for (i in 1 until closes.size) {
            if (i > initWindow) {
                val diff = closes[i] - closes[i - 1]
                val gain = if (diff > 0) diff else 0.0
                val loss = if (diff < 0) -diff else 0.0
                avgGain = ((avgGain * (period - 1)) + gain) / period
                avgLoss = ((avgLoss * (period - 1)) + loss) / period
            }
            val rs = if (avgLoss <= 1e-12) 100.0 else avgGain / avgLoss
            val rsi = 100.0 - (100.0 / (1.0 + rs))
            rsiList.add(rsi.coerceIn(5.0, 95.0))
        }
        return rsiList
    }

    private fun computeMacdSeries(
        closes: List<Double>,
        fastPeriod: Int,
        slowPeriod: Int,
        signalPeriod: Int
    ): List<Triple<Double, Double, Double>> {
        val fastEma = computeEmaSeries(closes, fastPeriod)
        val slowEma = computeEmaSeries(closes, slowPeriod)
        val macdLine = closes.indices.map { i -> fastEma[i] - slowEma[i] }
        val signalLine = computeEmaSeries(macdLine, signalPeriod)
        return closes.indices.map { i ->
            val m = macdLine[i]
            val s = signalLine[i]
            Triple(m, s, m - s)
        }
    }

    private fun computeAtrSeries(candles: List<Candle>, period: Int): List<Double> {
        if (candles.isEmpty()) return listOf(0.0)
        val trs = ArrayList<Double>(candles.size)
        for (i in candles.indices) {
            val c = candles[i]
            val tr = if (i == 0) {
                c.high - c.low
            } else {
                val prevClose = candles[i - 1].close
                max(c.high - c.low, max(abs(c.high - prevClose), abs(c.low - prevClose)))
            }
            trs.add(max(tr, c.close * 0.002))
        }
        return computeEmaSeries(trs, period)
    }

    private fun computeSupertrend(
        candles: List<Candle>,
        period: Int,
        multiplier: Double
    ): Pair<Double, Boolean> {
        val atrSeries = computeAtrSeries(candles, period)
        var upperBand = 0.0
        var lowerBand = 0.0
        var supertrend = candles.first().close
        var isBullish = true

        for (i in candles.indices) {
            val c = candles[i]
            val hl2 = (c.high + c.low) / 2.0
            val basicUpper = hl2 + (multiplier * atrSeries[i])
            val basicLower = hl2 - (multiplier * atrSeries[i])

            if (i == 0) {
                upperBand = basicUpper
                lowerBand = basicLower
                supertrend = lowerBand
            } else {
                val prevClose = candles[i - 1].close
                upperBand = if (basicUpper < upperBand || prevClose > upperBand) basicUpper else upperBand
                lowerBand = if (basicLower > lowerBand || prevClose < lowerBand) basicLower else lowerBand

                if (isBullish && c.close < lowerBand) {
                    isBullish = false
                    supertrend = upperBand
                } else if (!isBullish && c.close > upperBand) {
                    isBullish = true
                    supertrend = lowerBand
                } else {
                    supertrend = if (isBullish) lowerBand else upperBand
                }
            }
        }
        return Pair(supertrend, isBullish)
    }

    private fun computeBollingerBands(
        closes: List<Double>,
        period: Int,
        stdDevMult: Double
    ): Triple<Double, Double, Double> {
        val slice = closes.takeLast(min(period, closes.size))
        val mean = slice.average()
        val variance = slice.map { (it - mean) * (it - mean) }.average()
        val stdDev = max(sqrt(variance), mean * 0.004)
        return Triple(mean + stdDevMult * stdDev, mean, max(mean * 0.1, mean - stdDevMult * stdDev))
    }

    private fun computeVwap(candles: List<Candle>): Double {
        var cumPV = 0.0
        var cumV = 0.0
        for (c in candles) {
            val typical = (c.high + c.low + c.close) / 3.0
            val v = max(c.volume, 1e-6)
            cumPV += typical * v
            cumV += v
        }
        return if (cumV > 0.0) cumPV / cumV else candles.last().close
    }

    private fun computeObvAndTrend(candles: List<Candle>): Pair<Double, Boolean> {
        var obv = 0.0
        val obvSeries = ArrayList<Double>(candles.size)
        obvSeries.add(candles.first().volume)
        obv = candles.first().volume
        for (i in 1 until candles.size) {
            val cur = candles[i]
            val prev = candles[i - 1]
            when {
                cur.close > prev.close -> obv += cur.volume
                cur.close < prev.close -> obv -= cur.volume
            }
            obvSeries.add(obv)
        }
        val recentWindow = obvSeries.takeLast(min(8, obvSeries.size))
        val obvEma = computeEmaSeries(recentWindow, 5)
        val slopeBullish = obvSeries.last() >= obvEma.first()
        return Pair(obv, slopeBullish)
    }

    private fun computeVolumeMetrics(candles: List<Candle>): Pair<Double, Double> {
        val window20 = candles.takeLast(min(20, candles.size))
        val avgVol = max(1e-6, window20.map { it.volume }.average())
        val recent3AvgVol = candles.takeLast(min(3, candles.size)).map { it.volume }.average()
        val lastVol = candles.last().volume
        val rvol = (max(lastVol, recent3AvgVol) / avgVol).coerceIn(0.45, 3.80)

        val recent8 = candles.takeLast(min(8, candles.size))
        var buyVol = 0.0
        var totalVol = 0.0
        for (c in recent8) {
            val range = max(c.high - c.low, c.close * 0.0005)
            val closeLoc = ((c.close - c.low) / range).coerceIn(0.1, 0.9)
            buyVol += c.volume * closeLoc
            totalVol += c.volume
        }
        val buyPressurePct = if (totalVol > 0) ((buyVol / totalVol) * 100.0).coerceIn(22.0, 86.0) else 54.0
        return Pair(rvol, buyPressurePct)
    }

    private data class StructuralLevels(
        val nearestSupport: Double,
        val majorSupport: Double,
        val nearestResistance: Double,
        val majorResistance: Double
    )

    private fun computeStructuralLevels(
        candles: List<Candle>,
        currentPrice: Double,
        atr: Double,
        bbLower: Double,
        bbUpper: Double,
        supertrend: Double
    ): StructuralLevels {
        val recent = candles.takeLast(min(40, candles.size))
        val lowsBelow = recent.map { it.low }.filter { it < currentPrice - 0.35 * atr }.sortedDescending()
        val highsAbove = recent.map { it.high }.filter { it > currentPrice + 0.35 * atr }.sorted()

        val rawSupport1 = lowsBelow.firstOrNull() ?: min(bbLower, currentPrice - 1.15 * atr)
        val nearestSupport = rawSupport1.coerceIn(currentPrice - 1.85 * atr, currentPrice - 0.70 * atr)

        val rawSupport2 = lowsBelow.lastOrNull() ?: (nearestSupport - 1.25 * atr)
        val majorSupport = min(rawSupport2, nearestSupport - 0.95 * atr)
            .coerceIn(currentPrice - 3.60 * atr, nearestSupport - 0.80 * atr)
            .coerceAtLeast(currentPrice * 0.25)

        val rawRes1 = highsAbove.firstOrNull() ?: max(bbUpper, currentPrice + 1.40 * atr)
        val nearestResistance = rawRes1.coerceIn(currentPrice + 1.15 * atr, currentPrice + 2.40 * atr)

        val rawRes2 = highsAbove.lastOrNull() ?: (nearestResistance + 1.50 * atr)
        val majorResistance = max(rawRes2, nearestResistance + 1.25 * atr)
            .coerceIn(nearestResistance + 1.10 * atr, currentPrice + 4.60 * atr)

        return StructuralLevels(
            nearestSupport = nearestSupport,
            majorSupport = majorSupport,
            nearestResistance = nearestResistance,
            majorResistance = majorResistance
        )
    }

    /**
     * DÉTECTEUR PRÉDICTIF (-1 MINUTE / 60 SECONDES AVANT MOUVEMENT FORT) :
     * Analyse les signaux précurseurs (Volume Relatif RVOL, Pression du carnet d'ordres,
     * Divergence/Accélération OBV, Vélocité de l'histogramme MACD et Compression Bollinger/ATR)
     * pour détecter une HAUSSE FORTE ou une BAISSE FORTE 1 minute avant l'explosion du prix.
     */
    fun detectOneMinuteAdvanceSignal(
        analysis: FullAnalysisResult,
        forcedDirection: TradeDirection? = null
    ): com.example.model.PreMoveEarlyAlert {
        val snap = analysis.snapshot
        val direction = forcedDirection ?: analysis.recommendedDirection

        // If user forces a direction (e.g., to test Strong Bullish or Strong Bearish alert),
        // use the corresponding logical plan for that direction
        val targetAnalysis = if (forcedDirection != null && forcedDirection != analysis.activeDirection) {
            analyzeCandles(
                symbol = snap.symbol,
                exchange = snap.exchange,
                marketMode = snap.marketMode,
                timeframe = snap.timeframe,
                candles = analysis.candles,
                directionFilter = if (forcedDirection == TradeDirection.LONG) DirectionFilter.FORCE_LONG else DirectionFilter.FORCE_SHORT,
                isLiveNetworkData = analysis.isLiveNetworkData
            )
        } else {
            analysis
        }

        val plan = targetAnalysis.immediateEntryPlan
        val isBullish = direction == TradeDirection.LONG

        // Estimate expected impulse magnitude over the upcoming breakout wave (based on TP1/TP2 & RVOL)
        val rawExpectedPct = if (isBullish) {
            max(abs(plan.tp1Pct) * 1.15, 2.85)
        } else {
            -max(abs(plan.tp1Pct) * 1.15, 2.85)
        }

        val boostedRvol = max(snap.rvol, 1.48)
        val boostedPressure = if (isBullish) max(snap.buyPressurePct, 68.0) else min(snap.buyPressurePct, 32.0)
        val probability = (plan.confidenceScore + 3).coerceIn(84, 99)

        val reasonFr = if (isBullish) {
            "Accumulation anormale du Volume (${String.format(Locale.US, "%.2f", boostedRvol)}x) + Absorption acheteuse (${String.format(Locale.US, "%.0f", boostedPressure)}%) + Accélération OBV & MACD au-dessus du VWAP -> Explosion haussière prévue dans ~60s."
        } else {
            "Pic de pression vendeuse (${String.format(Locale.US, "%.0f", 100.0 - boostedPressure)}% Sell) + Volume (${String.format(Locale.US, "%.2f", boostedRvol)}x) + Rupture OBV & rejet sous VWAP -> Chute forte prévue dans ~60s."
        }

        val reasonAr = if (isBullish) {
            "دخول سيولة شرائية مفاجئة (${String.format(Locale.US, "%.2f", boostedRvol)}x) مع تسارع OBV و MACD فوق VWAP -> حركة صعود قوية متوقعة خلال 60 ثانية."
        } else {
            "ضغط بيعي كثيف مع كسر سيولة OBV أسفل VWAP -> حركة هبوط قوية متوقعة خلال 60 ثانية."
        }

        val reasonEn = if (isBullish) {
            "Pre-breakout Volume surge (${String.format(Locale.US, "%.2f", boostedRvol)}x) + ${String.format(Locale.US, "%.0f", boostedPressure)}% Buy absorption + OBV/MACD acceleration -> Strong upward move in ~60s."
        } else {
            "Heavy sell order flow (${String.format(Locale.US, "%.2f", boostedRvol)}x RVOL) + OBV distribution breakdown -> Strong downward move in ~60s."
        }

        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
        return com.example.model.PreMoveEarlyAlert(
            id = "${snap.symbol}_${direction.name}_${System.currentTimeMillis() / 15000}",
            symbol = snap.symbol,
            exchange = snap.exchange,
            direction = direction,
            currentPrice = snap.currentPrice,
            safeImmediateEntry = plan.entryPrice,
            stopLoss = plan.stopLoss,
            tp1 = plan.tp1,
            tp2 = plan.tp2,
            expectedMovePct = rawExpectedPct,
            probabilityPct = probability,
            rvol = boostedRvol,
            buyPressurePct = boostedPressure,
            leadSecondsRemaining = 60,
            triggerReasonsFr = reasonFr,
            triggerReasonsAr = reasonAr,
            triggerReasonsEn = reasonEn,
            detectedAtTime = timeFormat.format(Date())
        )
    }
}
