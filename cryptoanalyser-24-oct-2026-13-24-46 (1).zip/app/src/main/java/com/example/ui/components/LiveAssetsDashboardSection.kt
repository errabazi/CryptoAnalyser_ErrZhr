package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CryptoPriceFormatter
import com.example.model.LiveCryptoAsset
import com.example.model.TradeDirection
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderCyan
import com.example.ui.theme.CrimsonBear
import com.example.ui.theme.CrimsonBearDark
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardElevated
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.EmeraldBull
import com.example.ui.theme.EmeraldBullDark
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.max

private enum class AssetTrendFilter {
    ALL,
    BULLISH,
    BEARISH
}

@Composable
fun LiveAssetsDashboardSection(
    assets: List<LiveCryptoAsset>,
    selectedSymbol: String,
    language: AppLanguage,
    onSelectAsset: (String) -> Unit,
    onRefreshDashboard: () -> Unit,
    modifier: Modifier = Modifier
) {
    var trendFilter by remember { mutableStateOf(AssetTrendFilter.ALL) }

    val filteredAssets = remember(assets, trendFilter) {
        when (trendFilter) {
            AssetTrendFilter.ALL -> assets
            AssetTrendFilter.BULLISH -> assets.filter { it.change24hPct >= 0.0 || it.trendDirection == TradeDirection.LONG }
            AssetTrendFilter.BEARISH -> assets.filter { it.change24hPct < 0.0 || it.trendDirection == TradeDirection.SHORT }
        }
    }

    val bullishCount = assets.count { it.change24hPct >= 0.0 }
    val topMover = assets.maxByOrNull { it.change24hPct }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("live_crypto_dashboard_section"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Dashboard Summary Header Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NeonCyan.copy(alpha = 0.65f), RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCardElevated)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(EmeraldBull)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = when (language) {
                                    AppLanguage.FR -> "TABLEAU DE BORD CRYPTO EN TEMPS RÉEL"
                                    AppLanguage.AR -> "لوحة أسعار العملات الرقمية المباشرة"
                                    AppLanguage.EN -> "LIVE CRYPTO ASSETS DASHBOARD"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = when (language) {
                                    AppLanguage.FR -> "Prix actuels, indicateurs visuels de tendance & Entrée Sûre 100%"
                                    AppLanguage.AR -> "الأسعار الحالية ومؤشرات الاتجاه المباشرة مع سعر الدخول الآمن"
                                    AppLanguage.EN -> "Live prices, visual trend indicators & 100% Safe Entry levels"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onRefreshDashboard,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("refresh_dashboard_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Actualiser les actifs",
                            tint = NeonCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Market pulse mini stats
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberNavyDark)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = when (language) {
                                AppLanguage.FR -> "Actifs Suivis"
                                AppLanguage.AR -> "العملات المتابعة"
                                AppLanguage.EN -> "Tracked Assets"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                        Text(
                            text = "${assets.size} Paires USDT",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = when (language) {
                                AppLanguage.FR -> "Tendance Marché"
                                AppLanguage.AR -> "اتجاه السوق"
                                AppLanguage.EN -> "Market Trend"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                        Text(
                            text = "$bullishCount/${assets.size} Haussiers",
                            style = MaterialTheme.typography.labelLarge,
                            color = EmeraldBull
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Top Gainer",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                        Text(
                            text = topMover?.let {
                                "${it.baseAsset} (${CryptoPriceFormatter.formatSignedPct(it.change24hPct)})"
                            } ?: "--",
                            style = MaterialTheme.typography.labelLarge,
                            color = AmberGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Trend filter chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        AssetTrendFilter.ALL to when (language) {
                            AppLanguage.FR -> "Tous (${assets.size})"
                            AppLanguage.AR -> "الكل (${assets.size})"
                            AppLanguage.EN -> "All (${assets.size})"
                        },
                        AssetTrendFilter.BULLISH to when (language) {
                            AppLanguage.FR -> "Haussiers"
                            AppLanguage.AR -> "صاعد"
                            AppLanguage.EN -> "Bullish"
                        },
                        AssetTrendFilter.BEARISH to when (language) {
                            AppLanguage.FR -> "Baissiers"
                            AppLanguage.AR -> "هابط"
                            AppLanguage.EN -> "Bearish"
                        }
                    ).forEach { (filter, label) ->
                        val selected = trendFilter == filter
                        FilterChip(
                            selected = selected,
                            onClick = { trendFilter = filter },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonCyan.copy(alpha = 0.22f),
                                selectedLabelColor = NeonCyan,
                                containerColor = CyberSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                borderColor = if (selected) NeonCyan else BorderCyan
                            ),
                            modifier = Modifier.testTag("asset_filter_${filter.name.lowercase()}")
                        )
                    }
                }
            }
        }

        // 2. List of Live Crypto Assets with Current Price & Visual Trend Indicator
        filteredAssets.forEach { asset ->
            LiveCryptoAssetRowCard(
                asset = asset,
                isSelected = asset.symbol == selectedSymbol,
                language = language,
                onClick = { onSelectAsset(asset.symbol) }
            )
        }
    }
}

@Composable
private fun LiveCryptoAssetRowCard(
    asset: LiveCryptoAsset,
    isSelected: Boolean,
    language: AppLanguage,
    onClick: () -> Unit
) {
    val isBullish = asset.change24hPct >= 0.0
    val trendColor = if (isBullish) EmeraldBull else CrimsonBear
    val trendBg = if (isBullish) EmeraldBullDark else CrimsonBearDark

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 1.8.dp else 1.dp,
                color = if (isSelected) NeonCyan else BorderCyan,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .testTag("live_asset_card_${asset.symbol.lowercase()}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) CyberCardElevated else CyberCard
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Asset Badge + Name & Symbol
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1.1f)
                ) {
                    Surface(
                        modifier = Modifier.size(42.dp),
                        shape = CircleShape,
                        color = CyberNavyDark,
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, trendColor)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = asset.baseAsset.take(3),
                                style = MaterialTheme.typography.labelLarge,
                                color = trendColor,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = asset.baseAsset,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = " /USDT",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                        Text(
                            text = "${asset.name} • ${asset.exchange.displayName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                // Middle: Visual Sparkline Trend Curve
                Box(
                    modifier = Modifier
                        .width(78.dp)
                        .height(36.dp)
                        .padding(horizontal = 4.dp)
                        .testTag("sparkline_${asset.symbol.lowercase()}")
                ) {
                    AssetSparklineCanvas(
                        prices = asset.sparkline,
                        lineColor = trendColor
                    )
                }

                // Right: Current Price + Visual Trend Indicator Badge
                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "$${CryptoPriceFormatter.formatPrice(asset.currentPrice)}",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 14.sp
                        ),
                        color = TextPrimary,
                        modifier = Modifier.testTag("asset_price_${asset.symbol.lowercase()}")
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Surface(
                        color = trendBg,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, trendColor.copy(alpha = 0.7f)),
                        modifier = Modifier.testTag("trend_indicator_${asset.symbol.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isBullish) Icons.AutoMirrored.Filled.TrendingUp else Icons.AutoMirrored.Filled.TrendingDown,
                                contentDescription = if (isBullish) "Bullish trend" else "Bearish trend",
                                tint = trendColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = CryptoPriceFormatter.formatSignedPct(asset.change24hPct),
                                style = MaterialTheme.typography.labelSmall,
                                color = trendColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Bottom Strip: 100% Logical Immediate Entry Preview (SL < Entrée < TP1 < TP2)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyberNavyDark)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Entrée Sûre",
                        tint = NeonCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Entrée: ${CryptoPriceFormatter.formatPrice(asset.safeImmediateEntry)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan,
                        fontSize = 10.sp
                    )
                }

                Text(
                    text = "SL: ${CryptoPriceFormatter.formatPrice(asset.stopLoss)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = CrimsonBear,
                    fontSize = 10.sp
                )

                Text(
                    text = "TP1: ${CryptoPriceFormatter.formatPrice(asset.tp1)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldBull,
                    fontSize = 10.sp
                )

                Text(
                    text = "TP2: ${CryptoPriceFormatter.formatPrice(asset.tp2)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = AmberGold,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun AssetSparklineCanvas(
    prices: List<Double>,
    lineColor: Color
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        if (prices.size < 2) return@Canvas
        val w = size.width
        val h = size.height
        val minP = prices.minOrNull() ?: 0.0
        val maxP = prices.maxOrNull() ?: 1.0
        val range = max(maxP - minP, maxP * 0.001)

        val linePath = Path()
        val fillPath = Path()

        prices.forEachIndexed { idx, p ->
            val x = (idx.toFloat() / (prices.size - 1).toFloat()) * w
            val normY = ((p - minP) / range).toFloat().coerceIn(0f, 1f)
            val y = h - (normY * (h * 0.78f) + h * 0.11f)
            if (idx == 0) {
                linePath.moveTo(x, y)
                fillPath.moveTo(x, h)
                fillPath.lineTo(x, y)
            } else {
                linePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
            if (idx == prices.lastIndex) {
                fillPath.lineTo(x, h)
                fillPath.close()
                drawCircle(
                    color = lineColor,
                    radius = 3.5f,
                    center = Offset(x, y)
                )
            }
        }

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(lineColor.copy(alpha = 0.28f), Color.Transparent)
            )
        )
        drawPath(
            path = linePath,
            color = lineColor,
            style = Stroke(width = 2.4f, cap = StrokeCap.Round)
        )
    }
}
