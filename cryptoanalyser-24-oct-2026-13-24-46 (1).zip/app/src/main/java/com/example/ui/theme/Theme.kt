package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CryptoDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = CyberNavyDark,
    primaryContainer = CyberCardElevated,
    onPrimaryContainer = TextPrimary,
    secondary = EmeraldBull,
    onSecondary = EmeraldBullDark,
    secondaryContainer = Color(0xFF0E3925),
    onSecondaryContainer = EmeraldBull,
    tertiary = MagentaAccent,
    onTertiary = CyberNavyDark,
    background = CyberNavyDark,
    onBackground = TextPrimary,
    surface = CyberSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberCard,
    onSurfaceVariant = TextSecondary,
    error = CrimsonBear,
    onError = Color.White,
    outline = BorderCyan
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = CryptoDarkColorScheme,
        typography = Typography,
        content = content
    )
}
