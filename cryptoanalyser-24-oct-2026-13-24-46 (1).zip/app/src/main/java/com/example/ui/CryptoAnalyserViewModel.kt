package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CryptoMarketRepository
import com.example.domain.TechnicalAnalysisEngine
import com.example.model.AppLanguage
import com.example.model.DirectionFilter
import com.example.model.ExchangePlatform
import com.example.model.FullAnalysisResult
import com.example.model.LiveCryptoAsset
import com.example.model.MarketAlertItem
import com.example.model.MarketMode
import com.example.model.PreMoveEarlyAlert
import com.example.model.Timeframe
import com.example.model.TradeDirection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class CryptoTab {
    DASHBOARD,
    IMMEDIATE_ENTRY,
    CHARTS_MACD,
    INDICATORS_VOLUME,
    ALERTS_SCANNER
}

data class CryptoUiState(
    val language: AppLanguage = AppLanguage.FR,
    val selectedTab: CryptoTab = CryptoTab.DASHBOARD,
    val selectedSymbol: String = "XRPUSDT",
    val selectedExchange: ExchangePlatform = ExchangePlatform.BITGET,
    val selectedMarketMode: MarketMode = MarketMode.FUTURES_USDT,
    val selectedTimeframe: Timeframe = Timeframe.TF_4H,
    val directionFilter: DirectionFilter = DirectionFilter.AUTO_CONFLUENCE,
    val customPriceOverride: Double? = null,
    val capitalUsdt: Double = 500.0,
    val leverage: Int = 5,
    val autoNotifyOneMinBefore: Boolean = true,
    val activePreMoveAlert: PreMoveEarlyAlert? = null,
    val isLoading: Boolean = false,
    val liveAssets: List<LiveCryptoAsset> = emptyList(),
    val analysisResult: FullAnalysisResult? = null,
    val marketAlerts: List<MarketAlertItem> = emptyList(),
    val featuredPairs: List<String> = emptyList()
)

class CryptoAnalyserViewModel(
    private val repository: CryptoMarketRepository = CryptoMarketRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        CryptoUiState(featuredPairs = repository.featuredPairs)
    )
    val uiState: StateFlow<CryptoUiState> = _uiState.asStateFlow()

    init {
        refreshDashboardAssets()
        refreshAnalysis()
        refreshAlerts()
    }

    fun selectLanguage(lang: AppLanguage) {
        _uiState.update { it.copy(language = lang) }
    }

    fun selectTab(tab: CryptoTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun toggleAutoNotifyOneMin(enabled: Boolean) {
        _uiState.update { it.copy(autoNotifyOneMinBefore = enabled) }
    }

    fun triggerPreMoveEarlyAlert(direction: TradeDirection): PreMoveEarlyAlert? {
        val currentResult = _uiState.value.analysisResult ?: return null
        val alert = TechnicalAnalysisEngine.detectOneMinuteAdvanceSignal(
            analysis = currentResult,
            forcedDirection = direction
        )
        val filter = if (direction == TradeDirection.LONG) DirectionFilter.FORCE_LONG else DirectionFilter.FORCE_SHORT
        _uiState.update {
            it.copy(
                activePreMoveAlert = alert,
                directionFilter = filter
            )
        }
        refreshAnalysis()
        return alert
    }

    fun selectSymbol(symbol: String, switchToEntryTab: Boolean = false) {
        val formatted = symbol.uppercase().trim().let {
            if (it.isEmpty()) "XRPUSDT" else if (it.endsWith("USDT")) it else "${it}USDT"
        }
        _uiState.update {
            it.copy(
                selectedSymbol = formatted,
                customPriceOverride = null,
                selectedTab = if (switchToEntryTab) CryptoTab.IMMEDIATE_ENTRY else it.selectedTab
            )
        }
        refreshAnalysis()
    }

    fun selectExchange(exchange: ExchangePlatform) {
        _uiState.update { it.copy(selectedExchange = exchange) }
        refreshDashboardAssets()
        refreshAnalysis()
        refreshAlerts()
    }

    fun selectMarketMode(mode: MarketMode) {
        _uiState.update { it.copy(selectedMarketMode = mode) }
        refreshDashboardAssets()
        refreshAnalysis()
    }

    fun selectTimeframe(timeframe: Timeframe) {
        _uiState.update { it.copy(selectedTimeframe = timeframe) }
        refreshDashboardAssets()
        refreshAnalysis()
    }

    fun selectDirectionFilter(filter: DirectionFilter) {
        _uiState.update { it.copy(directionFilter = filter) }
        refreshAnalysis()
    }

    fun applyCustomPriceOverride(priceText: String) {
        val parsed = priceText.replace(',', '.').trim().toDoubleOrNull()
        _uiState.update {
            it.copy(customPriceOverride = if (parsed != null && parsed > 0.0) parsed else null)
        }
        refreshAnalysis()
    }

    fun updateCapitalAndLeverage(capital: Double, leverage: Int) {
        _uiState.update {
            it.copy(
                capitalUsdt = capital.coerceIn(10.0, 1_000_000.0),
                leverage = leverage.coerceIn(1, 50)
            )
        }
    }

    fun refreshDashboardAssets() {
        val state = _uiState.value
        viewModelScope.launch {
            val assets = repository.fetchLiveCryptoAssetsDashboard(
                exchange = state.selectedExchange,
                marketMode = state.selectedMarketMode,
                timeframe = state.selectedTimeframe
            )
            _uiState.update { it.copy(liveAssets = assets) }
        }
    }

    fun refreshAnalysis() {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val result = repository.fetchAndAnalyze(
                symbol = state.selectedSymbol,
                exchange = state.selectedExchange,
                marketMode = state.selectedMarketMode,
                timeframe = state.selectedTimeframe,
                directionFilter = state.directionFilter,
                customPriceOverride = state.customPriceOverride
            )
            val preMoveAlert = TechnicalAnalysisEngine.detectOneMinuteAdvanceSignal(
                analysis = result,
                forcedDirection = result.activeDirection
            )
            _uiState.update {
                it.copy(
                    isLoading = false,
                    analysisResult = result,
                    activePreMoveAlert = preMoveAlert
                )
            }
        }
    }

    fun refreshAlerts() {
        val state = _uiState.value
        viewModelScope.launch {
            val alerts = repository.scanMarketAlerts(
                exchange = state.selectedExchange,
                marketMode = state.selectedMarketMode,
                timeframe = state.selectedTimeframe
            )
            _uiState.update { it.copy(marketAlerts = alerts) }
        }
    }
}
