package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CryptoPriceFormatter
import com.example.model.DirectionFilter
import com.example.model.EntryPlan
import com.example.model.FullAnalysisResult
import com.example.model.IndicatorVote
import com.example.model.TradeDirection
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderCyan
import com.example.ui.theme.CrimsonBear
import com.example.ui.theme.CrimsonBearDark
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardElevated
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.EmeraldBull
import com.example.ui.theme.EmeraldBullDark
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MagentaAccent
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.abs

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EntryPlansSection(
    result: FullAnalysisResult,
    language: AppLanguage,
    directionFilter: DirectionFilter,
    customPriceOverride: Double?,
    capitalUsdt: Double,
    leverage: Int,
    onDirectionFilterChange: (DirectionFilter) -> Unit,
    onApplyCustomPrice: (String) -> Unit,
    onCapitalLeverageChange: (Double, Int) -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showSimulator by remember { mutableStateOf(false) }
    var customPriceInput by remember(result.snapshot.symbol) {
        mutableStateOf(customPriceOverride?.let { CryptoPriceFormatter.formatPrice(it) } ?: "")
    }
    var capitalInput by remember { mutableStateOf(capitalUsdt.toInt().toString()) }

    val immediatePlan = result.immediateEntryPlan
    val snap = result.snapshot
    val isBull = immediatePlan.direction == TradeDirection.LONG
    val accentColor = if (isBull) EmeraldBull else CrimsonBear

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Direction Mode & Confluence Header Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderCyan, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCard)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.GppGood,
                            contentDescription = "Sécurité 100%",
                            tint = EmeraldBull,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = when (language) {
                                    AppLanguage.FR -> "MOTEUR D'ENTRÉE IMMÉDIATE SÛRE 100%"
                                    AppLanguage.AR -> "محرك الدخول الفوري الآمن والمنطقي 100%"
                                    AppLanguage.EN -> "100% LOGICAL & SAFE IMMEDIATE ENTRY ENGINE"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = when (language) {
                                    AppLanguage.FR -> "Confluence Indicateurs + Volume + OBV • ${result.timestampLabel}"
                                    AppLanguage.AR -> "توافق جميع المؤشرات والسيولة والحجم • ${result.timestampLabel}"
                                    AppLanguage.EN -> "Multi-Indicator + Volume + OBV Confluence • ${result.timestampLabel}"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("refresh_analysis_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Rafraîchir l'analyse",
                            tint = NeonCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Mode selector (Auto Confluence / Force LONG / Force SHORT)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DirectionFilter.entries.forEach { filter ->
                        val selected = directionFilter == filter
                        FilterChip(
                            selected = selected,
                            onClick = { onDirectionFilterChange(filter) },
                            label = {
                                Text(
                                    text = filter.label(language),
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonCyan.copy(alpha = 0.22f),
                                selectedLabelColor = NeonCyan,
                                containerColor = CyberSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                borderColor = if (selected) NeonCyan else BorderCyan
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("direction_filter_${filter.name.lowercase()}")
                        )
                    }
                }
            }
        }

        // 2. HERO CARD: ENTRÉE IMMÉDIATE SÛRE 100% (Fixed & Mathematically Verified)
        ImmediateSafeEntryHeroCard(
            plan = immediatePlan,
            currentPrice = snap.currentPrice,
            rvol = snap.rvol,
            buyPressurePct = snap.buyPressurePct,
            obvBullish = snap.obvSlopeBullish,
            language = language,
            capitalUsdt = capitalUsdt,
            leverage = leverage,
            onCopyPlan = {
                val clipText = buildCopyText(snap.symbol, immediatePlan)
                copyToClipboard(context, clipText)
            }
        )

        // 3. Multi-Indicator + Volume Confluence Breakdown (Why this entry is 100% logical)
        ConfluenceIndicatorsSummaryCard(
            votes = result.indicatorVotes,
            activeDirection = result.activeDirection,
            globalConfluenceScore = result.globalConfluenceScore,
            language = language
        )

        // 4. Interactive Price & Position Simulator (Test custom entry price or capital)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderCyan, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCard)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showSimulator = !showSimulator }
                        .minimumInteractiveComponentSize()
                        .testTag("toggle_simulator_button"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Simulateur",
                            tint = AmberGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (language) {
                                AppLanguage.FR -> "Simulateur de Prix & Calculateur de Gains USDT"
                                AppLanguage.AR -> "محاكي سعر الدخول وحاسبة الأرباح USDT"
                                AppLanguage.EN -> "Custom Price & USDT Profit Calculator"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = AmberGold
                        )
                    }
                    Icon(
                        imageVector = if (showSimulator) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Déplier",
                        tint = TextSecondary
                    )
                }

                AnimatedVisibility(visible = showSimulator) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = when (language) {
                                AppLanguage.FR -> "Testez n'importe quel prix du marché pour recalculer instantanément un Prix d'Entrée Immédiat, SL, TP1 et TP2 100% logiques :"
                                AppLanguage.AR -> "أدخل أي سعر لاختبار وحساب سعر الدخول الفوري و TP1 و TP2 ووقف الخسارة بشكل منطقي 100%:"
                                AppLanguage.EN -> "Enter any market price to recalculate 100% logical Immediate Entry, SL, TP1 & TP2:"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = customPriceInput,
                                onValueChange = { customPriceInput = it },
                                label = {
                                    Text(
                                        when (language) {
                                            AppLanguage.FR -> "Prix personnalisé (ex: 0.5810)"
                                            AppLanguage.AR -> "سعر مخصص"
                                            AppLanguage.EN -> "Custom price (e.g. 0.5810)"
                                        },
                                        fontSize = 12.sp
                                    )
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonCyan,
                                    unfocusedBorderColor = BorderCyan,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("custom_price_input")
                            )

                            Button(
                                onClick = { onApplyCustomPrice(customPriceInput) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonCyan,
                                    contentColor = CyberNavyDark
                                ),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("apply_custom_price_button")
                            ) {
                                Text(
                                    text = when (language) {
                                        AppLanguage.FR -> "Calculer"
                                        AppLanguage.AR -> "حساب"
                                        AppLanguage.EN -> "Calculate"
                                    },
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (customPriceOverride != null) {
                            OutlinedButton(
                                onClick = {
                                    customPriceInput = ""
                                    onApplyCustomPrice("")
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = when (language) {
                                        AppLanguage.FR -> "Réinitialiser au prix réel du marché"
                                        AppLanguage.AR -> "إعادة الضبط لسعر السوق المباشر"
                                        AppLanguage.EN -> "Reset to live market price"
                                    },
                                    color = NeonCyan
                                )
                            }
                        }

                        HorizontalDivider(color = BorderCyan)

                        // Leverage & Capital quick selector
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = capitalInput,
                                onValueChange = {
                                    capitalInput = it
                                    val parsed = it.toDoubleOrNull()
                                    if (parsed != null && parsed > 0) {
                                        onCapitalLeverageChange(parsed, leverage)
                                    }
                                },
                                label = { Text("Capital (USDT)", fontSize = 11.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )

                            listOf(1, 5, 10, 20).forEach { lev ->
                                val selected = leverage == lev
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { onCapitalLeverageChange(capitalUsdt, lev) }
                                        .border(
                                            1.dp,
                                            if (selected) AmberGold else BorderCyan,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(horizontal = 10.dp, vertical = 10.dp),
                                    color = if (selected) AmberGold.copy(alpha = 0.2f) else CyberSurface
                                ) {
                                    Text(
                                        text = "${lev}x",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (selected) AmberGold else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 5. Secondary Strategy Cards: PULLBACK ENTRY & BREAKOUT-RETEST ENTRY (Frames 00:06-00:08)
        SecondaryStrategyPlanCard(
            plan = result.pullbackEntryPlan,
            language = language,
            accentColor = NeonCyan,
            testTagPrefix = "pullback_plan",
            onCopy = {
                copyToClipboard(context, buildCopyText(snap.symbol, result.pullbackEntryPlan))
            }
        )

        SecondaryStrategyPlanCard(
            plan = result.breakoutRetestPlan,
            language = language,
            accentColor = MagentaAccent,
            testTagPrefix = "breakout_plan",
            onCopy = {
                copyToClipboard(context, buildCopyText(snap.symbol, result.breakoutRetestPlan))
            }
        )
    }
}

@Composable
private fun ImmediateSafeEntryHeroCard(
    plan: EntryPlan,
    currentPrice: Double,
    rvol: Double,
    buyPressurePct: Double,
    obvBullish: Boolean,
    language: AppLanguage,
    capitalUsdt: Double,
    leverage: Int,
    onCopyPlan: () -> Unit
) {
    val isLong = plan.direction == TradeDirection.LONG
    val directionColor = if (isLong) EmeraldBull else CrimsonBear
    val directionBg = if (isLong) EmeraldBullDark else CrimsonBearDark

    val effectivePositionUsdt = capitalUsdt * leverage
    val profitTp1Usdt = effectivePositionUsdt * (abs(plan.tp1Pct) / 100.0)
    val profitTp2Usdt = effectivePositionUsdt * (abs(plan.tp2Pct) / 100.0)
    val riskSlUsdt = effectivePositionUsdt * (abs(plan.slPct) / 100.0)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 2.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(directionColor, NeonCyan, directionColor)
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .testTag("immediate_entry_hero_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCardElevated)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Badge + Direction + Confidence %
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = directionBg,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.border(1.dp, directionColor, RoundedCornerShape(10.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isLong) Icons.AutoMirrored.Filled.TrendingUp else Icons.AutoMirrored.Filled.TrendingDown,
                                contentDescription = plan.direction.name,
                                tint = directionColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = plan.direction.label(language),
                                style = MaterialTheme.typography.labelLarge,
                                color = directionColor
                            )
                        }
                    }

                    Surface(
                        color = CyberSurface,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.border(1.dp, EmeraldBull.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Sûr 100%",
                                tint = EmeraldBull,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${plan.confidenceScore}% SÛR",
                                style = MaterialTheme.typography.labelMedium,
                                color = EmeraldBull,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onCopyPlan,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("copy_immediate_entry_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copier les niveaux",
                        tint = NeonCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = plan.title(language),
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary
            )
            Text(
                text = plan.subtitle(language),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Highlighted Safe Immediate Entry Box + Current Price comparison
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                CyberNavyDark,
                                directionBg.copy(alpha = 0.65f),
                                CyberNavyDark
                            )
                        )
                    )
                    .border(1.5.dp, NeonCyan, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = when (language) {
                                    AppLanguage.FR -> "PRIX D'ENTRÉE IMMÉDIATE SÛR (100%)"
                                    AppLanguage.AR -> "سعر الدخول الفوري الآمن (الدخول)"
                                    AppLanguage.EN -> "100% SAFE IMMEDIATE ENTRY PRICE"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = NeonCyan
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${CryptoPriceFormatter.formatPrice(plan.entryPrice)} USDT",
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 24.sp
                                ),
                                color = TextPrimary,
                                modifier = Modifier.testTag("immediate_entry_price_value")
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = when (language) {
                                    AppLanguage.FR -> "Prix Actuel"
                                    AppLanguage.AR -> "السعر الحالي"
                                    AppLanguage.EN -> "Market Price"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                            Text(
                                text = CryptoPriceFormatter.formatPrice(currentPrice),
                                style = MaterialTheme.typography.labelLarge,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Zone: ${CryptoPriceFormatter.formatPrice(plan.safeEntryZoneLow)} - ${CryptoPriceFormatter.formatPrice(plan.safeEntryZoneHigh)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldBull,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 4-Column Logical Price Grid (Matching and fixing Video Frame 00:06: SL | Entrée | TP1 | TP2)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PriceLevelBox(
                    label = when (language) {
                        AppLanguage.FR -> "STOP LOSS"
                        AppLanguage.AR -> "وقف الخسارة SL"
                        AppLanguage.EN -> "STOP LOSS"
                    },
                    priceText = CryptoPriceFormatter.formatPrice(plan.stopLoss),
                    pctText = CryptoPriceFormatter.formatSignedPct(plan.slPct),
                    subBadge = "-${String.format(Locale.US, "%.1f", riskSlUsdt)}$",
                    borderColor = CrimsonBear,
                    valueColor = CrimsonBear,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("immediate_sl_box")
                )

                PriceLevelBox(
                    label = when (language) {
                        AppLanguage.FR -> "TP1 (SÛR)"
                        AppLanguage.AR -> "الهدف TP1"
                        AppLanguage.EN -> "TP1 (SAFE)"
                    },
                    priceText = CryptoPriceFormatter.formatPrice(plan.tp1),
                    pctText = CryptoPriceFormatter.formatSignedPct(plan.tp1Pct),
                    subBadge = "R:R 1:${String.format(Locale.US, "%.1f", plan.riskRewardTp1)} (+${String.format(Locale.US, "%.1f", profitTp1Usdt)}$)",
                    borderColor = EmeraldBull,
                    valueColor = EmeraldBull,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("immediate_tp1_box")
                )

                PriceLevelBox(
                    label = when (language) {
                        AppLanguage.FR -> "TP2 (MAX)"
                        AppLanguage.AR -> "الهدف TP2"
                        AppLanguage.EN -> "TP2 (MAX)"
                    },
                    priceText = CryptoPriceFormatter.formatPrice(plan.tp2),
                    pctText = CryptoPriceFormatter.formatSignedPct(plan.tp2Pct),
                    subBadge = "R:R 1:${String.format(Locale.US, "%.1f", plan.riskRewardTp2)} (+${String.format(Locale.US, "%.1f", profitTp2Usdt)}$)",
                    borderColor = AmberGold,
                    valueColor = AmberGold,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("immediate_tp2_box")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Mathematical & Logical Verification Banner (Guaranteed SL < Entry < TP1 < TP2 for Long)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("logical_proof_banner"),
                color = CyberNavyDark,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldBull.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Preuve logique",
                            tint = EmeraldBull,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = when (language) {
                                AppLanguage.FR -> "ORDRE LOGIQUE 100% VÉRIFIÉ (SANS ERREUR) :"
                                AppLanguage.AR -> "الترتيب المنطقي للأسعار مؤكد 100%:"
                                AppLanguage.EN -> "100% VERIFIED LOGICAL PRICE ORDER:"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = EmeraldBull
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = plan.logicalInequalityProof,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextPrimary,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Volume & Order Flow Confirmation Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyberSurface)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = when (language) {
                            AppLanguage.FR -> "Volume Relatif (RVOL)"
                            AppLanguage.AR -> "الحجم النسبي RVOL"
                            AppLanguage.EN -> "Relative Volume (RVOL)"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Text(
                        text = "${String.format(Locale.US, "%.2f", rvol)}x (${if (rvol >= 1.0) "Fort" else "Modéré"})",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonCyan
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = when (language) {
                            AppLanguage.FR -> "Flux Acheteur"
                            AppLanguage.AR -> "قوة الشراء"
                            AppLanguage.EN -> "Buy Pressure"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Text(
                        text = "${String.format(Locale.US, "%.1f", buyPressurePct)}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (buyPressurePct >= 50.0) EmeraldBull else CrimsonBear
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Tendance OBV",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Text(
                        text = if (obvBullish) "Accumulation (+)" else "Distribution (-)",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (obvBullish) EmeraldBull else CrimsonBear
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = plan.reasoning(language),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun PriceLevelBox(
    label: String,
    priceText: String,
    pctText: String,
    subBadge: String,
    borderColor: Color,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(CyberNavyDark)
            .border(1.dp, borderColor.copy(alpha = 0.85f), RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontSize = 10.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = priceText,
            style = MaterialTheme.typography.labelLarge,
            color = valueColor,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = pctText,
            style = MaterialTheme.typography.labelSmall,
            color = TextPrimary,
            fontSize = 10.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = subBadge,
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            fontSize = 9.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun ConfluenceIndicatorsSummaryCard(
    votes: List<IndicatorVote>,
    activeDirection: TradeDirection,
    globalConfluenceScore: Int,
    language: AppLanguage
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderCyan, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Analytics,
                        contentDescription = "Confluence",
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (language) {
                            AppLanguage.FR -> "Validation des 7 Indicateurs & Volume"
                            AppLanguage.AR -> "تحليل وتوافق جميع المؤشرات والحجم"
                            AppLanguage.EN -> "7-Indicator & Volume Validation"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                }

                Text(
                    text = "$globalConfluenceScore% Confluence",
                    style = MaterialTheme.typography.labelLarge,
                    color = EmeraldBull
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { (globalConfluenceScore / 100f).coerceIn(0.1f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape),
                color = EmeraldBull,
                trackColor = CyberNavyDark
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                votes.forEach { vote ->
                    val aligned = vote.signalDirection == activeDirection
                    val pillColor = if (vote.signalDirection == TradeDirection.LONG) EmeraldBull else CrimsonBear
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberSurface)
                            .border(
                                1.dp,
                                if (aligned) pillColor.copy(alpha = 0.5f) else BorderCyan,
                                RoundedCornerShape(10.dp)
                            )
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(pillColor)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = vote.name(language),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontSize = 13.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = vote.detail(language),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = vote.formattedValue,
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonCyan
                            )
                            Text(
                                text = if (vote.signalDirection == TradeDirection.LONG) "HAUSSIER" else "BAISSIER",
                                style = MaterialTheme.typography.labelSmall,
                                color = pillColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SecondaryStrategyPlanCard(
    plan: EntryPlan,
    language: AppLanguage,
    accentColor: Color,
    testTagPrefix: String,
    onCopy: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, accentColor.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
            .testTag("${testTagPrefix}_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = plan.title(language),
                        style = MaterialTheme.typography.titleLarge,
                        color = accentColor,
                        fontSize = 16.sp
                    )
                    Text(
                        text = plan.subtitle(language),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
                IconButton(
                    onClick = onCopy,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copier",
                        tint = accentColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 4-Column Row matching Frame 00:06 of video: TP2 | TP1 | SL | Entry (clearly labeled & strictly logical)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CompactLevelCell(
                    title = when (language) {
                        AppLanguage.FR -> "Entrée"
                        AppLanguage.AR -> "الدخول"
                        AppLanguage.EN -> "Entry"
                    },
                    value = CryptoPriceFormatter.formatPrice(plan.entryPrice),
                    sub = "100% Logique",
                    color = NeonCyan,
                    modifier = Modifier.weight(1f)
                )
                CompactLevelCell(
                    title = "Stop Loss",
                    value = CryptoPriceFormatter.formatPrice(plan.stopLoss),
                    sub = CryptoPriceFormatter.formatSignedPct(plan.slPct),
                    color = CrimsonBear,
                    modifier = Modifier.weight(1f)
                )
                CompactLevelCell(
                    title = "TP1",
                    value = CryptoPriceFormatter.formatPrice(plan.tp1),
                    sub = CryptoPriceFormatter.formatSignedPct(plan.tp1Pct),
                    color = EmeraldBull,
                    modifier = Modifier.weight(1f)
                )
                CompactLevelCell(
                    title = "TP2",
                    value = CryptoPriceFormatter.formatPrice(plan.tp2),
                    sub = CryptoPriceFormatter.formatSignedPct(plan.tp2Pct),
                    color = AmberGold,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "✓ ${plan.logicalInequalityProof}",
                style = MaterialTheme.typography.labelSmall,
                color = EmeraldBull,
                fontSize = 10.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = plan.reasoning(language),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun CompactLevelCell(
    title: String,
    value: String,
    sub: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(CyberNavyDark)
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontSize = 10.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = color,
            fontSize = 11.sp,
            textAlign = TextAlign.Center
        )
        Text(
            text = sub,
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            fontSize = 9.sp
        )
    }
}

private fun buildCopyText(symbol: String, plan: EntryPlan): String {
    return """
        CryptoAnalyser - $symbol (${plan.direction.name})
        ${plan.titleFr}
        Prix d'Entrée Sûr : ${CryptoPriceFormatter.formatPrice(plan.entryPrice)} USDT
        Stop Loss (SL)    : ${CryptoPriceFormatter.formatPrice(plan.stopLoss)} USDT (${CryptoPriceFormatter.formatSignedPct(plan.slPct)})
        Objectif TP1      : ${CryptoPriceFormatter.formatPrice(plan.tp1)} USDT (${CryptoPriceFormatter.formatSignedPct(plan.tp1Pct)})
        Objectif TP2      : ${CryptoPriceFormatter.formatPrice(plan.tp2)} USDT (${CryptoPriceFormatter.formatSignedPct(plan.tp2Pct)})
        Preuve Logique    : ${plan.logicalInequalityProof}
    """.trimIndent()
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    clipboard?.setPrimaryClip(ClipData.newPlainText("CryptoAnalyser Signal", text))
    Toast.makeText(context, "Signal copié dans le presse-papiers !", Toast.LENGTH_SHORT).show()
}
