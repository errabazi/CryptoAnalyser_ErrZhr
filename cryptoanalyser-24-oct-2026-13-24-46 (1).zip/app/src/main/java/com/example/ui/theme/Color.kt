package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberNavyDark = Color(0xFF030C19)
val CyberSurface = Color(0xFF07192A)
val CyberCard = Color(0xFF0A2138)
val CyberCardElevated = Color(0xFF102C4A)

val NeonCyan = Color(0xFF00DBE8)
val NeonCyanDim = Color(0xFF008B94)
val EmeraldBull = Color(0xFF25D366)
val EmeraldBullDark = Color(0xFF062616)
val CrimsonBear = Color(0xFFFF3B69)
val CrimsonBearDark = Color(0xFF3A0B19)
val AmberGold = Color(0xFFFFB800)
val MagentaAccent = Color(0xFFE040FB)

val TextPrimary = Color(0xFFF2F8FD)
val TextSecondary = Color(0xFF9FDBE4)
val TextMuted = Color(0xFF6C8EA6)
val BorderCyan = Color(0xFF154B6B)
