package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CryptoPriceFormatter
import com.example.model.FullAnalysisResult
import com.example.model.MarketAlertItem
import com.example.model.TradeDirection
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderCyan
import com.example.ui.theme.CrimsonBear
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardElevated
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.EmeraldBull
import com.example.ui.theme.EmeraldBullDark
import com.example.ui.theme.MagentaAccent
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * GRAPHIQUES & MACD (Frames 00:03 - 00:05 of CryptoAnalyser video)
 * Shows Candlestick Chart + horizontal levels for Entrée Immédiate, SL, TP1, TP2 + MACD(12,26,9) + Volume.
 */
@Composable
fun ChartsAndMacdSection(
    result: FullAnalysisResult,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val candles = result.candles.takeLast(42)
    val macdSlice = result.macdSeries.takeLast(42)
    val plan = result.immediateEntryPlan
    val snap = result.snapshot

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Candlestick + Price Levels Chart Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NeonCyan.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .testTag("candlestick_chart_card"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCard)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${snap.symbol} • ${snap.timeframe.label} (${snap.exchange.displayName})",
                            style = MaterialTheme.typography.titleMedium,
                            color = NeonCyan
                        )
                        Text(
                            text = when (language) {
                                AppLanguage.FR -> "Bougies + Niveaux Entrée / SL / TP1 / TP2"
                                AppLanguage.AR -> "الشموع اليابانية ومستويات الدخول والأهداف"
                                AppLanguage.EN -> "Candlesticks + Entry / SL / TP1 / TP2 Levels"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Text(
                        text = "${CryptoPriceFormatter.formatPrice(snap.currentPrice)} USDT",
                        style = MaterialTheme.typography.labelLarge,
                        color = EmeraldBull
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Legend Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ChartLegendDot("Entrée: ${CryptoPriceFormatter.formatPrice(plan.entryPrice)}", NeonCyan)
                    ChartLegendDot("SL: ${CryptoPriceFormatter.formatPrice(plan.stopLoss)}", CrimsonBear)
                    ChartLegendDot("TP1: ${CryptoPriceFormatter.formatPrice(plan.tp1)}", EmeraldBull)
                    ChartLegendDot("TP2: ${CryptoPriceFormatter.formatPrice(plan.tp2)}", AmberGold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberNavyDark)
                        .border(1.dp, BorderCyan, RoundedCornerShape(12.dp))
                        .padding(8.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        if (candles.isEmpty()) return@Canvas
                        val w = size.width
                        val h = size.height

                        val minCandleLow = candles.minOf { it.low }
                        val maxCandleHigh = candles.maxOf { it.high }
                        val minPrice = min(minCandleLow, min(plan.stopLoss, plan.tp2)) * 0.997
                        val maxPrice = max(maxCandleHigh, max(plan.stopLoss, plan.tp2)) * 1.003
                        val range = max(maxPrice - minPrice, maxPrice * 0.01)

                        fun priceToY(p: Double): Float {
                            val ratio = ((p - minPrice) / range).toFloat().coerceIn(0f, 1f)
                            return h - (ratio * h)
                        }

                        // Grid lines
                        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                        for (g in 1..4) {
                            val gy = h * (g / 5f)
                            drawLine(
                                color = BorderCyan.copy(alpha = 0.35f),
                                start = Offset(0f, gy),
                                end = Offset(w, gy),
                                strokeWidth = 1f
                            )
                        }

                        // Horizontal level lines for SL, Entry, TP1, TP2
                        val ySl = priceToY(plan.stopLoss)
                        val yEntry = priceToY(plan.entryPrice)
                        val yTp1 = priceToY(plan.tp1)
                        val yTp2 = priceToY(plan.tp2)

                        drawLine(
                            color = CrimsonBear,
                            start = Offset(0f, ySl),
                            end = Offset(w, ySl),
                            strokeWidth = 2.5f,
                            pathEffect = dashEffect
                        )
                        drawLine(
                            color = NeonCyan,
                            start = Offset(0f, yEntry),
                            end = Offset(w, yEntry),
                            strokeWidth = 3f
                        )
                        drawLine(
                            color = EmeraldBull,
                            start = Offset(0f, yTp1),
                            end = Offset(w, yTp1),
                            strokeWidth = 2.5f,
                            pathEffect = dashEffect
                        )
                        drawLine(
                            color = AmberGold,
                            start = Offset(0f, yTp2),
                            end = Offset(w, yTp2),
                            strokeWidth = 2.5f,
                            pathEffect = dashEffect
                        )

                        // Draw Candlesticks
                        val count = candles.size
                        val slotWidth = w / count.toFloat()
                        val bodyWidth = max(3f, slotWidth * 0.62f)

                        for (i in candles.indices) {
                            val c = candles[i]
                            val cx = (i + 0.5f) * slotWidth
                            val yHigh = priceToY(c.high)
                            val yLow = priceToY(c.low)
                            val yOpen = priceToY(c.open)
                            val yClose = priceToY(c.close)
                            val bull = c.close >= c.open
                            val color = if (bull) EmeraldBull else CrimsonBear

                            drawLine(
                                color = color,
                                start = Offset(cx, yHigh),
                                end = Offset(cx, yLow),
                                strokeWidth = 1.8f
                            )
                            val top = min(yOpen, yClose)
                            val bottom = max(yOpen, yClose)
                            val rectH = max(2.5f, bottom - top)
                            drawRect(
                                color = color,
                                topLeft = Offset(cx - bodyWidth / 2f, top),
                                size = Size(bodyWidth, rectH)
                            )
                        }
                    }
                }
            }
        }

        // 2. MACD (12, 26, 9) Sub-Chart Card (Matching Video Frame 00:04)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, EmeraldBull.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .testTag("macd_chart_card"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCard)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MACD (12, 26, 9) - ${snap.timeframe.label}",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = "Hist: ${CryptoPriceFormatter.formatPrice(snap.macdHistogram)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (snap.macdHistogram >= 0) EmeraldBull else CrimsonBear
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberNavyDark)
                        .border(1.dp, BorderCyan, RoundedCornerShape(12.dp))
                        .padding(8.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        if (macdSlice.isEmpty()) return@Canvas
                        val w = size.width
                        val h = size.height
                        val midY = h * 0.55f

                        val maxAbs = macdSlice.maxOf {
                            max(abs(it.first), max(abs(it.second), abs(it.third)))
                        }.coerceAtLeast(1e-9)

                        fun valToY(v: Double): Float {
                            val norm = (v / maxAbs).toFloat().coerceIn(-1f, 1f)
                            return midY - (norm * (h * 0.42f))
                        }

                        drawLine(
                            color = BorderCyan,
                            start = Offset(0f, midY),
                            end = Offset(w, midY),
                            strokeWidth = 1.5f
                        )

                        val count = macdSlice.size
                        val slotW = w / count.toFloat()
                        val barW = max(3f, slotW * 0.55f)

                        val macdPath = Path()
                        val sigPath = Path()

                        for (i in macdSlice.indices) {
                            val (m, s, hist) = macdSlice[i]
                            val x = (i + 0.5f) * slotW
                            val yHist = valToY(hist)
                            val histColor = if (hist >= 0) EmeraldBull else MagentaAccent
                            val top = min(midY, yHist)
                            val bottom = max(midY, yHist)
                            drawRect(
                                color = histColor.copy(alpha = 0.85f),
                                topLeft = Offset(x - barW / 2f, top),
                                size = Size(barW, max(2f, bottom - top))
                            )

                            val ym = valToY(m)
                            val ys = valToY(s)
                            if (i == 0) {
                                macdPath.moveTo(x, ym)
                                sigPath.moveTo(x, ys)
                            } else {
                                macdPath.lineTo(x, ym)
                                sigPath.lineTo(x, ys)
                            }
                        }

                        drawPath(path = macdPath, color = EmeraldBull, style = Stroke(width = 3f))
                        drawPath(path = sigPath, color = AmberGold, style = Stroke(width = 2.5f))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = when (language) {
                        AppLanguage.FR -> "L'histogramme MACD et le volume confirment l'impulsion avant la validation du Prix d'Entrée Immédiate."
                        AppLanguage.AR -> "مؤشر MACD وحجم التداول يؤكدان الزخم قبل اعتماد سعر الدخول الفوري."
                        AppLanguage.EN -> "MACD histogram and volume confirm momentum prior to validating the Immediate Entry price."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun ChartLegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontSize = 10.sp
        )
    }
}

/**
 * INDICATEURS MULTIPLES EN UN SEUL ENDROIT (Frames 00:12 - 00:14 of CryptoAnalyser video)
 * Shows dual comparison & detailed cards for OBV, MACD/Signal, Supertrend(10,3), RSI(14), VWAP, Bollinger, ATR.
 */
@Composable
fun AllIndicatorsDashboardSection(
    result: FullAnalysisResult,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val snap = result.snapshot
    val imm = result.immediateEntryPlan
    val pull = result.pullbackEntryPlan

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NeonCyan.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                .testTag("all_indicators_dashboard_card"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCard)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Indicateurs",
                        tint = NeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = when (language) {
                                AppLanguage.FR -> "INDICATEURS & VOLUME EN UN SEUL ENDROIT"
                                AppLanguage.AR -> "أدوات ومؤشرات فنية متعددة في مكان واحد"
                                AppLanguage.EN -> "MULTIPLE TECHNICAL INDICATORS IN ONE PLACE"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = NeonCyan
                        )
                        Text(
                            text = "${snap.symbol} • ${snap.exchange.displayName} • ${snap.timeframe.label}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Dual Side-by-Side Comparison Columns (Matching Frame 00:12-00:14 of video!)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Column 1: Setup Entrée Immédiate Sûre
                    IndicatorColumnCard(
                        headerTitle = when (language) {
                            AppLanguage.FR -> "Entrée Immédiate"
                            AppLanguage.AR -> "الدخول الفوري"
                            AppLanguage.EN -> "Immediate Setup"
                        },
                        currentPrice = "${CryptoPriceFormatter.formatPrice(snap.currentPrice)} USDT",
                        entryLabel = when (language) {
                            AppLanguage.FR -> "Prix d'Entrée Sûr"
                            AppLanguage.AR -> "السعر المقترح للدخول"
                            AppLanguage.EN -> "Safe Entry Price"
                        },
                        entryValue = CryptoPriceFormatter.formatPrice(imm.entryPrice),
                        slLabel = when (language) {
                            AppLanguage.FR -> "Stop Loss (SL)"
                            AppLanguage.AR -> "وقف الخسارة"
                            AppLanguage.EN -> "Stop Loss (SL)"
                        },
                        slValue = CryptoPriceFormatter.formatPrice(imm.stopLoss),
                        tp1Value = CryptoPriceFormatter.formatPrice(imm.tp1),
                        tp2Value = CryptoPriceFormatter.formatPrice(imm.tp2),
                        obvValue = CryptoPriceFormatter.formatCompactVolume(snap.obv),
                        macdSignalValue = "${CryptoPriceFormatter.formatPrice(snap.macdLine)}\n${CryptoPriceFormatter.formatPrice(snap.signalLine)}",
                        supertrendValue = CryptoPriceFormatter.formatPrice(snap.supertrendValue),
                        rsiValue = "${String.format(Locale.US, "%.1f", snap.rsi14)}\navg ${String.format(Locale.US, "%.2f", snap.rsiAvg14 / 100.0)}",
                        modifier = Modifier.weight(1f)
                    )

                    // Column 2: Setup Entrée sur Repli (Pullback)
                    IndicatorColumnCard(
                        headerTitle = when (language) {
                            AppLanguage.FR -> "Entrée sur Repli"
                            AppLanguage.AR -> "الدخول بعد التصحيح"
                            AppLanguage.EN -> "Pullback Setup"
                        },
                        currentPrice = "${CryptoPriceFormatter.formatPrice(snap.currentPrice)} USDT",
                        entryLabel = when (language) {
                            AppLanguage.FR -> "Entrée Pullback"
                            AppLanguage.AR -> "سعر الدخول التصحيحي"
                            AppLanguage.EN -> "Pullback Entry"
                        },
                        entryValue = CryptoPriceFormatter.formatPrice(pull.entryPrice),
                        slLabel = when (language) {
                            AppLanguage.FR -> "Stop Loss (SL)"
                            AppLanguage.AR -> "وقف الخسارة"
                            AppLanguage.EN -> "Stop Loss (SL)"
                        },
                        slValue = CryptoPriceFormatter.formatPrice(pull.stopLoss),
                        tp1Value = CryptoPriceFormatter.formatPrice(pull.tp1),
                        tp2Value = CryptoPriceFormatter.formatPrice(pull.tp2),
                        obvValue = "RVOL ${String.format(Locale.US, "%.2f", snap.rvol)}x",
                        macdSignalValue = "VWAP\n${CryptoPriceFormatter.formatPrice(snap.vwap)}",
                        supertrendValue = "${CryptoPriceFormatter.formatPrice(snap.ema21)} (EMA21)",
                        rsiValue = "ATR(14)\n${CryptoPriceFormatter.formatPrice(snap.atr14)}",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun IndicatorColumnCard(
    headerTitle: String,
    currentPrice: String,
    entryLabel: String,
    entryValue: String,
    slLabel: String,
    slValue: String,
    tp1Value: String,
    tp2Value: String,
    obvValue: String,
    macdSignalValue: String,
    supertrendValue: String,
    rsiValue: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = CyberNavyDark,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderCyan)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = headerTitle,
                style = MaterialTheme.typography.titleMedium,
                color = NeonCyan,
                fontSize = 13.sp
            )
            Text(
                text = currentPrice,
                style = MaterialTheme.typography.labelLarge,
                color = TextPrimary
            )

            HorizontalDivider(color = BorderCyan)

            MetricPairRow(entryLabel, entryValue, NeonCyan)
            MetricPairRow(slLabel, slValue, CrimsonBear)
            MetricPairRow("TP1 (Sûr)", tp1Value, EmeraldBull)
            MetricPairRow("TP2 (Max)", tp2Value, AmberGold)

            HorizontalDivider(color = BorderCyan)

            MetricPairRow("OBV / Flux", obvValue, NeonCyan)
            MetricPairRow("MACD / Signal", macdSignalValue, TextPrimary)
            MetricPairRow("Supertrend (10,3)", supertrendValue, EmeraldBull)
            MetricPairRow("RSI (14)", rsiValue, TextSecondary)
        }
    }
}

@Composable
private fun MetricPairRow(label: String, value: String, valueColor: Color) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            fontSize = 10.sp,
            textAlign = TextAlign.Center
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = valueColor,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * ALERTES DU MARCHÉ & CONTACT (Frames 00:09 - 00:11 & 00:18 - 00:20 of CryptoAnalyser video)
 */
@Composable
fun MarketAlertsAndScannerSection(
    alerts: List<MarketAlertItem>,
    language: AppLanguage,
    onSelectAlertSymbol: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = when (language) {
                AppLanguage.FR -> "ALERTES DU MARCHÉ & MOUVEMENTS VÉRIFIÉS"
                AppLanguage.AR -> "تنبيهات السوق وتحركات العملات المؤكدة"
                AppLanguage.EN -> "MARKET ALERTS & VERIFIED MOVES"
            },
            style = MaterialTheme.typography.titleMedium,
            color = NeonCyan
        )

        alerts.forEach { item ->
            val isLong = item.direction == TradeDirection.LONG
            val dirColor = if (isLong) EmeraldBull else CrimsonBear

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderCyan, RoundedCornerShape(16.dp))
                    .clickable { onSelectAlertSymbol(item.symbol) }
                    .testTag("alert_card_${item.symbol.lowercase()}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = "Alerte",
                                tint = NeonCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = item.symbol,
                                style = MaterialTheme.typography.titleLarge,
                                color = TextPrimary,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = dirColor.copy(alpha = 0.18f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "${item.direction.name} • ${item.confidenceScore}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = dirColor,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Text(
                            text = item.timeAgoLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = item.headline(language),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "${item.exchange.displayName} • ${CryptoPriceFormatter.formatPrice(item.price)} USDT • 24h ${CryptoPriceFormatter.formatSignedPct(item.change24hPct)} • recent +${String.format(Locale.US, "%.2f", item.recentImpulsePct)}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberNavyDark)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Entrée: ${CryptoPriceFormatter.formatPrice(item.immediateSafeEntry)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonCyan
                        )
                        Text(
                            text = "SL: ${CryptoPriceFormatter.formatPrice(item.stopLoss)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrimsonBear
                        )
                        Text(
                            text = "TP1: ${CryptoPriceFormatter.formatPrice(item.tp1)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldBull
                        )
                        Text(
                            text = "TP2: ${CryptoPriceFormatter.formatPrice(item.tp2)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberGold
                        )
                    }
                }
            }
        }

        // Direct WhatsApp Support Card (from the user's CryptoAnalyser-by ErrZhr package)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, EmeraldBull, RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCardElevated)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "CryptoAnalyser • by ErrZhr",
                    style = MaterialTheme.typography.titleLarge,
                    color = NeonCyan
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = when (language) {
                        AppLanguage.FR -> "Partager ou contacter le support direct sur WhatsApp"
                        AppLanguage.AR -> "تواصل معنا مباشرة عبر WhatsApp"
                        AppLanguage.EN -> "Contact us directly on WhatsApp"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        val url = "https://wa.me/212620202714"
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldBull,
                        contentColor = EmeraldBullDark
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("whatsapp_contact_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "WhatsApp",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "WhatsApp Direct (+212 620 202 714)",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
