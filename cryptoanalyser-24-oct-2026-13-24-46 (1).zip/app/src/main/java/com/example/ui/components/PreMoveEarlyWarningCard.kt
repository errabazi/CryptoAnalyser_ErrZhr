package com.example.ui.components

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CryptoPriceFormatter
import com.example.model.PreMoveEarlyAlert
import com.example.model.TradeDirection
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderCyan
import com.example.ui.theme.CrimsonBear
import com.example.ui.theme.CrimsonBearDark
import com.example.ui.theme.CyberCardElevated
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.EmeraldBull
import com.example.ui.theme.EmeraldBullDark
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.CryptoPreMoveNotificationHelper
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs

@Composable
fun PreMoveEarlyWarningCard(
    alert: PreMoveEarlyAlert,
    autoNotifyEnabled: Boolean,
    language: AppLanguage,
    onToggleAutoNotify: (Boolean) -> Unit,
    onTriggerPreMoveAlert: (TradeDirection) -> PreMoveEarlyAlert?,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var countdownSeconds by remember(alert.id) { mutableIntStateOf(60) }
    var pendingAlertToNotify by remember { mutableStateOf<PreMoveEarlyAlert?>(null) }
    var lastAutoNotifiedId by remember { mutableStateOf("") }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            pendingAlertToNotify?.let { target ->
                CryptoPreMoveNotificationHelper.sendOneMinuteAdvanceNotification(context, target, language)
            }
            Toast.makeText(
                context,
                "Notifications prédictives (-1 min) activées !",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Toast.makeText(
                context,
                "Alerte affichée à l'écran (autorisez les notifications système pour les recevoir en arrière-plan).",
                Toast.LENGTH_SHORT
            ).show()
        }
        pendingAlertToNotify = null
    }

    fun dispatchNotificationWithPermissionCheck(targetAlert: PreMoveEarlyAlert, showToast: Boolean) {
        if (CryptoPreMoveNotificationHelper.hasNotificationPermission(context)) {
            CryptoPreMoveNotificationHelper.sendOneMinuteAdvanceNotification(context, targetAlert, language)
            if (showToast) {
                val moveType = if (targetAlert.direction == TradeDirection.LONG) "HAUSSE FORTE" else "BAISSE FORTE"
                Toast.makeText(
                    context,
                    "Notification (-1 min) envoyée : $moveType sur ${targetAlert.symbol} !",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pendingAlertToNotify = targetAlert
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Live 60-second countdown timer (1 minute before predicted impulse)
    LaunchedEffect(alert.id) {
        countdownSeconds = 60
        if (autoNotifyEnabled && alert.id != lastAutoNotifiedId) {
            lastAutoNotifiedId = alert.id
            dispatchNotificationWithPermissionCheck(alert, showToast = false)
        }
        while (countdownSeconds > 0) {
            delay(1000L)
            countdownSeconds--
        }
    }

    val isBull = alert.direction == TradeDirection.LONG
    val accentColor = if (isBull) EmeraldBull else CrimsonBear
    val badgeBg = if (isBull) EmeraldBullDark else CrimsonBearDark
    val movePctStr = "${if (isBull) "+" else "-"}${String.format(Locale.US, "%.2f", abs(alert.expectedMovePct))}%"

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.8.dp,
                brush = Brush.horizontalGradient(listOf(accentColor, AmberGold, NeonCyan)),
                shape = RoundedCornerShape(18.dp)
            )
            .testTag("pre_move_1min_warning_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCardElevated)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Radar Icon + 1-Min Early Warning Title + Auto-Notify Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = AmberGold.copy(alpha = 0.2f),
                        shape = CircleShape,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = "Alerte -1 min",
                                tint = AmberGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = when (language) {
                                AppLanguage.FR -> "RADAR PRÉDICTIF : NOTIFICATION 1 MIN AVANT"
                                AppLanguage.AR -> "رادار التوقع المبكر: تنبيه قبل دقيقة واحدة"
                                AppLanguage.EN -> "EARLY WARNING RADAR: 1 MIN BEFORE MOVE"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = AmberGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = when (language) {
                                AppLanguage.FR -> "Détection anticipée de Hausse Forte ou Baisse Forte (Volume + OBV)"
                                AppLanguage.AR -> "كشف مبكر لحركة الصعود القوي أو الهبوط القوي قبل حدوثها بدقيقة"
                                AppLanguage.EN -> "Detects strong upward or downward moves 60s in advance"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Switch(
                    checked = autoNotifyEnabled,
                    onCheckedChange = { enabled ->
                        onToggleAutoNotify(enabled)
                        if (enabled) {
                            dispatchNotificationWithPermissionCheck(alert, showToast = true)
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CyberNavyDark,
                        checkedTrackColor = EmeraldBull,
                        uncheckedThumbColor = TextSecondary,
                        uncheckedTrackColor = CyberNavyDark
                    ),
                    modifier = Modifier.testTag("auto_notify_1min_switch")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Active 60s Countdown & Detected Move Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(CyberNavyDark)
                    .border(1.dp, accentColor.copy(alpha = 0.8f), RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = badgeBg,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, accentColor)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isBull) Icons.AutoMirrored.Filled.TrendingUp else Icons.AutoMirrored.Filled.TrendingDown,
                                    contentDescription = null,
                                    tint = accentColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = when (language) {
                                        AppLanguage.FR -> if (isBull) "HAUSSE FORTE PRÉVUE ($movePctStr)" else "BAISSE FORTE PRÉVUE ($movePctStr)"
                                        AppLanguage.AR -> if (isBull) "صعود قوي متوقع ($movePctStr)" else "هبوط قوي متوقع ($movePctStr)"
                                        AppLanguage.EN -> if (isBull) "STRONG UPWARD MOVE ($movePctStr)" else "STRONG DOWNWARD MOVE ($movePctStr)"
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    color = accentColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // 1-Minute Countdown Pill (T - 00:XXs)
                        Surface(
                            color = CyberSurface,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = "Compte à rebours 1 min",
                                    tint = AmberGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "T-00:${String.format(Locale.US, "%02d", countdownSeconds)}s",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontFamily = JetBrainsMonoFontFamily
                                    ),
                                    color = AmberGold,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.testTag("pre_move_countdown_timer")
                                )
                            }
                        }
                    }

                    LinearProgressIndicator(
                        progress = { (countdownSeconds / 60f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(CircleShape),
                        color = accentColor,
                        trackColor = CyberSurface
                    )

                    Text(
                        text = "${alert.symbol} (${alert.exchange.displayName}) • ${alert.triggerReason(language)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        fontSize = 12.sp
                    )

                    // Pre-Move Safe Immediate Entry Levels
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSurface)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Entrée: ${CryptoPriceFormatter.formatPrice(alert.safeImmediateEntry)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonCyan
                        )
                        Text(
                            text = "SL: ${CryptoPriceFormatter.formatPrice(alert.stopLoss)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrimsonBear
                        )
                        Text(
                            text = "TP1: ${CryptoPriceFormatter.formatPrice(alert.tp1)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldBull
                        )
                        Text(
                            text = "TP2: ${CryptoPriceFormatter.formatPrice(alert.tp2)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberGold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Instant Test Buttons for Strong Upward (Hausse Forte) & Strong Downward (Baisse Forte) 1-Min Notifications
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val newAlert = onTriggerPreMoveAlert(TradeDirection.LONG) ?: alert
                        countdownSeconds = 60
                        dispatchNotificationWithPermissionCheck(newAlert, showToast = true)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldBull,
                        contentColor = EmeraldBullDark
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("trigger_bullish_1min_notification")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = when (language) {
                            AppLanguage.FR -> "Alerte Hausse (-1m)"
                            AppLanguage.AR -> "تنبيه صعود (-1د)"
                            AppLanguage.EN -> "Notify Pump (-1m)"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = {
                        val newAlert = onTriggerPreMoveAlert(TradeDirection.SHORT) ?: alert
                        countdownSeconds = 60
                        dispatchNotificationWithPermissionCheck(newAlert, showToast = true)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CrimsonBear,
                        contentColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("trigger_bearish_1min_notification")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.TrendingDown,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = when (language) {
                            AppLanguage.FR -> "Alerte Baisse (-1m)"
                            AppLanguage.AR -> "تنبيه هبوط (-1د)"
                            AppLanguage.EN -> "Notify Dump (-1m)"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
