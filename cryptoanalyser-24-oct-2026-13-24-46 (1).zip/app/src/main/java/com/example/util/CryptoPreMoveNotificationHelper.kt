package com.example.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import com.example.model.AppLanguage
import com.example.model.CryptoPriceFormatter
import com.example.model.PreMoveEarlyAlert
import com.example.model.TradeDirection
import java.util.Locale

object CryptoPreMoveNotificationHelper {

    private const val CHANNEL_ID = "crypto_pre_move_1min_alerts"
    private const val CHANNEL_NAME = "Alertes Prédictives (-1 min) Hausse/Baisse Forte"

    fun ensureChannelCreated(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications envoyées 1 minute avant un mouvement de hausse forte ou de baisse forte détecté par le volume et les indicateurs"
                enableVibration(true)
                vibrationPattern = longArrayOf(0L, 350L, 150L, 450L)
            }
            manager?.createNotificationChannel(channel)
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun sendOneMinuteAdvanceNotification(
        context: Context,
        alert: PreMoveEarlyAlert,
        language: AppLanguage
    ): Boolean {
        ensureChannelCreated(context)
        if (!hasNotificationPermission(context)) {
            return false
        }

        val isBullish = alert.direction == TradeDirection.LONG
        val moveSign = if (isBullish) "+" else "-"
        val movePctFormatted = "$moveSign${String.format(Locale.US, "%.2f", kotlin.math.abs(alert.expectedMovePct))}%"
        val fEntry = CryptoPriceFormatter.formatPrice(alert.safeImmediateEntry)
        val fSl = CryptoPriceFormatter.formatPrice(alert.stopLoss)
        val fTp1 = CryptoPriceFormatter.formatPrice(alert.tp1)
        val fTp2 = CryptoPriceFormatter.formatPrice(alert.tp2)

        val title = when (language) {
            AppLanguage.FR -> if (isBullish) {
                "ALERTE -1 MIN : HAUSSE FORTE PRÉVUE sur ${alert.symbol} ($movePctFormatted)"
            } else {
                "ALERTE -1 MIN : BAISSE FORTE PRÉVUE sur ${alert.symbol} ($movePctFormatted)"
            }
            AppLanguage.AR -> if (isBullish) {
                "تنبيه قبل دقيقة: صعود قوي متوقع على ${alert.symbol} ($movePctFormatted)"
            } else {
                "تنبيه قبل دقيقة: هبوط قوي متوقع على ${alert.symbol} ($movePctFormatted)"
            }
            AppLanguage.EN -> if (isBullish) {
                "1-MIN EARLY WARNING: STRONG PUMP on ${alert.symbol} ($movePctFormatted)"
            } else {
                "1-MIN EARLY WARNING: STRONG DUMP on ${alert.symbol} ($movePctFormatted)"
            }
        }

        val shortBody = when (language) {
            AppLanguage.FR -> "Mouvement prévu dans ~1 min (${alert.probabilityPct}% sûr) • Entrée: $fEntry | TP1: $fTp1 | TP2: $fTp2 | SL: $fSl"
            AppLanguage.AR -> "حركة قوية خلال دقيقة (${alert.probabilityPct}%) • الدخول: $fEntry | TP1: $fTp1 | TP2: $fTp2 | SL: $fSl"
            AppLanguage.EN -> "Predicted move in ~1 min (${alert.probabilityPct}% conf) • Entry: $fEntry | TP1: $fTp1 | TP2: $fTp2 | SL: $fSl"
        }

        val expandedBody = """
            $shortBody
            Indicateurs Précurseurs : ${alert.triggerReason(language)}
            Volume RVOL : ${String.format(Locale.US, "%.2f", alert.rvol)}x | Flux : ${String.format(Locale.US, "%.0f", alert.buyPressurePct)}%
        """.trimIndent()

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            alert.symbol.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(shortBody)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expandedBody))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(0L, 350L, 150L, 450L))
            .build()

        return try {
            NotificationManagerCompat.from(context).notify(
                (alert.id.hashCode() and 0x7FFFFFFF),
                notification
            )
            true
        } catch (_: SecurityException) {
            false
        }
    }
}
