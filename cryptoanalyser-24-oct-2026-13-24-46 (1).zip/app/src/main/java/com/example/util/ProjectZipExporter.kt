package com.example.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.model.CryptoPriceFormatter
import com.example.model.FullAnalysisResult
import com.example.model.LiveCryptoAsset
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ProjectZipExporter {

    fun buildZipBytes(
        analysis: FullAnalysisResult?,
        liveAssets: List<LiveCryptoAsset>
    ): ByteArray {
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            // 1. Add HTML Ad Landing Page (CryptoAnalyser_Ad_WhatsApp.html)
            addTextEntry(
                zos,
                "CryptoAnalyser_Ad_WhatsApp.html",
                buildWhatsAppLandingHtml()
            )

            // 2. Add Live Technical Analysis & Safe Immediate Entry Report
            addTextEntry(
                zos,
                "Rapport_Entree_Immediate_100_Sure.txt",
                buildLiveReportText(analysis, liveAssets)
            )

            // 3. Add README & Build Instructions
            addTextEntry(
                zos,
                "LISEZ_MOI_INSTRUCTIONS.txt",
                """
                ================================================================
                CRYPTOANALYSER - BY ERRZHR (VERSION FINALE CORRIGÉE 100%)
                ================================================================
                
                1. CORRECTIONS APPORTÉES :
                   - Entrée Immédiate Sûre 100% : Calcul mathématique strict basé
                     sur 7 indicateurs (EMA 9/21/50, MACD 12/26/9, RSI 14,
                     Supertrend 10/3, VWAP, Bandes de Bollinger, ATR 14) + Volume
                     (RVOL & OBV).
                   - Garantie stricte en LONG  : Stop Loss < Prix d'Entrée < TP1 < TP2
                   - Garantie stricte en SHORT : Stop Loss > Prix d'Entrée > TP1 > TP2
                   - Détecteur Prédictif (-1 Minute / 60s avant mouvement fort) :
                     Envoie une notification haute priorité 1 minute avant une
                     Hausse Forte ou une Baisse Forte.
                   - Tableau de bord en temps réel des actifs Crypto avec prix et
                     indicateur visuel de tendance (Sparkline + Badge 24h).
                """.trimIndent()
            )
        }
        return baos.toByteArray()
    }

    fun writeZipToUri(
        context: Context,
        uri: Uri,
        analysis: FullAnalysisResult?,
        liveAssets: List<LiveCryptoAsset>
    ): Boolean {
        return try {
            val bytes = buildZipBytes(analysis, liveAssets)
            context.contentResolver.openOutputStream(uri)?.use { os ->
                os.write(bytes)
                os.flush()
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun saveZipToDownloads(
        context: Context,
        fileName: String = "CryptoAnalyser_Final_Corrige.zip",
        analysis: FullAnalysisResult?,
        liveAssets: List<LiveCryptoAsset>
    ): String? {
        return try {
            val bytes = buildZipBytes(analysis, liveAssets)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return null
                resolver.openOutputStream(uri)?.use { os: OutputStream ->
                    os.write(bytes)
                    os.flush()
                }
                "Download/$fileName"
            } else {
                val file = java.io.File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
                file.writeBytes(bytes)
                file.absolutePath
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun addTextEntry(zos: ZipOutputStream, name: String, content: String) {
        val entry = ZipEntry(name)
        zos.putNextEntry(entry)
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }

    private fun buildLiveReportText(
        analysis: FullAnalysisResult?,
        liveAssets: List<LiveCryptoAsset>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("=== CRYPTOANALYSER - RAPPORT D'ENTRÉE IMMÉDIATE SÛRE 100% ===")
        if (analysis != null) {
            val snap = analysis.snapshot
            val imm = analysis.immediateEntryPlan
            val pull = analysis.pullbackEntryPlan
            val brk = analysis.breakoutRetestPlan
            sb.appendLine("Paire Active : ${snap.symbol} (${snap.exchange.displayName} - ${snap.timeframe.label})")
            sb.appendLine("Prix Actuel  : ${CryptoPriceFormatter.formatPrice(snap.currentPrice)} USDT")
            sb.appendLine("Confluence   : ${analysis.globalConfluenceScore}% (${imm.direction.name})")
            sb.appendLine()
            sb.appendLine("1) ENTRÉE IMMÉDIATE SÛRE 100% :")
            sb.appendLine("   - Prix d'Entrée Sûr : ${CryptoPriceFormatter.formatPrice(imm.entryPrice)} USDT")
            sb.appendLine("   - Stop Loss (SL)    : ${CryptoPriceFormatter.formatPrice(imm.stopLoss)} USDT (${CryptoPriceFormatter.formatSignedPct(imm.slPct)})")
            sb.appendLine("   - Objectif TP1      : ${CryptoPriceFormatter.formatPrice(imm.tp1)} USDT (${CryptoPriceFormatter.formatSignedPct(imm.tp1Pct)})")
            sb.appendLine("   - Objectif TP2      : ${CryptoPriceFormatter.formatPrice(imm.tp2)} USDT (${CryptoPriceFormatter.formatSignedPct(imm.tp2Pct)})")
            sb.appendLine("   - Preuve Logique    : ${imm.logicalInequalityProof}")
            sb.appendLine()
            sb.appendLine("2) ENTRÉE SUR REPLI (PULLBACK) :")
            sb.appendLine("   - ${pull.logicalInequalityProof}")
            sb.appendLine()
            sb.appendLine("3) ENTRÉE CASSURE & RETEST (BREAKOUT-RETEST) :")
            sb.appendLine("   - ${brk.logicalInequalityProof}")
            sb.appendLine()
        }
        sb.appendLine("=== TABLEAU DE BORD DES ACTIFS EN TEMPS RÉEL ===")
        liveAssets.forEach { asset ->
            sb.appendLine(
                "${asset.symbol} | Prix: ${CryptoPriceFormatter.formatPrice(asset.currentPrice)} USDT (${CryptoPriceFormatter.formatSignedPct(asset.change24hPct)}) | " +
                    "Entrée Sûre: ${CryptoPriceFormatter.formatPrice(asset.safeImmediateEntry)} | SL: ${CryptoPriceFormatter.formatPrice(asset.stopLoss)} | " +
                    "TP1: ${CryptoPriceFormatter.formatPrice(asset.tp1)} | TP2: ${CryptoPriceFormatter.formatPrice(asset.tp2)}"
            )
        }
        return sb.toString()
    }

    private fun buildWhatsAppLandingHtml(): String {
        return """<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CryptoAnalyser-by ErrZhr</title><style>body{margin:0;background:#030c19;color:white;font-family:Arial,sans-serif;text-align:center}.wrap{max-width:540px;margin:auto;padding:16px}.card{background:#07192a;border:1px solid #00dbe8;border-radius:16px;padding:16px;margin:14px 0;text-align:left}.wa{display:block;background:#25d366;color:#062616;text-decoration:none;font-weight:bold;padding:18px 10px;border-radius:18px;font-size:19px;margin:10px 0;text-align:center}.num{color:#9fdbe4}</style><div class="wrap"><h1>CryptoAnalyser-by ErrZhr</h1><div class="card"><h3 style="color:#00dbe8;margin-top:0">Entrée Immédiate Sûre 100% + Alerte -1 Min</h3><p>Analyse multi-indicateurs (MACD, RSI, Supertrend, EMA, VWAP) + Volume (RVOL & OBV) avec garantie mathématique SL &lt; Entrée &lt; TP1 &lt; TP2.</p></div><a class="wa" id="wa" href="https://wa.me/212620202714?text=Bonjour,%20je%20souhaite%20obtenir%20l%E2%80%99APK%20de%20CryptoAnalyser-by%20ErrZhr.">Cliquez ici pour nous contacter sur WhatsApp</a><p class="num">+212 620 202 714</p></div></html>"""
    }
}
