package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AppLanguage
import com.example.model.CryptoPriceFormatter
import com.example.model.ExchangePlatform
import com.example.model.MarketMode
import com.example.model.Timeframe
import com.example.ui.CryptoAnalyserViewModel
import com.example.ui.CryptoTab
import com.example.ui.components.AllIndicatorsDashboardSection
import com.example.ui.components.ChartsAndMacdSection
import com.example.ui.components.EntryPlansSection
import com.example.ui.components.LiveAssetsDashboardSection
import com.example.ui.components.MarketAlertsAndScannerSection
import com.example.ui.theme.AmberGold
import com.example.ui.theme.BorderCyan
import com.example.ui.theme.CrimsonBear
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardElevated
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.EmeraldBull
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CryptoAnalyserApp()
            }
        }
    }
}

@Composable
fun CryptoAnalyserApp(
    viewModel: CryptoAnalyserViewModel = viewModel()
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showSearchDialog by remember { mutableStateOf(false) }
    var customSymbolInput by remember { mutableStateOf("") }
    var zipDownloadMessage by remember { mutableStateOf<String?>(null) }

    val saveZipLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            val ok = com.example.util.ProjectZipExporter.writeZipToUri(
                context = context,
                uri = uri,
                analysis = state.analysisResult,
                liveAssets = state.liveAssets
            )
            if (ok) {
                zipDownloadMessage = "Le fichier CryptoAnalyser_Final_Corrige.zip a été enregistré avec succès sur votre appareil !"
            }
        }
    }

    if (state.selectedTab != CryptoTab.DASHBOARD) {
        BackHandler {
            viewModel.selectTab(CryptoTab.DASHBOARD)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = CyberNavyDark,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            NavigationBar(
                containerColor = CyberSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.border(width = 1.dp, color = BorderCyan)
            ) {
                val tabs = listOf(
                    Triple(
                        CryptoTab.DASHBOARD,
                        Icons.Default.Dashboard,
                        when (state.language) {
                            AppLanguage.FR -> "Marché"
                            AppLanguage.AR -> "السوق"
                            AppLanguage.EN -> "Dashboard"
                        }
                    ),
                    Triple(
                        CryptoTab.IMMEDIATE_ENTRY,
                        Icons.Default.GppGood,
                        when (state.language) {
                            AppLanguage.FR -> "Entrée 100%"
                            AppLanguage.AR -> "الدخول الفوري"
                            AppLanguage.EN -> "Safe Entry"
                        }
                    ),
                    Triple(
                        CryptoTab.CHARTS_MACD,
                        Icons.Default.BarChart,
                        when (state.language) {
                            AppLanguage.FR -> "Graph & MACD"
                            AppLanguage.AR -> "الشارت"
                            AppLanguage.EN -> "Charts"
                        }
                    ),
                    Triple(
                        CryptoTab.INDICATORS_VOLUME,
                        Icons.Default.Speed,
                        when (state.language) {
                            AppLanguage.FR -> "Indicateurs"
                            AppLanguage.AR -> "المؤشرات"
                            AppLanguage.EN -> "Indicators"
                        }
                    ),
                    Triple(
                        CryptoTab.ALERTS_SCANNER,
                        Icons.Default.NotificationsActive,
                        when (state.language) {
                            AppLanguage.FR -> "Alertes"
                            AppLanguage.AR -> "التنبيهات"
                            AppLanguage.EN -> "Alerts"
                        }
                    )
                )

                tabs.forEach { (tab, icon, label) ->
                    val selected = state.selectedTab == tab
                    NavigationBarItem(
                        selected = selected,
                        onClick = { viewModel.selectTab(tab) },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = label
                            )
                        },
                        label = {
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberNavyDark,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("main_dashboard_lazy_column"),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Top Brand & Language Bar
            item {
                TopHeaderAndMarketBar(
                    selectedLanguage = state.language,
                    selectedSymbol = state.selectedSymbol,
                    selectedExchange = state.selectedExchange,
                    selectedMarketMode = state.selectedMarketMode,
                    selectedTimeframe = state.selectedTimeframe,
                    featuredPairs = state.featuredPairs,
                    currentPrice = state.analysisResult?.snapshot?.currentPrice,
                    change24hPct = state.analysisResult?.snapshot?.priceChange24hPct,
                    onLanguageChange = viewModel::selectLanguage,
                    onSymbolSelect = { sym -> viewModel.selectSymbol(sym, switchToEntryTab = false) },
                    onOpenSearchDialog = { showSearchDialog = true },
                    onExchangeSelect = viewModel::selectExchange,
                    onMarketModeSelect = viewModel::selectMarketMode,
                    onTimeframeSelect = viewModel::selectTimeframe
                )
            }

            // 1.2. Bouton Direct : Télécharger le fichier .ZIP Final
            item {
                Button(
                    onClick = {
                        val savedPath = com.example.util.ProjectZipExporter.saveZipToDownloads(
                            context = context,
                            analysis = state.analysisResult,
                            liveAssets = state.liveAssets
                        )
                        if (savedPath != null) {
                            zipDownloadMessage = "Fichier enregistré dans vos Téléchargements : $savedPath\n\nVous pouvez aussi choisir un autre dossier en cliquant sur « Enregistrer sous... »."
                        } else {
                            saveZipLauncher.launch("CryptoAnalyser_Final_Corrige.zip")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonCyan,
                        contentColor = CyberNavyDark
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("download_final_zip_button")
                ) {
                    Text(
                        text = when (state.language) {
                            AppLanguage.FR -> "⬇ TÉLÉCHARGER LE FICHIER .ZIP FINAL"
                            AppLanguage.AR -> "⬇ تحميل ملف .ZIP النهائي"
                            AppLanguage.EN -> "⬇ DOWNLOAD FINAL .ZIP FILE"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // 1.5. Radar Prédictif : Notification 1 Minute Avant Mouvement Fort (Hausse / Baisse)
            item {
                val preAlert = state.activePreMoveAlert
                if (preAlert != null) {
                    com.example.ui.components.PreMoveEarlyWarningCard(
                        alert = preAlert,
                        autoNotifyEnabled = state.autoNotifyOneMinBefore,
                        language = state.language,
                        onToggleAutoNotify = viewModel::toggleAutoNotifyOneMin,
                        onTriggerPreMoveAlert = viewModel::triggerPreMoveEarlyAlert
                    )
                }
            }

            // 2. Main Tab Content
            item {
                val result = state.analysisResult
                when (state.selectedTab) {
                    CryptoTab.DASHBOARD -> {
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            LiveAssetsDashboardSection(
                                assets = state.liveAssets,
                                selectedSymbol = state.selectedSymbol,
                                language = state.language,
                                onSelectAsset = { symbol ->
                                    viewModel.selectSymbol(symbol, switchToEntryTab = true)
                                },
                                onRefreshDashboard = {
                                    viewModel.refreshDashboardAssets()
                                    viewModel.refreshAnalysis()
                                }
                            )

                            // Also show the active symbol's 100% Logical Immediate Entry right below on the main dashboard
                            if (result != null) {
                                EntryPlansSection(
                                    result = result,
                                    language = state.language,
                                    directionFilter = state.directionFilter,
                                    customPriceOverride = state.customPriceOverride,
                                    capitalUsdt = state.capitalUsdt,
                                    leverage = state.leverage,
                                    onDirectionFilterChange = viewModel::selectDirectionFilter,
                                    onApplyCustomPrice = viewModel::applyCustomPriceOverride,
                                    onCapitalLeverageChange = viewModel::updateCapitalAndLeverage,
                                    onRefresh = viewModel::refreshAnalysis
                                )
                            }
                        }
                    }

                    CryptoTab.IMMEDIATE_ENTRY -> {
                        if (result == null) {
                            LoadingBox()
                        } else {
                            EntryPlansSection(
                                result = result,
                                language = state.language,
                                directionFilter = state.directionFilter,
                                customPriceOverride = state.customPriceOverride,
                                capitalUsdt = state.capitalUsdt,
                                leverage = state.leverage,
                                onDirectionFilterChange = viewModel::selectDirectionFilter,
                                onApplyCustomPrice = viewModel::applyCustomPriceOverride,
                                onCapitalLeverageChange = viewModel::updateCapitalAndLeverage,
                                onRefresh = viewModel::refreshAnalysis
                            )
                        }
                    }

                    CryptoTab.CHARTS_MACD -> {
                        if (result == null) {
                            LoadingBox()
                        } else {
                            ChartsAndMacdSection(
                                result = result,
                                language = state.language
                            )
                        }
                    }

                    CryptoTab.INDICATORS_VOLUME -> {
                        if (result == null) {
                            LoadingBox()
                        } else {
                            AllIndicatorsDashboardSection(
                                result = result,
                                language = state.language
                            )
                        }
                    }

                    CryptoTab.ALERTS_SCANNER -> {
                        MarketAlertsAndScannerSection(
                            alerts = state.marketAlerts,
                            language = state.language,
                            onSelectAlertSymbol = { sym ->
                                viewModel.selectSymbol(sym, switchToEntryTab = true)
                            }
                        )
                    }
                }
            }
        }
    }

    if (zipDownloadMessage != null) {
        AlertDialog(
            onDismissRequest = { zipDownloadMessage = null },
            containerColor = CyberCardElevated,
            title = {
                Text(
                    text = "Fichier .ZIP Téléchargé !",
                    color = EmeraldBull
                )
            },
            text = {
                Text(
                    text = zipDownloadMessage ?: "",
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        zipDownloadMessage = null
                        saveZipLauncher.launch("CryptoAnalyser_Final_Corrige.zip")
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonCyan,
                        contentColor = CyberNavyDark
                    )
                ) {
                    Text("Enregistrer sous...", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { zipDownloadMessage = null }) {
                    Text("Fermer", color = TextSecondary)
                }
            }
        )
    }

    if (showSearchDialog) {
        AlertDialog(
            onDismissRequest = { showSearchDialog = false },
            containerColor = CyberCardElevated,
            title = {
                Text(
                    text = when (state.language) {
                        AppLanguage.FR -> "Choisir une paire USDT"
                        AppLanguage.AR -> "اختر زوج التداول USDT"
                        AppLanguage.EN -> "Enter USDT Pair"
                    },
                    color = NeonCyan
                )
            },
            text = {
                OutlinedTextField(
                    value = customSymbolInput,
                    onValueChange = { customSymbolInput = it },
                    label = { Text("Ex: BTCUSDT, XRPUSDT, MAGMAUSDT") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_symbol_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (customSymbolInput.isNotBlank()) {
                            viewModel.selectSymbol(customSymbolInput, switchToEntryTab = true)
                        }
                        showSearchDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonCyan,
                        contentColor = CyberNavyDark
                    ),
                    modifier = Modifier.testTag("confirm_symbol_button")
                ) {
                    Text("Analyser", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSearchDialog = false }) {
                    Text("Annuler", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun LoadingBox() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(260.dp),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(color = NeonCyan)
    }
}

@Composable
private fun TopHeaderAndMarketBar(
    selectedLanguage: AppLanguage,
    selectedSymbol: String,
    selectedExchange: ExchangePlatform,
    selectedMarketMode: MarketMode,
    selectedTimeframe: Timeframe,
    featuredPairs: List<String>,
    currentPrice: Double?,
    change24hPct: Double?,
    onLanguageChange: (AppLanguage) -> Unit,
    onSymbolSelect: (String) -> Unit,
    onOpenSearchDialog: () -> Unit,
    onExchangeSelect: (ExchangePlatform) -> Unit,
    onMarketModeSelect: (MarketMode) -> Unit,
    onTimeframeSelect: (Timeframe) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(CyberCardElevated, CyberSurface)
                )
            )
            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Brand Title + Language Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "CRYPTOANALYSER",
                        style = MaterialTheme.typography.titleLarge,
                        color = NeonCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = EmeraldBull.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "by ErrZhr",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldBull,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = when (selectedLanguage) {
                        AppLanguage.FR -> "Analysez le marché crypto intelligemment • Entrée 100% Sûre"
                        AppLanguage.AR -> "حلّل سوق العملات الرقمية بذكاء • دخول فوري آمن 100%"
                        AppLanguage.EN -> "Analyze the crypto market smarter • 100% Safe Entry"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            // FR / AR / EN selector
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                AppLanguage.entries.forEach { lang ->
                    val active = selectedLanguage == lang
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onLanguageChange(lang) }
                            .minimumInteractiveComponentSize()
                            .testTag("lang_button_${lang.code}"),
                        color = if (active) NeonCyan else CyberNavyDark,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) NeonCyan else BorderCyan)
                    ) {
                        Text(
                            text = lang.code.uppercase(),
                            style = MaterialTheme.typography.labelMedium,
                            color = if (active) CyberNavyDark else TextSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Exchange & Spot/Futures Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ExchangePlatform.entries.forEach { ex ->
                val selected = selectedExchange == ex
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onExchangeSelect(ex) }
                        .testTag("exchange_chip_${ex.name.lowercase()}"),
                    color = if (selected) NeonCyan.copy(alpha = 0.2f) else CyberNavyDark,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (selected) NeonCyan else BorderCyan
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(Color(ex.badgeColorHex))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = ex.displayName,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) NeonCyan else TextSecondary
                        )
                    }
                }
            }

            MarketMode.entries.forEach { mode ->
                val selected = selectedMarketMode == mode
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onMarketModeSelect(mode) }
                        .testTag("market_mode_${mode.name.lowercase()}"),
                    color = if (selected) AmberGold.copy(alpha = 0.2f) else CyberNavyDark,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (selected) AmberGold else BorderCyan
                    )
                ) {
                    Text(
                        text = mode.label(selectedLanguage),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) AmberGold else TextSecondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Active Symbol Banner + Search Button + Timeframe Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyberNavyDark)
                    .border(1.dp, NeonCyan, RoundedCornerShape(12.dp))
                    .clickable { onOpenSearchDialog() }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .testTag("open_symbol_search_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Rechercher une paire",
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = selectedSymbol,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    if (currentPrice != null) {
                        val chg = change24hPct ?: 0.0
                        Text(
                            text = "${CryptoPriceFormatter.formatPrice(currentPrice)} (${CryptoPriceFormatter.formatSignedPct(chg)})",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (chg >= 0) EmeraldBull else CrimsonBear
                        )
                    }
                }
            }

            // Timeframe chips: 15m, 1H, 4H, 1D
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Timeframe.entries.forEach { tf ->
                    val selected = selectedTimeframe == tf
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onTimeframeSelect(tf) }
                            .testTag("timeframe_chip_${tf.label}"),
                        color = if (selected) EmeraldBull else CyberNavyDark,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) EmeraldBull else BorderCyan
                        )
                    ) {
                        Text(
                            text = tf.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) CyberNavyDark else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Featured Pairs Quick-Select Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            featuredPairs.forEach { pair ->
                val isSelected = pair == selectedSymbol
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onSymbolSelect(pair) }
                        .testTag("pair_chip_${pair.lowercase()}"),
                    color = if (isSelected) CyberCard else CyberNavyDark,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) NeonCyan else BorderCyan.copy(alpha = 0.6f)
                    )
                ) {
                    Text(
                        text = pair,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) NeonCyan else TextMuted,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}
