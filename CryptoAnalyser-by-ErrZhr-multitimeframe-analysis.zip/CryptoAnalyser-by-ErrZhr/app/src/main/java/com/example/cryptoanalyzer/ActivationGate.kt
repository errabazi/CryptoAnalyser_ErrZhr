package com.example.cryptoanalyzer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

private const val ACTIVATION_ENDPOINT = "https://script.google.com/macros/s/AKfycbzX5LyGohau7F1e6RSG6slMv7LGmtcUqJpYsmOOXXwOaLAu5LzCwRw1KCe9LhpMbwVrkw/exec"
private const val MAX_RECEIPT_BYTES = 4 * 1024 * 1024
private val activationHttp = OkHttpClient.Builder()
    .connectTimeout(20, TimeUnit.SECONDS).readTimeout(40, TimeUnit.SECONDS).writeTimeout(40, TimeUnit.SECONDS).build()
private val activationJsonType = "application/json; charset=utf-8".toMediaType()
private val activationBg = Color(0xFF080D1B)
private val activationCard = Color(0xFF111A2E)
private val activationMint = Color(0xFF5EEAD4)


private fun activationTr(text: String, language: String): String {
    val translations = mapOf(
        "ar" to mapOf(
            "Language" to "اللغة", "العربية" to "العربية", "Français" to "الفرنسية", "English" to "الإنجليزية",
            "Activate your account" to "تفعيل حسابك", "Simple and secure steps to access analysis tools" to "خطوات بسيطة وآمنة للوصول إلى أدوات التحليل",
            "Sign in" to "تسجيل الدخول",
            "Enter the email used for your activation request and the code you received." to "أدخل البريد الإلكتروني الذي استخدمته في طلب التفعيل والكود الذي تلقيته.",
            "Email address" to "البريد الإلكتروني", "Activation / login code" to "كود الدخول / التفعيل",
            "Verify code and sign in" to "التحقق من الكود والدخول",
            "Forgot code? Recover it once by email" to "نسيت الكود؟ استعادة لمرة واحدة عبر البريد الإلكتروني",
            "I did not receive the code / Submit an activation request" to "لم أتلقَّ الكود / أريد إرسال طلب التفعيل وإيصال الدفع",
            "Forgot activation code?" to "نسيت كود التفعيل؟",
            "Enter the email address used when you purchased activation. You can recover the code only once; after payment is confirmed, it will be sent to this email." to "أدخل البريد الإلكتروني الذي استخدمته عند شراء التفعيل. يمكن استعادة الكود مرة واحدة فقط، وبعد تأكيد الدفع سنرسله إلى هذا البريد.",
            "Enter a valid email address." to "أدخل بريدًا إلكترونيًا صحيحًا.",
            "Send activation code to my email" to "إرسال كود التفعيل إلى بريدي",
            "Back to sign in" to "العودة إلى تسجيل الدخول",
            "If payment is confirmed, the code will be sent to your email." to "إذا كان الدفع مؤكدًا، فستصلك رسالة بالبريد الإلكتروني.",
            "Enter your email address and activation code." to "أدخل البريد الإلكتروني وكود التفعيل.",
            "Could not request code recovery. Please try again later." to "تعذر إرسال طلب استعادة الكود. حاول لاحقًا."
        ),
        "fr" to mapOf(
            "Language" to "Langue", "العربية" to "Arabe", "Français" to "Français", "English" to "Anglais",
            "Activate your account" to "Activer votre compte", "Simple and secure steps to access analysis tools" to "Des étapes simples et sûres pour accéder aux outils d’analyse",
            "Sign in" to "Connexion",
            "Enter the email used for your activation request and the code you received." to "Saisissez l’adresse e-mail utilisée pour la demande d’activation et le code reçu.",
            "Email address" to "Adresse e-mail", "Activation / login code" to "Code d’activation / connexion",
            "Verify code and sign in" to "Vérifier le code et se connecter",
            "Forgot code? Recover it once by email" to "Code oublié ? Récupération par e-mail (une seule fois)",
            "I did not receive the code / Submit an activation request" to "Code non reçu / Envoyer une demande d’activation",
            "Forgot activation code?" to "Code d’activation oublié ?",
            "Enter the email address used when you purchased activation. You can recover the code only once; after payment is confirmed, it will be sent to this email." to "Saisissez l’adresse e-mail utilisée lors de l’achat de l’activation. La récupération est possible une seule fois ; après confirmation du paiement, le code sera envoyé à cette adresse.",
            "Enter a valid email address." to "Saisissez une adresse e-mail valide.",
            "Send activation code to my email" to "Envoyer le code d’activation à mon e-mail",
            "Back to sign in" to "Retour à la connexion",
            "If payment is confirmed, the code will be sent to your email." to "Si le paiement est confirmé, le code sera envoyé par e-mail.",
            "Enter your email address and activation code." to "Saisissez votre adresse e-mail et le code d’activation.",
            "Could not request code recovery. Please try again later." to "Impossible de demander la récupération du code. Réessayez plus tard."
        ),
        "de" to mapOf(
            "Language" to "Sprache", "العربية" to "Arabisch", "Français" to "Französisch", "English" to "Englisch",
            "Activate your account" to "Konto aktivieren", "Simple and secure steps to access analysis tools" to "Einfache und sichere Schritte zum Zugriff auf Analysewerkzeuge",
            "Sign in" to "Anmelden", "Enter the email used for your activation request and the code you received." to "Geben Sie die E-Mail-Adresse Ihrer Aktivierungsanfrage und den erhaltenen Code ein.",
            "Email address" to "E-Mail-Adresse", "Activation / login code" to "Aktivierungs-/Anmeldecode", "Verify code and sign in" to "Code prüfen und anmelden",
            "Forgot code? Recover it once by email" to "Code vergessen? Einmalige Wiederherstellung per E-Mail", "I did not receive the code / Submit an activation request" to "Code nicht erhalten / Aktivierungsanfrage senden",
            "Forgot activation code?" to "Aktivierungscode vergessen?", "Enter the email address used when you purchased activation. You can recover the code only once; after payment is confirmed, it will be sent to this email." to "Geben Sie die beim Kauf verwendete E-Mail-Adresse ein. Sie können den Code nur einmal wiederherstellen; nach bestätigter Zahlung wird er an diese Adresse gesendet.",
            "Enter a valid email address." to "Geben Sie eine gültige E-Mail-Adresse ein.", "Send activation code to my email" to "Aktivierungscode per E-Mail senden", "Back to sign in" to "Zurück zur Anmeldung",
            "If payment is confirmed, the code will be sent to your email." to "Wenn die Zahlung bestätigt ist, wird der Code per E-Mail gesendet.", "Enter your email address and activation code." to "Geben Sie Ihre E-Mail-Adresse und den Aktivierungscode ein.",
            "Could not request code recovery. Please try again later." to "Der Code konnte nicht angefordert werden. Bitte versuchen Sie es später erneut."
        ),
        "it" to mapOf(
            "Language" to "Lingua", "العربية" to "Arabo", "Français" to "Francese", "English" to "Inglese",
            "Activate your account" to "Attiva il tuo account", "Simple and secure steps to access analysis tools" to "Passaggi semplici e sicuri per accedere agli strumenti di analisi",
            "Sign in" to "Accedi", "Enter the email used for your activation request and the code you received." to "Inserisci l’e-mail usata per la richiesta di attivazione e il codice ricevuto.",
            "Email address" to "Indirizzo e-mail", "Activation / login code" to "Codice di attivazione/accesso", "Verify code and sign in" to "Verifica il codice e accedi",
            "Forgot code? Recover it once by email" to "Hai dimenticato il codice? Recuperalo una sola volta via e-mail", "I did not receive the code / Submit an activation request" to "Codice non ricevuto / Invia una richiesta di attivazione",
            "Forgot activation code?" to "Hai dimenticato il codice di attivazione?", "Enter the email address used when you purchased activation. You can recover the code only once; after payment is confirmed, it will be sent to this email." to "Inserisci l’indirizzo e-mail usato per acquistare l’attivazione. Puoi recuperare il codice una sola volta; dopo la conferma del pagamento sarà inviato a questo indirizzo.",
            "Enter a valid email address." to "Inserisci un indirizzo e-mail valido.", "Send activation code to my email" to "Invia il codice di attivazione alla mia e-mail", "Back to sign in" to "Torna all’accesso",
            "If payment is confirmed, the code will be sent to your email." to "Se il pagamento è confermato, il codice sarà inviato via e-mail.", "Enter your email address and activation code." to "Inserisci l’indirizzo e-mail e il codice di attivazione.",
            "Could not request code recovery. Please try again later." to "Impossibile richiedere il recupero del codice. Riprova più tardi."
        ),
        "zh" to mapOf(
            "Language" to "语言", "العربية" to "阿拉伯语", "Français" to "法语", "English" to "英语",
            "Activate your account" to "激活账户", "Simple and secure steps to access analysis tools" to "通过简单安全的步骤访问分析工具",
            "Sign in" to "登录", "Enter the email used for your activation request and the code you received." to "请输入提交激活申请时使用的邮箱和收到的验证码。",
            "Email address" to "电子邮箱", "Activation / login code" to "激活码/登录码", "Verify code and sign in" to "验证代码并登录",
            "Forgot code? Recover it once by email" to "忘记代码？可通过电子邮件找回一次", "I did not receive the code / Submit an activation request" to "未收到代码 / 提交激活申请",
            "Forgot activation code?" to "忘记激活码？", "Enter the email address used when you purchased activation. You can recover the code only once; after payment is confirmed, it will be sent to this email." to "请输入购买激活时使用的邮箱。每个邮箱只能找回一次；付款确认后，代码将发送到该邮箱。",
            "Enter a valid email address." to "请输入有效的电子邮箱地址。", "Send activation code to my email" to "将激活码发送到我的邮箱", "Back to sign in" to "返回登录",
            "If payment is confirmed, the code will be sent to your email." to "付款确认后，代码将发送到您的邮箱。", "Enter your email address and activation code." to "请输入您的邮箱地址和激活码。",
            "Could not request code recovery. Please try again later." to "无法申请找回代码，请稍后重试。"
        ),
        "ja" to mapOf(
            "Language" to "言語", "العربية" to "アラビア語", "Français" to "フランス語", "English" to "英語",
            "Activate your account" to "アカウントを有効化", "Simple and secure steps to access analysis tools" to "簡単で安全な手順で分析ツールにアクセス",
            "Sign in" to "ログイン", "Enter the email used for your activation request and the code you received." to "有効化申請に使用したメールアドレスと受け取ったコードを入力してください。",
            "Email address" to "メールアドレス", "Activation / login code" to "有効化コード／ログインコード", "Verify code and sign in" to "コードを確認してログイン",
            "Forgot code? Recover it once by email" to "コードを忘れましたか？メールで一度だけ復元できます", "I did not receive the code / Submit an activation request" to "コードが届かない／有効化申請を送信",
            "Forgot activation code?" to "有効化コードを忘れましたか？", "Enter the email address used when you purchased activation. You can recover the code only once; after payment is confirmed, it will be sent to this email." to "有効化の購入時に使用したメールアドレスを入力してください。コードの復元は一度のみ可能で、支払い確認後にこのメールアドレスへ送信されます。",
            "Enter a valid email address." to "有効なメールアドレスを入力してください。", "Send activation code to my email" to "有効化コードをメールで送信", "Back to sign in" to "ログインに戻る",
            "If payment is confirmed, the code will be sent to your email." to "支払いが確認されると、コードがメールで送信されます。", "Enter your email address and activation code." to "メールアドレスと有効化コードを入力してください。",
            "Could not request code recovery. Please try again later." to "コードの復元をリクエストできませんでした。後でもう一度お試しください。"
        ),
        "es" to mapOf(
            "Language" to "Idioma", "العربية" to "Árabe", "Français" to "Francés", "English" to "Inglés",
            "Activate your account" to "Activa tu cuenta", "Simple and secure steps to access analysis tools" to "Pasos sencillos y seguros para acceder a las herramientas de análisis",
            "Sign in" to "Iniciar sesión", "Enter the email used for your activation request and the code you received." to "Introduce el correo usado en tu solicitud de activación y el código recibido.",
            "Email address" to "Correo electrónico", "Activation / login code" to "Código de activación/inicio de sesión", "Verify code and sign in" to "Verificar código e iniciar sesión",
            "Forgot code? Recover it once by email" to "¿Olvidaste el código? Recupéralo una vez por correo", "I did not receive the code / Submit an activation request" to "No recibí el código / Enviar solicitud de activación",
            "Forgot activation code?" to "¿Olvidaste el código de activación?", "Enter the email address used when you purchased activation. You can recover the code only once; after payment is confirmed, it will be sent to this email." to "Introduce el correo usado para comprar la activación. Solo puedes recuperar el código una vez; tras confirmar el pago, se enviará a ese correo.",
            "Enter a valid email address." to "Introduce un correo electrónico válido.", "Send activation code to my email" to "Enviar el código de activación a mi correo", "Back to sign in" to "Volver al inicio de sesión",
            "If payment is confirmed, the code will be sent to your email." to "Si se confirma el pago, el código se enviará a tu correo.", "Enter your email address and activation code." to "Introduce tu correo electrónico y el código de activación.",
            "Could not request code recovery. Please try again later." to "No se pudo solicitar la recuperación del código. Inténtalo más tarde."
        ),
        "ko" to mapOf(
            "Language" to "언어", "العربية" to "아랍어", "Français" to "프랑스어", "English" to "영어",
            "Activate your account" to "계정 활성화", "Simple and secure steps to access analysis tools" to "분석 도구에 안전하고 간편하게 접근하세요",
            "Sign in" to "로그인", "Enter the email used for your activation request and the code you received." to "활성화 요청에 사용한 이메일과 받은 코드를 입력하세요.",
            "Email address" to "이메일 주소", "Activation / login code" to "활성화/로그인 코드", "Verify code and sign in" to "코드 확인 후 로그인",
            "Forgot code? Recover it once by email" to "코드를 잊으셨나요? 이메일로 한 번 복구할 수 있습니다", "I did not receive the code / Submit an activation request" to "코드를 받지 못함 / 활성화 요청 제출",
            "Forgot activation code?" to "활성화 코드를 잊으셨나요?", "Enter the email address used when you purchased activation. You can recover the code only once; after payment is confirmed, it will be sent to this email." to "활성화를 구매할 때 사용한 이메일을 입력하세요. 코드는 한 번만 복구할 수 있으며 결제가 확인되면 이 이메일로 전송됩니다.",
            "Enter a valid email address." to "올바른 이메일 주소를 입력하세요.", "Send activation code to my email" to "활성화 코드를 이메일로 보내기", "Back to sign in" to "로그인으로 돌아가기",
            "If payment is confirmed, the code will be sent to your email." to "결제가 확인되면 코드가 이메일로 전송됩니다.", "Enter your email address and activation code." to "이메일 주소와 활성화 코드를 입력하세요.",
            "Could not request code recovery. Please try again later." to "코드 복구를 요청할 수 없습니다. 나중에 다시 시도하세요."
        )
    )
    val extraTranslations = mapOf(
        "ar" to mapOf("This email has already been verified as paid. Please sign in using your email and activation code." to "سبق التحقق من دفع هذا البريد الإلكتروني. يرجى تسجيل الدخول باستخدام بريدك الإلكتروني وكود التفعيل."),
        "fr" to mapOf("This email has already been verified as paid. Please sign in using your email and activation code." to "Le paiement associé à cette adresse e-mail a déjà été vérifié. Connectez-vous avec votre adresse e-mail et votre code d’activation."),
        "de" to mapOf("This email has already been verified as paid. Please sign in using your email and activation code." to "Die Zahlung für diese E-Mail-Adresse wurde bereits bestätigt. Melden Sie sich mit Ihrer E-Mail-Adresse und Ihrem Aktivierungscode an."),
        "it" to mapOf("This email has already been verified as paid. Please sign in using your email and activation code." to "Il pagamento associato a questa e-mail è già stato verificato. Accedi con il tuo indirizzo e-mail e il codice di attivazione."),
        "zh" to mapOf("This email has already been verified as paid. Please sign in using your email and activation code." to "此邮箱的付款已确认。请使用您的邮箱和激活码登录。"),
        "ja" to mapOf("This email has already been verified as paid. Please sign in using your email and activation code." to "このメールアドレスの支払いは確認済みです。メールアドレスと有効化コードでログインしてください。"),
        "es" to mapOf("This email has already been verified as paid. Please sign in using your email and activation code." to "El pago asociado a este correo ya ha sido verificado. Inicia sesión con tu correo y código de activación."),
        "ko" to mapOf("This email has already been verified as paid. Please sign in using your email and activation code." to "이 이메일의 결제가 이미 확인되었습니다. 이메일과 활성화 코드로 로그인하세요.")
    )
    val paymentCheckTranslations = mapOf(
        "ar" to mapOf("Check my payment request" to "التحقق من طلب الدفع الخاص بي", "Enter the email used for your payment request. If payment has been verified, we will send your activation code to that email." to "أدخل البريد الإلكتروني الذي استعملته في طلب الدفع. إذا تم تأكيد الدفع، سنرسل كود التفعيل إلى بريدك.", "Check and receive the code" to "التحقق واستلام الكود", "Checking, please wait…" to "جاري التحقق، المرجو الانتظار من فضلك…", "If your payment is confirmed, your activation code has been sent to your email." to "إذا تم تأكيد الدفع، أرسلنا كود التفعيل إلى بريدك الإلكتروني. تحقق من صندوق الوارد والرسائل غير المرغوب فيها.", "Could not check your payment request. Please try again later." to "تعذر التحقق من طلب الدفع. حاول مرة أخرى لاحقًا.", "Back to payment request" to "العودة إلى طلب الدفع"),
        "fr" to mapOf("Check my payment request" to "Vérifier ma demande de paiement", "Enter the email used for your payment request. If payment has been verified, we will send your activation code to that email." to "Saisissez l’adresse e-mail utilisée pour la demande. Si le paiement est confirmé, le code sera envoyé à cette adresse.", "Check and receive the code" to "Vérifier et recevoir le code", "Checking, please wait…" to "Vérification en cours, veuillez patienter…", "If your payment is confirmed, your activation code has been sent to your email." to "Si votre paiement est confirmé, le code a été envoyé à votre adresse e-mail. Vérifiez aussi les courriers indésirables.", "Could not check your payment request. Please try again later." to "Impossible de vérifier la demande. Réessayez plus tard.", "Back to payment request" to "Retour à la demande de paiement"),
        "de" to mapOf("Check my payment request" to "Meine Zahlungsanfrage prüfen", "Enter the email used for your payment request. If payment has been verified, we will send your activation code to that email." to "Geben Sie die E-Mail-Adresse Ihrer Zahlungsanfrage ein. Bei bestätigter Zahlung senden wir den Aktivierungscode an diese Adresse.", "Check and receive the code" to "Prüfen und Code erhalten", "Checking, please wait…" to "Prüfung läuft, bitte warten…", "If your payment is confirmed, your activation code has been sent to your email." to "Bei bestätigter Zahlung wurde der Aktivierungscode per E-Mail gesendet.", "Could not check your payment request. Please try again later." to "Zahlungsanfrage konnte nicht geprüft werden. Bitte später erneut versuchen.", "Back to payment request" to "Zurück zur Zahlungsanfrage"),
        "it" to mapOf("Check my payment request" to "Verifica la mia richiesta di pagamento", "Enter the email used for your payment request. If payment has been verified, we will send your activation code to that email." to "Inserisci l’e-mail usata per la richiesta. Se il pagamento è confermato, invieremo il codice a quell’indirizzo.", "Check and receive the code" to "Verifica e ricevi il codice", "Checking, please wait…" to "Verifica in corso, attendi…", "If your payment is confirmed, your activation code has been sent to your email." to "Se il pagamento è confermato, il codice è stato inviato alla tua e-mail.", "Could not check your payment request. Please try again later." to "Impossibile verificare la richiesta. Riprova più tardi.", "Back to payment request" to "Torna alla richiesta di pagamento"),
        "es" to mapOf("Check my payment request" to "Comprobar mi solicitud de pago", "Enter the email used for your payment request. If payment has been verified, we will send your activation code to that email." to "Introduce el correo usado en la solicitud. Si el pago está confirmado, enviaremos el código a ese correo.", "Check and receive the code" to "Verificar y recibir el código", "Checking, please wait…" to "Verificando, espera por favor…", "If your payment is confirmed, your activation code has been sent to your email." to "Si el pago está confirmado, enviamos el código a tu correo.", "Could not check your payment request. Please try again later." to "No se pudo verificar la solicitud. Inténtalo más tarde.", "Back to payment request" to "Volver a la solicitud de pago"),
        "zh" to mapOf("Check my payment request" to "查询我的付款申请", "Enter the email used for your payment request. If payment has been verified, we will send your activation code to that email." to "请输入提交付款申请时使用的邮箱。付款确认后，我们会将激活码发送到该邮箱。", "Check and receive the code" to "查询并接收激活码", "Checking, please wait…" to "正在验证，请稍候…", "If your payment is confirmed, your activation code has been sent to your email." to "如果付款已确认，激活码已发送到您的邮箱。", "Could not check your payment request. Please try again later." to "无法查询付款申请，请稍后重试。", "Back to payment request" to "返回付款申请"),
        "ja" to mapOf("Check my payment request" to "支払い申請を確認", "Enter the email used for your payment request. If payment has been verified, we will send your activation code to that email." to "支払い申請に使用したメールアドレスを入力してください。支払い確認後、コードをそのメールに送信します。", "Check and receive the code" to "確認してコードを受け取る", "Checking, please wait…" to "確認中です。お待ちください…", "If your payment is confirmed, your activation code has been sent to your email." to "支払いが確認された場合、コードをメールに送信しました。", "Could not check your payment request. Please try again later." to "申請を確認できませんでした。後でもう一度お試しください。", "Back to payment request" to "支払い申請に戻る"),
        "ko" to mapOf("Check my payment request" to "결제 요청 확인", "Enter the email used for your payment request. If payment has been verified, we will send your activation code to that email." to "결제 요청에 사용한 이메일을 입력하세요. 결제가 확인되면 해당 이메일로 활성화 코드를 보냅니다.", "Check and receive the code" to "확인하고 코드 받기", "Checking, please wait…" to "확인 중입니다. 잠시 기다려 주세요…", "If your payment is confirmed, your activation code has been sent to your email." to "결제가 확인되면 활성화 코드를 이메일로 보냈습니다.", "Could not check your payment request. Please try again later." to "결제 요청을 확인할 수 없습니다. 나중에 다시 시도하세요.", "Back to payment request" to "결제 요청으로 돌아가기")
    )
    return translations[language]?.get(text) ?: extraTranslations[language]?.get(text) ?: paymentCheckTranslations[language]?.get(text) ?: text
}

private fun activationDeviceId(context: Context): String {
    Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)?.takeIf { it.isNotBlank() }?.let { return it }
    // Avoid treating every device with an unavailable Android ID as the same device.
    val prefs = context.getSharedPreferences("cryptoanalyser_activation", Context.MODE_PRIVATE)
    return prefs.getString("fallback_device_id", null) ?: java.util.UUID.randomUUID().toString().also {
        prefs.edit().putString("fallback_device_id", it).apply()
    }
}

private class ActivationTransportException(message: String, cause: Throwable? = null) : IllegalStateException(message, cause)
private class ActivationDeniedException(message: String) : IllegalStateException(message)

private suspend fun activationCall(payload: JSONObject): JSONObject = withContext(Dispatchers.IO) {
    val request = Request.Builder().url(ACTIVATION_ENDPOINT)
        .post(payload.toString().toRequestBody(activationJsonType)).build()
    try {
        activationHttp.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw ActivationTransportException("تعذر الاتصال بخدمة التفعيل (HTTP ${response.code}).")
            val body = response.body?.string().orEmpty()
            val json = try { JSONObject(body) } catch (e: Exception) { throw ActivationTransportException("استجابة خدمة التفعيل غير صالحة مؤقتًا. حاول مجددًا عند توفر الاتصال.", e) }
            if (!json.optBoolean("ok", false)) throw ActivationDeniedException(json.optString("message", "رفضت خدمة التفعيل الطلب."))
            json
        }
    } catch (e: ActivationDeniedException) {
        throw e
    } catch (e: ActivationTransportException) {
        throw e
    } catch (e: IOException) {
        throw ActivationTransportException("تعذر الاتصال بالإنترنت للتحقق من الترخيص. سنحافظ على الجلسة المحفوظة مؤقتًا.", e)
    }
}

private fun receiptName(context: Context, uri: Uri): String {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0) return cursor.getString(index) ?: "payment-receipt"
        }
    }
    return "payment-receipt"
}

private fun receiptMime(context: Context, uri: Uri): String =
    context.contentResolver.getType(uri)?.lowercase() ?: "application/octet-stream"

private fun receiptBase64(context: Context, uri: Uri): String {
    val mime = receiptMime(context, uri)
    require(mime in listOf("image/jpeg", "image/png", "application/pdf")) {
        "اختر صورة JPG أو PNG أو ملف PDF فقط."
    }
    val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            require(total <= MAX_RECEIPT_BYTES) { "حجم الإيصال يجب ألا يتجاوز 4 ميغابايت." }
            output.write(buffer, 0, read)
        }
        output.toByteArray()
    } ?: throw IllegalStateException("تعذر قراءة ملف الإيصال.")
    require(bytes.isNotEmpty()) { "ملف الإيصال فارغ." }
    return Base64.encodeToString(bytes, Base64.NO_WRAP)
}

@Composable
fun ActivationGate(content: @Composable (suspend () -> Boolean) -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("cryptoanalyser_activation", Context.MODE_PRIVATE) }
    val appPrefs = remember(context) { context.getSharedPreferences("cryptoanalyser_preferences", Context.MODE_PRIVATE) }
    var appLanguage by remember { mutableStateOf(appPrefs.getString("app_language", "en") ?: "en") }
    var showActivationLanguageMenu by remember { mutableStateOf(false) }
    val deviceId = remember(context) { activationDeviceId(context) }
    var email by remember { mutableStateOf(prefs.getString("activation_email", prefs.getString("pending_activation_email", "")) ?: "") }
    var code by remember { mutableStateOf("") }
    var trialCode by remember { mutableStateOf("") }
    var verifiedRequestEmail by remember { mutableStateOf("") }
    var showAlreadyPaidDialog by remember { mutableStateOf(false) }
    // Start on the payment-request page after every fresh app launch; switch to login after a request is submitted.
    var screenMode by remember { mutableStateOf("request") }
    var receiptUri by remember { mutableStateOf<Uri?>(null) }
    var receiptLabel by remember { mutableStateOf("") }
    var activated by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var messageIsError by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val receiptPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val mime = receiptMime(context, uri)
                require(mime in listOf("image/jpeg", "image/png", "application/pdf")) { "اختر صورة JPG أو PNG أو ملف PDF فقط." }
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                // Validate and enforce the size limit immediately, before the user submits.
                receiptBase64(context, uri)
                receiptUri = uri
                receiptLabel = receiptName(context, uri)
                message = "تم اختيار الإيصال: $receiptLabel"
                messageIsError = false
            } catch (e: Exception) {
                receiptUri = null; receiptLabel = ""
                message = e.message ?: "تعذر فتح الإيصال."; messageIsError = true
            }
        }
    }

    LaunchedEffect(Unit) {
        val savedEmail = prefs.getString("activation_email", "").orEmpty()
        val savedTrialExpiry = prefs.getLong("trial_expires_at", 0L)
        val savedTrialEmail = prefs.getString("trial_email", "").orEmpty()
        if (savedEmail.isNotBlank()) {
            try {
                val result = activationCall(JSONObject().put("action", "heartbeat").put("email", savedEmail).put("deviceId", deviceId))
                email = savedEmail
                if (result.optBoolean("trial", false)) {
                    val expiry = result.optLong("expiresAt", 0L)
                    if (expiry > 0L) prefs.edit().putString("trial_email", savedEmail).putLong("trial_expires_at", expiry).apply()
                }
                activated = true
            } catch (e: ActivationTransportException) {
                // A temporary network outage must not restart the trial or force the user to re-enter the code.
                if (savedTrialEmail.equals(savedEmail, ignoreCase = true) && savedTrialExpiry > System.currentTimeMillis()) {
                    email = savedEmail
                    activated = true
                    message = "الاتصال غير متاح مؤقتًا؛ تستمر جلستك المحفوظة حتى انتهاء التجربة المجانية."
                    messageIsError = false
                } else {
                    message = e.message ?: "تعذر التحقق من الترخيص. تحقق من الإنترنت وحاول مجددًا."
                    messageIsError = true
                }
            } catch (e: ActivationDeniedException) {
                prefs.edit().remove("activation_email").remove("trial_email").remove("trial_expires_at").apply()
                message = e.message ?: "انتهت التجربة المجانية أو لا يوجد ترخيص فعال."
                messageIsError = true
            } catch (e: Exception) {
                message = e.message ?: "تعذر التحقق من الترخيص."
                messageIsError = true
            }
        }
        checking = false
    }

    LaunchedEffect(activated, email, deviceId) {
        if (activated && email.isNotBlank()) {
            while (true) {
                delay(30_000)
                try {
                    val result = activationCall(JSONObject().put("action", "heartbeat").put("email", email).put("deviceId", deviceId))
                    if (result.optBoolean("trial", false)) {
                        val expiry = result.optLong("expiresAt", 0L)
                        if (expiry > 0L) prefs.edit().putString("trial_email", email).putLong("trial_expires_at", expiry).apply()
                    }
                } catch (e: ActivationTransportException) {
                    // Do not log the user out because Wi-Fi/mobile data briefly drops.
                    message = e.message ?: "الاتصال غير متاح مؤقتًا؛ ستُعاد المحاولة تلقائيًا."
                    messageIsError = false
                } catch (e: Exception) {
                    activated = false
                    val detail = e.message ?: "انتهت جلسة التفعيل. سجّل الدخول مجددًا."
                    if (detail.contains("another device", ignoreCase = true) || detail.contains("جهاز آخر")) {
                        prefs.edit().remove("activation_email").remove("trial_email").remove("trial_expires_at").apply()
                        message = "هذا الحساب نشط على جهاز آخر. تم تسجيل الخروج."
                    } else {
                        prefs.edit().remove("activation_email").remove("trial_email").remove("trial_expires_at").apply()
                        message = detail
                    }
                    messageIsError = true
                    break
                }
            }
        }
    }

    if (activated) {
        content {
            try {
                activationCall(JSONObject().put("action", "authorizeAnalysis").put("email", email).put("deviceId", deviceId))
                true
            } catch (e: ActivationTransportException) {
                val cachedTrialEmail = prefs.getString("trial_email", "").orEmpty()
                val cachedTrialExpiry = prefs.getLong("trial_expires_at", 0L)
                if (cachedTrialEmail.equals(email, ignoreCase = true) && cachedTrialExpiry > System.currentTimeMillis()) {
                    message = "الاتصال بالخادم متعذر مؤقتًا؛ تستمر التجربة المحفوظة حتى موعد انتهائها."
                    messageIsError = false
                    true
                } else {
                    message = e.message ?: "تعذر التحقق من الترخيص قبل التحليل. تحقق من الإنترنت."
                    messageIsError = true
                    false
                }
            } catch (e: Exception) {
                val detail = e.message.orEmpty()
                if (detail.contains("another device", ignoreCase = true) || detail.contains("جهاز آخر")) {
                    prefs.edit().remove("activation_email").remove("trial_email").remove("trial_expires_at").apply()
                    activated = false
                    message = "هذا الحساب نشط على جهاز آخر. تم تسجيل الخروج."
                    messageIsError = true
                } else {
                    if (e is ActivationDeniedException) {
                        prefs.edit().remove("activation_email").remove("trial_email").remove("trial_expires_at").apply()
                        activated = false
                    }
                    message = detail.ifBlank { "تعذر التحقق من الترخيص قبل التحليل." }
                    messageIsError = true
                }
                false
            }
        }
        return
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = activationMint, background = activationBg, surface = activationCard, onSurface = Color(0xFFEAF2FF))) {
        Box(
            Modifier.fillMaxSize()
                .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFF0B1224), Color(0xFF080D1B), Color(0xFF101D32))))
                .padding(horizontal = 14.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            if (checking) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    CircularProgressIndicator(color = activationMint)
                    Text("جارٍ التحقق من ترخيص CryptoAnalyser…", color = Color.White)
                }
            } else {
                Column(
                    Modifier.fillMaxWidth().fillMaxHeight().verticalScroll(rememberScrollState())
                        .background(activationCard, RoundedCornerShape(28.dp))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Brand header
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            Modifier.size(54.dp).background(
                                androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF5EEAD4), Color(0xFF38BDF8))),
                                RoundedCornerShape(17.dp)
                            ), contentAlignment = Alignment.Center
                        ) {
                            Text("CA", color = Color(0xFF07111F), fontSize = 20.sp, fontWeight = FontWeight.Black)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("CryptoAnalyser", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                            Text("by ErrZhr  •  SMART CRYPTO INSIGHTS", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    HorizontalDivider(color = Color(0xFF26354D))
                    if (screenMode == "login" || screenMode == "forgot") {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                            Text(activationTr("Language", appLanguage), color = Color(0xFFB8C7DA), fontSize = 13.sp)
                            Box {
                                TextButton(onClick = { showActivationLanguageMenu = true }) {
                                    Text(when (appLanguage) { "ar" -> "العربية"; "fr" -> "Français"; "de" -> "Deutsch"; "it" -> "Italiano"; "zh" -> "中文"; "ja" -> "日本語"; "es" -> "Español"; "ko" -> "한국어"; else -> "English" }, color = activationMint, fontWeight = FontWeight.Bold)
                                }
                                DropdownMenu(expanded = showActivationLanguageMenu, onDismissRequest = { showActivationLanguageMenu = false }) {
                                    listOf("en" to "English", "fr" to "Français", "ar" to "العربية", "de" to "Deutsch", "it" to "Italiano", "zh" to "中文", "ja" to "日本語", "es" to "Español", "ko" to "한국어").forEach { (languageCode, languageName) ->
                                        DropdownMenuItem(text = { Text(languageName) }, onClick = {
                                            appLanguage = languageCode
                                            appPrefs.edit().putString("app_language", languageCode).apply()
                                            showActivationLanguageMenu = false
                                        })
                                    }
                                }
                            }
                        }
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(if (screenMode == "login" || screenMode == "forgot") activationTr("Activate your account", appLanguage) else "تفعيل حسابك", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Text(if (screenMode == "login" || screenMode == "forgot") activationTr("Simple and secure steps to access analysis tools", appLanguage) else "خطوات بسيطة وآمنة للوصول إلى أدوات التحليل", color = activationMint, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }

                    if (screenMode == "request") {
                        Button(
                            onClick = { trialCode = ""; message = ""; messageIsError = false; screenMode = "trial" },
                            modifier = Modifier.fillMaxWidth().height(54.dp), enabled = !busy,
                            shape = RoundedCornerShape(15.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7CFFB2), contentColor = Color(0xFF07111F))
                        ) { Text("🎁 جرّب التطبيق مجانًا لمدة 24 ساعة", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp) }
                        Text(
                            "تحتاج إلى بريد إلكتروني صالح والتحقق منه. تبدأ التجربة بعد التحقق، وتشمل جميع الوظائف لمدة 24 ساعة.",
                            color = Color(0xFFB8C7DA), fontSize = 12.sp, lineHeight = 17.sp
                        )
                        TextButton(
                            onClick = {
                                email = prefs.getString("pending_activation_email", email).orEmpty()
                                code = ""
                                message = ""
                                messageIsError = false
                                screenMode = "login"
                            },
                            modifier = Modifier.fillMaxWidth(), enabled = !busy
                        ) {
                            Text("👉  لقد دفعت وتلقيت الكود؟ اضغط هنا للدخول", color = Color(0xFFFFD166), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, textDecoration = TextDecoration.Underline)
                        }
                        // Morocco payment instructions
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF142A35)), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("الدفع داخل المغرب", color = Color(0xFF99F6E4), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("رسوم التفعيل: 50 درهمًا مغربيًا", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("أرسل المبلغ عبر وفاكاش أو كاش بليس إلى المستفيد: Errabazi Zouhair، ثم أرفق وصل الدفع. سيتم التحقق من وصول المبلغ يدويًا قبل إصدار كود التفعيل.", color = Color(0xFFD5E4EF), fontSize = 13.sp, lineHeight = 19.sp)
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("1  •  بريدك الإلكتروني", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = email, onValueChange = { email = it.trim() }, modifier = Modifier.fillMaxWidth(),
                            label = { Text("البريد الإلكتروني") }, placeholder = { Text("name@example.com") },
                            singleLine = true, shape = RoundedCornerShape(14.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = activationMint, unfocusedBorderColor = Color(0xFF3A4A63),
                                focusedLabelColor = activationMint, cursorColor = activationMint
                            )
                        )
                        Text("استخدم بريدًا صحيحًا حتى تتمكن الإدارة من ربط طلبك وإرسال تعليمات التفعيل.", color = Color(0xFF94A3B8), fontSize = 12.sp, lineHeight = 17.sp)
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("2  •  إثبات الدفع", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17243A)), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                Text("أرفق صورة أو ملف PDF", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                Text("الصيغ المقبولة: JPG، PNG، PDF  •  الحد الأقصى 4 MB", color = Color(0xFFB8C7DA), fontSize = 12.sp)
                                OutlinedButton(
                                    onClick = { receiptPicker.launch(arrayOf("image/jpeg", "image/png", "application/pdf")) },
                                    modifier = Modifier.fillMaxWidth(), enabled = !busy,
                                    shape = RoundedCornerShape(13.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = activationMint)
                                ) {
                                    Text(if (receiptLabel.isBlank()) "＋  اختيار إيصال الدفع من الهاتف" else "✓  $receiptLabel  •  تغيير الملف", fontWeight = FontWeight.SemiBold)
                                }
                                if (receiptLabel.isNotBlank()) {
                                    Text("تم اختيار الملف. تأكد من وضوح بيانات الدفع قبل إرسال الطلب.", color = Color(0xFF86EFAC), fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // International payment instructions in separate readable sections
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2339)), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("INTERNATIONAL PAYMENTS", color = Color(0xFF93C5FD), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Outside Morocco: pay 5 USDT via Bitget internal transfer to ID 6569055905. Before confirming, verify that the recipient account name is zhr_err. The screenshot must show the sender, recipient and amount. Alternatively, send 5 USDT over the BEP-20 (BSC) network to:", color = Color(0xFFE2E8F0), fontSize = 12.sp, lineHeight = 18.sp)
                            Text("0x56c878126b17d8029f2646bf0107b47edca28658", color = Color(0xFF93C5FD), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Attach the payment screenshot to this request and enter your email address above.", color = Color(0xFFCBD5E1), fontSize = 12.sp, lineHeight = 18.sp)
                            HorizontalDivider(color = Color(0xFF334155))
                            Text("PAIEMENTS INTERNATIONAUX", color = Color(0xFF93C5FD), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Si vous résidez hors du Maroc, payez 5 USDT par transfert interne Bitget à l’identifiant 6569055905. Avant de confirmer, vérifiez que le nom du compte destinataire est zhr_err. La capture d’écran doit afficher l’expéditeur, le destinataire et le montant. Vous pouvez aussi envoyer 5 USDT via le réseau BEP-20 (BSC) à l’adresse suivante :", color = Color(0xFFE2E8F0), fontSize = 12.sp, lineHeight = 18.sp)
                            Text("0x56c878126b17d8029f2646bf0107b47edca28658", color = Color(0xFF93C5FD), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Joignez la capture d’écran du paiement à cette demande et saisissez votre adresse e-mail ci-dessus.", color = Color(0xFFCBD5E1), fontSize = 12.sp, lineHeight = 18.sp)
                        }
                    }

                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF332A18)), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Besoin d’aide ? / تحتاج إلى مساعدة؟", color = Color(0xFFFDE68A), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("العربية: إذا لم تتوصل بكود التفعيل خلال نصف ساعة على الأكثر عبر بريدك الإلكتروني، المرجو إرسال رسالة مع وصل تأكيد الدفع إلى errabazi@gmail.com أو عبر واتساب على الرقم 00212620202714.", color = Color(0xFFFFF3C4), fontSize = 12.sp, lineHeight = 18.sp)
                            Text("English: If you do not receive your activation code by email within 30 minutes at most, please send a message with your payment receipt to errabazi@gmail.com or via WhatsApp at +212620202714.", color = Color(0xFFFFF3C4), fontSize = 12.sp, lineHeight = 18.sp)
                            Text("Français : Si vous ne recevez pas votre code d’activation par e-mail dans un délai maximal de 30 minutes, veuillez envoyer un message accompagné du justificatif de paiement à errabazi@gmail.com ou par WhatsApp au +212620202714.", color = Color(0xFFFFF3C4), fontSize = 12.sp, lineHeight = 18.sp)
                            Text("Merci pour votre confiance. / Thank you for your trust. / شكراً لثقتكم.", color = Color(0xFFFDE68A), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("3  •  إرسال الطلب", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("راجع بريدك الإلكتروني والملف المرفق قبل الإرسال. لا يُفعّل الحساب إلا بعد مراجعة الدفع.", color = Color(0xFF94A3B8), fontSize = 12.sp, lineHeight = 17.sp)
                        Button(
                            onClick = {
                                val normalized = email.trim().lowercase()
                                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(normalized).matches()) {
                                    message = activationTr("Enter a valid email address.", appLanguage); messageIsError = true
                                } else if (receiptUri == null) {
                                    message = "يجب إرفاق إيصال الدفع قبل إرسال الطلب."; messageIsError = true
                                } else {
                                    busy = true; message = ""
                                    scope.launch {
                                        try {
                                            val uri = receiptUri ?: throw IllegalStateException("أرفق إيصال الدفع أولًا.")
                                            val base64 = withContext(Dispatchers.IO) { receiptBase64(context, uri) }
                                            val payload = JSONObject()
                                                .put("action", "request")
                                                .put("email", normalized)
                                                .put("deviceId", deviceId)
                                                .put("receiptBase64", base64)
                                                .put("receiptMimeType", receiptMime(context, uri))
                                                .put("receiptFileName", receiptName(context, uri))
                                            val result = activationCall(payload)
                                            email = normalized
                                            prefs.edit().putString("pending_activation_email", normalized).apply()
                                            code = ""
                                            if (result.optBoolean("alreadyPaid", false)) {
                                                message = activationTr("This email has already been verified as paid. Please sign in using your email and activation code.", appLanguage)
                                                messageIsError = false
                                                showAlreadyPaidDialog = true
                                            } else {
                                                screenMode = "login"
                                                message = "تم إرسال طلب التفعيل بنجاح. بعد مراجعة الدفع، أدخل البريد الإلكتروني وكود الدخول الذي يصلك."
                                                messageIsError = false
                                            }
                                        } catch (e: Exception) { message = e.message ?: "تعذر إرسال الطلب."; messageIsError = true }
                                        finally { busy = false }
                                    }
                                }
                            }, modifier = Modifier.fillMaxWidth().height(52.dp), enabled = !busy,
                            shape = RoundedCornerShape(15.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = activationMint, contentColor = Color(0xFF07111F))
                        ) {
                            if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF07111F))
                            else Text("طلب التفعيل واستلام كود التفعيل", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        }
                        TextButton(
                            onClick = {
                                email = prefs.getString("activation_email", prefs.getString("pending_activation_email", email)).orEmpty()
                                code = ""; message = ""; messageIsError = false; screenMode = "login"
                            },
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp), enabled = !busy
                        ) {
                            Text("👉  لقد دفعت وتلقيت الكود الخاص بي — الدخول الآن", color = Color(0xFFFFD166), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, textDecoration = TextDecoration.Underline, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                        TextButton(
                            onClick = { verifiedRequestEmail = email; message = ""; messageIsError = false; screenMode = "checkPayment" },
                            modifier = Modifier.fillMaxWidth(), enabled = !busy
                        ) {
                            Text("⏳  التحقق من طلب الدفع الخاص بي", color = Color(0xFF7DD3FC), fontSize = 15.sp, fontWeight = FontWeight.Bold, textDecoration = TextDecoration.Underline, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                    } else if (screenMode == "trial") {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("تجربة مجانية لمدة 24 ساعة", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            Text("أدخل بريدك الإلكتروني. سنرسل رمز تحقق إليه. لا تبدأ التجربة إلا بعد إدخال الرمز الصحيح، وتُمنح تجربة واحدة لكل سجل جهاز/بريد وفق التحقق المتاح.", color = Color(0xFFB8C7DA), fontSize = 14.sp, lineHeight = 20.sp)
                            OutlinedTextField(
                                value = email, onValueChange = { email = it.trim() }, modifier = Modifier.fillMaxWidth(),
                                label = { Text("البريد الإلكتروني") }, placeholder = { Text("name@example.com") }, singleLine = true,
                                shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = activationMint, unfocusedBorderColor = Color(0xFF3A4A63), focusedLabelColor = activationMint, cursorColor = activationMint)
                            )
                            Button(onClick = {
                                val normalized = email.trim().lowercase()
                                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(normalized).matches()) { message = "أدخل بريدًا إلكترونيًا صحيحًا."; messageIsError = true }
                                else { busy = true; message = ""; scope.launch { try {
                                    val result = activationCall(JSONObject().put("action", "sendTrialCode").put("email", normalized).put("deviceId", deviceId).put("deviceManufacturer", android.os.Build.MANUFACTURER.take(80)).put("deviceModel", android.os.Build.MODEL.take(100)).put("androidVersion", android.os.Build.VERSION.RELEASE.take(30)))
                                    email = normalized; message = result.optString("message", "إذا كان الطلب صالحًا، أرسلنا رمز التحقق إلى بريدك."); messageIsError = false
                                } catch (e: Exception) { message = e.message ?: "تعذر إرسال رمز التحقق."; messageIsError = true } finally { busy = false } }
                                }
                            }, modifier = Modifier.fillMaxWidth().height(50.dp), enabled = !busy, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = activationMint, contentColor = Color(0xFF07111F))) {
                                Text(if (busy) "جارٍ الإرسال…" else "إرسال رمز التحقق إلى البريد", fontWeight = FontWeight.ExtraBold)
                            }
                            OutlinedTextField(value = trialCode, onValueChange = { trialCode = it.filter(Char::isDigit).take(6) }, modifier = Modifier.fillMaxWidth(), label = { Text("رمز التحقق المكوّن من 6 أرقام") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done), shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = activationMint, unfocusedBorderColor = Color(0xFF3A4A63), focusedLabelColor = activationMint, cursorColor = activationMint))
                            Button(onClick = {
                                val normalized = email.trim().lowercase()
                                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(normalized).matches() || trialCode.length != 6) { message = "أدخل بريدًا صحيحًا ورمز التحقق المكوّن من 6 أرقام."; messageIsError = true }
                                else { busy = true; message = ""; scope.launch { try {
                                    val result = activationCall(JSONObject().put("action", "verifyTrialCode").put("email", normalized).put("deviceId", deviceId).put("deviceManufacturer", android.os.Build.MANUFACTURER.take(80)).put("deviceModel", android.os.Build.MODEL.take(100)).put("androidVersion", android.os.Build.VERSION.RELEASE.take(30)).put("code", trialCode))
                                    val trialExpiry = result.optLong("expiresAt", System.currentTimeMillis() + 24L * 60L * 60L * 1000L)
                                    prefs.edit().putString("activation_email", normalized).putString("trial_email", normalized).putLong("trial_expires_at", trialExpiry).apply()
                                    email = normalized; activated = true
                                    message = result.optString("message", "بدأت تجربتك المجانية لمدة 24 ساعة."); messageIsError = false
                                } catch (e: Exception) { message = e.message ?: "تعذر التحقق من الرمز."; messageIsError = true } finally { busy = false } }
                                }
                            }, modifier = Modifier.fillMaxWidth().height(52.dp), enabled = !busy, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7CFFB2), contentColor = Color(0xFF07111F))) { Text(if (busy) "جارٍ التحقق…" else "تحقق وابدأ التجربة المجانية", fontWeight = FontWeight.ExtraBold) }
                            TextButton(onClick = { screenMode = "request"; message = ""; messageIsError = false }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("العودة إلى خيارات التفعيل", color = activationMint, fontWeight = FontWeight.Bold) }
                        }
                    } else if (screenMode == "checkPayment") {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(activationTr("Check my payment request", appLanguage), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            Text(activationTr("Enter the email used for your payment request. If payment has been verified, we will send your activation code to that email.", appLanguage), color = Color(0xFFB8C7DA), fontSize = 14.sp, lineHeight = 20.sp)
                            OutlinedTextField(
                                value = verifiedRequestEmail, onValueChange = { verifiedRequestEmail = it.trim() }, modifier = Modifier.fillMaxWidth(),
                                label = { Text(activationTr("Email address", appLanguage)) }, placeholder = { Text("name@example.com") }, singleLine = true,
                                shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Done),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = activationMint, unfocusedBorderColor = Color(0xFF3A4A63), focusedLabelColor = activationMint, cursorColor = activationMint)
                            )
                            Button(
                                onClick = {
                                    val normalized = verifiedRequestEmail.trim().lowercase()
                                    if (!android.util.Patterns.EMAIL_ADDRESS.matcher(normalized).matches()) {
                                        message = activationTr("Enter a valid email address.", appLanguage); messageIsError = true
                                    } else {
                                        busy = true; message = ""
                                        scope.launch {
                                            try {
                                                val result = activationCall(JSONObject().put("action", "checkPayment").put("email", normalized))
                                                message = result.optString("message", activationTr("If your payment is confirmed, your activation code has been sent to your email.", appLanguage))
                                                messageIsError = false
                                            } catch (e: Exception) { message = e.message ?: activationTr("Could not check your payment request. Please try again later.", appLanguage); messageIsError = true }
                                            finally { busy = false }
                                        }
                                    }
                                }, modifier = Modifier.fillMaxWidth().height(52.dp), enabled = !busy,
                                shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = activationMint, contentColor = Color(0xFF07111F))
                            ) {
                                if (busy) {
                                    val transition = rememberInfiniteTransition(label = "payment-check")
                                    val rotation by transition.animateFloat(initialValue = 0f, targetValue = 360f, animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Restart), label = "hourglass-rotation")
                                    CircularProgressIndicator(modifier = Modifier.size(22.dp).graphicsLayer { rotationZ = rotation }, strokeWidth = 2.5.dp, color = Color(0xFF07111F))
                                    Spacer(Modifier.width(10.dp)); Text(activationTr("Checking, please wait…", appLanguage), fontWeight = FontWeight.Bold)
                                } else Text(activationTr("Check and receive the code", appLanguage), fontWeight = FontWeight.ExtraBold)
                            }
                            TextButton(onClick = { screenMode = "request"; message = ""; messageIsError = false }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                                Text(activationTr("Back to payment request", appLanguage), color = activationMint, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else if (screenMode == "forgot") {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(activationTr("Forgot activation code?", appLanguage), color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                            Text(activationTr("Enter the email address used when you purchased activation. You can recover the code only once; after payment is confirmed, it will be sent to this email.", appLanguage), color = Color(0xFFB8C7DA), fontSize = 13.sp, lineHeight = 19.sp)
                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it.trim() },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text(activationTr("Email address", appLanguage)) },
                                placeholder = { Text("name@example.com") },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Done),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = activationMint, unfocusedBorderColor = Color(0xFF3A4A63), focusedLabelColor = activationMint, cursorColor = activationMint)
                            )
                            Button(
                                onClick = {
                                    val normalized = email.trim().lowercase()
                                    if (!android.util.Patterns.EMAIL_ADDRESS.matcher(normalized).matches()) {
                                        message = activationTr("Enter a valid email address.", appLanguage); messageIsError = true
                                    } else {
                                        busy = true; message = ""
                                        scope.launch {
                                            try {
                                                val result = activationCall(JSONObject().put("action", "recoverCode").put("email", normalized))
                                                email = normalized
                                                message = result.optString("message", activationTr("If payment is confirmed, the code will be sent to your email.", appLanguage))
                                                messageIsError = false
                                                screenMode = "login"
                                            } catch (e: Exception) {
                                                message = e.message ?: activationTr("Could not request code recovery. Please try again later.", appLanguage)
                                                messageIsError = true
                                            } finally { busy = false }
                                        }
                                    }
                                }, modifier = Modifier.fillMaxWidth().height(50.dp), enabled = !busy,
                                shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = activationMint, contentColor = Color(0xFF07111F))
                            ) {
                                if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF07111F))
                                else Text(activationTr("Send activation code to my email", appLanguage), fontWeight = FontWeight.ExtraBold)
                            }
                            TextButton(onClick = { screenMode = "login"; message = ""; messageIsError = false }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                                Text(activationTr("Back to sign in", appLanguage), color = activationMint, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        // A focused login screen: email and activation code only.
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(activationTr("Sign in", appLanguage), color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                            Text(activationTr("Enter the email used for your activation request and the code you received.", appLanguage), color = Color(0xFFB8C7DA), fontSize = 13.sp, lineHeight = 19.sp)
                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it.trim() },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text(activationTr("Email address", appLanguage)) },
                                placeholder = { Text("name@example.com") },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = activationMint, unfocusedBorderColor = Color(0xFF3A4A63), focusedLabelColor = activationMint, cursorColor = activationMint)
                            )
                            OutlinedTextField(
                                value = code,
                                onValueChange = { code = it.filter { ch -> ch.isLetterOrDigit() || "-_*#@!\$%".contains(ch) }.take(48) },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text(activationTr("Activation / login code", appLanguage)) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = activationMint, unfocusedBorderColor = Color(0xFF3A4A63), focusedLabelColor = activationMint, cursorColor = activationMint)
                            )
                            Button(
                                onClick = {
                                    val normalized = email.trim().lowercase()
                                    if (!android.util.Patterns.EMAIL_ADDRESS.matcher(normalized).matches() || code.trim().isBlank()) {
                                        message = activationTr("Enter your email address and activation code.", appLanguage); messageIsError = true
                                    } else {
                                        busy = true; message = ""
                                        scope.launch {
                                            try {
                                                activationCall(JSONObject().put("action", "activate").put("email", normalized).put("code", code.trim()).put("deviceId", deviceId))
                                                prefs.edit().putString("activation_email", normalized).remove("trial_email").remove("trial_expires_at").apply()
                                                email = normalized; activated = true; message = ""; messageIsError = false
                                            } catch (e: Exception) { message = e.message ?: "تعذر تفعيل الحساب."; messageIsError = true }
                                            finally { busy = false }
                                        }
                                    }
                                }, modifier = Modifier.fillMaxWidth().height(50.dp), enabled = !busy,
                                shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = activationMint, contentColor = Color(0xFF07111F))
                            ) {
                                if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF07111F))
                                else Text(activationTr("Verify code and sign in", appLanguage), fontWeight = FontWeight.ExtraBold)
                            }
                            TextButton(
                                onClick = {
                                    message = ""
                                    messageIsError = false
                                    screenMode = "forgot"
                                },
                                modifier = Modifier.fillMaxWidth(), enabled = !busy
                            ) {
                                Text(activationTr("Forgot code? Recover it once by email", appLanguage), color = activationMint, fontWeight = FontWeight.Bold)
                            }
                            TextButton(
                                onClick = {
                                    code = ""
                                    message = ""
                                    messageIsError = false
                                    receiptUri = null
                                    receiptLabel = ""
                                    screenMode = "request"
                                },
                                modifier = Modifier.fillMaxWidth(), enabled = !busy
                            ) {
                                Text(activationTr("I did not receive the code / Submit an activation request", appLanguage), color = activationMint, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (showAlreadyPaidDialog) {
                        val pulse = rememberInfiniteTransition(label = "already-paid-hint")
                        val zoom by pulse.animateFloat(initialValue = 1f, targetValue = 1.12f, animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "hint-zoom")
                        AlertDialog(
                            onDismissRequest = { showAlreadyPaidDialog = false },
                            containerColor = Color(0xFF111A2E),
                            title = { Text("✓  ${if (appLanguage == "ar") "هذا البريد سبق تأكيد دفعه" else activationTr("This email has already been verified as paid. Please sign in using your email and activation code.", appLanguage)}", color = Color(0xFFFFD166), fontWeight = FontWeight.ExtraBold) },
                            text = {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("👆", modifier = Modifier.graphicsLayer { scaleX = zoom; scaleY = zoom }, fontSize = 34.sp)
                                    Text(if (appLanguage == "ar") "لا يمكن لهذا البريد إرسال طلب مدفوع مرتين. أغلق هذه الرسالة ثم اضغط على العبارة الصفراء المسطرة أسفل زر طلب التفعيل للانتقال إلى تسجيل الدخول." else activationTr("This email has already been verified as paid. Please sign in using your email and activation code.", appLanguage), color = Color(0xFFE2E8F0), fontSize = 14.sp, lineHeight = 21.sp)
                                    Text("👇  لقد دفعت وتلقيت الكود الخاص بي — الدخول الآن", modifier = Modifier.graphicsLayer { scaleX = zoom; scaleY = zoom }, color = Color(0xFFFFD166), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, textDecoration = TextDecoration.Underline, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                            },
                            confirmButton = {
                                TextButton(onClick = { showAlreadyPaidDialog = false; screenMode = "login"; message = ""; messageIsError = false }) {
                                    Text(if (appLanguage == "ar") "الانتقال إلى تسجيل الدخول" else activationTr("Sign in", appLanguage), color = activationMint, fontWeight = FontWeight.Bold)
                                }
                            }
                        )
                    }

                    if (message.isNotBlank()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = if (messageIsError) Color(0xFF3B202A) else Color(0xFF15352D)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(message, modifier = Modifier.fillMaxWidth().padding(13.dp), color = if (messageIsError) Color(0xFFFFB4C0) else Color(0xFF9FF3D2), fontSize = 13.sp, lineHeight = 19.sp)
                        }
                    }
                    Text("يسمح النظام بجهاز نشط واحد لكل بريد إلكتروني. يلزم اتصال بالإنترنت للتحقق من الترخيص.", color = Color(0xFF64748B), fontSize = 11.sp, lineHeight = 16.sp)
                    Text("CryptoAnalyser by ErrZhr  •  Thank you for your trust", modifier = Modifier.fillMaxWidth(), color = Color(0xFF64748B), fontSize = 10.sp)
                }
            }
        }
    }
}
