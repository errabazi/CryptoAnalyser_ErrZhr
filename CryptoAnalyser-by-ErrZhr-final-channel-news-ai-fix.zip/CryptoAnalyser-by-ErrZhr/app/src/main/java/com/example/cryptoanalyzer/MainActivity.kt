
package com.example.cryptoanalyzer

import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import android.text.Html
import android.webkit.WebView
import android.webkit.WebViewClient
import android.util.Xml
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZonedDateTime
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val appLanguages = listOf(
    "en" to "English", "fr" to "Français", "ar" to "العربية", "zh" to "中文",
    "ja" to "日本語", "es" to "Español", "de" to "Deutsch", "it" to "Italiano", "ko" to "한국어"
)

private val baseUiTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf(
        "PRIVACY" to "CONFIDENTIALITÉ", "PUBLIC MARKET DATA · BITGET API" to "DONNÉES PUBLIQUES · API BITGET",
        "YOUR MARKET,\nCLEARER." to "VOTRE MARCHÉ,\nPLUS CLAIR.", "Technical signals and multi-timeframe insights in one place." to "Signaux techniques et analyses multi-unités de temps au même endroit.",
        "PUBLIC BITGET DATA" to "DONNÉES PUBLIQUES BITGET", "ANALYZE A MARKET" to "ANALYSER UN MARCHÉ", "Choose a pair and market type" to "Choisissez une paire et un type de marché",
        "Coin or trading pair" to "Crypto ou paire de trading", "Type BTC, ETH, AI…" to "Saisissez BTC, ETH, AI…", "MARKET TYPE" to "TYPE DE MARCHÉ",
        "ANALYZING MARKET…" to "ANALYSE DU MARCHÉ…", "✦  ANALYZE MARKET" to "✦  ANALYSER LE MARCHÉ", "LISTEN TO THE SUMMARY" to "ÉCOUTER LE RÉSUMÉ",
        "Choose a voice tone, then tap the speaker button. Available voices depend on your phone and selected language." to "Choisissez une tonalité puis appuyez sur le bouton audio. Les voix disponibles dépendent du téléphone et de la langue choisie.",
        "👩  Woman" to "👩  Femme", "👨  Man" to "👨  Homme", "🔊  HEAR SUMMARY" to "🔊  ÉCOUTER LE RÉSUMÉ", "Preparing voice…" to "Préparation de la voix…",
        "ENTRY PLAN · AUTOMATIC" to "PLAN D’ENTRÉE · AUTOMATIQUE", "PRICE RANGE" to "FOURCHETTE DE PRIX", "HIGH / LOW" to "HAUT / BAS", "PRICE CHART · CANDLESTICKS" to "GRAPHIQUE · BOUGIES JAPONAISES", "15 minutes" to "15 minutes", "1 hour" to "1 heure", "4 hours" to "4 heures", "1 day" to "1 jour", "1 month" to "1 mois", "Run analysis to load the price chart." to "Lancez l’analyse pour charger le graphique.", "Candlestick data is unavailable for this pair and timeframe." to "Données de bougies indisponibles pour cette paire et cette période.",
        "ALL-TIME HIGH" to "PLUS HAUT HISTORIQUE", "ALL-TIME LOW" to "PLUS BAS HISTORIQUE", "24H HIGH" to "PLUS HAUT 24 H", "24H LOW" to "PLUS BAS 24 H",
        "Unavailable" to "Indisponible", "Close" to "Fermer", "Fermer" to "Fermer", "LANGUAGE" to "LANGUE", "PLATFORM" to "PLATEFORME", "PUBLIC MARKET DATA" to "DONNÉES PUBLIQUES",
        "Stop" to "Arrêter", "−5 sec" to "−5 s", "+5 sec" to "+5 s", "Restart" to "Recommencer"
    ),
    "ar" to mapOf(
        "PRIVACY" to "الخصوصية", "PUBLIC MARKET DATA · BITGET API" to "بيانات السوق العامة · واجهة BITGET",
        "YOUR MARKET,\nCLEARER." to "سوقك،\nبوضوح أكبر.", "Technical signals and multi-timeframe insights in one place." to "إشارات فنية وتحليلات لعدة أطر زمنية في مكان واحد.",
        "PUBLIC BITGET DATA" to "بيانات BITGET العامة", "ANALYZE A MARKET" to "تحليل السوق", "Choose a pair and market type" to "اختر زوج التداول ونوع السوق",
        "Coin or trading pair" to "العملة أو زوج التداول", "Type BTC, ETH, AI…" to "اكتب BTC أو ETH أو AI…", "MARKET TYPE" to "نوع السوق",
        "ANALYZING MARKET…" to "جارٍ تحليل السوق…", "✦  ANALYZE MARKET" to "✦  تحليل السوق", "LISTEN TO THE SUMMARY" to "استمع إلى الملخص",
        "Choose a voice tone, then tap the speaker button. Available voices depend on your phone and selected language." to "اختر نبرة الصوت ثم اضغط زر التشغيل. يعتمد الصوت المتاح على الهاتف واللغة المختارة، دون تنزيل تطبيق إضافي.",
        "👩  Woman" to "👩  امرأة", "👨  Man" to "👨  رجل", "🔊  HEAR SUMMARY" to "🔊  استمع إلى الملخص", "Preparing voice…" to "جارٍ تجهيز الصوت…",
        "ENTRY PLAN · AUTOMATIC" to "خطة الدخول · تلقائي", "PRICE RANGE" to "نطاق السعر", "HIGH / LOW" to "الأعلى / الأدنى", "PRICE CHART · CANDLESTICKS" to "الرسم البياني · الشموع اليابانية", "15 minutes" to "15 دقيقة", "1 hour" to "ساعة واحدة", "4 hours" to "4 ساعات", "1 day" to "يوم واحد", "1 month" to "شهر واحد", "Run analysis to load the price chart." to "ابدأ التحليل لتحميل الرسم البياني.", "Candlestick data is unavailable for this pair and timeframe." to "بيانات الشموع غير متاحة لهذا الزوج والإطار الزمني.",
        "ALL-TIME HIGH" to "أعلى سعر تاريخي", "ALL-TIME LOW" to "أدنى سعر تاريخي", "24H HIGH" to "أعلى سعر خلال 24 ساعة", "24H LOW" to "أدنى سعر خلال 24 ساعة",
        "Unavailable" to "غير متاح", "Close" to "إغلاق", "Fermer" to "إغلاق", "LANGUAGE" to "اللغة", "PLATFORM" to "المنصة", "PUBLIC MARKET DATA" to "بيانات السوق العامة",
        "Stop" to "إيقاف", "−5 sec" to "−5 ثوانٍ", "+5 sec" to "+5 ثوانٍ", "Restart" to "إعادة من البداية"
    ),
    "es" to mapOf("PRIVACY" to "PRIVACIDAD", "ANALYZE A MARKET" to "ANALIZAR MERCADO", "Choose a pair and market type" to "Elige un par y tipo de mercado", "MARKET TYPE" to "TIPO DE MERCADO", "ANALYZING MARKET…" to "ANALIZANDO MERCADO…", "✦  ANALYZE MARKET" to "✦  ANALIZAR MERCADO", "LISTEN TO THE SUMMARY" to "ESCUCHAR EL RESUMEN", "👩  Woman" to "👩  Mujer", "👨  Man" to "👨  Hombre", "🔊  HEAR SUMMARY" to "🔊  ESCUCHAR RESUMEN", "ENTRY PLAN · AUTOMATIC" to "PLAN DE ENTRADA · AUTOMÁTICO", "PRICE RANGE" to "RANGO DE PRECIOS", "ALL-TIME HIGH" to "MÁXIMO HISTÓRICO", "ALL-TIME LOW" to "MÍNIMO HISTÓRICO", "24H HIGH" to "MÁXIMO 24 H", "24H LOW" to "MÍNIMO 24 H", "Unavailable" to "No disponible", "LANGUAGE" to "IDIOMA", "Stop" to "Detener", "−5 sec" to "−5 s", "+5 sec" to "+5 s", "Restart" to "Reiniciar"),
    "de" to mapOf("PRIVACY" to "DATENSCHUTZ", "ANALYZE A MARKET" to "MARKT ANALYSIEREN", "Choose a pair and market type" to "Wähle ein Handelspaar und einen Markttyp", "MARKET TYPE" to "MARKTTYP", "ANALYZING MARKET…" to "MARKTANALYSE…", "✦  ANALYZE MARKET" to "✦  MARKT ANALYSIEREN", "LISTEN TO THE SUMMARY" to "ZUSAMMENFASSUNG ANHÖREN", "👩  Woman" to "👩  Frau", "👨  Man" to "👨  Mann", "🔊  HEAR SUMMARY" to "🔊  ZUSAMMENFASSUNG", "ENTRY PLAN · AUTOMATIC" to "EINSTIEGSPLAN · AUTOMATISCH", "PRICE RANGE" to "PREISBEREICH", "ALL-TIME HIGH" to "ALLZEITHOCH", "ALL-TIME LOW" to "ALLZEITTIEF", "24H HIGH" to "24H-HOCH", "24H LOW" to "24H-TIEF", "Unavailable" to "Nicht verfügbar", "LANGUAGE" to "SPRACHE", "Stop" to "Stopp", "−5 sec" to "−5 Sek.", "+5 sec" to "+5 Sek.", "Restart" to "Neu starten"),
    "it" to mapOf("PRIVACY" to "PRIVACY", "ANALYZE A MARKET" to "ANALIZZA MERCATO", "Choose a pair and market type" to "Scegli una coppia e il tipo di mercato", "MARKET TYPE" to "TIPO DI MERCATO", "ANALYZING MARKET…" to "ANALISI DEL MERCATO…", "✦  ANALYZE MARKET" to "✦  ANALIZZA MERCATO", "LISTEN TO THE SUMMARY" to "ASCOLTA IL RIEPILOGO", "👩  Woman" to "👩  Donna", "👨  Man" to "👨  Uomo", "🔊  HEAR SUMMARY" to "🔊  ASCOLTA RIEPILOGO", "ENTRY PLAN · AUTOMATIC" to "PIANO DI INGRESSO · AUTOMATICO", "PRICE RANGE" to "INTERVALLO DI PREZZO", "ALL-TIME HIGH" to "MASSIMO STORICO", "ALL-TIME LOW" to "MINIMO STORICO", "24H HIGH" to "MASSIMO 24 ORE", "24H LOW" to "MINIMO 24 ORE", "Unavailable" to "Non disponibile", "LANGUAGE" to "LINGUA", "Stop" to "Ferma", "−5 sec" to "−5 s", "+5 sec" to "+5 s", "Restart" to "Ricomincia"),
    "zh" to mapOf("PRIVACY" to "隐私", "ANALYZE A MARKET" to "分析市场", "Choose a pair and market type" to "选择交易对和市场类型", "MARKET TYPE" to "市场类型", "ANALYZING MARKET…" to "正在分析市场…", "✦  ANALYZE MARKET" to "✦  分析市场", "LISTEN TO THE SUMMARY" to "收听摘要", "👩  Woman" to "👩  女声", "👨  Man" to "👨  男声", "🔊  HEAR SUMMARY" to "🔊  收听摘要", "ENTRY PLAN · AUTOMATIC" to "自动入场计划", "PRICE RANGE" to "价格区间", "ALL-TIME HIGH" to "历史最高价", "ALL-TIME LOW" to "历史最低价", "24H HIGH" to "24小时最高", "24H LOW" to "24小时最低", "Unavailable" to "不可用", "LANGUAGE" to "语言", "Stop" to "停止", "−5 sec" to "后退5秒", "+5 sec" to "前进5秒", "Restart" to "从头播放"),
    "ja" to mapOf("PRIVACY" to "プライバシー", "ANALYZE A MARKET" to "市場を分析", "Choose a pair and market type" to "取引ペアと市場タイプを選択", "MARKET TYPE" to "市場タイプ", "ANALYZING MARKET…" to "市場を分析中…", "✦  ANALYZE MARKET" to "✦  市場を分析", "LISTEN TO THE SUMMARY" to "要約を聞く", "👩  Woman" to "👩  女性", "👨  Man" to "👨  男性", "🔊  HEAR SUMMARY" to "🔊  要約を聞く", "ENTRY PLAN · AUTOMATIC" to "エントリープラン · 自動", "PRICE RANGE" to "価格範囲", "ALL-TIME HIGH" to "史上最高値", "ALL-TIME LOW" to "史上最安値", "24H HIGH" to "24時間高値", "24H LOW" to "24時間安値", "Unavailable" to "利用不可", "LANGUAGE" to "言語", "Stop" to "停止", "−5 sec" to "5秒戻る", "+5 sec" to "5秒進む", "Restart" to "最初から再生"),
    "ko" to mapOf("PRIVACY" to "개인정보", "ANALYZE A MARKET" to "시장 분석", "Choose a pair and market type" to "거래 쌍과 시장 유형 선택", "MARKET TYPE" to "시장 유형", "ANALYZING MARKET…" to "시장 분석 중…", "✦  ANALYZE MARKET" to "✦  시장 분석", "LISTEN TO THE SUMMARY" to "요약 듣기", "👩  Woman" to "👩  여성 음성", "👨  Man" to "👨  남성 음성", "🔊  HEAR SUMMARY" to "🔊  요약 듣기", "ENTRY PLAN · AUTOMATIC" to "자동 진입 계획", "PRICE RANGE" to "가격 범위", "ALL-TIME HIGH" to "역대 최고가", "ALL-TIME LOW" to "역대 최저가", "24H HIGH" to "24시간 최고가", "24H LOW" to "24시간 최저가", "Unavailable" to "사용 불가", "LANGUAGE" to "언어", "Stop" to "중지", "−5 sec" to "5초 뒤로", "+5 sec" to "5초 앞으로", "Restart" to "처음부터 재생")
)

private val additionalTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf(
        "COIN RESEARCH REPORT" to "RAPPORT DE RECHERCHE SUR LA CRYPTO", "Summary and source checks" to "Résumé et vérification des sources", "Project identity and utility" to "Projet et utilité", "Launch and first market data" to "Lancement et premières données de marché", "Investors and funding" to "Investisseurs et financement", "Token unlock schedule" to "Calendrier de déblocage des tokens", "Adoption and partnerships" to "Adoption et partenariats", "Price scenarios: 1 month to 5 years" to "Scénarios de prix : 1 mois à 5 ans", "Search sources inside app" to "Rechercher les sources dans l’application", "Close" to "Fermer", "No claim is treated as confirmed unless a reliable source supports it. Check the selected coin name and ticker to avoid confusing projects with similar symbols." to "Aucune affirmation n’est considérée comme confirmée sans source fiable. Vérifiez le nom et le symbole pour éviter toute confusion entre projets similaires.", "The report separates verified facts from claims that still need checking. Forecasts are scenarios, not guarantees. Data not found is marked unknown instead of being invented." to "Le rapport distingue les faits vérifiés des affirmations à confirmer. Les prévisions sont des scénarios, pas des garanties. Les données introuvables sont signalées comme inconnues, sans invention.", "Source access depends on public availability. Private groups and some social-platform posts cannot be searched automatically; missing data is not proof that no information exists." to "L’accès aux sources dépend de leur disponibilité publique. Les groupes privés et certaines publications sociales ne peuvent pas être recherchés automatiquement ; une donnée manquante ne prouve pas son inexistence.",
        "LIVE PRICE" to "PRIX EN DIRECT", "Live public market data · Bitget" to "Données publiques en direct · Bitget", "MAX. 4" to "MAX. 4",
        "Les actualités affichées concernent uniquement la crypto sélectionnée." to "Les actualités affichées concernent uniquement la crypto sélectionnée.",
        "Chargement des actualités récentes…" to "Chargement des actualités récentes…", "PUBLIC BITGET DATA" to "DONNÉES PUBLIQUES BITGET",
        "Signal interpretation" to "Interprétation du signal", "Scores are heuristic signals, not calibrated probabilities." to "Les scores sont des indicateurs heuristiques, pas des probabilités calibrées.",
        "BACKTEST LAB" to "LABORATOIRE DE BACKTEST", "EMA 9/21 crossover" to "Croisement EMA 9/21", "PROJECT RESEARCH" to "RECHERCHE SUR LE PROJET",
        "Fundamentals & investors" to "Fondamentaux et investisseurs", "What this app does" to "Fonctionnement de l’application", "Network and privacy" to "Réseau et confidentialité",
        "Financial risk" to "Risques financiers", "Third-party services" to "Services tiers", "Stop loss (SL)" to "Stop-loss (SL)",
        "Entry / trigger" to "Entrée / déclencheur", "BULLISH SCORE" to "SCORE HAUSSIER", "BEARISH SCORE" to "SCORE BAISSIER",
        "MOVING AVERAGES" to "MOYENNES MOBILES", "MOMENTUM" to "MOMENTUM", "SUPPORT" to "SUPPORT", "RESISTANCE" to "RÉSISTANCE"
    ),
    "ar" to mapOf(
        "COIN RESEARCH REPORT" to "تقرير بحث العملة", "Summary and source checks" to "ملخص والتحقق من المصادر", "Project identity and utility" to "تعريف المشروع واستخدام العملة", "Launch and first market data" to "الإطلاق وأول بيانات السوق", "Investors and funding" to "المستثمرون والتمويل", "Token unlock schedule" to "جدول تحرير العملات", "Adoption and partnerships" to "التبني والشراكات", "Price scenarios: 1 month to 5 years" to "سيناريوهات السعر: من شهر إلى 5 سنوات", "Search sources inside app" to "البحث في المصادر داخل التطبيق", "Close" to "إغلاق", "No claim is treated as confirmed unless a reliable source supports it. Check the selected coin name and ticker to avoid confusing projects with similar symbols." to "لن تُعد أي معلومة مؤكدة دون مصدر موثوق. تحقق من اسم العملة ورمزها لتجنب الخلط بين المشاريع المتشابهة.", "The report separates verified facts from claims that still need checking. Forecasts are scenarios, not guarantees. Data not found is marked unknown instead of being invented." to "يفصل التقرير بين الحقائق المؤكدة والادعاءات التي تحتاج إلى تحقق. التوقعات سيناريوهات وليست ضمانات. ستُعرض البيانات غير المتاحة على أنها مجهولة بدل اختلاقها.", "Source access depends on public availability. Private groups and some social-platform posts cannot be searched automatically; missing data is not proof that no information exists." to "يعتمد الوصول إلى المصادر على إتاحتها للعامة. لا يمكن البحث آليًا في المجموعات الخاصة وبعض منشورات المنصات الاجتماعية؛ وعدم العثور على معلومة لا يعني أنها غير موجودة.",
        "LIVE PRICE" to "السعر المباشر", "Live public market data · Bitget" to "بيانات السوق العامة المباشرة · Bitget", "MAX. 4" to "الحد الأقصى 4",
        "Les actualités affichées concernent uniquement la crypto sélectionnée." to "تُعرض فقط الأخبار المرتبطة بالعملة التي اخترتها.",
        "Chargement des actualités récentes…" to "جارٍ تحميل آخر الأخبار…", "PUBLIC BITGET DATA" to "بيانات Bitget العامة",
        "Signal interpretation" to "تفسير الإشارة", "Scores are heuristic signals, not calibrated probabilities." to "الدرجات مؤشرات تقديرية وليست احتمالات معايرة.",
        "BACKTEST LAB" to "مختبر الاختبار التاريخي", "EMA 9/21 crossover" to "تقاطع EMA 9/21", "PROJECT RESEARCH" to "بحث المشروع",
        "Fundamentals & investors" to "الأساسيات والمستثمرون", "What this app does" to "وظيفة التطبيق", "Network and privacy" to "الشبكة والخصوصية",
        "Financial risk" to "المخاطر المالية", "Third-party services" to "خدمات الجهات الخارجية", "Stop loss (SL)" to "وقف الخسارة (SL)",
        "Entry / trigger" to "الدخول / شرط التفعيل", "BULLISH SCORE" to "درجة الصعود", "BEARISH SCORE" to "درجة الهبوط",
        "MOVING AVERAGES" to "المتوسطات المتحركة", "MOMENTUM" to "الزخم", "SUPPORT" to "الدعم", "RESISTANCE" to "المقاومة"
    ),
    "es" to mapOf("LIVE PRICE" to "PRECIO EN VIVO", "Signal interpretation" to "Interpretación de señales", "BACKTEST LAB" to "LABORATORIO DE BACKTEST", "PROJECT RESEARCH" to "INVESTIGACIÓN DEL PROYECTO", "Fundamentals & investors" to "Fundamentos e inversores", "BULLISH SCORE" to "PUNTUACIÓN ALCISTA", "BEARISH SCORE" to "PUNTUACIÓN BAJISTA", "MOVING AVERAGES" to "MEDIAS MÓVILES", "SUPPORT" to "SOPORTE", "RESISTANCE" to "RESISTENCIA", "Stop loss (SL)" to "Stop loss (SL)"),
    "de" to mapOf("LIVE PRICE" to "LIVE-PREIS", "Signal interpretation" to "Signalinterpretation", "BACKTEST LAB" to "BACKTEST-LABOR", "PROJECT RESEARCH" to "PROJEKTRECHERCHE", "Fundamentals & investors" to "Fundamentaldaten und Investoren", "BULLISH SCORE" to "AUFWÄRTSWERT", "BEARISH SCORE" to "ABWÄRTSWERT", "MOVING AVERAGES" to "GLEITENDE DURCHSCHNITTE", "SUPPORT" to "UNTERSTÜTZUNG", "RESISTANCE" to "WIDERSTAND", "Stop loss (SL)" to "Stop-Loss (SL)"),
    "it" to mapOf("LIVE PRICE" to "PREZZO LIVE", "Signal interpretation" to "Interpretazione del segnale", "BACKTEST LAB" to "LABORATORIO BACKTEST", "PROJECT RESEARCH" to "RICERCA SUL PROGETTO", "Fundamentals & investors" to "Fondamentali e investitori", "BULLISH SCORE" to "PUNTEGGIO RIALZISTA", "BEARISH SCORE" to "PUNTEGGIO RIBASSISTA", "MOVING AVERAGES" to "MEDIE MOBILI", "SUPPORT" to "SUPPORTO", "RESISTANCE" to "RESISTENZA", "Stop loss (SL)" to "Stop loss (SL)"),
    "zh" to mapOf("LIVE PRICE" to "实时价格", "Signal interpretation" to "信号解读", "BACKTEST LAB" to "回测实验室", "PROJECT RESEARCH" to "项目研究", "Fundamentals & investors" to "基本面与投资者", "BULLISH SCORE" to "看涨评分", "BEARISH SCORE" to "看跌评分", "MOVING AVERAGES" to "移动平均线", "SUPPORT" to "支撑位", "RESISTANCE" to "阻力位", "Stop loss (SL)" to "止损 (SL)"),
    "ja" to mapOf("LIVE PRICE" to "リアルタイム価格", "Signal interpretation" to "シグナル解釈", "BACKTEST LAB" to "バックテスト", "PROJECT RESEARCH" to "プロジェクト調査", "Fundamentals & investors" to "ファンダメンタルズと投資家", "BULLISH SCORE" to "強気スコア", "BEARISH SCORE" to "弱気スコア", "MOVING AVERAGES" to "移動平均線", "SUPPORT" to "サポート", "RESISTANCE" to "レジスタンス", "Stop loss (SL)" to "損切り (SL)"),
    "ko" to mapOf("LIVE PRICE" to "실시간 가격", "Signal interpretation" to "신호 해석", "BACKTEST LAB" to "백테스트 실험실", "PROJECT RESEARCH" to "프로젝트 조사", "Fundamentals & investors" to "펀더멘털 및 투자자", "BULLISH SCORE" to "상승 점수", "BEARISH SCORE" to "하락 점수", "MOVING AVERAGES" to "이동평균", "SUPPORT" to "지지선", "RESISTANCE" to "저항선", "Stop loss (SL)" to "손절매 (SL)")
)

private val uiTranslations: Map<String, Map<String, String>> = baseUiTranslations.mapValues { (language, translations) ->
    translations + additionalTranslations[language].orEmpty()
}

private val tradingTermTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf(
        "Aggressive entry" to "Entrée agressive", "Breakout-confirmation entry" to "Entrée après confirmation de cassure", "More conservative entry" to "Entrée plus prudente",
        "Near support; higher risk. Prefer a visible support reaction." to "Près du support ; risque plus élevé. Attendez une réaction visible du support.",
        "Trigger only after a candle closes above resistance; a retest is preferable." to "Déclenchez l’entrée seulement après la clôture d’une bougie au-dessus de la résistance ; un retest est préférable.",
        "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "Attendez une hausse plus nette au-dessus de la résistance et confirmez le volume ; le prix d’entrée peut être plus élevé.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "Les trois scénarios sont affichés ensemble. Les niveaux utilisent le support et la résistance en 4 h. TP1–TP3 sont des objectifs indicatifs à 1R/2R/3R calculés depuis la distance du stop-loss ; ils ne sont pas garantis.",
        "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "Risque : ces niveaux sont des repères d’analyse, pas des ordres réels. Une entrée sur cassure exige une confirmation ; un stop peut subir du glissement en période volatile.",
        "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "Niveaux de trading indisponibles : les données de support/résistance ne sont pas assez fiables pour établir un plan.",
        "ABOVE" to "AU-DESSUS", "BELOW" to "EN DESSOUS", "Spot" to "Marché au comptant", "USDT Futures" to "Contrats à terme USDT",
        "Entry / trigger" to "Entrée / déclencheur", "Stop loss (SL)" to "Stop-loss (SL)", "TAKE PROFIT" to "PRISE DE BÉNÉFICES", "Volume" to "Volume", "Price" to "Prix", "Change" to "Variation", "Market cap" to "Capitalisation", "Liquidity" to "Liquidité", "Trend" to "Tendance", "Buy" to "Acheter", "Sell" to "Vendre", "Bullish" to "Haussier", "Bearish" to "Baissier", "Timeframe" to "Unité de temps", "Last close" to "Dernière clôture", "Signal" to "Signal", "History" to "Historique", "Risk/Reward" to "Risque/rendement", "Take profit" to "Prise de bénéfices", "Stop loss" to "Stop-loss", "Entry price" to "Prix d’entrée", "Current price" to "Prix actuel", "High" to "Plus haut", "Low" to "Plus bas", "Support" to "Support", "Resistance" to "Résistance", "Momentum" to "Momentum (dynamique)", "Moving averages" to "Moyennes mobiles", "Bullish score" to "Score haussier", "Bearish score" to "Score baissier"
    ),
    "ar" to mapOf(
        "Aggressive entry" to "دخول هجومي", "Breakout-confirmation entry" to "دخول بعد تأكيد الاختراق", "More conservative entry" to "دخول أكثر تحفظًا",
        "Near support; higher risk. Prefer a visible support reaction." to "بالقرب من الدعم؛ المخاطرة أعلى. يُفضّل انتظار ارتداد واضح من الدعم.",
        "Trigger only after a candle closes above resistance; a retest is preferable." to "لا تُفعّل الدخول إلا بعد إغلاق شمعة فوق المقاومة؛ وإعادة اختبار المستوى أفضل.",
        "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "انتظر حركة أقوى فوق المقاومة وتأكد من حجم التداول؛ قد يكون سعر الدخول أعلى.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "تُعرض السيناريوهات الثلاثة معًا. تعتمد المستويات على الدعم والمقاومة في إطار 4 ساعات. أهداف TP1–TP3 توضيحية عند 1R و2R و3R وفق مسافة وقف الخسارة، وليست نتائج مضمونة.",
        "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "تنبيه للمخاطر: هذه مستويات مرجعية للتحليل وليست أوامر تداول فعلية. الدخول بعد الاختراق يحتاج إلى تأكيد، وقد يتجاوز التنفيذ سعر وقف الخسارة أثناء التقلبات.",
        "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "مستويات التداول غير متاحة: بيانات الدعم والمقاومة غير كافية لبناء خطة.",
        "ABOVE" to "أعلى من", "BELOW" to "أدنى من", "Spot" to "السوق الفوري", "USDT Futures" to "العقود الآجلة USDT",
        "Entry / trigger" to "سعر الدخول / شرط التفعيل", "Stop loss (SL)" to "وقف الخسارة (SL)", "TAKE PROFIT" to "جني الأرباح", "Volume" to "حجم التداول", "Price" to "السعر", "Change" to "التغير", "Market cap" to "القيمة السوقية", "Liquidity" to "السيولة", "Trend" to "الاتجاه", "Buy" to "شراء", "Sell" to "بيع", "Bullish" to "صاعد", "Bearish" to "هابط", "Timeframe" to "الإطار الزمني", "Last close" to "آخر إغلاق", "Signal" to "الإشارة", "History" to "السجل التاريخي", "Risk/Reward" to "المخاطرة إلى العائد", "Take profit" to "جني الأرباح", "Stop loss" to "وقف الخسارة", "Entry price" to "سعر الدخول", "Current price" to "السعر الحالي", "High" to "الأعلى", "Low" to "الأدنى", "Support" to "الدعم", "Resistance" to "المقاومة", "Momentum" to "الزخم", "Moving averages" to "المتوسطات المتحركة", "Bullish score" to "درجة الصعود", "Bearish score" to "درجة الهبوط"
    ),
    "es" to mapOf(
        "Aggressive entry" to "Entrada agresiva", "Breakout-confirmation entry" to "Entrada tras confirmar la ruptura", "More conservative entry" to "Entrada más conservadora",
        "Near support; higher risk. Prefer a visible support reaction." to "Cerca del soporte; mayor riesgo. Es preferible ver una reacción clara del soporte.",
        "Trigger only after a candle closes above resistance; a retest is preferable." to "Activar solo después de que una vela cierre por encima de la resistencia; es preferible un retesteo.",
        "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "Espera un movimiento más fuerte por encima de la resistencia y confirma el volumen; la entrada puede ser más alta.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "Se muestran los tres escenarios. Los niveles usan el soporte y la resistencia de 4 h. TP1–TP3 son objetivos orientativos 1R/2R/3R según la distancia al stop-loss; no están garantizados.",
        "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "Riesgo: estos niveles son referencias de análisis, no órdenes reales. Las entradas por ruptura requieren confirmación; las órdenes stop pueden sufrir deslizamiento con volatilidad.",
        "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "Niveles de operación no disponibles: los datos de soporte/resistencia no bastan para crear un plan.",
        "ABOVE" to "POR ENCIMA", "BELOW" to "POR DEBAJO", "Spot" to "Mercado al contado", "USDT Futures" to "Futuros USDT",
        "Entry / trigger" to "Entrada / activación", "Stop loss (SL)" to "Stop-loss (SL)", "TAKE PROFIT" to "TOMA DE GANANCIAS", "Volume" to "Volumen", "Price" to "Precio", "Change" to "Variación", "Market cap" to "Capitalización de mercado", "Liquidity" to "Liquidez", "Trend" to "Tendencia", "Buy" to "Comprar", "Sell" to "Vender", "Bullish" to "Alcista", "Bearish" to "Bajista", "Timeframe" to "Marco temporal", "Last close" to "Último cierre", "Signal" to "Señal", "History" to "Historial", "Risk/Reward" to "Riesgo/beneficio", "Take profit" to "Toma de ganancias", "Stop loss" to "Stop-loss", "Entry price" to "Precio de entrada", "Current price" to "Precio actual", "High" to "Máximo", "Low" to "Mínimo", "Support" to "Soporte", "Resistance" to "Resistencia", "Momentum" to "Impulso", "Moving averages" to "Medias móviles", "Bullish score" to "Puntuación alcista", "Bearish score" to "Puntuación bajista"
    ),
    "de" to mapOf(
        "Aggressive entry" to "Aggressiver Einstieg", "Breakout-confirmation entry" to "Einstieg nach Ausbruchsbestätigung", "More conservative entry" to "Konservativerer Einstieg",
        "Near support; higher risk. Prefer a visible support reaction." to "Nahe der Unterstützung; höheres Risiko. Eine erkennbare Reaktion an der Unterstützung abwarten.",
        "Trigger only after a candle closes above resistance; a retest is preferable." to "Erst auslösen, wenn eine Kerze über dem Widerstand schließt; ein Retest ist vorzuziehen.",
        "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "Eine stärkere Bewegung über den Widerstand abwarten und das Volumen bestätigen; der Einstieg kann höher liegen.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "Alle drei Szenarien werden angezeigt. Die Niveaus basieren auf Unterstützung und Widerstand im 4-Stunden-Zeitrahmen. TP1–TP3 sind beispielhafte 1R/2R/3R-Ziele anhand des Stop-Abstands und nicht garantiert.",
        "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "Risikohinweis: Dies sind Analyse-Referenzwerte, keine Live-Orders. Ausbruchseinstiege benötigen eine Bestätigung; Stop-Orders können bei Volatilität abweichen.",
        "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "Handelsniveaus nicht verfügbar: Die Unterstützungs-/Widerstandsdaten reichen für einen Plan nicht aus.",
        "ABOVE" to "DARÜBER", "BELOW" to "DARUNTER", "Spot" to "Spotmarkt", "USDT Futures" to "USDT-Futures",
        "Entry / trigger" to "Einstieg / Auslöser", "Stop loss (SL)" to "Stop-Loss (SL)", "TAKE PROFIT" to "GEWINNMITNAHME", "Volume" to "Volumen", "Price" to "Preis", "Change" to "Änderung", "Market cap" to "Marktkapitalisierung", "Liquidity" to "Liquidität", "Trend" to "Trend", "Buy" to "Kaufen", "Sell" to "Verkaufen", "Bullish" to "Bullisch", "Bearish" to "Bärisch", "Timeframe" to "Zeitrahmen", "Last close" to "Letzter Schlusskurs", "Signal" to "Signal", "History" to "Verlauf", "Risk/Reward" to "Risiko/Rendite", "Take profit" to "Gewinnmitnahme", "Stop loss" to "Stop-Loss", "Entry price" to "Einstiegspreis", "Current price" to "Aktueller Preis", "High" to "Hoch", "Low" to "Tief", "Support" to "Unterstützung", "Resistance" to "Widerstand", "Momentum" to "Momentum", "Moving averages" to "Gleitende Durchschnitte", "Bullish score" to "Aufwärtsscore", "Bearish score" to "Abwärtsscore"
    ),
    "it" to mapOf(
        "Aggressive entry" to "Ingresso aggressivo", "Breakout-confirmation entry" to "Ingresso dopo conferma della rottura", "More conservative entry" to "Ingresso più prudente",
        "Near support; higher risk. Prefer a visible support reaction." to "Vicino al supporto; rischio maggiore. Preferire una reazione visibile del supporto.",
        "Trigger only after a candle closes above resistance; a retest is preferable." to "Attivare solo dopo la chiusura di una candela sopra la resistenza; meglio attendere un retest.",
        "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "Attendere un movimento più forte sopra la resistenza e confermare i volumi; l’ingresso può essere più alto.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "Sono mostrati tutti e tre gli scenari. I livelli usano supporto e resistenza sul grafico a 4 ore. TP1–TP3 sono obiettivi indicativi 1R/2R/3R calcolati dalla distanza dello stop-loss e non sono garantiti.",
        "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "Rischio: questi livelli sono riferimenti analitici, non ordini reali. Gli ingressi su rottura richiedono conferma; gli stop possono subire slippage durante la volatilità.",
        "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "Livelli di trading non disponibili: i dati di supporto/resistenza non sono sufficienti per un piano.",
        "ABOVE" to "SOPRA", "BELOW" to "SOTTO", "Spot" to "Mercato spot", "USDT Futures" to "Futures USDT",
        "Entry / trigger" to "Ingresso / attivazione", "Stop loss (SL)" to "Stop-loss (SL)", "TAKE PROFIT" to "PRESA DI PROFITTO", "Volume" to "Volume", "Price" to "Prezzo", "Change" to "Variazione", "Market cap" to "Capitalizzazione di mercato", "Liquidity" to "Liquidità", "Trend" to "Tendenza", "Buy" to "Compra", "Sell" to "Vendi", "Bullish" to "Rialzista", "Bearish" to "Ribassista", "Timeframe" to "Intervallo temporale", "Last close" to "Ultima chiusura", "Signal" to "Segnale", "History" to "Storico", "Risk/Reward" to "Rischio/rendimento", "Take profit" to "Presa di profitto", "Stop loss" to "Stop-loss", "Entry price" to "Prezzo d’ingresso", "Current price" to "Prezzo attuale", "High" to "Massimo", "Low" to "Minimo", "Support" to "Supporto", "Resistance" to "Resistenza", "Momentum" to "Momentum", "Moving averages" to "Medie mobili", "Bullish score" to "Punteggio rialzista", "Bearish score" to "Punteggio ribassista"
    ),
    "zh" to mapOf(
        "Aggressive entry" to "激进入场", "Breakout-confirmation entry" to "突破确认后入场", "More conservative entry" to "更稳健的入场",
        "Near support; higher risk. Prefer a visible support reaction." to "接近支撑位，风险较高。优先等待支撑位出现明确反应。", "Trigger only after a candle closes above resistance; a retest is preferable." to "仅在K线收于阻力位上方后触发；最好等待回踩确认。", "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "等待价格更有力地突破阻力位并确认成交量；入场价格可能更高。",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "同时显示三种情景。价位依据4小时支撑位和阻力位。TP1–TP3是按止损距离计算的示例目标1R/2R/3R，并非保证结果。", "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "风险提示：这些是分析参考价位，并非实时订单。突破入场需要确认；波动剧烈时止损单可能出现滑点。", "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "交易价位不可用：支撑位/阻力位数据不足以制定计划。",
        "ABOVE" to "高于", "BELOW" to "低于", "Spot" to "现货", "USDT Futures" to "USDT合约", "Entry / trigger" to "入场价 / 触发条件", "Stop loss (SL)" to "止损 (SL)", "TAKE PROFIT" to "止盈", "Volume" to "成交量", "Price" to "价格", "Change" to "涨跌幅", "Market cap" to "市值", "Liquidity" to "流动性", "Trend" to "趋势", "Buy" to "买入", "Sell" to "卖出", "Bullish" to "看涨", "Bearish" to "看跌", "Timeframe" to "时间周期", "Last close" to "最新收盘价", "Signal" to "信号", "History" to "历史", "Risk/Reward" to "风险/回报", "Take profit" to "止盈", "Stop loss" to "止损", "Entry price" to "入场价", "Current price" to "当前价格", "High" to "最高", "Low" to "最低", "Support" to "支撑位", "Resistance" to "阻力位", "Momentum" to "动量", "Moving averages" to "移动平均线", "Bullish score" to "看涨评分", "Bearish score" to "看跌评分"
    ),
    "ja" to mapOf(
        "Aggressive entry" to "積極的なエントリー", "Breakout-confirmation entry" to "ブレイク確認後のエントリー", "More conservative entry" to "より慎重なエントリー",
        "Near support; higher risk. Prefer a visible support reaction." to "サポート付近でリスクは高め。サポートで明確な反発を確認するのが望ましいです。", "Trigger only after a candle closes above resistance; a retest is preferable." to "ローソク足がレジスタンスを上抜けて確定した後にのみ実行し、再テストを待つのが望ましいです。", "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "レジスタンスを明確に上抜け、出来高を確認してから判断します。エントリー価格は高くなる可能性があります。",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "3つのシナリオをまとめて表示します。価格水準は4時間足のサポートとレジスタンスに基づきます。TP1～TP3は損切り幅に基づく1R/2R/3Rの参考目標で、結果を保証するものではありません。", "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "リスク：これらは分析上の参考水準であり、実際の注文ではありません。ブレイクアウトには確認が必要で、相場急変時は損切り注文にスリッページが生じる場合があります。", "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "取引水準を表示できません。サポート／レジスタンスのデータが計画作成に十分ではありません。",
        "ABOVE" to "上回る", "BELOW" to "下回る", "Spot" to "現物", "USDT Futures" to "USDT先物", "Entry / trigger" to "エントリー / 発動条件", "Stop loss (SL)" to "損切り (SL)", "TAKE PROFIT" to "利確", "Volume" to "出来高", "Price" to "価格", "Change" to "変動率", "Market cap" to "時価総額", "Liquidity" to "流動性", "Trend" to "トレンド", "Buy" to "買い", "Sell" to "売り", "Bullish" to "強気", "Bearish" to "弱気", "Timeframe" to "時間足", "Last close" to "直近終値", "Signal" to "シグナル", "History" to "履歴", "Risk/Reward" to "リスク／リワード", "Take profit" to "利確", "Stop loss" to "損切り", "Entry price" to "エントリー価格", "Current price" to "現在価格", "High" to "高値", "Low" to "安値", "Support" to "サポート", "Resistance" to "レジスタンス", "Momentum" to "モメンタム", "Moving averages" to "移動平均線", "Bullish score" to "強気スコア", "Bearish score" to "弱気スコア"
    ),
    "ko" to mapOf(
        "Aggressive entry" to "공격적 진입", "Breakout-confirmation entry" to "돌파 확인 후 진입", "More conservative entry" to "더 보수적인 진입",
        "Near support; higher risk. Prefer a visible support reaction." to "지지선 부근으로 위험이 더 큽니다. 지지선의 뚜렷한 반응을 확인하는 것이 좋습니다.", "Trigger only after a candle closes above resistance; a retest is preferable." to "캔들이 저항선 위에서 마감된 후에만 실행하고, 재테스트를 기다리는 것이 좋습니다.", "Wait for a stronger move above resistance and confirm volume; entry may be higher." to "저항선을 강하게 돌파하고 거래량을 확인하세요. 진입 가격은 더 높을 수 있습니다.",
        "All three scenarios are shown together. Levels use the 4H support/resistance range. TP1–TP3 are illustrative 1R/2R/3R targets from each stop distance; they are not guaranteed outcomes." to "세 가지 시나리오를 함께 표시합니다. 가격 수준은 4시간봉 지지선과 저항선을 사용합니다. TP1–TP3는 손절 거리 기준의 예시 목표 1R/2R/3R이며 보장된 결과가 아닙니다.", "Risk note: these are analytical reference levels, not live orders. Breakout entries require confirmation; stop orders may slip during volatility." to "위험 안내: 이 가격은 분석 참고값이며 실제 주문이 아닙니다. 돌파 진입은 확인이 필요하며 변동성이 클 때 손절 주문에 슬리피지가 발생할 수 있습니다.", "Trade levels unavailable: support/resistance data is not valid enough to build a plan." to "거래 수준을 사용할 수 없습니다. 지지선/저항선 데이터가 계획을 세우기에 충분하지 않습니다.",
        "ABOVE" to "상회", "BELOW" to "하회", "Spot" to "현물", "USDT Futures" to "USDT 선물", "Entry / trigger" to "진입 / 발동 조건", "Stop loss (SL)" to "손절 (SL)", "TAKE PROFIT" to "익절", "Volume" to "거래량", "Price" to "가격", "Change" to "변동", "Market cap" to "시가총액", "Liquidity" to "유동성", "Trend" to "추세", "Buy" to "매수", "Sell" to "매도", "Bullish" to "강세", "Bearish" to "약세", "Timeframe" to "시간 프레임", "Last close" to "최근 종가", "Signal" to "신호", "History" to "기록", "Risk/Reward" to "위험/보상", "Take profit" to "익절", "Stop loss" to "손절", "Entry price" to "진입 가격", "Current price" to "현재 가격", "High" to "고가", "Low" to "저가", "Support" to "지지선", "Resistance" to "저항선", "Momentum" to "모멘텀", "Moving averages" to "이동평균", "Bullish score" to "상승 점수", "Bearish score" to "하락 점수"
    )
)

private val tradingSectionTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf("TECHNICAL OVERVIEW" to "VUE TECHNIQUE", "Signals across three timeframes" to "Signaux sur trois unités de temps", "Signal interpretation" to "Interprétation des signaux", "Scores are heuristic signals, not calibrated probabilities." to "Les scores sont des indicateurs heuristiques, pas des probabilités calibrées.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "Référence pédagogique uniquement. Les frais, le glissement, le financement, la liquidation et la taille de position ne sont pas modélisés.", "BACKTEST LAB" to "LABORATOIRE DE BACKTEST", "PROJECT RESEARCH" to "RECHERCHE SUR LE PROJET", "Fundamentals & investors" to "Fondamentaux et investisseurs"),
    "ar" to mapOf("TECHNICAL OVERVIEW" to "نظرة عامة فنية", "Signals across three timeframes" to "الإشارات عبر ثلاثة أطر زمنية", "Signal interpretation" to "تفسير الإشارات", "Scores are heuristic signals, not calibrated probabilities." to "الدرجات إشارات تقديرية وليست احتمالات محسوبة بدقة.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "لأغراض تعليمية فقط. لا يشمل الحساب الرسوم والانزلاق والتمويل والتصفية وتحديد حجم الصفقة.", "BACKTEST LAB" to "مختبر الاختبار التاريخي", "PROJECT RESEARCH" to "بحث المشروع", "Fundamentals & investors" to "الأساسيات والمستثمرون"),
    "es" to mapOf("TECHNICAL OVERVIEW" to "RESUMEN TÉCNICO", "Signals across three timeframes" to "Señales en tres marcos temporales", "Signal interpretation" to "Interpretación de señales", "Scores are heuristic signals, not calibrated probabilities." to "Las puntuaciones son señales heurísticas, no probabilidades calibradas.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "Solo referencia educativa. No se modelan comisiones, deslizamiento, financiación, liquidación ni tamaño de posición.", "BACKTEST LAB" to "LABORATORIO DE BACKTEST", "PROJECT RESEARCH" to "INVESTIGACIÓN DEL PROYECTO", "Fundamentals & investors" to "Fundamentos e inversores"),
    "de" to mapOf("TECHNICAL OVERVIEW" to "TECHNISCHER ÜBERBLICK", "Signals across three timeframes" to "Signale über drei Zeitrahmen", "Signal interpretation" to "Signalinterpretation", "Scores are heuristic signals, not calibrated probabilities." to "Die Werte sind heuristische Signale, keine kalibrierten Wahrscheinlichkeiten.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "Nur eine Lernreferenz. Gebühren, Slippage, Finanzierung, Liquidation und Positionsgröße werden nicht modelliert.", "BACKTEST LAB" to "BACKTEST-LABOR", "PROJECT RESEARCH" to "PROJEKTRECHERCHE", "Fundamentals & investors" to "Fundamentaldaten und Investoren"),
    "it" to mapOf("TECHNICAL OVERVIEW" to "PANORAMICA TECNICA", "Signals across three timeframes" to "Segnali su tre intervalli temporali", "Signal interpretation" to "Interpretazione del segnale", "Scores are heuristic signals, not calibrated probabilities." to "I punteggi sono segnali euristici, non probabilità calibrate.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "Solo riferimento didattico. Commissioni, slippage, funding, liquidazione e dimensionamento della posizione non sono modellati.", "BACKTEST LAB" to "LABORATORIO BACKTEST", "PROJECT RESEARCH" to "RICERCA SUL PROGETTO", "Fundamentals & investors" to "Fondamentali e investitori"),
    "zh" to mapOf("TECHNICAL OVERVIEW" to "技术概览", "Signals across three timeframes" to "三个时间周期的信号", "Signal interpretation" to "信号解读", "Scores are heuristic signals, not calibrated probabilities." to "评分是启发式信号，并非经过校准的概率。", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "仅供学习参考。未计入手续费、滑点、资金费用、强平和仓位大小。", "BACKTEST LAB" to "回测实验室", "PROJECT RESEARCH" to "项目研究", "Fundamentals & investors" to "基本面与投资者"),
    "ja" to mapOf("TECHNICAL OVERVIEW" to "テクニカル概要", "Signals across three timeframes" to "3つの時間足のシグナル", "Signal interpretation" to "シグナルの解釈", "Scores are heuristic signals, not calibrated probabilities." to "スコアは経験則に基づくシグナルであり、較正済みの確率ではありません。", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "学習用の基準値です。手数料、スリッページ、資金調達料、清算、ポジションサイズは計算に含まれません。", "BACKTEST LAB" to "バックテストラボ", "PROJECT RESEARCH" to "プロジェクト調査", "Fundamentals & investors" to "ファンダメンタルズと投資家"),
    "ko" to mapOf("TECHNICAL OVERVIEW" to "기술적 분석 개요", "Signals across three timeframes" to "세 가지 시간 프레임의 신호", "Signal interpretation" to "신호 해석", "Scores are heuristic signals, not calibrated probabilities." to "점수는 휴리스틱 신호이며 보정된 확률이 아닙니다.", "Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled." to "교육용 기준값입니다. 수수료, 슬리피지, 펀딩, 청산 및 포지션 규모는 계산하지 않습니다.", "BACKTEST LAB" to "백테스트 실험실", "PROJECT RESEARCH" to "프로젝트 조사", "Fundamentals & investors" to "펀더멘털 및 투자자")
)

private val indicatorTermTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf("EMA" to "EMA (moyenne mobile exponentielle)", "RSI" to "RSI (indice de force relative)", "MACD" to "MACD (convergence/divergence des moyennes mobiles)", "OBV" to "OBV (volume en équilibre)", "Hist" to "Histogramme", "LONG" to "ACHAT", "SHORT" to "VENTE À DÉCOUVERT", "TP1" to "Objectif 1 (TP1)", "TP2" to "Objectif 2 (TP2)", "TP3" to "Objectif 3 (TP3)"),
    "ar" to mapOf("EMA" to "EMA (المتوسط المتحرك الأسي)", "RSI" to "RSI (مؤشر القوة النسبية)", "MACD" to "MACD (تقارب وتباعد المتوسطات المتحركة)", "OBV" to "OBV (حجم التداول التراكمي)", "Hist" to "المدرج التكراري", "LONG" to "شراء", "SHORT" to "بيع على المكشوف", "TP1" to "هدف الربح الأول (TP1)", "TP2" to "هدف الربح الثاني (TP2)", "TP3" to "هدف الربح الثالث (TP3)"),
    "es" to mapOf("EMA" to "EMA (media móvil exponencial)", "RSI" to "RSI (índice de fuerza relativa)", "MACD" to "MACD (convergencia/divergencia de medias móviles)", "OBV" to "OBV (volumen en balance)", "Hist" to "Histograma", "LONG" to "COMPRA", "SHORT" to "VENTA EN CORTO", "TP1" to "Objetivo 1 (TP1)", "TP2" to "Objetivo 2 (TP2)", "TP3" to "Objetivo 3 (TP3)"),
    "de" to mapOf("EMA" to "EMA (exponentieller gleitender Durchschnitt)", "RSI" to "RSI (Relative-Stärke-Index)", "MACD" to "MACD (Konvergenz/Divergenz gleitender Durchschnitte)", "OBV" to "OBV (On-Balance-Volumen)", "Hist" to "Histogramm", "LONG" to "KAUF", "SHORT" to "LEERVERKAUF", "TP1" to "Kursziel 1 (TP1)", "TP2" to "Kursziel 2 (TP2)", "TP3" to "Kursziel 3 (TP3)"),
    "it" to mapOf("EMA" to "EMA (media mobile esponenziale)", "RSI" to "RSI (indice di forza relativa)", "MACD" to "MACD (convergenza/divergenza delle medie mobili)", "OBV" to "OBV (volume cumulativo)", "Hist" to "Istogramma", "LONG" to "ACQUISTO", "SHORT" to "VENDITA ALLO SCOPERTO", "TP1" to "Obiettivo 1 (TP1)", "TP2" to "Obiettivo 2 (TP2)", "TP3" to "Obiettivo 3 (TP3)"),
    "zh" to mapOf("EMA" to "EMA（指数移动平均线）", "RSI" to "RSI（相对强弱指标）", "MACD" to "MACD（移动平均线收敛发散）", "OBV" to "OBV（能量潮指标）", "Hist" to "柱状图", "LONG" to "做多", "SHORT" to "做空", "TP1" to "第一止盈目标（TP1）", "TP2" to "第二止盈目标（TP2）", "TP3" to "第三止盈目标（TP3）"),
    "ja" to mapOf("EMA" to "EMA（指数移動平均線）", "RSI" to "RSI（相対力指数）", "MACD" to "MACD（移動平均収束拡散）", "OBV" to "OBV（オンバランスボリューム）", "Hist" to "ヒストグラム", "LONG" to "買い", "SHORT" to "空売り", "TP1" to "第1利確目標（TP1）", "TP2" to "第2利確目標（TP2）", "TP3" to "第3利確目標（TP3）"),
    "ko" to mapOf("EMA" to "EMA(지수이동평균)", "RSI" to "RSI(상대강도지수)", "MACD" to "MACD(이동평균 수렴확산)", "OBV" to "OBV(누적 거래량 지표)", "Hist" to "히스토그램", "LONG" to "매수", "SHORT" to "공매도", "TP1" to "1차 익절 목표(TP1)", "TP2" to "2차 익절 목표(TP2)", "TP3" to "3차 익절 목표(TP3)")
)

private val setupTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "Biais haussier ; attendez un repli ou un retest avant d’envisager une position acheteuse ou une entrée au comptant.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "Biais baissier ; vente à découvert uniquement après confirmation ; évitez de poursuivre une baisse.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "Signaux mitigés ; attendez une cassure confirmée ou un rejet du support."
    ),
    "ar" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "الاتجاه يميل للصعود؛ انتظر تراجعًا أو إعادة اختبار قبل التفكير في صفقة شراء أو دخول في السوق الفوري.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "الاتجاه يميل للهبوط؛ لا تدخل صفقة بيع على المكشوف إلا بعد التأكيد، وتجنب مطاردة الهبوط.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "الإشارات متضاربة؛ انتظر اختراقًا مؤكدًا أو رفضًا واضحًا لمستوى الدعم."
    ),
    "es" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "Sesgo alcista; espera un retroceso o retesteo antes de considerar una posición larga o una entrada al contado.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "Sesgo bajista; abre cortos solo tras confirmación y evita perseguir la caída.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "Señales mixtas; espera una ruptura confirmada o un rechazo del soporte."
    ),
    "de" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "Aufwärtstendenz; vor einem Long- oder Spot-Einstieg einen Rücksetzer oder Retest abwarten.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "Abwärtstendenz; Short nur nach Bestätigung und nicht einer fallenden Bewegung hinterherlaufen.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "Gemischte Signale; einen bestätigten Ausbruch oder eine Zurückweisung der Unterstützung abwarten."
    ),
    "it" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "Orientamento rialzista; attendere un ritracciamento o un retest prima di valutare una posizione long o un ingresso spot.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "Orientamento ribassista; aprire short solo dopo conferma ed evitare di inseguire il ribasso.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "Segnali contrastanti; attendere una rottura confermata o un rifiuto del supporto."
    ),
    "zh" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "偏多趋势；考虑做多或现货入场前，先等待回调或回踩确认。",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "偏空趋势；确认后再考虑做空，避免追跌。",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "信号混杂；等待有效突破或支撑位拒绝下跌的确认。"
    ),
    "ja" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "強気傾向です。ロングまたは現物でのエントリーを検討する前に、押し目や再テストを待ってください。",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "弱気傾向です。確認後にのみショートを検討し、下落を追いかけないでください。",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "シグナルは混在しています。ブレイクアウトの確認、またはサポートでの反発拒否を待ってください。"
    ),
    "ko" to mapOf(
        "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry." to "상승 우세입니다. 롱 또는 현물 진입을 고려하기 전에 되돌림이나 재테스트를 기다리세요.",
        "Bearish bias; SHORT only after confirmation; avoid chasing a drop." to "하락 우세입니다. 확인 후에만 숏을 고려하고 하락을 추격하지 마세요.",
        "Mixed signals; wait for a confirmed breakout or support rejection." to "신호가 혼재되어 있습니다. 확인된 돌파 또는 지지선 반응을 기다리세요."
    )
)

private fun translateBacktestSummary(text: String, language: String): String? {
    val match = Regex("EMA 9/21 crossover on (.+?) · (\\d+) candles · (\\d+) closed trades · return (.+?) · win rate (.+?) \\(fees/slippage excluded; not a forecast\\)\\.").matchEntire(text) ?: return null
    val tf = match.groupValues[1]
    val candles = match.groupValues[2]
    val trades = match.groupValues[3]
    val returns = match.groupValues[4]
    val winRate = match.groupValues[5]
    return when (language) {
        "fr" -> "Croisement EMA 9/21 sur $tf · $candles bougies · $trades trades clôturés · rendement $returns · taux de réussite $winRate (frais et glissement exclus ; ce n’est pas une prévision)."
        "ar" -> "تقاطع EMA 9/21 على إطار $tf · عدد الشموع $candles · الصفقات المغلقة $trades · العائد $returns · نسبة النجاح $winRate (لا تشمل الرسوم والانزلاق السعري؛ وليست توقعًا)."
        "es" -> "Cruce EMA 9/21 en $tf · $candles velas · $trades operaciones cerradas · rendimiento $returns · tasa de acierto $winRate (sin comisiones ni deslizamiento; no es una previsión)."
        "de" -> "EMA-9/21-Kreuzung auf $tf · $candles Kerzen · $trades geschlossene Trades · Rendite $returns · Trefferquote $winRate (Gebühren und Slippage nicht enthalten; keine Prognose)."
        "it" -> "Incrocio EMA 9/21 su $tf · $candles candele · $trades operazioni chiuse · rendimento $returns · percentuale di successo $winRate (commissioni e slippage esclusi; non è una previsione)."
        "zh" -> "$tf 周期 EMA 9/21 交叉 · $candles 根K线 · $trades 笔已平仓交易 · 回报 $returns · 胜率 $winRate（未计手续费和滑点；不构成预测）。"
        "ja" -> "$tf の EMA 9/21 クロス · ローソク足 $candles 本 · 決済済み取引 $trades 件 · リターン $returns · 勝率 $winRate（手数料とスリッページを除外。予測ではありません）。"
        "ko" -> "$tf EMA 9/21 교차 · 캔들 ${candles}개 · 종료 거래 ${trades}건 · 수익률 $returns · 승률 $winRate (수수료와 슬리피지 제외, 예측이 아닙니다)."
        else -> text
    }
}

private val featureTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf("Price alerts" to "Alertes de prix", "Favorites" to "Favoris", "Movement signals are monitored for recent searches, favorites, and price-alert pairs on both Bitget and Binance." to "Les signaux sont surveillés pour les recherches récentes, les favoris et les paires en alerte sur Bitget et Binance.", "Coin news" to "Actualités de la crypto", "Show section" to "Afficher la section", "Hide section" to "Masquer la section", "Add current pair to favorites" to "Ajouter la paire aux favoris", "Remove from favorites" to "Retirer des favoris", "Add price alert" to "Ajouter une alerte de prix", "Alert condition" to "Condition de l’alerte", "When price is above" to "Lorsque le prix dépasse", "When price is below" to "Lorsque le prix passe sous", "Target price" to "Prix cible", "Save" to "Enregistrer", "Edit" to "Modifier", "Delete" to "Supprimer", "Cancel" to "Annuler", "No price alerts yet" to "Aucune alerte de prix", "No favorites yet" to "Aucun favori", "Notifications require permission" to "Les notifications nécessitent une autorisation", "Alert saved" to "Alerte enregistrée", "Price alert triggered" to "Alerte de prix déclenchée", "Spot" to "Spot", "USDT Futures" to "Contrats à terme USDT", "ABOVE" to "AU-DESSUS", "BELOW" to "EN-DESSOUS", "Edit alert" to "Modifier l’alerte", "Recently analyzed" to "Analyses récentes", "Token unlocks" to "Déverrouillages de tokens", "Unlocks are not verified" to "Les déverrouillages ne sont pas vérifiés", "Open unlock sources" to "Consulter les sources de déverrouillage", "Search Tokenomist" to "Rechercher sur Tokenomist", "Search CryptoRank" to "Rechercher sur CryptoRank", "Search official announcements" to "Rechercher les annonces officielles", "Based on available history" to "Selon l’historique disponible", "Historical data is incomplete" to "Les données historiques sont incomplètes", "Date" to "Date", "Quantity" to "Quantité", "% supply" to "% de l’offre", "Time remaining" to "Temps restant", "Recipient" to "Bénéficiaire", "Source" to "Source", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "Aucun calendrier de déverrouillage vérifié dans cette version. Aucune date ni quantité n’est inventée."),
    "ar" to mapOf("Price alerts" to "تنبيهات الأسعار", "Favorites" to "المفضلة", "Movement signals are monitored for recent searches, favorites, and price-alert pairs on both Bitget and Binance." to "تتم مراقبة إشارات الحركة لعمليات البحث الأخيرة والعملات المفضلة وأزواج التنبيه على منصتي Bitget وBinance.", "Coin news" to "أخبار العملة", "Show section" to "إظهار القسم", "Hide section" to "إخفاء القسم", "Add current pair to favorites" to "إضافة الزوج الحالي إلى المفضلة", "Remove from favorites" to "إزالة من المفضلة", "Add price alert" to "إضافة تنبيه سعري", "Alert condition" to "شرط التنبيه", "When price is above" to "عندما يتجاوز السعر", "When price is below" to "عندما ينخفض السعر عن", "Target price" to "السعر المستهدف", "Save" to "حفظ", "Edit" to "تعديل", "Delete" to "حذف", "Cancel" to "إلغاء", "No price alerts yet" to "لا توجد تنبيهات أسعار بعد", "No favorites yet" to "لا توجد عملات مفضلة بعد", "Notifications require permission" to "تتطلب الإشعارات إذنًا", "Alert saved" to "تم حفظ التنبيه", "Price alert triggered" to "تم تفعيل تنبيه السعر", "Spot" to "فوري", "USDT Futures" to "عقود USDT الآجلة", "ABOVE" to "أعلى من", "BELOW" to "أقل من", "Edit alert" to "تعديل التنبيه", "Recently analyzed" to "العملات التي تم تحليلها مؤخرًا", "Token unlocks" to "فتح قفل التوكنات", "Unlocks are not verified" to "بيانات فتح القفل غير مؤكدة", "Open unlock sources" to "فتح مصادر مواعيد فك القفل", "Search Tokenomist" to "البحث في Tokenomist", "Search CryptoRank" to "البحث في CryptoRank", "Search official announcements" to "البحث عن الإعلانات الرسمية", "Based on available history" to "حسب السجل التاريخي المتاح", "Historical data is incomplete" to "البيانات التاريخية غير مكتملة", "Date" to "التاريخ", "Quantity" to "الكمية", "% supply" to "٪ من المعروض", "Time remaining" to "الوقت المتبقي", "Recipient" to "المستفيد", "Source" to "المصدر", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "لا يتوفر جدول فتح قفل موثوق في هذه النسخة. لن نخمن التواريخ أو الكميات."),
    "es" to mapOf("Price alerts" to "Alertas de precio", "Favorites" to "Favoritos", "Coin news" to "Noticias de la criptomoneda", "Show section" to "Mostrar sección", "Hide section" to "Ocultar sección", "Add current pair to favorites" to "Añadir el par actual a favoritos", "Remove from favorites" to "Quitar de favoritos", "Add price alert" to "Añadir alerta de precio", "Alert condition" to "Condición de alerta", "When price is above" to "Cuando el precio supere", "When price is below" to "Cuando el precio baje de", "Target price" to "Precio objetivo", "Save" to "Guardar", "Edit" to "Editar", "Delete" to "Eliminar", "Cancel" to "Cancelar", "No price alerts yet" to "Aún no hay alertas", "No favorites yet" to "Aún no hay favoritos", "Notifications require permission" to "Las notificaciones requieren permiso", "Alert saved" to "Alerta guardada", "Price alert triggered" to "Alerta de precio activada", "Spot" to "Spot", "USDT Futures" to "Futuros USDT", "ABOVE" to "POR ENCIMA", "BELOW" to "POR DEBAJO", "Edit alert" to "Editar alerta"),
    "de" to mapOf("Price alerts" to "Preisalarme", "Favorites" to "Favoriten", "Coin news" to "Krypto-Nachrichten", "Show section" to "Bereich anzeigen", "Hide section" to "Bereich ausblenden", "Add current pair to favorites" to "Aktuelles Handelspaar zu Favoriten hinzufügen", "Remove from favorites" to "Aus Favoriten entfernen", "Add price alert" to "Preisalarm hinzufügen", "Alert condition" to "Alarmbedingung", "When price is above" to "Wenn der Preis über", "When price is below" to "Wenn der Preis unter", "Target price" to "Zielpreis", "Save" to "Speichern", "Edit" to "Bearbeiten", "Delete" to "Löschen", "Cancel" to "Abbrechen", "No price alerts yet" to "Noch keine Preisalarme", "No favorites yet" to "Noch keine Favoriten", "Notifications require permission" to "Benachrichtigungen benötigen eine Berechtigung", "Alert saved" to "Alarm gespeichert", "Price alert triggered" to "Preisalarm ausgelöst", "Spot" to "Spot", "USDT Futures" to "USDT-Futures", "ABOVE" to "ÜBER", "BELOW" to "UNTER", "Edit alert" to "Alarm bearbeiten"),
    "it" to mapOf("Price alerts" to "Avvisi di prezzo", "Favorites" to "Preferiti", "Coin news" to "Notizie sulla criptovaluta", "Show section" to "Mostra sezione", "Hide section" to "Nascondi sezione", "Add current pair to favorites" to "Aggiungi la coppia ai preferiti", "Remove from favorites" to "Rimuovi dai preferiti", "Add price alert" to "Aggiungi avviso di prezzo", "Alert condition" to "Condizione avviso", "When price is above" to "Quando il prezzo supera", "When price is below" to "Quando il prezzo scende sotto", "Target price" to "Prezzo obiettivo", "Save" to "Salva", "Edit" to "Modifica", "Delete" to "Elimina", "Cancel" to "Annulla", "No price alerts yet" to "Nessun avviso di prezzo", "No favorites yet" to "Nessun preferito", "Notifications require permission" to "Le notifiche richiedono un’autorizzazione", "Alert saved" to "Avviso salvato", "Price alert triggered" to "Avviso di prezzo attivato", "Spot" to "Spot", "USDT Futures" to "Futures USDT", "ABOVE" to "SOPRA", "BELOW" to "SOTTO", "Edit alert" to "Modifica avviso"),
    "zh" to mapOf("Price alerts" to "价格提醒", "Favorites" to "收藏", "Coin news" to "币种新闻", "Show section" to "展开此部分", "Hide section" to "收起此部分", "Add current pair to favorites" to "收藏当前交易对", "Remove from favorites" to "取消收藏", "Add price alert" to "添加价格提醒", "Alert condition" to "提醒条件", "When price is above" to "价格高于时", "When price is below" to "价格低于时", "Target price" to "目标价格", "Save" to "保存", "Edit" to "编辑", "Delete" to "删除", "Cancel" to "取消", "No price alerts yet" to "暂无价格提醒", "No favorites yet" to "暂无收藏", "Notifications require permission" to "通知需要权限", "Alert saved" to "提醒已保存", "Price alert triggered" to "价格提醒已触发", "Spot" to "现货", "USDT Futures" to "USDT合约", "ABOVE" to "高于", "BELOW" to "低于", "Edit alert" to "编辑提醒"),
    "ja" to mapOf("Price alerts" to "価格アラート", "Favorites" to "お気に入り", "Coin news" to "銘柄ニュース", "Show section" to "セクションを表示", "Hide section" to "セクションを折りたたむ", "Add current pair to favorites" to "現在の取引ペアをお気に入りに追加", "Remove from favorites" to "お気に入りから削除", "Add price alert" to "価格アラートを追加", "Alert condition" to "アラート条件", "When price is above" to "価格が次を上回ったとき", "When price is below" to "価格が次を下回ったとき", "Target price" to "目標価格", "Save" to "保存", "Edit" to "編集", "Delete" to "削除", "Cancel" to "キャンセル", "No price alerts yet" to "価格アラートはありません", "No favorites yet" to "お気に入りはありません", "Notifications require permission" to "通知には許可が必要です", "Alert saved" to "アラートを保存しました", "Price alert triggered" to "価格アラートが発動しました", "Spot" to "現物", "USDT Futures" to "USDT先物", "ABOVE" to "上回る", "BELOW" to "下回る", "Edit alert" to "アラートを編集"),
    "ko" to mapOf("Price alerts" to "가격 알림", "Favorites" to "즐겨찾기", "Coin news" to "코인 뉴스", "Show section" to "섹션 펼치기", "Hide section" to "섹션 접기", "Add current pair to favorites" to "현재 거래쌍 즐겨찾기에 추가", "Remove from favorites" to "즐겨찾기에서 제거", "Add price alert" to "가격 알림 추가", "Alert condition" to "알림 조건", "When price is above" to "가격이 다음보다 높을 때", "When price is below" to "가격이 다음보다 낮을 때", "Target price" to "목표 가격", "Save" to "저장", "Edit" to "수정", "Delete" to "삭제", "Cancel" to "취소", "No price alerts yet" to "가격 알림이 없습니다", "No favorites yet" to "즐겨찾기가 없습니다", "Notifications require permission" to "알림 권한이 필요합니다", "Alert saved" to "알림이 저장되었습니다", "Price alert triggered" to "가격 알림이 발생했습니다", "Spot" to "현물", "USDT Futures" to "USDT 선물", "ABOVE" to "초과", "BELOW" to "미만", "Edit alert" to "알림 수정")
)

private val commonFeatureTextTranslations: Map<String, Map<String, String>> = mapOf(
    "fr" to mapOf("Run a market analysis to view price information." to "Lancez une analyse du marché pour afficher les informations de prix.", "Les actualités affichées concernent uniquement la crypto sélectionnée." to "Les actualités affichées concernent uniquement la crypto sélectionnée.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente.", "Futures" to "Contrats à terme"),
    "ar" to mapOf("Run a market analysis to view price information." to "ابدأ تحليل السوق لعرض معلومات السعر.", "Les actualités affichées concernent uniquement la crypto sélectionnée." to "تُعرض فقط الأخبار المرتبطة بالعملة التي اخترتها.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "مصادر RSS عامة · العناوين والملخصات للمعلومات فقط وليست إشارات شراء أو بيع.", "Futures" to "العقود الآجلة"),
    "es" to mapOf("Run a market analysis to view price information." to "Ejecuta un análisis de mercado para ver la información de precios.", "Les actualités affichées concernent uniquement la crypto sélectionnée." to "Solo se muestran noticias relacionadas con la criptomoneda seleccionada.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "Fuentes RSS públicas · los títulos y resúmenes son informativos, no señales de compra/venta.", "Futures" to "Futuros"),
    "de" to mapOf("Run a market analysis to view price information." to "Führe eine Marktanalyse aus, um Preisinformationen anzuzeigen.", "Les actualités affichées concernent uniquement la crypto sélectionnée." to "Es werden nur Nachrichten zur ausgewählten Kryptowährung angezeigt.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "Öffentliche RSS-Quellen · Titel und Zusammenfassungen dienen der Information und sind keine Kauf-/Verkaufssignale.", "Futures" to "Futures"),
    "it" to mapOf("Run a market analysis to view price information." to "Avvia un’analisi di mercato per visualizzare le informazioni sui prezzi.", "Les actualités affichées concernent uniquement la crypto sélectionnée." to "Sono mostrate solo notizie relative alla criptovaluta selezionata.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "Fonti RSS pubbliche · titoli e riepiloghi sono informativi, non segnali di acquisto/vendita.", "Futures" to "Futures"),
    "zh" to mapOf("Run a market analysis to view price information." to "请运行市场分析以查看价格信息。", "Les actualités affichées concernent uniquement la crypto sélectionnée." to "仅显示与所选加密货币相关的新闻。", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "公开 RSS 来源 · 标题和摘要仅供参考，不构成买卖信号。", "Futures" to "合约"),
    "ja" to mapOf("Run a market analysis to view price information." to "価格情報を表示するには市場分析を実行してください。", "Les actualités affichées concernent uniquement la crypto sélectionnée." to "選択した暗号資産に関連するニュースのみを表示します。", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "公開RSSソース · 見出しと要約は情報提供のみで、売買シグナルではありません。", "Futures" to "先物"),
    "ko" to mapOf("Run a market analysis to view price information." to "가격 정보를 보려면 시장 분석을 실행하세요.", "Les actualités affichées concernent uniquement la crypto sélectionnée." to "선택한 암호화폐와 관련된 뉴스만 표시합니다.", "Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente." to "공개 RSS 출처 · 제목과 요약은 정보 제공용이며 매수/매도 신호가 아닙니다.", "Futures" to "선물")
)

private val unlockUiTranslations = mapOf(
    "es" to mapOf("Recently analyzed" to "Analizadas recientemente", "Token unlocks" to "Desbloqueos de tokens", "Unlocks are not verified" to "Los desbloqueos no están verificados", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "Esta versión no tiene acceso autenticado a una base completa de desbloqueos. No inventará fechas ni cantidades. Consulta estas fuentes y verifica el token antes de confiar en un calendario.", "Search Tokenomist" to "Buscar en Tokenomist", "Search CryptoRank" to "Buscar en CryptoRank", "Search official announcements" to "Buscar anuncios oficiales", "Date" to "Fecha", "Quantity" to "Cantidad", "% supply" to "% del suministro", "Time remaining" to "Tiempo restante", "Recipient" to "Destinatario", "Source" to "Fuente", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "No hay un calendario de desbloqueos verificado en esta versión. No se inventan fechas ni cantidades."),
    "de" to mapOf("Recently analyzed" to "Zuletzt analysiert", "Token unlocks" to "Token-Freischaltungen", "Unlocks are not verified" to "Freischaltungen sind nicht verifiziert", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "Diese App-Version hat keinen authentifizierten Zugriff auf eine vollständige Token-Freischaltungsdatenbank. Sie erfindet keine Daten oder Mengen. Bitte Quellen öffnen und den Token prüfen.", "Search Tokenomist" to "Tokenomist durchsuchen", "Search CryptoRank" to "CryptoRank durchsuchen", "Search official announcements" to "Offizielle Ankündigungen suchen", "Date" to "Datum", "Quantity" to "Menge", "% supply" to "% des Angebots", "Time remaining" to "Verbleibende Zeit", "Recipient" to "Empfänger", "Source" to "Quelle", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "In dieser Version ist kein verifizierter Freischaltungsplan verfügbar. Daten und Mengen werden nicht erfunden."),
    "it" to mapOf("Recently analyzed" to "Analizzate di recente", "Token unlocks" to "Sblocco dei token", "Unlocks are not verified" to "Gli sblocchi non sono verificati", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "Questa versione non ha accesso autenticato a un database completo degli sblocchi. Non inventa date o quantità. Apri le fonti e verifica il token prima di fare affidamento sul calendario.", "Search Tokenomist" to "Cerca su Tokenomist", "Search CryptoRank" to "Cerca su CryptoRank", "Search official announcements" to "Cerca annunci ufficiali", "Date" to "Data", "Quantity" to "Quantità", "% supply" to "% dell’offerta", "Time remaining" to "Tempo rimanente", "Recipient" to "Destinatario", "Source" to "Fonte", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "In questa versione non è disponibile un calendario di sblocco verificato. Date e quantità non vengono inventate."),
    "zh" to mapOf("Recently analyzed" to "最近分析", "Token unlocks" to "代币解锁", "Unlocks are not verified" to "解锁信息尚未验证", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "此版本无法通过认证访问完整的代币解锁数据集，因此不会编造日期或数量。请打开来源并核实代币后再参考解锁计划。", "Search Tokenomist" to "搜索 Tokenomist", "Search CryptoRank" to "搜索 CryptoRank", "Search official announcements" to "搜索官方公告", "Date" to "日期", "Quantity" to "数量", "% supply" to "占供应量", "Time remaining" to "剩余时间", "Recipient" to "接收方", "Source" to "来源", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "此版本没有经过验证的解锁计划，不会猜测日期或数量。"),
    "ja" to mapOf("Recently analyzed" to "最近分析した銘柄", "Token unlocks" to "トークンのロック解除", "Unlocks are not verified" to "解除情報は未検証です", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "このバージョンは包括的なロック解除データベースへの認証アクセスがないため、日付や数量を捏造しません。情報源を開き、対象トークンを確認してください。", "Search Tokenomist" to "Tokenomistを検索", "Search CryptoRank" to "CryptoRankを検索", "Search official announcements" to "公式発表を検索", "Date" to "日付", "Quantity" to "数量", "% supply" to "供給量比", "Time remaining" to "残り時間", "Recipient" to "受取先", "Source" to "情報源", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "このバージョンには検証済みの解除予定がありません。日付や数量は推測しません。"),
    "ko" to mapOf("Recently analyzed" to "최근 분석한 코인", "Token unlocks" to "토큰 언락", "Unlocks are not verified" to "언락 정보가 검증되지 않았습니다", "This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule." to "이 앱 버전은 종합 토큰 언락 데이터에 인증된 접근 권한이 없어 날짜나 수량을 만들어내지 않습니다. 출처를 열어 토큰을 확인하세요.", "Search Tokenomist" to "Tokenomist 검색", "Search CryptoRank" to "CryptoRank 검색", "Search official announcements" to "공식 공지 검색", "Date" to "날짜", "Quantity" to "수량", "% supply" to "공급량 비율", "Time remaining" to "남은 시간", "Recipient" to "수령자", "Source" to "출처", "No verified unlock schedule available in this app build. No dates or quantities are being guessed." to "이 버전에는 검증된 언락 일정이 없습니다. 날짜나 수량을 추측하지 않습니다.")
)

private val alertStateTranslations: Map<String, Map<String, String>> = mapOf(
    "en" to mapOf("Deactivated" to "Deactivated", "Activate" to "Activate", "Active" to "Active"),
    "fr" to mapOf("Deactivated" to "A été désactivée", "Activate" to "Activer", "Active" to "Active"),
    "ar" to mapOf("Deactivated" to "تم تعطيله", "Activate" to "إعادة التنشيط", "Active" to "نشط"),
    "es" to mapOf("Deactivated" to "Desactivada", "Activate" to "Activar", "Active" to "Activa"),
    "de" to mapOf("Deactivated" to "Deaktiviert", "Activate" to "Aktivieren", "Active" to "Aktiv"),
    "it" to mapOf("Deactivated" to "Disattivata", "Activate" to "Riattiva", "Active" to "Attiva"),
    "zh" to mapOf("Deactivated" to "已停用", "Activate" to "重新启用", "Active" to "已启用"),
    "ja" to mapOf("Deactivated" to "無効化済み", "Activate" to "再度有効にする", "Active" to "有効"),
    "ko" to mapOf("Deactivated" to "비활성화됨", "Activate" to "다시 활성화", "Active" to "활성"),
)

private fun tr(text: String, language: String): String {
    alertStateTranslations[language]?.get(text)?.let { return it }
    unlockUiTranslations[language]?.get(text)?.let { return it }
    commonFeatureTextTranslations[language]?.get(text)?.let { return it }
    featureTranslations[language]?.get(text)?.let { return it }
    translateBacktestSummary(text, language)?.let { return it }

    setupTranslations[language]?.get(text)?.let { return it }
    tradingSectionTranslations[language]?.get(text)?.let { return it }
    uiTranslations[language]?.get(text)?.let { return it }
    tradingTermTranslations[language]?.get(text)?.let { return it }
    // Translate common trading terms even when embedded in dynamic UI text.
    var result = text
    val terms = (tradingTermTranslations[language].orEmpty() + indicatorTermTranslations[language].orEmpty()).entries.sortedByDescending { it.key.length }
    for ((source, target) in terms) {
        result = result.replace(Regex("(?i)${Regex.escape(source)}")) { match ->
            val original = match.value
            when {
                original == original.uppercase(Locale.ROOT) -> target.uppercase(Locale.ROOT)
                original.firstOrNull()?.isUpperCase() == true -> target.replaceFirstChar { it.uppercase(Locale.ROOT) }
                else -> target
            }
        }
    }
    if (language != "fr" && language != "en") {
        if (result == "ACTUALITÉ") result = when (language) {
            "ar" -> "الأخبار"; "es" -> "NOTICIAS"; "de" -> "NACHRICHTEN"; "it" -> "NOTIZIE"; "zh" -> "新闻"; "ja" -> "ニュース"; "ko" -> "뉴스"; else -> result
        }
        if (result == "Publié il y a moins de 7 jours. Cette information peut influencer le marché, mais son impact sur le prix reste incertain.") result = when (language) {
            "ar" -> "نُشر خلال آخر 7 أيام. قد تؤثر هذه المعلومة في السوق، لكن أثرها على السعر غير مؤكد.";
            "es" -> "Publicado en los últimos 7 días. Esta información puede influir en el mercado, pero su impacto en el precio es incierto.";
            "de" -> "Vor weniger als 7 Tagen veröffentlicht. Diese Information kann den Markt beeinflussen, ihre Preiswirkung ist jedoch ungewiss.";
            "it" -> "Pubblicato negli ultimi 7 giorni. Questa informazione può influenzare il mercato, ma l’impatto sul prezzo è incerto.";
            "zh" -> "发布于最近7天内。这条信息可能影响市场，但对价格的影响尚不确定。";
            "ja" -> "過去7日以内に公開。この情報は市場に影響する可能性がありますが、価格への影響は不確かです。";
            "ko" -> "최근 7일 이내에 게시되었습니다. 시장에 영향을 줄 수 있지만 가격에 미치는 영향은 불확실합니다."; else -> result
        }
        val frenchNews = "Marché crypto · "
        if (result.startsWith(frenchNews)) {
            val coinAndPeriod = result.removePrefix(frenchNews)
            val period = when (language) {
                "ar" -> "سوق العملات الرقمية · "
                "es" -> "Mercado cripto · "
                "de" -> "Kryptomarkt · "
                "it" -> "Mercato crypto · "
                "zh" -> "加密市场 · "
                "ja" -> "暗号資産市場 · "
                "ko" -> "암호화폐 시장 · "
                else -> frenchNews
            }
            result = period + coinAndPeriod.replace("7 derniers jours", when (language) {
                "ar" -> "آخر 7 أيام"; "es" -> "últimos 7 días"; "de" -> "letzte 7 Tage"; "it" -> "ultimi 7 giorni"; "zh" -> "最近7天"; "ja" -> "過去7日間"; "ko" -> "최근 7일"; else -> "7 derniers jours"
            })
        }
        if (result == "Lancez l’analyse pour charger les actualités récentes.") result = when (language) {
            "ar" -> "ابدأ التحليل لتحميل آخر الأخبار."; "es" -> "Inicia el análisis para cargar las noticias recientes."; "de" -> "Starte die Analyse, um aktuelle Nachrichten zu laden."; "it" -> "Avvia l’analisi per caricare le notizie recenti."; "zh" -> "请先运行分析以加载最新资讯。"; "ja" -> "最新ニュースを読み込むには分析を開始してください。"; "ko" -> "최신 뉴스를 불러오려면 분석을 시작하세요."; else -> result
        }
    }
    return result
}
private fun localeForAppLanguage(language: String): Locale = when (language) {
    "zh" -> Locale.SIMPLIFIED_CHINESE
    "ja" -> Locale.JAPANESE
    "ar" -> Locale("ar")
    else -> Locale(language)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Block screenshots, screen recording, and the app preview in Recents.
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            val darkScheme = darkColorScheme(
                primary = Color(0xFF5EEAD4),
                onPrimary = Color(0xFF062A2A),
                secondary = Color(0xFFA78BFA),
                tertiary = Color(0xFF60A5FA),
                background = Color(0xFF080D1B),
                surface = Color(0xFF111A2E),
                surfaceVariant = Color(0xFF1B2942),
                onBackground = Color(0xFFEAF2FF),
                onSurface = Color(0xFFEAF2FF),
                onSurfaceVariant = Color(0xFFB7C5DA),
                error = Color(0xFFFF718B)
            )
            MaterialTheme(colorScheme = darkScheme) { ActivationGate { authorizeAnalysis -> AnalyzerApp(authorizeAnalysis) } }
        }
    }
}

@Composable
private fun adviceFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    focusedBorderColor = Color(0xFF5EEAD4), unfocusedBorderColor = Color(0xFF53647C),
    focusedLabelColor = Color(0xFF5EEAD4), unfocusedLabelColor = Color(0xFFB8C7E3),
    cursorColor = Color(0xFF5EEAD4)
)

data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)

private data class DescendingPriceChannel(
    val startIndex: Int,
    val upperStart: Double,
    val upperEnd: Double,
    val lowerStart: Double,
    val lowerEnd: Double,
    val projectedUpper: Double,
    val projectedLower: Double,
    val status: String
)

/** Detect a plausible descending parallel channel from recent candle highs/lows; returns null when evidence is weak. */
private fun detectDescendingPriceChannel(candles: List<Candle>, window: Int = 30): DescendingPriceChannel? {
    if (candles.size < window) return null
    val recent = candles.takeLast(window)
    if (recent.any { !it.high.isFinite() || !it.low.isFinite() || it.high <= 0.0 || it.low <= 0.0 || it.high < it.low }) return null

    fun regression(values: List<Double>): Pair<Double, Double> {
        val n = values.size.toDouble()
        val meanX = (values.indices.sumOf { it.toDouble() }) / n
        val meanY = values.average()
        var numerator = 0.0
        var denominator = 0.0
        values.indices.forEach { i ->
            val dx = i - meanX
            numerator += dx * (values[i] - meanY)
            denominator += dx * dx
        }
        val slope = if (denominator == 0.0) 0.0 else numerator / denominator
        return slope to (meanY - slope * meanX)
    }

    val (upperSlope, upperIntercept) = regression(recent.map { it.high })
    val (lowerSlope, lowerIntercept) = regression(recent.map { it.low })
    val typicalRange = (recent.maxOf { it.high } - recent.minOf { it.low }).coerceAtLeast(recent.last().close * 0.0001)
    if (upperSlope >= 0.0 || lowerSlope >= 0.0) return null
    val slopeScale = maxOf(kotlin.math.abs(upperSlope), kotlin.math.abs(lowerSlope)).coerceAtLeast(1e-12)
    if (kotlin.math.abs(upperSlope - lowerSlope) / slopeScale > 0.85) return null

    val lastX = (window - 1).toDouble()
    val upperStart = upperIntercept
    val upperEnd = upperSlope * lastX + upperIntercept
    val lowerStart = lowerIntercept
    val lowerEnd = lowerSlope * lastX + lowerIntercept
    val widthStart = upperStart - lowerStart
    val widthEnd = upperEnd - lowerEnd
    if (widthStart <= 0.0 || widthEnd <= 0.0 || widthStart > typicalRange * 0.95 || widthEnd > typicalRange * 0.95) return null

    // A small buffer reduces false breakouts caused by wick noise.
    val buffer = maxOf(widthEnd * 0.06, recent.last().close * 0.0005)
    val lastClose = recent.last().close
    val status = when {
        lastClose > upperEnd + buffer -> "up"
        lastClose < lowerEnd - buffer -> "down"
        else -> "inside"
    }
    return DescendingPriceChannel(candles.size - window, upperStart, upperEnd, lowerStart, lowerEnd, upperEnd, lowerEnd, status)
}
data class IndicatorRow(
    val timeframe: String,
    val price: Double,
    val emas: Map<Int, Double>,
    val obv: Double,
    val obvRising: Boolean,
    val macd: Double,
    val signal: Double,
    val hist: Double,
    val upProbability: Int,
    val downProbability: Int,
    val support: Double,
    val resistance: Double,
    val setup: String,
    val rsi: Double?,
    val volume: Double,
    val averageVolume: Double,
    val supertrend: Double,
    val supertrendBullish: Boolean
)

data class TradePlan(
    val title: String,
    val description: String,
    val entry: Double,
    val stopLoss: Double,
    val tp1: Double,
    val tp2: Double,
    val tp3: Double
)

/** Builds four conditional long/Spot planning scenarios from latest price and 4H support/resistance. */
private fun buildTradePlans(currentPrice: Double, row: IndicatorRow): List<TradePlan> {
    val support = row.support
    val resistance = row.resistance
    if (!currentPrice.isFinite() || currentPrice <= 0.0 ||
        !support.isFinite() || !resistance.isFinite() || support <= 0.0 || resistance <= support
    ) return emptyList()

    val aggressiveEntry = if (currentPrice > support) support + (currentPrice - support) * 0.20 else currentPrice
    val confirmedEntry = max(currentPrice, resistance * 1.002)
    val conservativeEntry = max(currentPrice, resistance * 1.008)
    // A retest entry sits close to the broken resistance/current market, rather than using a fixed percentage offset.
    val retestEntry = if (currentPrice > resistance) max(resistance, currentPrice - (currentPrice - resistance) * 0.35) else max(currentPrice, resistance * 1.002)

    fun plan(title: String, description: String, entry: Double, proposedStop: Double): TradePlan {
        val stop = proposedStop.coerceIn(entry * 0.50, entry * 0.999)
        val risk = (entry - stop).coerceAtLeast(entry * 0.001)
        return TradePlan(title, description, entry, stop, entry + risk, entry + risk * 2.0, entry + risk * 3.0)
    }

    return listOf(
        plan("Aggressive entry", "Near support; higher risk. Prefer a visible support reaction.", aggressiveEntry, min(support * 0.995, aggressiveEntry * 0.985)),
        plan("Breakout-confirmation entry", "Trigger only after a candle closes above resistance; a retest is preferable.", confirmedEntry, min(resistance * 0.99, confirmedEntry * 0.985)),
        plan("Breakout-retest entry", "After a confirmed breakout, wait for a pullback and confirmation that the former resistance holds as support.", retestEntry, min(resistance * 0.99, retestEntry * 0.985)),
        plan("More conservative entry", "Wait for a stronger move above resistance and confirm volume; entry may be higher.", conservativeEntry, min(resistance * 0.99, conservativeEntry * 0.985))
    )
}

private val client = OkHttpClient.Builder().connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS).readTimeout(10, java.util.concurrent.TimeUnit.SECONDS).build()

data class MarketNews(
    val title: String,
    val summary: String,
    val publishedAt: Long,
    val source: String,
    val url: String
)

private data class NewsFeed(val url: String, val source: String)
private val newsFeeds = listOf(
    NewsFeed("https://www.coindesk.com/arc/outboundfeeds/rss/", "CoinDesk"),
    NewsFeed("https://cointelegraph.com/rss", "Cointelegraph")
)

private fun parseNewsDate(value: String): Long? {
    val raw = value.trim()
    if (raw.isBlank()) return null
    try { return Instant.parse(raw).toEpochMilli() } catch (_: Exception) {}
    try { return OffsetDateTime.parse(raw).toInstant().toEpochMilli() } catch (_: Exception) {}
    try { return ZonedDateTime.parse(raw).toInstant().toEpochMilli() } catch (_: Exception) {}
    val patterns = listOf("EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm Z", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd'T'HH:mm:ss.SSSX")
    for (pattern in patterns) {
        try {
            val format = SimpleDateFormat(pattern, Locale.US).apply { isLenient = true; timeZone = TimeZone.getTimeZone("UTC") }
            return format.parse(raw)?.time
        } catch (_: Exception) {}
    }
    return null
}

private fun cleanNewsText(raw: String): String = Html.fromHtml(raw, Html.FROM_HTML_MODE_LEGACY).toString()
    .replace(Regex("\\s+"), " ").trim()

private fun parseRssFeed(xml: String, source: String): List<MarketNews> {
    val parser = Xml.newPullParser()
    parser.setInput(StringReader(xml))
    val output = mutableListOf<MarketNews>()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        if (event == XmlPullParser.START_TAG && parser.name.substringAfter(':') in setOf("item", "entry")) {
            var title = ""; var summary = ""; var date = ""; var link = ""
            val itemTag = parser.name
            var depth = 1
            while (depth > 0) {
                event = parser.next()
                when (event) {
                    XmlPullParser.START_TAG -> {
                        depth++
                        val tag = parser.name.substringAfter(':').lowercase(Locale.ROOT)
                        if (tag == "link") {
                            val href = parser.getAttributeValue(null, "href")
                            if (!href.isNullOrBlank()) link = href
                            else { val t = try { parser.nextText() } catch (_: Exception) { "" }; if (t.isNotBlank()) link = t; depth-- }
                        } else if (tag in setOf("title", "description", "summary", "encoded", "pubdate", "published", "updated", "date")) {
                            val value = try { parser.nextText() } catch (_: Exception) { "" }
                            when (tag) {
                                "title" -> if (title.isBlank()) title = value
                                "description", "summary", "encoded" -> if (summary.isBlank() || tag == "encoded") summary = value
                                "pubdate", "published", "updated", "date" -> if (date.isBlank()) date = value
                            }
                            depth--
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        depth--
                        if (depth == 0 && parser.name == itemTag) break
                    }
                }
            }
            val timestamp = parseNewsDate(date)
            val cleanedTitle = cleanNewsText(title)
            val cleanedSummary = cleanNewsText(summary)
            if (timestamp != null && cleanedTitle.isNotBlank()) output.add(MarketNews(cleanedTitle, cleanedSummary, timestamp, source, link))
        }
        event = parser.next()
    }
    return output
}

private fun loadRecentNews(symbol: String, coinName: String? = null): List<MarketNews> {
    val now = System.currentTimeMillis()
    val sevenDays = 7L * 24L * 60L * 60L * 1000L
    val token = symbol.uppercase(Locale.ROOT).removeSuffix("USDT")
    val tokenAliases = when (token) {
        "BTC" -> listOf("bitcoin", "btc")
        "ETH" -> listOf("ethereum", "ether", "eth")
        "SOL" -> listOf("solana", "sol")
        "XRP" -> listOf("xrp", "ripple")
        "BNB" -> listOf("bnb", "binance coin")
        "DOGE" -> listOf("dogecoin", "doge")
        else -> listOf(token.lowercase(Locale.ROOT))
    }.filter { it.length >= 2 }
    val all = mutableListOf<MarketNews>()
    for (feed in newsFeeds) {
        try {
            val request = Request.Builder().url(feed.url).header("User-Agent", "CryptoAnalyserByErrZhr/1.0").get().build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val xml = response.body?.string().orEmpty()
                    all.addAll(parseRssFeed(xml, feed.source))
                }
            }
        } catch (_: Exception) { /* The other feed may still be available. */ }
    }
    val fresh = all.distinctBy { it.url.ifBlank { it.title } }
        .filter { it.publishedAt in (now - sevenDays)..(now + 10L * 60L * 1000L) }
    // Strict relevance: show an article only when the selected coin's symbol or known name
    // appears as a whole token in its headline or summary. Never append generic market news.
    val cleanCoinName = coinName?.trim()?.lowercase(Locale.ROOT)?.takeIf { it.length >= 3 && it != token.lowercase(Locale.ROOT) }
    val coinSpecific = fresh.filter { item ->
        val originalText = item.title + " " + item.summary
        val text = originalText.lowercase(Locale.ROOT)
        val tickerMatch = tokenAliases.any { alias ->
            // Short tickers must appear uppercase to avoid matching ordinary words; long symbols are whole-token matches.
            val needle = if (alias.length <= 3) alias.uppercase(Locale.ROOT) else alias.lowercase(Locale.ROOT)
            val haystack = if (alias.length <= 3) originalText else text
            Regex("(^|[^a-zA-Z0-9])" + Regex.escape(needle) + "([^a-zA-Z0-9]|$)").containsMatchIn(haystack)
        }
        val nameMatch = cleanCoinName?.let { name ->
            Regex("(?i)(^|[^a-zA-Z0-9])" + Regex.escape(name) + "([^a-zA-Z0-9]|$)").containsMatchIn(originalText)
        } ?: false
        tickerMatch || nameMatch
    }
    return coinSpecific.sortedByDescending { it.publishedAt }
        .distinctBy { it.url.ifBlank { it.title } }.take(4)
}

/** Accepts base symbols (BTC), concatenated pairs (BTCUSDT), and separated pairs (BTC/USDT or BTC-USDT). */
private fun normalizeUsdtSymbol(input: String): String {
    val cleaned = input.trim().uppercase()
        .replace("/", "")
        .replace("-", "")
        .replace("_", "")
        .replace(" ", "")
    if (cleaned.isBlank()) throw IllegalArgumentException("Enter a coin symbol, e.g. BTC, BTCUSDT or AIAV/USDT.")
    val pair = if (cleaned.endsWith("USDT")) cleaned else "${cleaned}USDT"
    if (!pair.matches(Regex("[A-Z0-9]{2,20}USDT"))) {
        throw IllegalArgumentException("Invalid symbol. Enter a coin like BTC, BTCUSDT or AIAV/USDT.")
    }
    return pair
}

private fun loadListedUsdtSymbols(market: String, platform: String): List<String> {
    if (platform == "Binance") {
        val url = if (market == "Spot") "https://api.binance.com/api/v3/exchangeInfo" else "https://fapi.binance.com/fapi/v1/exchangeInfo"
        val root = getJson(url)
        val data = root.optJSONArray("symbols") ?: JSONArray()
        return (0 until data.length()).mapNotNull { i ->
            val item = data.optJSONObject(i) ?: return@mapNotNull null
            val pair = item.optString("symbol").uppercase()
            val quote = item.optString(if (market == "Spot") "quoteAsset" else "quoteAsset").uppercase()
            val status = item.optString("status")
            if (pair.endsWith("USDT") && quote == "USDT" && status == "TRADING" && (market == "Spot" || item.optString("contractType") == "PERPETUAL")) pair else null
        }.sorted()
    }
    val url = if (market == "Spot") {
        "https://api.bitget.com/api/v2/spot/public/symbols"
    } else {
        "https://api.bitget.com/api/v2/mix/market/contracts?productType=USDT-FUTURES"
    }
    val root = getJson(url)
    val data = root.optJSONArray("data") ?: JSONArray()
    val symbols = linkedSetOf<String>()
    for (i in 0 until data.length()) {
        val item = data.optJSONObject(i) ?: continue
        val pair = item.optString("symbol").uppercase()
        val quote = item.optString("quoteCoin", "USDT").uppercase()
        val status = item.optString("status", item.optString("symbolStatus", "online")).lowercase()
        if (pair.endsWith("USDT") && quote == "USDT" && status !in setOf("offline", "gray", "delisted", "halt")) {
            symbols.add(pair)
        }
    }
    return symbols.sorted()
}

private fun marketTickerUrl(symbol: String, market: String, platform: String): String = when (platform) {
    "Binance" -> if (market == "Spot") "https://api.binance.com/api/v3/ticker/24hr?symbol=$symbol" else "https://fapi.binance.com/fapi/v1/ticker/24hr?symbol=$symbol"
    else -> if (market == "Spot") "https://api.bitget.com/api/v2/spot/market/tickers?symbol=$symbol" else "https://api.bitget.com/api/v2/mix/market/ticker?productType=USDT-FUTURES&symbol=$symbol"
}

private fun marketCandlesUrl(symbol: String, market: String, platform: String, granularity: String, limit: Int): String {
    if (platform == "Binance") {
        val interval = when (granularity.lowercase()) {
            "15min", "15m" -> "15m"
            "1h" -> "1h"
            "4h" -> "4h"
            "1day", "1d" -> "1d"
            "1m" -> "1M"
            else -> granularity
        }
        val base = if (market == "Spot") "https://api.binance.com/api/v3/klines" else "https://fapi.binance.com/fapi/v1/klines"
        return "$base?symbol=$symbol&interval=$interval&limit=$limit"
    }
    return if (market == "Spot") {
        "https://api.bitget.com/api/v2/spot/market/candles?symbol=$symbol&granularity=${spotV2Granularity(granularity)}&limit=$limit"
    } else {
        "https://api.bitget.com/api/v2/mix/market/candles?symbol=$symbol&granularity=$granularity&productType=USDT-FUTURES&limit=$limit"
    }
}

private fun parseBinanceCandles(url: String): List<Candle> {
    val request = Request.Builder().url(url).get().build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw Exception("Binance HTTP ${response.code}")
        val data = JSONArray(response.body?.string() ?: "[]")
        val result = mutableListOf<Candle>()
        for (i in 0 until data.length()) {
            val a = data.optJSONArray(i) ?: continue
            if (a.length() < 6) continue
            result.add(Candle(a.optLong(0), a.optString(1).toDoubleOrNull() ?: 0.0, a.optString(2).toDoubleOrNull() ?: 0.0, a.optString(3).toDoubleOrNull() ?: 0.0, a.optString(4).toDoubleOrNull() ?: 0.0, a.optString(5).toDoubleOrNull() ?: 0.0))
        }
        return result.filter { it.close > 0.0 }.sortedBy { it.time }
    }
}

private fun loadMarketCandles(symbol: String, market: String, platform: String, granularity: String, limit: Int): List<Candle> {
    val url = marketCandlesUrl(symbol, market, platform, granularity, limit)
    return if (platform == "Binance") parseBinanceCandles(url) else parseCandles(getJson(url))
}

private fun getJson(url: String): JSONObject {
    val request = Request.Builder().url(url).get().build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw Exception("Bitget HTTP ${response.code}")
        val root = JSONObject(response.body?.string() ?: "{}")
        val apiCode = root.optString("code", "00000")
        if (apiCode.isNotBlank() && apiCode != "00000") {
            throw Exception("Bitget API error $apiCode: ${root.optString("msg", "unknown error")}")
        }
        return root
    }
}
private data class BitgetCoinChainInfo(
    val chain: String,
    val contractAddress: String,
    val depositEnabled: Boolean?,
    val withdrawalEnabled: Boolean?
)

private data class BitgetCoinProfile(
    val coin: String,
    val transferEnabled: Boolean?,
    val chains: List<BitgetCoinChainInfo>,
    val listedPairs: List<String>,
    val tradingStatus: String,
    val firstListingTime: Long?
)

private data class CoinFundamentals(
    val name: String,
    val symbol: String,
    val ambiguous: Boolean,
    val candidates: List<String>,
    val marketCapUsd: Double?,
    val circulatingSupply: Double?,
    val totalSupply: Double?,
    val maxSupply: Double?,
    val description: String,
    val tags: List<String>,
    val website: String?,
    val whitepaper: String?
)

/** Free CoinPaprika public endpoints; no API key required. Ambiguous tickers are never silently guessed. */
private fun loadCoinFundamentals(symbolInput: String): CoinFundamentals {
    val symbol = symbolInput.trim().uppercase(Locale.ROOT)
    val search = getJson("https://api.coinpaprika.com/v1/search/?q=${java.net.URLEncoder.encode(symbol, "UTF-8")}&c=currencies&limit=25")
    val currencies = search.optJSONArray("currencies") ?: JSONArray()
    val exact = (0 until currencies.length()).mapNotNull { currencies.optJSONObject(it) }
        .filter { it.optString("symbol").equals(symbol, ignoreCase = true) }
    if (exact.size > 1) {
        return CoinFundamentals(symbol, symbol, true, exact.take(8).map { "${it.optString("name")} (${it.optString("symbol")}) — ${it.optString("id")}" }, null, null, null, null, "", emptyList(), null, null)
    }
    val coin = exact.singleOrNull() ?: throw IllegalStateException("No exact CoinPaprika project match for $symbol. Supply and market capitalization are unavailable.")
    val id = coin.optString("id")
    val ticker = getJson("https://api.coinpaprika.com/v1/tickers/${java.net.URLEncoder.encode(id, "UTF-8")}?quotes=USD")
    val usd = ticker.optJSONObject("quotes")?.optJSONObject("USD")
    val detail = getJson("https://api.coinpaprika.com/v1/coins/${java.net.URLEncoder.encode(id, "UTF-8")}")
    fun number(obj: JSONObject?, key: String): Double? = obj?.optString(key)?.toDoubleOrNull()?.takeIf { it.isFinite() && it >= 0.0 }
    val tags = detail.optJSONArray("tags")
    val tagNames = (0 until (tags?.length() ?: 0)).mapNotNull { tags?.optJSONObject(it)?.optString("name")?.takeIf(String::isNotBlank) }.take(20)
    val links = detail.optJSONObject("links")
    val websiteArray = links?.optJSONArray("website")
    val whitepaperArray = links?.optJSONArray("whitepaper")
    return CoinFundamentals(
        name = ticker.optString("name", coin.optString("name", symbol)), symbol = symbol,
        ambiguous = false, candidates = emptyList(), marketCapUsd = number(usd, "market_cap"),
        circulatingSupply = number(ticker, "circulating_supply"), totalSupply = number(ticker, "total_supply"),
        maxSupply = number(ticker, "max_supply"), description = detail.optString("description", ""), tags = tagNames,
        website = websiteArray?.optString(0)?.takeIf(String::isNotBlank), whitepaper = whitepaperArray?.optString(0)?.takeIf(String::isNotBlank)
    )
}

/**
 * Uses Bitget's unauthenticated Spot public endpoints only. These endpoints expose
 * exchange/listing and chain-transfer metadata, but do NOT expose project whitepapers,
 * tokenomics supply figures, or a verified project description.
 */
private fun loadBitgetCoinProfile(baseCoinInput: String): BitgetCoinProfile {
    val baseCoin = baseCoinInput.trim().uppercase(Locale.ROOT)
    val coinUrl = "https://api.bitget.com/api/v2/spot/public/coins?coin=${java.net.URLEncoder.encode(baseCoin, "UTF-8")}"
    val coinRoot = getJson(coinUrl)
    val coinData = coinRoot.optJSONArray("data") ?: JSONArray()
    val coinItem = (0 until coinData.length()).mapNotNull { coinData.optJSONObject(it) }
        .firstOrNull { it.optString("coin").equals(baseCoin, ignoreCase = true) }
    val chains = mutableListOf<BitgetCoinChainInfo>()
    val chainArray = coinItem?.optJSONArray("chains") ?: JSONArray()
    for (i in 0 until chainArray.length()) {
        val chain = chainArray.optJSONObject(i) ?: continue
        val chainName = chain.optString("chain", chain.optString("chainName", "Unknown"))
        val contract = chain.optString("contractAddress", chain.optString("contract", ""))
        val deposit = when (chain.optString("rechargeable").lowercase(Locale.ROOT)) { "true" -> true; "false" -> false; else -> null }
        val withdraw = when (chain.optString("withdrawable").lowercase(Locale.ROOT)) { "true" -> true; "false" -> false; else -> null }
        chains += BitgetCoinChainInfo(chainName, contract, deposit, withdraw)
    }
    val symbolsRoot = getJson("https://api.bitget.com/api/v2/spot/public/symbols")
    val symbols = symbolsRoot.optJSONArray("data") ?: JSONArray()
    val pairs = mutableListOf<Pair<String, JSONObject>>()
    for (i in 0 until symbols.length()) {
        val item = symbols.optJSONObject(i) ?: continue
        val pair = item.optString("symbol").uppercase(Locale.ROOT)
        val base = item.optString("baseCoin").uppercase(Locale.ROOT)
        if (base == baseCoin) pairs += pair to item
    }
    val activePairs = pairs.filter { (_, item) -> item.optString("status", "online").lowercase(Locale.ROOT) == "online" }
    var firstListing = pairs.mapNotNull { (_, item) -> item.optString("launchTime").toLongOrNull()?.takeIf { it > 0L } }.minOrNull()
    if (firstListing == null) {
        // The newer Bitget instruments endpoint documents launchTime for spot symbols.
        try {
            val instrumentRoot = getJson("https://api.bitget.com/api/v3/market/instruments?category=SPOT&symbol=${baseCoin}USDT")
            val instruments = instrumentRoot.optJSONArray("data") ?: JSONArray()
            firstListing = (0 until instruments.length()).mapNotNull { i ->
                instruments.optJSONObject(i)?.optString("launchTime")?.toLongOrNull()?.takeIf { it > 0L }
            }.minOrNull()
        } catch (_: Exception) { /* Listing date stays unknown if Bitget does not return it. */ }
    }
    val status = when {
        activePairs.isNotEmpty() -> "Online"
        pairs.isNotEmpty() -> pairs.first().second.optString("status", "Unknown")
        else -> "Not found in Bitget Spot pairs"
    }
    return BitgetCoinProfile(
        coin = baseCoin,
        transferEnabled = when (coinItem?.optString("transfer")?.lowercase(Locale.ROOT)) { "true" -> true; "false" -> false; else -> null },
        chains = chains,
        listedPairs = pairs.map { it.first }.distinct().sorted(),
        tradingStatus = status,
        firstListingTime = firstListing
    )
}


private val coinProfileTranslations = mapOf(
    "fr" to mapOf("BITGET COIN PROFILE" to "FICHE DE LA CRYPTO SUR BITGET", "Exchange listing" to "Cotations sur la plateforme", "Trading status" to "Statut de cotation", "First listing date" to "Première date de cotation", "Available trading pairs" to "Paires de trading disponibles", "Supported chains" to "Réseaux pris en charge", "Contract address" to "Adresse du contrat", "Deposits" to "Dépôts", "Withdrawals" to "Retraits", "Transfer" to "Transfert", "Enabled" to "Activé", "Disabled" to "Désactivé", "Unknown" to "Inconnu", "Not found in Bitget Spot pairs" to "Introuvable dans les paires Spot Bitget", "Supply and project description" to "Offre et description du projet", "Bitget Spot does not publish circulating/total supply or a project whitepaper in this endpoint." to "Cette API Spot de Bitget ne publie ni l’offre en circulation/totale ni le livre blanc du projet.", "Search official project information" to "Rechercher les informations officielles du projet", "Loading Bitget coin information…" to "Chargement des informations Bitget…", "No chain contract returned by Bitget." to "Aucun contrat de réseau fourni par Bitget."),
    "ar" to mapOf("BITGET COIN PROFILE" to "ملف العملة على Bitget", "Exchange listing" to "الإدراج في المنصة", "Trading status" to "حالة التداول", "First listing date" to "تاريخ أول إدراج", "Available trading pairs" to "أزواج التداول المتاحة", "Supported chains" to "الشبكات المدعومة", "Contract address" to "عنوان العقد", "Deposits" to "الإيداع", "Withdrawals" to "السحب", "Transfer" to "التحويل", "Enabled" to "مفعّل", "Disabled" to "معطّل", "Unknown" to "غير معروف", "Not found in Bitget Spot pairs" to "غير موجود ضمن أزواج Bitget الفورية", "Supply and project description" to "المعروض ووصف المشروع", "Bitget Spot does not publish circulating/total supply or a project whitepaper in this endpoint." to "واجهة Bitget Spot هذه لا توفر المعروض المتداول أو الإجمالي ولا الورقة البيضاء للمشروع.", "Search official project information" to "البحث عن معلومات المشروع الرسمية", "Loading Bitget coin information…" to "جارٍ تحميل معلومات العملة من Bitget…", "No chain contract returned by Bitget." to "لم تُرجع Bitget عنوان عقد للشبكة."),
    "de" to mapOf("BITGET COIN PROFILE" to "BITGET-COIN-PROFIL", "Exchange listing" to "Börsenlisting", "Trading status" to "Handelsstatus", "First listing date" to "Erstes Listing-Datum", "Available trading pairs" to "Verfügbare Handelspaare", "Supported chains" to "Unterstützte Netzwerke", "Contract address" to "Vertragsadresse", "Deposits" to "Einzahlungen", "Withdrawals" to "Auszahlungen", "Transfer" to "Transfer", "Enabled" to "Aktiviert", "Disabled" to "Deaktiviert", "Unknown" to "Unbekannt", "Not found in Bitget Spot pairs" to "Nicht in Bitget-Spot-Paaren gefunden", "Supply and project description" to "Angebot und Projektbeschreibung", "Bitget Spot does not publish circulating/total supply or a project whitepaper in this endpoint." to "Diese Bitget-Spot-API liefert weder Umlauf-/Gesamtangebot noch Whitepaper.", "Search official project information" to "Offizielle Projektinformationen suchen", "Loading Bitget coin information…" to "Bitget-Coin-Informationen werden geladen…", "No chain contract returned by Bitget." to "Bitget hat keine Vertragsadresse geliefert."),
    "it" to mapOf("BITGET COIN PROFILE" to "SCHEDA CRYPTO BITGET", "Exchange listing" to "Quotazione sulla piattaforma", "Trading status" to "Stato di negoziazione", "First listing date" to "Data della prima quotazione", "Available trading pairs" to "Coppie disponibili", "Supported chains" to "Reti supportate", "Contract address" to "Indirizzo del contratto", "Deposits" to "Depositi", "Withdrawals" to "Prelievi", "Transfer" to "Trasferimento", "Enabled" to "Attivo", "Disabled" to "Disattivato", "Unknown" to "Sconosciuto", "Not found in Bitget Spot pairs" to "Non trovato nelle coppie Spot Bitget", "Supply and project description" to "Offerta e descrizione del progetto", "Bitget Spot does not publish circulating/total supply or a project whitepaper in this endpoint." to "Questa API Spot Bitget non fornisce offerta circolante/totale né whitepaper.", "Search official project information" to "Cerca informazioni ufficiali sul progetto", "Loading Bitget coin information…" to "Caricamento informazioni Bitget…", "No chain contract returned by Bitget." to "Bitget non ha restituito un contratto di rete."),
    "es" to mapOf("BITGET COIN PROFILE" to "FICHA DE CRIPTOMONEDA BITGET", "Exchange listing" to "Listado en el exchange", "Trading status" to "Estado de negociación", "First listing date" to "Fecha del primer listado", "Available trading pairs" to "Pares disponibles", "Supported chains" to "Redes compatibles", "Contract address" to "Dirección del contrato", "Deposits" to "Depósitos", "Withdrawals" to "Retiros", "Transfer" to "Transferencia", "Enabled" to "Activo", "Disabled" to "Desactivado", "Unknown" to "Desconocido", "Not found in Bitget Spot pairs" to "No aparece en pares Spot de Bitget", "Supply and project description" to "Oferta y descripción del proyecto", "Bitget Spot does not publish circulating/total supply or a project whitepaper in this endpoint." to "Esta API Spot de Bitget no ofrece suministro circulante/total ni whitepaper.", "Search official project information" to "Buscar información oficial del proyecto", "Loading Bitget coin information…" to "Cargando información de Bitget…", "No chain contract returned by Bitget." to "Bitget no devolvió un contrato de red."),
    "zh" to mapOf("BITGET COIN PROFILE" to "Bitget 币种资料", "Exchange listing" to "交易所上架", "Trading status" to "交易状态", "First listing date" to "首次上架日期", "Available trading pairs" to "可用交易对", "Supported chains" to "支持的链", "Contract address" to "合约地址", "Deposits" to "充值", "Withdrawals" to "提现", "Transfer" to "转账", "Enabled" to "已启用", "Disabled" to "已停用", "Unknown" to "未知", "Not found in Bitget Spot pairs" to "未在 Bitget 现货交易对中找到", "Supply and project description" to "供应量和项目介绍", "Bitget Spot does not publish circulating/total supply or a project whitepaper in this endpoint." to "此 Bitget 现货接口不提供流通/总供应量或项目白皮书。", "Search official project information" to "搜索项目官方信息", "Loading Bitget coin information…" to "正在加载 Bitget 币种信息…", "No chain contract returned by Bitget." to "Bitget 未返回链上合约地址。"),
    "ja" to mapOf("BITGET COIN PROFILE" to "Bitget コイン情報", "Exchange listing" to "取引所上場", "Trading status" to "取引状態", "First listing date" to "初回上場日", "Available trading pairs" to "利用可能な取引ペア", "Supported chains" to "対応チェーン", "Contract address" to "コントラクトアドレス", "Deposits" to "入金", "Withdrawals" to "出金", "Transfer" to "送金", "Enabled" to "有効", "Disabled" to "無効", "Unknown" to "不明", "Not found in Bitget Spot pairs" to "Bitget現物ペアに見つかりません", "Supply and project description" to "供給量とプロジェクト説明", "Bitget Spot does not publish circulating/total supply or a project whitepaper in this endpoint." to "このBitget現物APIは流通/総供給量やホワイトペーパーを提供しません。", "Search official project information" to "公式プロジェクト情報を検索", "Loading Bitget coin information…" to "Bitgetコイン情報を読み込み中…", "No chain contract returned by Bitget." to "Bitgetからチェーンコントラクトが返されませんでした。"),
    "ko" to mapOf("BITGET COIN PROFILE" to "BITGET 코인 정보", "Exchange listing" to "거래소 상장", "Trading status" to "거래 상태", "First listing date" to "최초 상장일", "Available trading pairs" to "사용 가능한 거래쌍", "Supported chains" to "지원 체인", "Contract address" to "컨트랙트 주소", "Deposits" to "입금", "Withdrawals" to "출금", "Transfer" to "전송", "Enabled" to "사용 가능", "Disabled" to "사용 중지", "Unknown" to "알 수 없음", "Not found in Bitget Spot pairs" to "Bitget 현물 거래쌍에서 찾을 수 없음", "Supply and project description" to "공급량 및 프로젝트 설명", "Bitget Spot does not publish circulating/total supply or a project whitepaper in this endpoint." to "이 Bitget 현물 API는 유통/총 공급량이나 백서를 제공하지 않습니다.", "Search official project information" to "프로젝트 공식 정보 검색", "Loading Bitget coin information…" to "Bitget 코인 정보를 불러오는 중…", "No chain contract returned by Bitget." to "Bitget에서 체인 컨트랙트를 반환하지 않았습니다.")
)

private fun coinProfileTr(text: String, language: String): String = coinProfileTranslations[language]?.get(text) ?: text

@Composable
private fun BitgetProfileLine(label: String, value: String, language: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
        Text(coinProfileTr(label, language), modifier = Modifier.weight(0.9f), color = Color(0xFF9BAAC2), style = MaterialTheme.typography.bodySmall)
        Text(value, modifier = Modifier.weight(1.1f), color = Color.White, style = MaterialTheme.typography.bodySmall)
    }
}

private fun parseCandles(root: JSONObject): List<Candle> {
    val data = root.optJSONArray("data") ?: JSONArray()
    val result = mutableListOf<Candle>()
    for (i in 0 until data.length()) {
        val a = data.optJSONArray(i) ?: continue
        if (a.length() < 6) continue
        result.add(Candle(a.optString(0).toLongOrNull() ?: 0L, a.optString(1).toDoubleOrNull() ?: 0.0, a.optString(2).toDoubleOrNull() ?: 0.0, a.optString(3).toDoubleOrNull() ?: 0.0, a.optString(4).toDoubleOrNull() ?: 0.0, a.optString(5).toDoubleOrNull() ?: 0.0))
    }
    return result.filter { it.close > 0.0 }.sortedBy { it.time }
}

private data class PriceExtremes(
    val allTimeHigh: Double,
    val allTimeLow: Double,
    val high24h: Double,
    val low24h: Double,
    val historyComplete: Boolean,
    val last24hComplete: Boolean
)

private fun spotV2Granularity(granularity: String): String = when (granularity.uppercase()) {
    // Bitget v2 Spot REST uses minute suffixes (5min/15min), lowercase hours and "1day".
    "5M" -> "5min"
    "15M" -> "15min"
    "30M" -> "30min"
    "1H" -> "1h"
    "4H" -> "4h"
    "1D" -> "1day"
    else -> granularity
}

private fun historyCandlesUrl(symbol: String, isSpot: Boolean, granularity: String, endTime: Long): String {
    return if (isSpot) {
        val spotGranularity = spotV2Granularity(granularity)
        "https://api.bitget.com/api/v2/spot/market/history-candles?symbol=$symbol&granularity=$spotGranularity&endTime=$endTime&limit=200"
    } else {
        "https://api.bitget.com/api/v2/mix/market/history-candles?productType=USDT-FUTURES&symbol=$symbol&granularity=$granularity&endTime=$endTime&limit=200"
    }
}

/**
 * Uses Bitget's public ticker statistics for the rolling 24-hour high/low.
 * Bitget's ticker endpoints do not expose a reliable all-time-high/all-time-low field,
 * so ATH/ATL are deliberately left unavailable rather than inferred from a partial candle scan.
 */
private fun loadPriceExtremesFromTicker(ticker: JSONObject): PriceExtremes {
    fun number(vararg keys: String): Double {
        for (key in keys) {
            val value = ticker.optString(key, "").toDoubleOrNull()
            if (value != null && value.isFinite() && value > 0.0) return value
        }
        return 0.0
    }
    return PriceExtremes(
        allTimeHigh = 0.0,
        allTimeLow = 0.0,
        high24h = number("high24h", "high24H", "high24Hour"),
        low24h = number("low24h", "low24H", "low24Hour"),
        historyComplete = false,
        last24hComplete = true
    )
}

/** Scans daily historical candles backwards for the selected Bitget market/instrument.
 * A bounded scan prevents endless loops; completeness is only true when the API indicates
 * that no older candles remain. Never substitutes a partial scan for a true all-time value. */
private fun loadAllTimeExtremes(symbol: String, isSpot: Boolean, ticker: JSONObject): PriceExtremes {
    val tickerValues = loadPriceExtremesFromTicker(ticker)
    var endTime = System.currentTimeMillis()
    var oldestSeen = Long.MAX_VALUE
    var highest = 0.0
    var lowest = Double.POSITIVE_INFINITY
    var pages = 0
    var complete = false
    while (pages < 120) {
        val url = historyCandlesUrl(symbol, isSpot, if (isSpot) "1D" else "1D", endTime)
        val batch = parseCandles(getJson(url))
        if (batch.isEmpty()) { complete = true; break }
        val oldest = batch.minOf { it.time }
        if (oldest >= oldestSeen) break
        oldestSeen = oldest
        batch.forEach { c ->
            if (c.high > 0.0 && c.high.isFinite()) highest = max(highest, c.high)
            if (c.low > 0.0 && c.low.isFinite()) lowest = min(lowest, c.low)
        }
        pages++
        if (batch.size < 200) { complete = true; break }
        endTime = oldest - 1L
    }
    val valid = highest > 0.0 && lowest.isFinite() && lowest > 0.0
    return tickerValues.copy(
        allTimeHigh = if (valid) highest else 0.0,
        allTimeLow = if (valid) lowest else 0.0,
        historyComplete = complete && valid
    )
}

private fun ema(values: List<Double>, period: Int): Double {
    if (values.isEmpty()) return 0.0
    val alpha = 2.0 / (period + 1.0)
    var result = values.take(min(period, values.size)).average()
    for (v in values.drop(min(period, values.size))) result = alpha * v + (1 - alpha) * result
    return result
}
private fun calculateRsi(candles: List<Candle>, period: Int = 14): Double? {
    if (candles.size <= period) return null
    val closes = candles.map { it.close }
    var avgGain = 0.0
    var avgLoss = 0.0
    for (i in 1..period) {
        val delta = closes[i] - closes[i - 1]
        if (delta > 0.0) avgGain += delta else avgLoss -= delta
    }
    avgGain /= period
    avgLoss /= period
    for (i in period + 1 until closes.size) {
        val delta = closes[i] - closes[i - 1]
        avgGain = (avgGain * (period - 1) + max(delta, 0.0)) / period
        avgLoss = (avgLoss * (period - 1) + max(-delta, 0.0)) / period
    }
    if (avgLoss == 0.0) return if (avgGain > 0.0) 100.0 else 50.0
    val rs = avgGain / avgLoss
    return 100.0 - (100.0 / (1.0 + rs))
}

private data class SupertrendValue(val level: Double, val bullish: Boolean)

private fun calculateSupertrend(candles: List<Candle>, period: Int = 10, multiplier: Double = 3.0): SupertrendValue {
    if (candles.size < period + 2) return SupertrendValue(candles.lastOrNull()?.close ?: 0.0, true)
    val trs = candles.mapIndexed { i, c ->
        if (i == 0) c.high - c.low else max(c.high - c.low, max(kotlin.math.abs(c.high - candles[i - 1].close), kotlin.math.abs(c.low - candles[i - 1].close)))
    }
    val atrValues = MutableList(candles.size) { 0.0 }
    atrValues[period - 1] = trs.take(period).average()
    for (i in period until trs.size) atrValues[i] = (atrValues[i - 1] * (period - 1) + trs[i]) / period
    var finalUpper = 0.0
    var finalLower = 0.0
    var trendUp = true
    var st = 0.0
    for (i in period until candles.size) {
        val localAtr = atrValues[i]
        val mid = (candles[i].high + candles[i].low) / 2.0
        val basicUpper = mid + multiplier * localAtr
        val basicLower = mid - multiplier * localAtr
        if (i == period) {
            finalUpper = basicUpper
            finalLower = basicLower
            trendUp = candles[i].close >= mid
        } else {
            finalUpper = if (basicUpper < finalUpper || candles[i - 1].close > finalUpper) basicUpper else finalUpper
            finalLower = if (basicLower > finalLower || candles[i - 1].close < finalLower) basicLower else finalLower
            trendUp = if (trendUp && candles[i].close < finalLower) false else if (!trendUp && candles[i].close > finalUpper) true else trendUp
        }
        st = if (trendUp) finalLower else finalUpper
    }
    return SupertrendValue(st, trendUp)
}

private fun calculateFibonacciLevels(candles: List<Candle>): List<Pair<String, Double>> {
    if (candles.size < 5) return emptyList()
    val recent = candles.takeLast(60)
    val low = recent.minOf { it.low }
    val high = recent.maxOf { it.high }
    if (!low.isFinite() || !high.isFinite() || low <= 0.0 || high <= low) return emptyList()
    val range = high - low
    return listOf(0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0).map { ratio ->
        val price = high - range * ratio
        ("%.1f%%".format(Locale.US, ratio * 100.0)) to price
    }
}

private fun analyze(candles: List<Candle>, tf: String): IndicatorRow {
    val closes = candles.map { it.close }
    val price = closes.last()
    val emas = listOf(9,14,21,50,100,200).associateWith { ema(closes, it) }
    var obv = 0.0
    for (i in 1 until candles.size) obv += when { candles[i].close > candles[i-1].close -> candles[i].volume; candles[i].close < candles[i-1].close -> -candles[i].volume; else -> 0.0 }
    val recentObvMove = candles.takeLast(21).zipWithNext().sumOf { (previous, current) ->
        when { current.close > previous.close -> current.volume; current.close < previous.close -> -current.volume; else -> 0.0 }
    }
    val obvRising = recentObvMove >= 0.0
    val macdSeries = mutableListOf<Double>()
    for (i in closes.indices) macdSeries.add(ema(closes.take(i + 1), 12) - ema(closes.take(i + 1), 26))
    val macd = macdSeries.lastOrNull() ?: 0.0
    val signal = ema(macdSeries, 9)
    val hist = macd - signal
    val rsi = calculateRsi(candles)
    val supertrend = calculateSupertrend(candles)
    val recentVolumes = candles.takeLast(21).map { it.volume }
    val volume = recentVolumes.lastOrNull() ?: 0.0
    val averageVolume = if (recentVolumes.size > 1) recentVolumes.dropLast(1).average() else volume
    val votes =
        (if (price > emas.getValue(9)) 1 else -1) +
        (if (price > emas.getValue(21)) 1 else -1) +
        (if (price > emas.getValue(50)) 1 else -1) +
        (if (emas.getValue(9) > emas.getValue(21)) 1 else -1) +
        (if (hist > 0) 1 else -1) +
        (if (obvRising) 1 else -1) +
        (if ((rsi ?: 50.0) > 55.0) 1 else if ((rsi ?: 50.0) < 45.0) -1 else 0) +
        (if (supertrend.bullish) 1 else -1) +
        (if (averageVolume > 0.0 && volume > averageVolume) if (price >= candles[candles.lastIndex - 1].close) 1 else -1 else 0)
    val up = (50 + votes * 5).coerceIn(5, 95)
    val lows = candles.takeLast(30).map { it.low }
    val highs = candles.takeLast(30).map { it.high }
    val support = lows.minOrNull() ?: price
    val resistance = highs.maxOrNull() ?: price
    val setup = when {
        price > emas.getValue(50) && hist > 0 && supertrend.bullish -> "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry."
        price < emas.getValue(50) && hist < 0 && !supertrend.bullish -> "Bearish bias; SHORT only after confirmation; avoid chasing a drop."
        else -> "Mixed signals; wait for a confirmed breakout or support rejection."
    }
    return IndicatorRow(tf, price, emas, obv, obvRising, macd, signal, hist, up, 100-up, support, resistance, setup, rsi, volume, averageVolume, supertrend.level, supertrend.bullish)
}

@Composable
private fun CandleChart(candles: List<Candle>, high24h: Double, low24h: Double, currentPrice: Double?, fibonacciLevels: List<Pair<String, Double>> = emptyList(), modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.background(Color(0xFF0B1220), RoundedCornerShape(12.dp)).padding(8.dp)) {
        if (candles.isEmpty()) return@Canvas
        val visible = candles.takeLast(60)
        val candleMin = visible.minOf { it.low }
        val candleMax = visible.maxOf { it.high }
        val minPrice = listOfNotNull(candleMin, low24h.takeIf { it > 0.0 }, currentPrice?.takeIf { it > 0.0 }).minOrNull() ?: candleMin
        val maxPrice = listOfNotNull(candleMax, high24h.takeIf { it > 0.0 }, currentPrice?.takeIf { it > 0.0 }).maxOrNull() ?: candleMax
        val range = (maxPrice - minPrice).takeIf { it > 0.0 } ?: (maxPrice * 0.01).coerceAtLeast(0.00000001)
        val candleWidth = (size.width / visible.size * 0.62f).coerceAtLeast(2f)
        val step = size.width / visible.size
        val channel = detectDescendingPriceChannel(visible)
        visible.forEachIndexed { index, candle ->
            val x = step * index + step / 2f
            fun y(value: Double) = size.height - (((value - minPrice) / range).toFloat() * size.height)
            val rising = candle.close >= candle.open
            val color = if (rising) Color(0xFF22C55E) else Color(0xFFEF4444)
            drawLine(color, Offset(x, y(candle.high)), Offset(x, y(candle.low)), strokeWidth = 1.5f)
            val top = minOf(y(candle.open), y(candle.close))
            val bottom = maxOf(y(candle.open), y(candle.close))
            drawRect(color, topLeft = Offset(x - candleWidth / 2f, top), size = androidx.compose.ui.geometry.Size(candleWidth, (bottom - top).coerceAtLeast(1.5f)))
        }
        fun yLevel(value: Double) = size.height - (((value - minPrice) / range).toFloat() * size.height)
        fun dashedLevel(value: Double, color: Color) {
            if (value <= 0.0 || !value.isFinite()) return
            val y = yLevel(value)
            var x = 0f
            while (x < size.width) {
                drawLine(color, Offset(x, y), Offset((x + 7f).coerceAtMost(size.width), y), strokeWidth = 2f)
                x += 12f
            }
        }
        // Fibonacci retracement lines are shown when the selected chart is 15m.
        fibonacciLevels.forEachIndexed { index, level -> dashedLevel(level.second, listOf(Color(0xFFA78BFA), Color(0xFF60A5FA), Color(0xFFFFD166), Color(0xFF5EEAD4), Color(0xFFF472B6), Color(0xFF93C5FD), Color(0xFFCBD5E1))[index % 7]) }
        // Draw a descending channel only when recent highs and lows form a reasonably parallel downward structure.
        channel?.let { ch ->
            fun channelY(value: Double) = yLevel(value)
            val startX = step * ch.startIndex + step / 2f
            val endX = step * (visible.lastIndex) + step / 2f
            drawLine(Color(0xFFFF718B), Offset(startX, channelY(ch.upperStart)), Offset(endX, channelY(ch.upperEnd)), strokeWidth = 2.6f)
            drawLine(Color(0xFF60A5FA), Offset(startX, channelY(ch.lowerStart)), Offset(endX, channelY(ch.lowerEnd)), strokeWidth = 2.6f)
        }
        // Rolling 24-hour levels stay the same when the chart timeframe changes.
        dashedLevel(high24h, Color(0xFF5EEAD4))
        dashedLevel(low24h, Color(0xFFFF9EB5))
        // Live ticker price line; it moves whenever the exchange ticker refreshes.
        currentPrice?.takeIf { it > 0.0 && it.isFinite() }?.let { live ->
            val y = yLevel(live)
            drawLine(Color(0xFFFFD166), Offset(0f, y), Offset(size.width, y), strokeWidth = 2.5f)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzerApp(onBeforeAnalysis: suspend () -> Boolean) {
    val context = LocalContext.current
    val preferences = remember(context) { context.getSharedPreferences("cryptoanalyser_preferences", android.content.Context.MODE_PRIVATE) }
    var symbol by remember { mutableStateOf("BTCUSDT") }
    var listedSymbols by remember { mutableStateOf<List<String>>(emptyList()) }
    var showSuggestions by remember { mutableStateOf(false) }
    var market by remember { mutableStateOf("Spot") }
    var platform by remember { mutableStateOf(preferences.getString("market_platform", "Bitget") ?: "Bitget") }
    var showPlatformMenu by remember { mutableStateOf(false) }
    var showInlineLanguageMenu by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var price by remember { mutableStateOf<Double?>(null) }
    var extremes by remember { mutableStateOf<PriceExtremes?>(null) }
    var chartCandles by remember { mutableStateOf<List<Candle>>(emptyList()) }
    var chartTimeframe by remember { mutableStateOf("4H") }
    var chartLoading by remember { mutableStateOf(false) }
    var livePriceUpdatedAt by remember { mutableStateOf(0L) }
    var rows by remember { mutableStateOf<List<IndicatorRow>>(emptyList()) }
    var backtest by remember { mutableStateOf("") }
    var news by remember { mutableStateOf<List<MarketNews>>(emptyList()) }
    var newsLoading by remember { mutableStateOf(false) }
    var newsError by remember { mutableStateOf("") }
    var selectedNews by remember { mutableStateOf<MarketNews?>(null) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var technicalExpanded by remember { mutableStateOf(true) }
    var adviceExpanded by remember { mutableStateOf(true) }
    var adviceQuestion by remember { mutableStateOf("") }
    var adviceEntryPrice by remember { mutableStateOf("") }
    var adviceQuantity by remember { mutableStateOf("") }
    var adviceTargetPrice by remember { mutableStateOf("") }
    var adviceAnswer by remember { mutableStateOf("") }
    var adviceLoading by remember { mutableStateOf(false) }
    var adviceError by remember { mutableStateOf("") }
    var newsExpanded by remember { mutableStateOf(false) }
    var researchExpanded by remember { mutableStateOf(true) }
    var researchTopic by remember { mutableStateOf("") }
    var researchWebUrl by remember { mutableStateOf("") }
    var researchWebTitle by remember { mutableStateOf("") }
    var bitgetCoinProfile by remember { mutableStateOf<BitgetCoinProfile?>(null) }
    var bitgetCoinProfileLoading by remember { mutableStateOf(false) }
    var bitgetCoinProfileError by remember { mutableStateOf("") }
    var coinFundamentals by remember { mutableStateOf<CoinFundamentals?>(null) }
    var coinFundamentalsLoading by remember { mutableStateOf(false) }
    var coinFundamentalsError by remember { mutableStateOf("") }
    var alertsExpanded by remember { mutableStateOf(false) }
    var recentSymbols by remember { mutableStateOf<List<String>>(emptyList()) }
    var favoriteSymbols by remember { mutableStateOf<List<String>>(emptyList()) }
    var unlocksExpanded by remember { mutableStateOf(false) }
    var priceAlerts by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var editingAlertId by remember { mutableStateOf<Long?>(null) }
    var alertSymbol by remember { mutableStateOf("BTCUSDT") }
    var alertTarget by remember { mutableStateOf("") }
    var alertDirection by remember { mutableStateOf("ABOVE") }
    var alertMarket by remember { mutableStateOf("Spot") }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        recentSymbols = try { val a = JSONArray(preferences.getString("recent_symbols", "[]")); (0 until minOf(a.length(), 50)).mapNotNull { a.optString(it).takeIf(String::isNotBlank) } } catch (_: Exception) { emptyList() }
        favoriteSymbols = try { val a = JSONArray(preferences.getString("favorite_symbols", "[]")); (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) } } catch (_: Exception) { emptyList() }
        priceAlerts = try { val a = JSONArray(preferences.getString("price_alerts", "[]")); (0 until a.length()).mapNotNull { a.optJSONObject(it) } } catch (_: Exception) { emptyList() }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val request = PeriodicWorkRequestBuilder<PriceAlertWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("crypto_price_alert_monitor", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
    var voiceGender by remember { mutableStateOf(preferences.getString("summary_voice_gender", "female") ?: "female") }
    var voiceName by remember { mutableStateOf(preferences.getString("summary_voice_name", "sara") ?: "sara") }
    var appLanguage by remember { mutableStateOf(preferences.getString("app_language", "en") ?: "en") }
    var showLanguageMenu by remember { mutableStateOf(false) }
    var speechWordOffset by remember { mutableIntStateOf(0) }
    var activeSpeechText by remember { mutableStateOf("") }
    var speechReady by remember { mutableStateOf(true) }
    var voiceBusy by remember { mutableStateOf(false) }
    var voiceError by remember { mutableStateOf("") }
    var localTtsReady by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    // Fully free on-device speech: no cloud account, API key, or external service.
    val localTts = remember(context) {
        TextToSpeech(context.applicationContext) { status ->
            localTtsReady = status == TextToSpeech.SUCCESS
        }
    }
    DisposableEffect(localTts) {
        onDispose { try { localTts.stop(); localTts.shutdown() } catch (_: Exception) { } }
    }
    fun stopVoicePlayback() {
        try { localTts.stop() } catch (_: Exception) { }
        voiceBusy = false
    }
    fun speakLocally(text: String, offset: Int = 0) {
        if (!localTtsReady) {
            voiceBusy = false
            voiceError = when (appLanguage) {
                "ar" -> "محرك الصوت المدمج ما زال يتهيأ. انتظر لحظة ثم اضغط تشغيل مجددًا."
                "fr" -> "Le moteur vocal intégré démarre encore. Attendez un instant puis réessayez."
                else -> "The built-in speech engine is still starting. Wait a moment and try again."
            }
            return
        }
        try {
            val localeTag = when (appLanguage) {
                "ar" -> "ar-SA"; "fr" -> "fr-FR"; "en" -> "en-US"; "zh" -> "zh-CN"
                "ja" -> "ja-JP"; "es" -> "es-ES"; "de" -> "de-DE"; "it" -> "it-IT"; "ko" -> "ko-KR"
                else -> "en-US"
            }
            var languageResult = localTts.setLanguage(Locale.forLanguageTag(localeTag))
            if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                languageResult = localTts.setLanguage(Locale.forLanguageTag(appLanguage))
            }
            if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                voiceBusy = false
                voiceError = when (appLanguage) {
                    "ar" -> "لا يوجد صوت مثبت يدعم هذه اللغة على الهاتف. لم يتم تشغيل أي خدمة مدفوعة أو تنزيل شيء تلقائيًا."
                    "fr" -> "Aucune voix disponible sur ce téléphone pour cette langue. Aucun service payant ni téléchargement automatique n’a été utilisé."
                    else -> "No installed voice supports this language on this phone. No paid service or automatic download was used."
                }
                return
            }
            localTts.setSpeechRate(0.92f)
            localTts.setPitch(if (voiceGender == "female") 1.08f else 0.94f)
            val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
            if (words.isEmpty()) { voiceBusy = false; return }
            val start = offset.coerceIn(0, max(0, words.size - 1))
            speechWordOffset = start
            voiceError = ""
            voiceBusy = true
            // Android TTS has an input-size limit. Queue short sentence-aware chunks for long reports.
            val remaining = words.drop(start).joinToString(" ")
            val chunks = mutableListOf<String>()
            var pending = StringBuilder()
            remaining.split(Regex("(?<=[.!?。！？])\\s+")).forEach { sentence ->
                if (pending.isNotEmpty() && pending.length + sentence.length + 1 > 2800) {
                    chunks.add(pending.toString().trim()); pending = StringBuilder()
                }
                if (sentence.length > 2800) {
                    sentence.chunked(2400).forEach { part -> if (pending.isNotEmpty()) { chunks.add(pending.toString().trim()); pending = StringBuilder() }; chunks.add(part) }
                } else {
                    if (pending.isNotEmpty()) pending.append(' ')
                    pending.append(sentence)
                }
            }
            if (pending.isNotEmpty()) chunks.add(pending.toString().trim())
            localTts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { }
                override fun onDone(utteranceId: String?) {
                    if (utteranceId?.endsWith("-${chunks.lastIndex}") == true) voiceBusy = false
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { voiceBusy = false; voiceError = "Speech playback failed." }
                override fun onError(utteranceId: String?, errorCode: Int) { voiceBusy = false; voiceError = "Speech playback failed ($errorCode)." }
            })
            chunks.forEachIndexed { index, chunk ->
                localTts.speak(chunk, if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "crypto-${System.currentTimeMillis()}-$index")
            }
        } catch (e: Exception) {
            voiceBusy = false
            voiceError = e.message ?: "Speech playback failed."
        }
    }
    val spokenSummary = remember(price, symbol, rows, appLanguage, chartCandles, chartTimeframe, market) {
        if (rows.isEmpty()) when (appLanguage) {
            "fr" -> "Lancez une analyse du marché pour écouter le résumé."
            "ar" -> "ابدأ تحليل السوق للاستماع إلى الملخص."
            "es" -> "Analiza el mercado primero para escuchar el resumen."
            "de" -> "Führen Sie zuerst eine Marktanalyse durch, um die Zusammenfassung zu hören."
            "it" -> "Esegui prima un'analisi del mercato per ascoltare il riepilogo."
            "zh" -> "请先运行市场分析以收听摘要。"
            "ja" -> "要約を聞くには先に市場分析を実行してください。"
            "ko" -> "요약을 들으려면 먼저 시장 분석을 실행하세요."
            else -> "Run a market analysis first to hear the summary."
        } else {
            val candles = chartCandles.sortedBy { it.time }
            val current = price ?: candles.lastOrNull()?.close
            val latest = candles.lastOrNull()
            val previous = candles.getOrNull(candles.lastIndex - 1)
            val shortMove = if (latest != null && previous != null && previous.close != 0.0) (latest.close - previous.close) / previous.close * 100.0 else null
            val rsi = calculateRsi(candles)
            val selected = rows.firstOrNull { it.timeframe.contains(chartTimeframe, ignoreCase = true) }
                ?: rows.minByOrNull { kotlin.math.abs(it.price - (current ?: it.price)) }
                ?: rows.first()
            val support = candles.takeLast(30).minOfOrNull { it.low } ?: selected.support
            val resistance = candles.takeLast(30).maxOfOrNull { it.high } ?: selected.resistance
            val bull = selected.upProbability
            val bear = selected.downProbability
            val momentum = when {
                bull >= bear + 8 && selected.hist > 0.0 && selected.macd > selected.signal -> "bull"
                bear >= bull + 8 && selected.hist < 0.0 && selected.macd < selected.signal -> "bear"
                bull > bear -> "slightBull"
                bear > bull -> "slightBear"
                else -> "mixed"
            }
            val frames = rows.filter { row ->
                val t = row.timeframe.uppercase().replace(" ", "")
                t.contains("15") || t.contains("1H") || t.contains("60") || t.contains("4H") || t.contains("240")
            }.take(3)
            val frameText = frames.joinToString(". ") { row ->
                val direction = when {
                    row.upProbability >= row.downProbability + 8 -> when (appLanguage) { "ar" -> "المشترون أرجح"; "fr" -> "avantage acheteurs"; "es" -> "ventaja compradora"; "de" -> "Käufer im Vorteil"; "it" -> "vantaggio compratori"; "zh" -> "买方占优"; "ja" -> "買い手優勢"; "ko" -> "매수세 우위"; else -> "buyers have the edge" }
                    row.downProbability >= row.upProbability + 8 -> when (appLanguage) { "ar" -> "البائعون أرجح"; "fr" -> "avantage vendeurs"; "es" -> "ventaja vendedora"; "de" -> "Verkäufer im Vorteil"; "it" -> "vantaggio venditori"; "zh" -> "卖方占优"; "ja" -> "売り手優勢"; "ko" -> "매도세 우위"; else -> "sellers have the edge" }
                    else -> when (appLanguage) { "ar" -> "التوازن مختلط"; "fr" -> "signal partagé"; "es" -> "señal mixta"; "de" -> "gemischtes Signal"; "it" -> "segnale misto"; "zh" -> "信号混合"; "ja" -> "方向感は混在"; "ko" -> "신호 혼조"; else -> "mixed signal" }
                }
                "${row.timeframe}: $direction"
            }
            val macdText = when {
                selected.hist > 0.0 && selected.macd > selected.signal -> when (appLanguage) { "ar" -> "MACD صاعد ويتحسن"; "fr" -> "MACD haussier"; "es" -> "MACD alcista"; "de" -> "MACD bullisch"; "it" -> "MACD rialzista"; "zh" -> "MACD 偏多"; "ja" -> "MACDは強気"; "ko" -> "MACD 상승 우위"; else -> "MACD bullish" }
                selected.hist < 0.0 && selected.macd < selected.signal -> when (appLanguage) { "ar" -> "MACD هابط"; "fr" -> "MACD baissier"; "es" -> "MACD bajista"; "de" -> "MACD bärisch"; "it" -> "MACD ribassista"; "zh" -> "MACD 偏空"; "ja" -> "MACDは弱気"; "ko" -> "MACD 하락 우위"; else -> "MACD bearish" }
                else -> when (appLanguage) { "ar" -> "MACD غير حاسم"; "fr" -> "MACD neutre"; "es" -> "MACD sin confirmación"; "de" -> "MACD uneindeutig"; "it" -> "MACD incerto"; "zh" -> "MACD 信号不明"; "ja" -> "MACDは不明瞭"; "ko" -> "MACD 신호 불명확"; else -> "MACD mixed" }
            }
            val rsiText = if (rsi == null) when (appLanguage) { "ar" -> "RSI غير متاح"; "fr" -> "RSI indisponible"; else -> "RSI unavailable" } else when (appLanguage) {
                "ar" -> "RSI ${String.format(Locale.US, "%.0f", rsi)}، ${when { rsi >= 70 -> "تشبع شراء محتمل"; rsi <= 30 -> "تشبع بيع محتمل، دون ضمان ارتداد"; rsi >= 55 -> "زخم شرائي"; rsi <= 45 -> "زخم بيعي"; else -> "زخم متوازن" }}"
                "fr" -> "RSI ${String.format(Locale.US, "%.0f", rsi)}, ${when { rsi >= 70 -> "surachat possible"; rsi <= 30 -> "survente possible"; rsi >= 55 -> "momentum acheteur"; rsi <= 45 -> "momentum vendeur"; else -> "momentum neutre" }}"
                "es" -> "RSI ${String.format(Locale.US, "%.0f", rsi)}, ${when { rsi >= 70 -> "posible sobrecompra"; rsi <= 30 -> "posible sobreventa"; rsi >= 55 -> "impulso comprador"; rsi <= 45 -> "impulso vendedor"; else -> "impulso neutral" }}"
                "de" -> "RSI ${String.format(Locale.US, "%.0f", rsi)}, ${when { rsi >= 70 -> "möglicherweise überkauft"; rsi <= 30 -> "möglicherweise überverkauft"; rsi >= 55 -> "Kaufmomentum"; rsi <= 45 -> "Verkaufsdruck"; else -> "neutrales Momentum" }}"
                "it" -> "RSI ${String.format(Locale.US, "%.0f", rsi)}, ${when { rsi >= 70 -> "possibile ipercomprato"; rsi <= 30 -> "possibile ipervenduto"; rsi >= 55 -> "spinta rialzista"; rsi <= 45 -> "spinta ribassista"; else -> "spinta neutra" }}"
                "zh" -> "RSI ${String.format(Locale.US, "%.0f", rsi)}，${when { rsi >= 70 -> "可能超买"; rsi <= 30 -> "可能超卖"; rsi >= 55 -> "买方动能"; rsi <= 45 -> "卖方动能"; else -> "动能中性" }}"
                "ja" -> "RSI ${String.format(Locale.US, "%.0f", rsi)}、${when { rsi >= 70 -> "買われ過ぎの可能性"; rsi <= 30 -> "売られ過ぎの可能性"; rsi >= 55 -> "買いの勢い"; rsi <= 45 -> "売りの勢い"; else -> "中立的な勢い" }}"
                "ko" -> "RSI ${String.format(Locale.US, "%.0f", rsi)}, ${when { rsi >= 70 -> "과매수 가능성"; rsi <= 30 -> "과매도 가능성"; rsi >= 55 -> "매수 모멘텀"; rsi <= 45 -> "매도 모멘텀"; else -> "중립 모멘텀" }}"
                else -> "RSI ${String.format(Locale.US, "%.0f", rsi)}, ${when { rsi >= 70 -> "possible overbought"; rsi <= 30 -> "possible oversold"; rsi >= 55 -> "buyer momentum"; rsi <= 45 -> "seller momentum"; else -> "neutral momentum" }}"
            }
            val outlook = when (momentum) {
                "bull" -> when (appLanguage) { "ar" -> "السيناريو الأقرب صعود محدود نحو المقاومة إذا استمر الزخم؛ ضعف MACD أو رفض المقاومة يرجح التراجع."; "fr" -> "Scénario privilégié : poursuite haussière vers la résistance si le momentum tient ; un rejet favoriserait un repli."; else -> "Near-term bias is upward toward resistance if momentum holds; a rejection could trigger a pullback." }
                "bear" -> when (appLanguage) { "ar" -> "السيناريو الأقرب هابط نحو الدعم إذا استمر الضغط؛ ضعف البيع أو ارتداد مؤكد قد يغير الصورة."; "fr" -> "Scénario privilégié : baisse vers le support si la pression persiste ; un rebond confirmé invaliderait ce biais."; else -> "Near-term bias is downward toward support if selling pressure persists; a confirmed bounce could change the outlook." }
                else -> when (appLanguage) { "ar" -> "الاتجاه غير محسوم؛ الحركة بين الدعم والمقاومة أوضح من توقع اتجاه واحد. انتظر كسرًا مؤكدًا أو ارتدادًا واضحًا."; "fr" -> "Direction incertaine : le prix peut osciller entre support et résistance. Attendre une cassure ou un rebond confirmé."; else -> "Direction is unclear; price may range between support and resistance. Wait for a confirmed breakout or bounce." }
            }
            when (appLanguage) {
                "ar" -> buildString {
                    append(symbol).append(". ")
                    current?.let { append("السعر ").append(speechPrice(it, appLanguage)).append(". ") }
                    if (frameText.isNotBlank()) append("القوة حسب الأطر: ").append(frameText).append(". ")
                    append("على إطار ").append(chartTimeframe).append("، ").append(rsiText).append("؛ ").append(macdText).append(". ")
                    append("الدعم الأقرب ").append(speechPrice(support, appLanguage)).append("، والمقاومة ").append(speechPrice(resistance, appLanguage)).append(". ")
                    if (latest != null && latest.low <= support * 1.002 && latest.close > support) append("السعر لمس الدعم وأغلق فوقه؛ ارتداد محتمل يحتاج تأكيدًا. ")
                    else if (latest != null && latest.high >= resistance * 0.998 && latest.close < resistance) append("السعر اختبر المقاومة وأغلق دونها؛ رفض محتمل. ")
                    shortMove?.let { append("آخر شمعة ").append(if (it >= 0) "صاعدة " else "هابطة ").append(String.format(Locale.US, "%.2f", kotlin.math.abs(it))).append(" بالمئة. ") }
                    append(when (momentum) { "bull" -> "الزخم الشرائي أقوى حاليًا."; "bear" -> "الضغط البيعي أقوى حاليًا."; "slightBull" -> "أفضلية شرائية ضعيفة، وتحتاج تأكيدًا."; "slightBear" -> "أفضلية بيعية ضعيفة، وتحتاج تأكيدًا."; else -> "لا توجد أفضلية واضحة." }).append(" ")
                    append("Spot: راقب شراءً قرب الدعم بعد ارتداد مؤكد، أو بعد اختراق المقاومة وإعادة اختبارها. Futures Long: فقط بعد اختراق مؤكد وثبات فوق المقاومة. Futures Short: فقط بعد كسر الدعم وإعادة اختباره من الأسفل. لا تدخل عند مجرد لمس المستوى؛ ضع وقف خسارة. ")
                    append(outlook).append(" التوقع احتمالي وليس ضمانًا.")
                }
                "fr" -> buildString {
                    append(symbol).append(". "); current?.let { append("Prix ").append(speechPrice(it, appLanguage)).append(". ") }
                    if (frameText.isNotBlank()) append("Force par unité : ").append(frameText).append(". ")
                    append("En ").append(chartTimeframe).append(" : ").append(rsiText).append(" ; ").append(macdText).append(". Support proche ").append(speechPrice(support, appLanguage)).append(" ; résistance ").append(speechPrice(resistance, appLanguage)).append(". ")
                    shortMove?.let { append("Dernière bougie : ").append(String.format(Locale.US, "%.2f", kotlin.math.abs(it))).append(" % ").append(if (it >= 0) "à la hausse. " else "à la baisse. ") }
                    append("Spot : attendre un rebond confirmé sur support ou une cassure suivie d'un retest. Long : cassure confirmée de la résistance. Short : rupture confirmée du support. Stop obligatoire. ").append(outlook).append(" Prévision incertaine.")
                }
                else -> buildString {
                    append(symbol).append(". "); current?.let { append("Price ").append(speechPrice(it, appLanguage)).append(". ") }
                    if (frameText.isNotBlank()) append("Timeframe strength: ").append(frameText).append(". ")
                    append(chartTimeframe).append(": ").append(rsiText).append("; ").append(macdText).append(". Support ").append(speechPrice(support, appLanguage)).append("; resistance ").append(speechPrice(resistance, appLanguage)).append(". ")
                    shortMove?.let { append("Last candle ").append(if (it >= 0) "rose " else "fell ").append(String.format(Locale.US, "%.2f", kotlin.math.abs(it))).append(" percent. ") }
                    append("Spot: wait for a confirmed support bounce or breakout retest. Futures Long: confirmed resistance breakout. Futures Short: confirmed support breakdown. Always define a stop. ").append(outlook).append(" This is an uncertain scenario, not a guarantee.")
                }
            }
        }
    }

    val spokenCoinProfile = remember(symbol, appLanguage, price, extremes, bitgetCoinProfile, coinFundamentals) {
        val coin = symbol.removeSuffix("USDT").removeSuffix("USDC").removeSuffix("BUSD").removeSuffix("FDUSD")
        val fundamentals = coinFundamentals?.takeIf { !it.ambiguous && it.symbol.equals(coin, true) }
        val listing = bitgetCoinProfile?.firstListingTime?.let { SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date(it)) }
        val ath = extremes?.takeIf { it.historyComplete && it.allTimeHigh > 0 }?.allTimeHigh
        val atl = extremes?.takeIf { it.historyComplete && it.allTimeLow > 0 }?.allTimeLow
        val description = fundamentals?.description?.takeIf { it.isNotBlank() }
        val tags = fundamentals?.tags?.takeIf { it.isNotEmpty() }?.take(3)?.joinToString(", ")
        when (appLanguage) {
            "ar" -> buildString {
                append("نبذة مختصرة عن ").append(fundamentals?.name ?: coin).append(" (الرمز ").append(coin).append("). ")
                if (description != null) append(description.take(420)).append(" ")
                if (tags != null) append("التصنيفات: ").append(tags).append(". ")
                if (listing != null) append("تاريخ الإدراج المسجل على Bitget: ").append(listing).append(". ")
                if (ath != null) append("أعلى سعر تاريخي مؤكد في السجل المتاح: ").append(speechPrice(ath, appLanguage)).append(". ")
                if (atl != null) append("أدنى سعر تاريخي مؤكد: ").append(speechPrice(atl, appLanguage)).append(". ")
                append("تقييم قوة المشروع يحتاج إلى التحقق من الاستخدام الفعلي والتطوير والشراكات والسيولة وتوزيع العملات. هذه نبذة معلوماتية وليست ضمانًا للربح.")
            }
            "fr" -> buildString {
                append("Présentation concise de ").append(fundamentals?.name ?: coin).append(" (symbole ").append(coin).append("). ")
                if (description != null) append(description.take(420)).append(" ")
                if (tags != null) append("Catégories : ").append(tags).append(". ")
                if (listing != null) append("Première cotation enregistrée sur Bitget : ").append(listing).append(". ")
                if (ath != null) append("Plus haut historique confirmé dans les données disponibles : ").append(speechPrice(ath, appLanguage)).append(". ")
                if (atl != null) append("Plus bas historique confirmé : ").append(speechPrice(atl, appLanguage)).append(". ")
                append("La solidité du projet doit être évaluée à partir de son usage réel, de son développement, de ses partenariats, de sa liquidité et de la distribution des tokens. Cette présentation ne garantit aucun rendement.")
            }
            else -> buildString {
                append("Brief profile of ").append(fundamentals?.name ?: coin).append(" (ticker ").append(coin).append("). ")
                if (description != null) append(description.take(420)).append(" ")
                if (tags != null) append("Categories: ").append(tags).append(". ")
                if (listing != null) append("First listing recorded on Bitget: ").append(listing).append(". ")
                if (ath != null) append("Confirmed all-time high in available history: ").append(speechPrice(ath, appLanguage)).append(". ")
                if (atl != null) append("Confirmed all-time low: ").append(speechPrice(atl, appLanguage)).append(". ")
                append("Project strength should be assessed through real usage, development, partnerships, liquidity and token distribution. This information is not a profit guarantee.")
            }
        }
    }

    fun speakFromWord(wordOffset: Int) {
        val textToSpeak = activeSpeechText.ifBlank { spokenSummary }.trim()
        if (textToSpeak.isBlank()) return
        stopVoicePlayback()
        speakLocally(textToSpeak, wordOffset)
    }
    LaunchedEffect(symbol) {
        val baseCoin = symbol.trim().uppercase(Locale.ROOT)
            .replace("/", "").replace("-", "").replace("_", "").replace(" ", "")
            .removeSuffix("USDT").removeSuffix("USDC").removeSuffix("BUSD").removeSuffix("FDUSD")
        if (baseCoin.isNotBlank() && baseCoin.matches(Regex("[A-Z0-9]{2,20}"))) {
            bitgetCoinProfileLoading = true
            bitgetCoinProfileError = ""
            bitgetCoinProfile = null
            try {
                bitgetCoinProfile = withContext(Dispatchers.IO) { loadBitgetCoinProfile(baseCoin) }
            } catch (e: Exception) {
                bitgetCoinProfileError = e.message ?: "Bitget data unavailable"
            } finally {
                bitgetCoinProfileLoading = false
            }
        }
    }
    LaunchedEffect(symbol) {
        val baseCoin = symbol.trim().uppercase(Locale.ROOT)
            .replace("/", "").replace("-", "").replace("_", "").replace(" ", "")
            .removeSuffix("USDT").removeSuffix("USDC").removeSuffix("BUSD").removeSuffix("FDUSD")
        if (baseCoin.isNotBlank() && baseCoin.matches(Regex("[A-Z0-9]{2,20}"))) {
            coinFundamentalsLoading = true
            coinFundamentalsError = ""
            coinFundamentals = null
            try {
                coinFundamentals = withContext(Dispatchers.IO) { loadCoinFundamentals(baseCoin) }
            } catch (e: Exception) {
                coinFundamentalsError = e.message ?: "Free project data unavailable"
            } finally {
                coinFundamentalsLoading = false
            }
        }
    }
    LaunchedEffect(market, platform) {
        listedSymbols = withContext(Dispatchers.IO) {
            try {
                loadListedUsdtSymbols(market, platform)
            } catch (_: Exception) {
                // Keep the input usable if Bitget's symbol-list endpoint is temporarily unavailable.
                listOf("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "BNBUSDT", "DOGEUSDT", "AIAVUSDT")
            }
        }
    }
    // Load candles once for the selected pair/timeframe, then refresh them every 15 seconds.
    // The effect does not depend on the changing ticker price, so the chart is not cleared on each tick.
    LaunchedEffect(symbol, market, platform, chartTimeframe, price != null) {
        if (price == null) {
            chartCandles = emptyList()
        } else {
            val chartSymbol = symbol.trim().uppercase(Locale.ROOT).replace("/", "").replace("-", "").replace("_", "").replace(" ", "")
            val granularity = when (chartTimeframe) {
                "5m" -> "5m"
                "15m" -> if (platform == "Binance") "15m" else if (market == "Spot") "15min" else "15m"
                "1H" -> if (market == "Spot") "1h" else "1H"
                "4H" -> if (market == "Spot") "4h" else "4H"
                "1D" -> if (market == "Spot") "1day" else "1D"
                else -> "1M"
            }
            while (true) {
                chartLoading = chartCandles.isEmpty()
                try {
                    val candles = withContext(Dispatchers.IO) { loadMarketCandles(chartSymbol, market, platform, granularity, 100) }
                    if (candles.isNotEmpty()) chartCandles = candles
                } catch (_: Exception) {
                    // Keep the last valid chart visible if a temporary refresh fails.
                } finally { chartLoading = false }
                delay(15_000L)
            }
        }
    }

    // Read the exchange's real ticker frequently. The latest value drives both the label and live price line.
    LaunchedEffect(symbol, market, platform, price != null) {
        if (price != null) {
            val liveSymbol = symbol.trim().uppercase(Locale.ROOT).replace("/", "").replace("-", "").replace("_", "").replace(" ", "")
            while (true) {
                try {
                    val latest = withContext(Dispatchers.IO) {
                        val root = getJson(marketTickerUrl(liveSymbol, market, platform))
                        val data = root.optJSONArray("data")
                        val ticker = if (platform == "Binance") root else if (data != null && data.length() > 0) data.optJSONObject(0) ?: JSONObject() else root.optJSONObject("data") ?: JSONObject()
                        ticker.optString(if (platform == "Binance") "lastPrice" else "lastPr", ticker.optString("last", "")).toDoubleOrNull()
                    }
                    if (latest != null && latest > 0.0 && latest.isFinite()) {
                        price = latest
                        livePriceUpdatedAt = System.currentTimeMillis()
                    }
                } catch (_: Exception) { /* Preserve last known price and retry on next tick. */ }
                delay(5_000L)
            }
        }
    }
    val cleanedQuery = symbol.trim().uppercase().replace("/", "").replace("-", "").replace("_", "").replace(" ", "")
    val suggestionQuery = cleanedQuery.removeSuffix("USDT")
    val filteredSuggestions = remember(listedSymbols, cleanedQuery, showSuggestions) {
        if (!showSuggestions || suggestionQuery.isBlank()) emptyList()
        else listedSymbols.filter { pair ->
            pair.startsWith(cleanedQuery) || pair.removeSuffix("USDT").startsWith(suggestionQuery)
        }.take(8)
    }
    val tfMap = listOf("5m" to "5m", "15m" to "15m", "1H" to "1H", "4H" to "4H", "1D" to "1D")
    val tradePlans = remember(price, rows) { val anchor = rows.firstOrNull { it.timeframe == "4H" }; if (price != null && anchor != null) buildTradePlans(price!!, anchor) else emptyList() }
    val fibonacciLevels = remember(chartCandles, chartTimeframe) { if (chartTimeframe == "15m") calculateFibonacciLevels(chartCandles) else emptyList() }

    fun runAnalysis() {
        val clean = try {
            normalizeUsdtSymbol(symbol)
        } catch (e: IllegalArgumentException) {
            error = e.message ?: "Enter a valid coin symbol, e.g. BTC or BTCUSDT."
            return
        }
        symbol = clean
        loading = true; error = ""; rows = emptyList(); backtest = ""; extremes = null
        scope.launch {
            // The server must authorize every analysis request before any coin data is fetched.
            if (!onBeforeAnalysis()) {
                loading = false
                error = "License verification failed. No market data was loaded."
                return@launch
            }
            recentSymbols = (listOf(clean) + recentSymbols.filterNot { it == clean }).take(50)
            preferences.edit().putString("recent_symbols", JSONArray().apply { recentSymbols.forEach { put(it) } }.toString()).apply()
            newsLoading = true; newsError = ""; news = emptyList()
            scope.launch {
                val selectedCoinName = coinFundamentals?.takeIf {
                    !it.ambiguous && it.symbol.equals(clean.removeSuffix("USDT").removeSuffix("USDC").removeSuffix("BUSD").removeSuffix("FDUSD"), true)
                }?.name
                val result = withContext(Dispatchers.IO) { loadRecentNews(clean, selectedCoinName) }
                news = result
                newsLoading = false
                if (result.isEmpty()) newsError = "Aucune actualité vérifiée disponible sur les 7 derniers jours. Réessayez plus tard."
            }
            try {
                val result = withContext(Dispatchers.IO) {
                    val isSpot = market == "Spot"
                    val tickerRoot = getJson(marketTickerUrl(clean, market, platform))
                    val tickerData = tickerRoot.optJSONArray("data")
                    val ticker = if (platform == "Binance") tickerRoot else if (tickerData != null && tickerData.length() > 0) tickerData.optJSONObject(0) ?: JSONObject() else tickerRoot.optJSONObject("data") ?: JSONObject()
                    val currentPrice = ticker.optString(if (platform == "Binance") "lastPrice" else "lastPr", ticker.optString("last", "")).toDoubleOrNull() ?: 0.0
                    val priceExtremes = if (platform == "Binance") PriceExtremes(0.0, 0.0, ticker.optString("highPrice").toDoubleOrNull() ?: 0.0, ticker.optString("lowPrice").toDoubleOrNull() ?: 0.0, false, true) else loadAllTimeExtremes(clean, isSpot, ticker)
                    val analyzed = mutableListOf<IndicatorRow>()
                    val candleSets = mutableListOf<Pair<String, List<Candle>>>()
                    for ((label, _) in tfMap) {
                        val granularity = when (label) {
                            "5m" -> "5m"
                            "15m" -> if (platform == "Binance") "15m" else if (market == "Spot") "15min" else "15m"
                            "1H" -> if (market == "Spot") "1h" else "1H"
                            "4H" -> if (market == "Spot") "4h" else "4H"
                            else -> if (market == "Spot") "1day" else "1D"
                        }
                        val candles = loadMarketCandles(clean, market, platform, granularity, 200)
                        if (candles.size < 30) throw Exception("$platform returned insufficient $label candles for $clean on $market. Check that this USDT pair is listed on the selected platform and market.")
                        candleSets.add(label to candles)
                        analyzed.add(analyze(candles, label))
                    }
                    val hourly = candleSets.first { it.first == "1H" }.second
                    // Simple educational EMA(9)/EMA(21) crossover backtest, one position at a time, close-to-close, fees excluded.
                    var cash = 1.0; var held = false; var entry = 0.0; var trades = 0; var wins = 0
                    for (i in 25 until hourly.size) {
                        val cs = hourly.take(i + 1).map { it.close }
                        val fast = ema(cs, 9); val slow = ema(cs, 21); val prevFast = ema(cs.dropLast(1), 9); val prevSlow = ema(cs.dropLast(1), 21)
                        if (!held && prevFast <= prevSlow && fast > slow) { held = true; entry = hourly[i].close }
                        else if (held && prevFast >= prevSlow && fast < slow) { val r = hourly[i].close / entry; cash *= r; trades++; if (r > 1) wins++; held = false }
                    }
                    if (held) { val r = hourly.last().close / entry; cash *= r; trades++; if (r > 1) wins++ }
                    Triple(currentPrice, analyzed, "EMA 9/21 crossover on 1H · ${hourly.size} candles · $trades closed trades · return ${(cash - 1) * 100.0}% · win rate ${if (trades > 0) wins * 100 / trades else 0}% (fees/slippage excluded; not a forecast)." to priceExtremes)
                }
                price = result.first.takeIf { it > 0.0 }; rows = result.second; backtest = result.third.first; extremes = result.third.second
                if (price == null) error = "Candles loaded, but $platform did not return a usable ticker price."
            } catch (e: Exception) { error = e.message ?: "Could not load market data. Check your connection, platform, and symbol." }
            finally { loading = false }
        }
    }

    // Refresh the complete analysis at most once every five minutes while this analysis screen remains composed.
    // Android may pause network work when the app is backgrounded; this is not a guaranteed background scheduler.
    LaunchedEffect(symbol, market, platform) {
        while (true) {
            delay(5 * 60 * 1000L)
            if (rows.isNotEmpty() && !loading) runAnalysis()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides if (appLanguage == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr) {
    Scaffold(
        containerColor = Color(0xFF080D1B),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier.size(38.dp).background(
                                Brush.linearGradient(listOf(Color(0xFF5EEAD4), Color(0xFF60A5FA), Color(0xFFA78BFA))),
                                RoundedCornerShape(13.dp)
                            ), contentAlignment = Alignment.Center
                        ) { Text(tr("₿", appLanguage), color = Color(0xFF07111F), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge) }
                        Column {
                            Text(tr("CRYPTOANALYSER-BY ERRZHR", appLanguage), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, letterSpacing = 1.2.sp)
                            Text(tr("PUBLIC MARKET DATA · BITGET API", appLanguage), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 0.7.sp)
                        }
                    }
                },
                actions = {
                    Box {
                        TextButton(onClick = { showLanguageMenu = true }) { Text("🌐 ${appLanguages.firstOrNull { it.first == appLanguage }?.second ?: "English"}", color = Color(0xFF5EEAD4)) }
                        DropdownMenu(expanded = showLanguageMenu, onDismissRequest = { showLanguageMenu = false }) {
                            appLanguages.forEach { (code, label) ->
                                DropdownMenuItem(text = { Text(label) }, onClick = {
                                    appLanguage = code
                                    preferences.edit().putString("app_language", code).apply()
                                    showLanguageMenu = false
                                    speechWordOffset = 0
                                    stopVoicePlayback()
                                })
                            }
                        }
                    }
                    TextButton(onClick = { showPrivacyDialog = true }) { Text(tr("PRIVACY", appLanguage), color = Color(0xFF5EEAD4)) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF080D1B))
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).background(Color(0xFF080D1B)).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp)
        ) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().background(
                        Brush.linearGradient(listOf(Color(0xFF172E4A), Color(0xFF202047), Color(0xFF122C35))),
                        RoundedCornerShape(24.dp)
                    ).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(tr("YOUR MARKET,\nCLEARER.", appLanguage), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = Color.White, lineHeight = 34.sp)
                    Text(tr("Technical signals and multi-timeframe insights in one place.", appLanguage), style = MaterialTheme.typography.bodyMedium, color = Color(0xFFD1DEF2))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(Color(0xFF5EEAD4), RoundedCornerShape(50)))
                        Text("${platform.uppercase(Locale.ROOT)} · ${tr("PUBLIC MARKET DATA", appLanguage)}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF5EEAD4), fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tr("ANALYZE A MARKET", appLanguage), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(tr("Choose a pair and market type", appLanguage), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(tr("01", appLanguage), color = Color(0xFFA78BFA), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) {
                                OutlinedButton(onClick = { showPlatformMenu = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                    Text("🏦 ${tr("PLATFORM", appLanguage)}: $platform", maxLines = 1)
                                    Spacer(Modifier.width(4.dp)); Text("⌄")
                                }
                                DropdownMenu(expanded = showPlatformMenu, onDismissRequest = { showPlatformMenu = false }) {
                                    listOf("Bitget", "Binance").forEach { option ->
                                        DropdownMenuItem(text = { Text(option) }, onClick = {
                                            platform = option
                                            preferences.edit().putString("market_platform", option).apply()
                                            showPlatformMenu = false
                                            price = null; rows = emptyList(); extremes = null; chartCandles = emptyList(); error = ""
                                        })
                                    }
                                }
                            }
                            Box(Modifier.weight(1f)) {
                                OutlinedButton(onClick = { showInlineLanguageMenu = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                    Text("🌐 ${appLanguages.firstOrNull { it.first == appLanguage }?.second ?: "English"}", maxLines = 1)
                                    Spacer(Modifier.width(2.dp)); Text("⌄")
                                }
                                DropdownMenu(expanded = showInlineLanguageMenu, onDismissRequest = { showInlineLanguageMenu = false }) {
                                    appLanguages.forEach { (code, label) ->
                                        DropdownMenuItem(text = { Text(label) }, onClick = {
                                            appLanguage = code
                                            preferences.edit().putString("app_language", code).apply()
                                            showInlineLanguageMenu = false
                                        })
                                    }
                                }
                            }
                        }
                        ExposedDropdownMenuBox(
                            expanded = filteredSuggestions.isNotEmpty(),
                            onExpandedChange = { showSuggestions = it }
                        ) {
                            OutlinedTextField(
                                value = symbol,
                                onValueChange = { symbol = it.uppercase(); showSuggestions = true },
                                label = { Text(tr("Coin or trading pair", appLanguage)) },
                                placeholder = { Text(tr("Type BTC, ETH, AI…", appLanguage)) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().menuAnchor(),
                                shape = RoundedCornerShape(15.dp),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = filteredSuggestions.isNotEmpty()) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF5EEAD4),
                                    unfocusedBorderColor = Color(0xFF34445F),
                                    focusedLabelColor = Color(0xFF5EEAD4),
                                    cursorColor = Color(0xFF5EEAD4)
                                )
                            )
                            ExposedDropdownMenu(
                                expanded = filteredSuggestions.isNotEmpty(),
                                onDismissRequest = { showSuggestions = false }
                            ) {
                                filteredSuggestions.forEach { pair ->
                                    DropdownMenuItem(
                                        text = {
                                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text(pair, fontWeight = FontWeight.Bold)
                                                Text("${pair.removeSuffix("USDT")} · ${tr(if (market == "Spot") "Spot" else "USDT Futures", appLanguage)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        },
                                        onClick = { symbol = pair; showSuggestions = false },
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                        Text(tr("MARKET TYPE", appLanguage), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            FilterChip(
                                selected = market == "Spot", onClick = { market = "Spot" },
                                label = { Text(tr("Spot", appLanguage)) }, leadingIcon = { Text(tr("●", appLanguage), color = if (market == "Spot") Color(0xFF5EEAD4) else Color.Gray) },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp)
                            )
                            FilterChip(
                                selected = market == "Futures", onClick = { market = "Futures" },
                                label = { Text(tr("USDT Futures", appLanguage)) }, leadingIcon = { Text(tr("↗", appLanguage), color = if (market == "Futures") Color(0xFFA78BFA) else Color.Gray) },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp)
                            )
                        }
                        val cleanFavoritePair = symbol.trim().uppercase(Locale.ROOT).replace("/", "").replace("-", "").replace("_", "").replace(" ", "").let { if (it.isBlank()) "" else if (it.endsWith("USDT")) it else "${it}USDT" }
                        OutlinedButton(
                            onClick = {
                                if (cleanFavoritePair.matches(Regex("[A-Z0-9]{3,30}USDT"))) {
                                    favoriteSymbols = if (favoriteSymbols.contains(cleanFavoritePair)) favoriteSymbols.filterNot { it == cleanFavoritePair } else (favoriteSymbols + cleanFavoritePair).distinct().take(100)
                                    preferences.edit().putString("favorite_symbols", JSONArray().apply { favoriteSymbols.forEach { put(it) } }.toString()).apply()
                                }
                            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (favoriteSymbols.contains(cleanFavoritePair)) "★  ${tr("Remove from favorites", appLanguage)}" else "☆  ${tr("Add current pair to favorites", appLanguage)}")
                        }
                        Button(
                            onClick = { runAnalysis() }, enabled = !loading,
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(15.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5EEAD4), contentColor = Color(0xFF062A2A))
                        ) {
                            if (loading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF062A2A))
                                Spacer(Modifier.width(10.dp)); Text(tr("ANALYZING MARKET…", appLanguage), fontWeight = FontWeight.Bold)
                            } else { Text(tr("✦  ANALYZE MARKET", appLanguage), fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp) }
                        }
                    }
                }
            }
            if (loading) item {
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFF5EEAD4), trackColor = Color(0xFF24324B))
            }
            if (error.isNotBlank()) item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF3A1C2B))) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                        Text(tr("!", appLanguage), color = Color(0xFFFF718B), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                        Text(tr(error, appLanguage), color = Color(0xFFFFD9E0), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tr("PRICE CHART · CANDLESTICKS", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("${coinFundamentals?.takeIf { !it.ambiguous && it.symbol.equals(symbol.removeSuffix("USDT").removeSuffix("USDC").removeSuffix("BUSD").removeSuffix("FDUSD"), true) }?.name ?: symbol.removeSuffix("USDT").removeSuffix("USDC")} (${symbol}) · ${tr(market, appLanguage)} · $platform", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                if (price != null) {
                                    Text("${fmt(price!!)} USDT", color = Color(0xFFFFD166), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                                    Text(if (appLanguage == "ar") "السعر المباشر · تحديث كل 5 ثوانٍ${if (livePriceUpdatedAt > 0L) " · " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(livePriceUpdatedAt)) else ""}" else "LIVE PRICE · refresh every 5 sec${if (livePriceUpdatedAt > 0L) " · " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(livePriceUpdatedAt)) else ""}", color = Color(0xFFB8D8D5), style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            if (chartLoading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFF5EEAD4))
                        }
                        if (chartCandles.isNotEmpty()) {
                            CandleChart(candles = chartCandles, high24h = extremes?.high24h ?: 0.0, low24h = extremes?.low24h ?: 0.0, currentPrice = price, fibonacciLevels = fibonacciLevels, modifier = Modifier.fillMaxWidth().height(190.dp))
                            val channelForLabel = remember(chartCandles, chartTimeframe) { detectDescendingPriceChannel(chartCandles.takeLast(60)) }
                            val timeframeLabel = when (chartTimeframe) { "5m" -> if (appLanguage == "ar") "5 دقائق" else "5m"; "15m" -> if (appLanguage == "ar") "15 دقيقة" else "15m"; "1H" -> if (appLanguage == "ar") "ساعة" else "1H"; "4H" -> if (appLanguage == "ar") "4 ساعات" else "4H"; "1D" -> if (appLanguage == "ar") "يوم" else "1D"; else -> if (appLanguage == "ar") "شهر" else "1M" }
                            if (channelForLabel != null) {
                                val channelMessage = when {
                                    appLanguage == "ar" && channelForLabel.status == "up" -> "قناة هابطة مرصودة على إطار $timeframeLabel: إغلاق السعر فوق خط المقاومة العلوي — اختراق محتمل يحتاج تأكيدًا."
                                    appLanguage == "ar" && channelForLabel.status == "down" -> "قناة هابطة مرصودة على إطار $timeframeLabel: السعر كسر خط الدعم السفلي؛ إشارة ضعف هبوطي إضافية."
                                    appLanguage == "ar" -> "قناة سعرية هابطة مرصودة على إطار $timeframeLabel: الأحمر مقاومة القناة والأزرق دعمها. الاختراق أو الكسر يحتاج إغلاق شمعة للتأكيد."
                                    appLanguage == "fr" && channelForLabel.status == "up" -> "Canal baissier détecté ($timeframeLabel) : clôture au-dessus de la résistance, cassure potentielle à confirmer."
                                    appLanguage == "fr" && channelForLabel.status == "down" -> "Canal baissier détecté ($timeframeLabel) : rupture sous le support, pression baissière accrue."
                                    appLanguage == "fr" -> "Canal baissier détecté ($timeframeLabel) : rouge = résistance, bleu = support. Confirmer toute cassure par une clôture."
                                    channelForLabel.status == "up" -> "Descending channel ($timeframeLabel): close above upper resistance; potential breakout needs confirmation."
                                    channelForLabel.status == "down" -> "Descending channel ($timeframeLabel): price broke below lower support; bearish weakness increased."
                                    else -> "Descending channel detected ($timeframeLabel): red = upper resistance, blue = lower support. Confirm a breakout with a candle close."
                                }
                                Text(channelMessage, color = if (channelForLabel.status == "up") Color(0xFF5EEAD4) else if (channelForLabel.status == "down") Color(0xFFFF9EB5) else Color(0xFFFFD166), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                            } else {
                                Text(if (appLanguage == "ar") "لا توجد قناة هابطة واضحة بما يكفي على إطار $timeframeLabel؛ لن نرسم قناة غير مؤكدة." else if (appLanguage == "fr") "Aucun canal baissier suffisamment net sur $timeframeLabel ; aucune ligne spéculative n’est tracée." else "No sufficiently clear descending channel on $timeframeLabel; no speculative channel is drawn.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                            }
                            if (chartTimeframe == "15m" && fibonacciLevels.isNotEmpty()) {
                                Text(if (appLanguage == "ar") "فيبوناتشي · مستويات التصحيح محسوبة من أعلى وأدنى آخر 60 شمعة على إطار 15 دقيقة" else if (appLanguage == "fr") "Fibonacci · retracements calculés sur les 60 dernières bougies 15 min" else "Fibonacci · retracements calculated from the latest 60 15m candles", color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    fibonacciLevels.forEach { (label, level) ->
                                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                            Text(label, modifier = Modifier.weight(1f), color = Color(0xFFC4B5FD), style = MaterialTheme.typography.labelSmall)
                                            Text(fmt(level), color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                            val shortHorizon = rows.firstOrNull { it.timeframe == "5m" } ?: rows.firstOrNull { it.timeframe == "15m" } ?: rows.firstOrNull()
                            if (shortHorizon != null) {
                                Text(if (appLanguage == "ar") "اتجاه المؤشرات للخمس دقائق القادمة — تقدير فني وليس احتمالًا مضمونًا" else if (appLanguage == "fr") "Biais des indicateurs pour les 5 prochaines minutes — estimation technique, non garantie" else "Next 5-minute indicator bias — technical estimate, not a guaranteed probability", color = Color(0xFFD9E4F5), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Column(Modifier.weight(1f).background(Color(0xFF123A38), RoundedCornerShape(12.dp)).padding(10.dp)) {
                                        Text(if (appLanguage == "ar") "ميل صعودي" else if (appLanguage == "fr") "Biais haussier" else "Bullish indicator score", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall)
                                        Text("${shortHorizon.upProbability}%", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                        LinearProgressIndicator(progress = { shortHorizon.upProbability / 100f }, modifier = Modifier.fillMaxWidth(), color = Color(0xFF22C55E), trackColor = Color(0xFF27414A))
                                    }
                                    Column(Modifier.weight(1f).background(Color(0xFF382338), RoundedCornerShape(12.dp)).padding(10.dp)) {
                                        Text(if (appLanguage == "ar") "ميل هبوطي" else if (appLanguage == "fr") "Biais baissier" else "Bearish indicator score", color = Color(0xFFFF9EB5), style = MaterialTheme.typography.labelSmall)
                                        Text("${shortHorizon.downProbability}%", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                        LinearProgressIndicator(progress = { shortHorizon.downProbability / 100f }, modifier = Modifier.fillMaxWidth(), color = Color(0xFFEF4444), trackColor = Color(0xFF4A2D3C))
                                    }
                                }
                                Text(if (appLanguage == "ar") "هذه النسب مشتقة من اتجاه EMA وMACD وOBV، وليست احتمالات معايرة إحصائيًا. قد تتحرك الأسعار بسرعة." else "Scores derive from EMA, MACD and OBV signals; they are not statistically calibrated probabilities.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Column(Modifier.weight(1f).background(Color(0xFF123A38), RoundedCornerShape(12.dp)).padding(10.dp)) {
                                    Text(tr("24H HIGH", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(if ((extremes?.high24h ?: 0.0) > 0.0) fmt(extremes!!.high24h) else tr("Unavailable", appLanguage), color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column(Modifier.weight(1f).background(Color(0xFF382338), RoundedCornerShape(12.dp)).padding(10.dp)) {
                                    Text(tr("24H LOW", appLanguage), color = Color(0xFFFF9EB5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(if ((extremes?.low24h ?: 0.0) > 0.0) fmt(extremes!!.low24h) else tr("Unavailable", appLanguage), color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            Text(tr(if (price == null) "Run analysis to load the price chart." else "Candlestick data is unavailable for this pair and timeframe.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("5m" to "5 minutes", "15m" to "15 minutes", "1H" to "1 hour", "4H" to "4 hours", "1D" to "1 day", "1M" to "1 month").forEach { (key, label) ->
                                val active = chartTimeframe == key
                                FilterChip(
                                    selected = active,
                                    onClick = { chartTimeframe = key },
                                    label = { Text(if (key == "5m" && appLanguage == "ar") "5 دقائق" else if (key == "5m" && appLanguage == "fr") "5 minutes" else tr(label, appLanguage), maxLines = 1, style = MaterialTheme.typography.labelSmall) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF22C55E), selectedLabelColor = Color(0xFF062A17)),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { if (!alertsExpanded && editingAlertId == null) alertSymbol = symbol; alertsExpanded = !alertsExpanded }, verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("Price alerts", appLanguage), modifier = Modifier.weight(1f), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(if (alertsExpanded) "⌃" else "⌄", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall)
                        }
                        if (alertsExpanded) {
                            Text(tr(if (editingAlertId != null) "Edit alert" else "Add price alert", appLanguage), color = Color(0xFF9BAAC2), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(value = alertSymbol, onValueChange = { alertSymbol = it.uppercase(Locale.ROOT) }, label = { Text(tr("Coin or trading pair", appLanguage)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(value = alertTarget, onValueChange = { alertTarget = it }, label = { Text(tr("Target price", appLanguage)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                FilterChip(selected = alertDirection == "ABOVE", onClick = { alertDirection = "ABOVE" }, label = { Text(tr("When price is above", appLanguage)) }, modifier = Modifier.weight(1f))
                                FilterChip(selected = alertDirection == "BELOW", onClick = { alertDirection = "BELOW" }, label = { Text(tr("When price is below", appLanguage)) }, modifier = Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                FilterChip(selected = alertMarket == "Spot", onClick = { alertMarket = "Spot" }, label = { Text(tr("Spot", appLanguage)) }, modifier = Modifier.weight(1f))
                                FilterChip(selected = alertMarket == "Futures", onClick = { alertMarket = "Futures" }, label = { Text(tr("USDT Futures", appLanguage)) }, modifier = Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(onClick = {
                                    val clean = alertSymbol.trim().uppercase(Locale.ROOT).replace("/", "").replace("-", "").replace("_", "").replace(" ", "").let { if (it.endsWith("USDT")) it else "${it}USDT" }
                                    val target = alertTarget.toDoubleOrNull()
                                    if (clean.matches(Regex("[A-Z0-9]{3,30}USDT")) && target != null && target > 0.0) {
                                        val id = editingAlertId ?: System.currentTimeMillis()
                                        val obj = JSONObject().put("id", id).put("symbol", clean).put("market", alertMarket).put("target", target).put("direction", alertDirection).put("triggered", false)
                                        val next = priceAlerts.filterNot { it.optLong("id") == id } + obj
                                        priceAlerts = next
                                        val arr = JSONArray(); next.forEach { arr.put(it) }
                                        preferences.edit().putString("price_alerts", arr.toString()).apply()
                                        editingAlertId = null; alertSymbol = symbol; alertTarget = ""
                                        val request = PeriodicWorkRequestBuilder<PriceAlertWorker>(15, TimeUnit.MINUTES).build()
                                        WorkManager.getInstance(context).enqueueUniquePeriodicWork("crypto_price_alert_monitor", ExistingPeriodicWorkPolicy.UPDATE, request)
                                    }
                                }, modifier = Modifier.weight(1f)) { Text(tr("Save", appLanguage)) }
                                OutlinedButton(onClick = { editingAlertId = null; alertSymbol = symbol; alertTarget = "" }, modifier = Modifier.weight(1f)) { Text(tr("Cancel", appLanguage)) }
                            }
                            if (priceAlerts.isEmpty()) Text(tr("No price alerts yet", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            priceAlerts.forEach { alert ->
                                HorizontalDivider(color = Color(0xFF283650))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("${alert.optString("symbol")} · ${fmt(alert.optDouble("target"))} USDT", color = Color.White, fontWeight = FontWeight.SemiBold)
                                        Text("${tr(alert.optString("direction"), appLanguage)} · ${tr(alert.optString("market"), appLanguage)}", color = Color(0xFF9BAAC2), style = MaterialTheme.typography.bodySmall)
                                        if (alert.optBoolean("triggered")) {
                                            Text(tr("Deactivated", appLanguage), color = Color(0xFFFBBF24), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                        } else {
                                            Text(tr("Active", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                    if (alert.optBoolean("triggered")) {
                                        TextButton(onClick = {
                                            val updatedAlert = JSONObject(alert.toString()).put("triggered", false)
                                            val next = priceAlerts.map { if (it.optLong("id") == alert.optLong("id")) updatedAlert else it }
                                            priceAlerts = next
                                            val arr = JSONArray(); next.forEach { arr.put(it) }
                                            preferences.edit().putString("price_alerts", arr.toString()).apply()
                                            val request = PeriodicWorkRequestBuilder<PriceAlertWorker>(15, TimeUnit.MINUTES).build()
                                            WorkManager.getInstance(context).enqueueUniquePeriodicWork("crypto_price_alert_monitor", ExistingPeriodicWorkPolicy.UPDATE, request)
                                        }) { Text(tr("Activate", appLanguage)) }
                                    }
                                    TextButton(onClick = {
                                        editingAlertId = alert.optLong("id"); alertSymbol = alert.optString("symbol"); alertTarget = alert.optDouble("target").toString(); alertDirection = alert.optString("direction", "ABOVE"); alertMarket = alert.optString("market", "Spot"); alertsExpanded = true
                                    }) { Text(tr("Edit", appLanguage)) }
                                    TextButton(onClick = {
                                        val next = priceAlerts.filterNot { it.optLong("id") == alert.optLong("id") }; priceAlerts = next
                                        val arr = JSONArray(); next.forEach { arr.put(it) }; preferences.edit().putString("price_alerts", arr.toString()).apply()
                                    }) { Text(tr("Delete", appLanguage)) }
                                }
                            }
                        }
                    }
                }
            }
            if (recentSymbols.isNotEmpty()) item {
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("Recently analyzed", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            recentSymbols.take(3).forEach { recent ->
                                TextButton(onClick = { symbol = recent; showSuggestions = false; runAnalysis() }) {
                                    Text(recent, color = Color(0xFF93C5FD), textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline)
                                }
                            }
                        }
                    }
                }
            }
            if (favoriteSymbols.isNotEmpty()) item {
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("Favorites", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            favoriteSymbols.forEach { favorite ->
                                AssistChip(
                                    onClick = { symbol = favorite; showSuggestions = false; runAnalysis() },
                                    label = { Text("★ $favorite") },
                                    trailingIcon = {
                                        Text("×", modifier = Modifier.clickable {
                                            favoriteSymbols = favoriteSymbols.filterNot { it == favorite }
                                            preferences.edit().putString("favorite_symbols", JSONArray().apply { favoriteSymbols.forEach { put(it) } }.toString()).apply()
                                        })
                                    }
                                )
                            }
                        }
                        Text(tr("Movement signals are monitored for recent searches, favorites, and price-alert pairs on both Bitget and Binance.", appLanguage), color = Color(0xFF9BAAC2), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF101D32))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { technicalExpanded = !technicalExpanded }, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(if (appLanguage == "ar") "التحليل الفني متعدد الأطر" else if (appLanguage == "fr") "ANALYSE TECHNIQUE MULTI-UNITÉS" else "MULTI-TIMEFRAME TECHNICAL ANALYSIS", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text(if (appLanguage == "ar") "5 دقائق · 15 دقيقة · ساعة · 4 ساعات · يوم" else if (appLanguage == "fr") "5 min · 15 min · 1 h · 4 h · 1 jour" else "5m · 15m · 1h · 4h · 1D", color = Color(0xFFB8C7E3), style = MaterialTheme.typography.bodySmall)
                            }
                            Text(if (technicalExpanded) "⌃" else "⌄", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall)
                        }
                        if (technicalExpanded) {
                            if (rows.isEmpty()) {
                                Text(if (appLanguage == "ar") "اضغط «تحليل السوق» لتحميل الشموع والمؤشرات الحقيقية من المنصة المختارة." else if (appLanguage == "fr") "Lancez l’analyse pour charger les bougies et indicateurs de la plateforme sélectionnée." else "Run market analysis to load candles and indicators from the selected exchange.", color = Color(0xFFB8C7E3), style = MaterialTheme.typography.bodyMedium)
                            } else {
                                Text(if (appLanguage == "ar") "ملخص الأطر الزمنية" else if (appLanguage == "fr") "RÉSUMÉ PAR UNITÉ DE TEMPS" else "TIMEFRAME SUMMARY", color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                                Text(if (appLanguage == "ar") "النسب التالية درجات لميل المؤشرات وليست احتمالًا إحصائيًا لحركة السعر." else if (appLanguage == "fr") "Ces pourcentages sont des scores d’indicateurs, pas des probabilités statistiques de prix." else "Percentages below are indicator-bias scores, not statistical probabilities of price movement.", color = Color(0xFFFFD166), style = MaterialTheme.typography.bodySmall)
                                rows.forEach { row ->
                                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17263D)), shape = RoundedCornerShape(15.dp)) {
                                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(row.timeframe, color = Color.White, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.ExtraBold)
                                                Spacer(Modifier.width(8.dp))
                                                Text(if (row.upProbability > row.downProbability + 8) { if (appLanguage == "ar") "ميل صعودي" else "Bullish bias" } else if (row.downProbability > row.upProbability + 8) { if (appLanguage == "ar") "ميل هبوطي" else "Bearish bias" } else { if (appLanguage == "ar") "إشارات مختلطة" else "Mixed signals" }, color = if (row.upProbability > row.downProbability + 8) Color(0xFF5EEAD4) else if (row.downProbability > row.upProbability + 8) Color(0xFFFF9EB5) else Color(0xFFFFD166), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                                Spacer(Modifier.weight(1f))
                                                Text("${row.upProbability}% ↑  ${row.downProbability}% ↓", color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                            }
                                            Text(if (appLanguage == "ar") "السعر المرجعي: ${fmt(row.price)} USDT" else "Reference price: ${fmt(row.price)} USDT", color = Color(0xFFD5E4EF), style = MaterialTheme.typography.bodySmall)
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Column(Modifier.weight(1f)) {
                                                    Text(if (appLanguage == "ar") "الدعم · آخر 30 شمعة" else if (appLanguage == "fr") "Support · 30 bougies" else "Support · last 30 candles", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall)
                                                    Text(fmt(row.support), color = Color.White, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                                }
                                                Column(Modifier.weight(1f)) {
                                                    Text(if (appLanguage == "ar") "المقاومة · آخر 30 شمعة" else if (appLanguage == "fr") "Résistance · 30 bougies" else "Resistance · last 30 candles", color = Color(0xFFFF9EB5), style = MaterialTheme.typography.labelSmall)
                                                    Text(fmt(row.resistance), color = Color.White, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                                }
                                            }
                                            HorizontalDivider(color = Color(0xFF2B3D56))
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Column(Modifier.weight(1f)) {
                                                    Text("RSI (14)", color = Color(0xFFB8C7E3), style = MaterialTheme.typography.labelSmall)
                                                    Text(row.rsi?.let { "%.1f".format(Locale.US, it) } ?: "—", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                                                }
                                                Column(Modifier.weight(1f)) {
                                                    Text("MACD / Signal", color = Color(0xFFB8C7E3), style = MaterialTheme.typography.labelSmall)
                                                    Text("${fmt(row.macd)} / ${fmt(row.signal)}", color = if (row.hist >= 0) Color(0xFF5EEAD4) else Color(0xFFFF9EB5), style = MaterialTheme.typography.bodySmall)
                                                }
                                                Column(Modifier.weight(1f)) {
                                                    Text("OBV", color = Color(0xFFB8C7E3), style = MaterialTheme.typography.labelSmall)
                                                    Text("${if (row.obvRising) "↑" else "↓"} ${if (row.obv >= 0) "+${fmt(row.obv)}" else fmt(row.obv)}", color = if (row.obvRising) Color(0xFF5EEAD4) else Color(0xFFFF9EB5), style = MaterialTheme.typography.bodySmall)
                                                }
                                            }
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Column(Modifier.weight(1f)) {
                                                    Text(if (appLanguage == "ar") "الحجم / متوسطه" else "Volume / avg.", color = Color(0xFFB8C7E3), style = MaterialTheme.typography.labelSmall)
                                                    val volumeRatio = if (row.averageVolume > 0.0) row.volume / row.averageVolume else 0.0
                                                    Text(if (volumeRatio > 0.0) "${fmt(row.volume)} · ${"%.2f".format(Locale.US, volumeRatio)}× avg" else "—", color = if (volumeRatio >= 1.0) Color(0xFF5EEAD4) else Color.White, style = MaterialTheme.typography.bodySmall)
                                                }
                                                Column(Modifier.weight(1f)) {
                                                    Text("Supertrend (10,3)", color = Color(0xFFB8C7E3), style = MaterialTheme.typography.labelSmall)
                                                    Text("${if (row.supertrendBullish) "↑" else "↓"} ${fmt(row.supertrend)}", color = if (row.supertrendBullish) Color(0xFF5EEAD4) else Color(0xFFFF9EB5), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                                }
                                                Column(Modifier.weight(1f)) {
                                                    Text("EMA 9 / 21 / 50", color = Color(0xFFB8C7E3), style = MaterialTheme.typography.labelSmall)
                                                    Text("${fmt(row.emas[9] ?: 0.0)} / ${fmt(row.emas[21] ?: 0.0)} / ${fmt(row.emas[50] ?: 0.0)}", color = Color.White, style = MaterialTheme.typography.bodySmall)
                                                }
                                            }
                                            Text(tr(row.setup, appLanguage), color = Color(0xFFD5E4EF), style = MaterialTheme.typography.bodySmall, lineHeight = 18.sp)
                                        }
                                    }
                                }
                                Text(if (appLanguage == "ar") "تنبيه: نسب الصعود والهبوط هنا درجات ميل فني مبنية على المؤشرات، وليست احتمالات إحصائية معايرة ولا ضمانًا لحركة السعر." else if (appLanguage == "fr") "Note : les pourcentages sont des scores de biais technique, pas des probabilités calibrées ni une garantie de prix." else "Note: up/down percentages are indicator-based bias scores, not calibrated statistical probabilities or guaranteed price moves.", color = Color(0xFFFFD166), style = MaterialTheme.typography.bodySmall)

                                HorizontalDivider(color = Color(0xFF2B3D56))
                                Text(if (appLanguage == "ar") "خطة الدخول وإدارة المخاطر · مبنية على دعم ومقاومة 4 ساعات" else if (appLanguage == "fr") "PLAN D’ENTRÉE ET GESTION DU RISQUE · SUPPORT/RÉSISTANCE 4 H" else "ENTRY & RISK PLAN · 4H SUPPORT/RESISTANCE", color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                if (tradePlans.isEmpty()) {
                                    Text(if (appLanguage == "ar") "لا يمكن حساب خطة موثوقة قبل توفر مستويات صالحة." else "Trade levels are unavailable until valid support/resistance data is available.", color = Color(0xFFB8C7E3), style = MaterialTheme.typography.bodySmall)
                                } else tradePlans.forEach { plan ->
                                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17263D)), shape = RoundedCornerShape(14.dp)) {
                                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text("${tradePlans.indexOf(plan) + 1}. ${tr(plan.title, appLanguage)}", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                            Text(tr(plan.description, appLanguage), color = Color(0xFFB8C7E3), style = MaterialTheme.typography.bodySmall)
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Column(Modifier.weight(1f)) { Text(if (appLanguage == "ar") "الدخول" else "Entry", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall); Text(fmt(plan.entry), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium) }
                                                Column(Modifier.weight(1f)) { Text(if (appLanguage == "ar") "وقف الخسارة" else "Stop loss", color = Color(0xFFFF9EB5), style = MaterialTheme.typography.labelSmall); Text(fmt(plan.stopLoss), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium) }
                                            }
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                listOf("TP1" to plan.tp1, "TP2" to plan.tp2, "TP3" to plan.tp3).forEach { (label, value) ->
                                                    Column(Modifier.weight(1f)) { Text(label, color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall); Text(fmt(value), color = Color.White, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold) }
                                                }
                                            }
                                        }
                                    }
                                }
                                val scalp = rows.firstOrNull { it.timeframe == "5m" }
                                if (scalp != null && (price ?: 0.0) > 0.0) {
                                    HorizontalDivider(color = Color(0xFF2B3D56))
                                    Text(if (appLanguage == "ar") "التداول السريع · قراءة 5 دقائق" else if (appLanguage == "fr") "SCALPING · LECTURE 5 MIN" else "SCALPING · 5-MINUTE READ", color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                    val entry = price!!
                                    val longStop = min(scalp.support * 0.998, entry * 0.995).coerceAtLeast(entry * 0.50)
                                    val longRisk = (entry - longStop).coerceAtLeast(entry * 0.001)
                                    val shortStop = max(scalp.resistance * 1.002, entry * 1.005)
                                    val shortRisk = (shortStop - entry).coerceAtLeast(entry * 0.001)
                                    Text(if (scalp.upProbability >= 60) { if (appLanguage == "ar") "الميل الحالي: صعودي مشروط؛ انتظر تأكيد الشمعة والحجم." else "Current bias: conditionally bullish; wait for candle and volume confirmation." } else if (scalp.downProbability >= 60) { if (appLanguage == "ar") "الميل الحالي: هبوطي؛ في السوق الفوري الأفضل انتظار استقرار السعر." else "Current bias: bearish; for Spot, waiting for stabilization is safer than buying." } else { if (appLanguage == "ar") "الميل الحالي: مختلط؛ لا توجد إشارة قوية للدخول الآن." else "Current bias: mixed; no strong entry signal right now." }, color = Color(0xFFD5E4EF), style = MaterialTheme.typography.bodySmall)
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Column(Modifier.weight(1f).background(Color(0xFF123A38), RoundedCornerShape(12.dp)).padding(10.dp)) {
                                            Text(if (appLanguage == "ar") "ميل الصعود" else "Bullish score", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall)
                                            Text("${scalp.upProbability}%", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                                            Text(if (appLanguage == "ar") "دخول مرجعي: ${fmt(entry)}" else "Reference entry: ${fmt(entry)}", color = Color.White, style = MaterialTheme.typography.bodySmall)
                                            Text(if (appLanguage == "ar") "وقف: ${fmt(longStop)}" else "Stop: ${fmt(longStop)}", color = Color(0xFFFF9EB5), style = MaterialTheme.typography.bodySmall)
                                            Text("TP1 ${fmt(entry + longRisk)} · TP2 ${fmt(entry + 2 * longRisk)}", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.bodySmall)
                                        }
                                        Column(Modifier.weight(1f).background(Color(0xFF382338), RoundedCornerShape(12.dp)).padding(10.dp)) {
                                            Text(if (appLanguage == "ar") "ميل الهبوط" else "Bearish score", color = Color(0xFFFF9EB5), style = MaterialTheme.typography.labelSmall)
                                            Text("${scalp.downProbability}%", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                                            Text(if (appLanguage == "ar") "مرجع البيع: ${fmt(entry)}" else "Reference short: ${fmt(entry)}", color = Color.White, style = MaterialTheme.typography.bodySmall)
                                            Text(if (appLanguage == "ar") "وقف: ${fmt(shortStop)}" else "Stop: ${fmt(shortStop)}", color = Color(0xFFFF9EB5), style = MaterialTheme.typography.bodySmall)
                                            Text("TP1 ${fmt((entry - shortRisk).coerceAtLeast(entry * 0.01))} · TP2 ${fmt((entry - 2 * shortRisk).coerceAtLeast(entry * 0.01))}", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                    Text(if (appLanguage == "ar") "هذه مستويات شرطية تعليمية وليست أوامر أو توصية مضمونة. لا تدخل قبل تحقق الإشارة؛ قد تتجاوز الفجوات والانزلاق وقف الخسارة." else "These are conditional educational levels, not orders or guaranteed advice. Confirm the signal first; gaps and slippage can exceed a stop.", color = Color(0xFFFFD166), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF17223A))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { adviceExpanded = !adviceExpanded }, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(if (appLanguage == "ar") "طلب نصيحة استثمارية" else if (appLanguage == "fr") "CONSEIL D’INVESTISSEMENT IA" else "AI INVESTMENT ADVICE", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text(if (appLanguage == "ar") "اسأل عن العملة أو دخولك أو سعر البيع المستهدف" else if (appLanguage == "fr") "Posez une question sur la crypto ou votre position" else "Ask about the coin, your entry, or a target sell price", color = Color(0xFFB8C7E3), style = MaterialTheme.typography.bodySmall)
                            }
                            Text(if (adviceExpanded) "⌃" else "⌄", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall)
                        }
                        if (adviceExpanded) {
                            OutlinedTextField(value = adviceEntryPrice, onValueChange = { adviceEntryPrice = it }, modifier = Modifier.fillMaxWidth(), label = { Text(if (appLanguage == "ar") "سعر دخولي (اختياري)" else "My entry price (optional)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), colors = adviceFieldColors())
                            OutlinedTextField(value = adviceQuantity, onValueChange = { adviceQuantity = it }, modifier = Modifier.fillMaxWidth(), label = { Text(if (appLanguage == "ar") "عدد العملات التي أملكها (اختياري)" else "Quantity held (optional)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), colors = adviceFieldColors())
                            OutlinedTextField(value = adviceTargetPrice, onValueChange = { adviceTargetPrice = it }, modifier = Modifier.fillMaxWidth(), label = { Text(if (appLanguage == "ar") "سعر البيع/الهدف الذي أنتظره (اختياري)" else "Target or planned sell price (optional)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), colors = adviceFieldColors())
                            OutlinedTextField(value = adviceQuestion, onValueChange = { adviceQuestion = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 6, label = { Text(if (appLanguage == "ar") "اكتب سؤالك" else if (appLanguage == "fr") "Votre question" else "Your question") }, placeholder = { Text(if (appLanguage == "ar") "مثلاً: هل أنتظر أم أبيع عند السعر الذي حددته؟ اشرح الأسباب والسيناريوهات." else "Example: Should I wait or sell at my target? Explain the reasons and scenarios.") }, colors = adviceFieldColors())
                            Button(onClick = {
                                if (adviceQuestion.isBlank()) {
                                    adviceError = if (appLanguage == "ar") "اكتب سؤالاً أولاً." else "Please enter a question first."
                                } else {
                                    adviceLoading = true; adviceError = ""; adviceAnswer = ""
                                    val current = price
                                    val entryContext = adviceEntryPrice.ifBlank { "not provided" }
                                    val quantityContext = adviceQuantity.ifBlank { "not provided" }
                                    val targetContext = adviceTargetPrice.ifBlank { "not provided" }
                                    val fundamentalsContext = coinFundamentals?.let { profile ->
                                        "name=${profile.name}; symbol=${profile.symbol}; ambiguous=${profile.ambiguous}; marketCapUsd=${profile.marketCapUsd}; circulatingSupply=${profile.circulatingSupply}; totalSupply=${profile.totalSupply}; maxSupply=${profile.maxSupply}; tags=${profile.tags}; description=${profile.description.take(1800)}; website=${profile.website}; whitepaper=${profile.whitepaper}"
                                    } ?: "not loaded or not matched to an exact project"
                                    val headlineContext = news.take(8).joinToString(" | ") { it.title }
                                    val contextText = buildString {
                                        appendLine("Selected symbol: $symbol; exchange: $platform; market: $market; current ticker price: ${current ?: "not loaded"} USDT")
                                        appendLine("User entry price: $entryContext; quantity held: $quantityContext; target/sell price: $targetContext")
                                        appendLine("Technical indicator rows (locally calculated from exchange candles; scores are heuristic bias scores, not calibrated probabilities):")
                                        rows.forEach { r -> appendLine("${r.timeframe}: price=${r.price}, bullishScore=${r.upProbability}, bearishScore=${r.downProbability}, support=${r.support}, resistance=${r.resistance}, RSI=${r.rsi}, MACD=${r.macd}, signal=${r.signal}, histogram=${r.hist}, OBV rising=${r.obvRising}, volume=${r.volume}, averageVolume=${r.averageVolume}, Supertrend=${r.supertrend}, Supertrend bullish=${r.supertrendBullish}") }
                                        appendLine("Coin fundamentals available in app: $fundamentalsContext")
                                        appendLine("Recent market headlines available in app: $headlineContext")
                                        appendLine("Technical trade plans/scalping levels shown in the app are conditional estimates; do not treat their scores as true probabilities.")
                                    }
                                    scope.launch {
                                        try {
                                            adviceAnswer = requestInvestmentAdvice(symbol, adviceQuestion.trim(), contextText, appLanguage)
                                        } catch (e: Exception) {
                                            adviceError = e.message ?: if (appLanguage == "ar") "تعذر الحصول على الإجابة. تحقق من إعداد خدمة الذكاء الاصطناعي." else "Could not get an answer. Check the AI service setup."
                                        } finally { adviceLoading = false }
                                    }
                                }
                            }, modifier = Modifier.fillMaxWidth(), enabled = !adviceLoading, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5EEAD4), contentColor = Color(0xFF062A2A))) {
                                Text(if (adviceLoading) { if (appLanguage == "ar") "جارٍ إعداد الإجابة..." else "Preparing answer…" } else { if (appLanguage == "ar") "حلّل سؤالي بالذكاء الاصطناعي" else if (appLanguage == "fr") "Analyser ma question avec l’IA" else "ASK AI TO ANALYZE" }, fontWeight = FontWeight.Bold)
                            }
                            if (adviceError.isNotBlank()) Text(adviceError, color = Color(0xFFFF9EB5), style = MaterialTheme.typography.bodySmall)
                            if (adviceAnswer.isNotBlank()) {
                                HorizontalDivider(color = Color(0xFF38516C))
                                Text(if (appLanguage == "ar") "الإجابة والتحليل" else if (appLanguage == "fr") "RÉPONSE ET ANALYSE" else "ANSWER & ANALYSIS", color = Color(0xFF5EEAD4), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                                Text(adviceAnswer, color = Color(0xFFEAF2FF), style = MaterialTheme.typography.bodyMedium)
                                Text(if (appLanguage == "ar") "التحليل مبني على البيانات المرسلة لحظة الطلب؛ حدّث تحليل السوق قبل الاعتماد عليه. لا توجد نتيجة مضمونة." else "Advice uses the data sent at request time. Refresh market analysis first; no outcome is guaranteed.", color = Color(0xFFFFD166), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { newsExpanded = !newsExpanded }, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tr("Coin news", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                                Text(tr("Marché crypto · ${symbol.removeSuffix("USDT")} · 7 derniers jours", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                            Text(if (newsExpanded) "⌃" else "⌄", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall)
                        }
                        if (newsExpanded) {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17243A)), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(if (appLanguage == "ar") "نبذة عن المشروع" else if (appLanguage == "fr") "Résumé du projet" else "Project summary", color = Color(0xFF5EEAD4), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall)
                                Text(spokenCoinProfile, color = Color(0xFFD5E4EF), style = MaterialTheme.typography.bodyMedium, lineHeight = 20.sp)
                                if (coinFundamentalsLoading) {
                                    Text(if (appLanguage == "ar") "يتم تحديث النبذة من المصادر العامة…" else if (appLanguage == "fr") "Mise à jour du résumé depuis les sources publiques…" else "Updating summary from public sources…", color = Color(0xFF9BAAC2), style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                        Text(tr("Les actualités affichées concernent uniquement la crypto sélectionnée.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        if (newsLoading) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFF5EEAD4))
                                Text(tr("Chargement des actualités récentes…", appLanguage), color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodySmall)
                            }
                        } else if (news.isEmpty()) {
                            Text(tr(newsError.ifBlank { "Lancez l’analyse pour charger les actualités récentes." }, appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        } else {
                            news.forEachIndexed { index, item ->
                                HorizontalDivider(color = Color(0xFF283650))
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable { selectedNews = item }.padding(vertical = 5.dp),
                                    verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                        Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                                        Text("${item.source} · ${java.text.SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(item.publishedAt))}", color = Color(0xFF8FA2BE), style = MaterialTheme.typography.labelSmall)
                                    }
                                    Text(tr("›", appLanguage), color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall)
                                }
                            }
                        }
                        Text(tr("Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente.", appLanguage), color = Color(0xFF73839D), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { unlocksExpanded = !unlocksExpanded }, verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("Token unlocks", appLanguage), modifier = Modifier.weight(1f), color = Color(0xFFA78BFA), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(if (unlocksExpanded) "⌃" else "⌄", color = Color(0xFFA78BFA), style = MaterialTheme.typography.headlineSmall)
                        }
                        if (unlocksExpanded) {
                            Text(tr("Unlocks are not verified", appLanguage), color = Color(0xFFFFC078), fontWeight = FontWeight.SemiBold)
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                listOf("Date", "Quantity", "% supply", "Time remaining", "Recipient", "Source").forEach { heading ->
                                    Text(tr(heading, appLanguage), color = Color(0xFF93C5FD), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(tr("No verified unlock schedule available in this app build. No dates or quantities are being guessed.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            Text(tr("This app build does not have authenticated access to a comprehensive token-unlock dataset. It will not invent dates or quantities. Open these sources and verify the selected token before relying on any schedule.", appLanguage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick = { researchWebTitle = "Tokenomist · ${symbol.removeSuffix("USDT")}"; researchWebUrl = "https://tokenomist.ai/search?q=${android.net.Uri.encode(symbol.removeSuffix("USDT"))}" }, modifier = Modifier.fillMaxWidth()) { Text(tr("Search Tokenomist", appLanguage)) }
                            OutlinedButton(onClick = { researchWebTitle = "CryptoRank · ${symbol.removeSuffix("USDT")}"; researchWebUrl = "https://cryptorank.io/price/${symbol.removeSuffix("USDT").lowercase(Locale.ROOT)}/vesting" }, modifier = Modifier.fillMaxWidth()) { Text(tr("Search CryptoRank", appLanguage)) }
                            OutlinedButton(onClick = { researchWebTitle = tr("Search official announcements", appLanguage); researchWebUrl = "https://www.google.com/search?q=" + android.net.Uri.encode("${symbol.removeSuffix("USDT")} token unlock official announcement") }, modifier = Modifier.fillMaxWidth()) { Text(tr("Search official announcements", appLanguage)) }
                        }
                    }
                }
            }
            if (rows.isNotEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF16263D))) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Independent, polished presenter panels. One TTS engine is shared,
                            // so starting either presenter naturally stops the other.
                            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1930)), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2878C8))) {
                                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Box(Modifier.size(54.dp).background(Color(0xFF153C68), CircleShape), contentAlignment = Alignment.Center) { Text("01", color = Color(0xFF8ED0FF), fontWeight = FontWeight.Black, fontSize = 20.sp) }
                                        Column(Modifier.weight(1f)) {
                                            Text(if (appLanguage == "ar") "المذيع الأول | ملف العملة والمشروع" else if (appLanguage == "fr") "PRÉSENTATEUR 1 | PROFIL DU PROJET" else "PRESENTER 1 | COIN & PROJECT PROFILE", color = Color(0xFF8ED0FF), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                            Text(if (appLanguage == "ar") "تقرير غني بالمعلومات والحقائق الموثّقة" else if (appLanguage == "fr") "Un récit détaillé, fondé sur des faits vérifiables" else "A detailed story grounded in verifiable facts", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                    Text(if (appLanguage == "ar") "تعريف العملة، الاستخدامات، تاريخ الإدراج، القمم والقيعان التاريخية، التطوير والمستثمرون عند توثيقهم، ثم سيناريوهات 6 أشهر وسنة و5 سنوات. ما لا يمكن تأكيده سيُذكر بوضوح، لا بالتخمين." else if (appLanguage == "fr") "Identité, utilité, cotation, sommets et creux historiques, développement, investisseurs vérifiés et scénarios à 6 mois, 1 an et 5 ans. Les informations inconnues restent signalées." else "Identity, utility, listing, historical highs and lows, development, verified backers, and six-month, one-year and five-year scenarios. Unknown information is clearly identified.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        Button(onClick = { activeSpeechText = spokenCoinProfile; speakFromWord(0) }, enabled = speechReady, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1769AA))) { Text(if (appLanguage == "ar") "▶ تشغيل التقرير" else if (appLanguage == "fr") "▶ Écouter le rapport" else "▶ Play report", fontWeight = FontWeight.Bold) }
                                        OutlinedButton(onClick = { stopVoicePlayback() }, enabled = speechReady, modifier = Modifier.weight(0.7f).height(48.dp), shape = RoundedCornerShape(14.dp)) { Text(if (appLanguage == "ar") "■ إيقاف" else if (appLanguage == "fr") "■ Arrêter" else "■ Stop") }
                                        OutlinedButton(onClick = { activeSpeechText = spokenCoinProfile; speakFromWord(0) }, enabled = speechReady, modifier = Modifier.weight(0.7f).height(48.dp), shape = RoundedCornerShape(14.dp)) { Text(if (appLanguage == "ar") "↻ إعادة" else if (appLanguage == "fr") "↻ Reprendre" else "↻ Restart") }
                                    }
                                }
                            }
                            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B2029)), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF168C80))) {
                                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Box(Modifier.size(54.dp).background(Color(0xFF14544E), CircleShape), contentAlignment = Alignment.Center) { Text("02", color = Color(0xFF7DE9D7), fontWeight = FontWeight.Black, fontSize = 20.sp) }
                                        Column(Modifier.weight(1f)) {
                                            Text(if (appLanguage == "ar") "المذيع الثاني | نظرة مختصرة عن السوق وتحركات العملة حاليًا" else if (appLanguage == "fr") "PRÉSENTATEUR 2 | MARCHÉ ET MOUVEMENT ACTUELS" else "PRESENTER 2 | CURRENT MARKET OUTLOOK", color = Color(0xFF7DE9D7), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                            Text(if (appLanguage == "ar") "مباشر، واضح، ومركّز على ما يهم المتداول" else if (appLanguage == "fr") "Clair, dynamique et centré sur le marché" else "Clear, engaging and focused on the market", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                    Text(if (appLanguage == "ar") "قراءة RSI وMACD، أقرب دعم ومقاومة، الارتداد أو الرفض الأخير، ميزان المشترين والبائعين على 15 دقيقة وساعة و4 ساعات، وخطط محتملة لـ Spot وLong وShort مع شروط التأكيد ووقف الخسارة." else if (appLanguage == "fr") "RSI et MACD, supports et résistances, dernier rebond ou rejet, acheteurs/vendeurs en 15 min, 1 h et 4 h, puis scénarios Spot, Long et Short avec confirmations et gestion du risque." else "RSI and MACD, nearby support and resistance, latest bounce or rejection, buyer/seller balance on 15m, 1h and 4h, plus Spot, Long and Short scenarios with confirmation and risk controls.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        Button(onClick = { activeSpeechText = spokenSummary; speakFromWord(0) }, enabled = speechReady && rows.isNotEmpty(), modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087F70))) { Text(if (appLanguage == "ar") "▶ تشغيل نظرة السوق" else if (appLanguage == "fr") "▶ Écouter le marché" else "▶ Play outlook", fontWeight = FontWeight.Bold) }
                                        OutlinedButton(onClick = { stopVoicePlayback() }, enabled = speechReady, modifier = Modifier.weight(0.7f).height(48.dp), shape = RoundedCornerShape(14.dp)) { Text(if (appLanguage == "ar") "■ إيقاف" else if (appLanguage == "fr") "■ Arrêter" else "■ Stop") }
                                        OutlinedButton(onClick = { activeSpeechText = spokenSummary; speakFromWord(0) }, enabled = speechReady && rows.isNotEmpty(), modifier = Modifier.weight(0.7f).height(48.dp), shape = RoundedCornerShape(14.dp)) { Text(if (appLanguage == "ar") "↻ إعادة" else if (appLanguage == "fr") "↻ Reprendre" else "↻ Restart") }
                                    }
                                }
                            }
                            if (voiceError.isNotBlank()) Text(voiceError, color = Color(0xFFFFB4AB), style = MaterialTheme.typography.bodySmall)
                            Text(if (appLanguage == "ar") "اختيار المذيع الصوتي" else if (appLanguage == "fr") "CHOISIR LA VOIX DU PRÉSENTATEUR" else "CHOOSE PRESENTER VOICE", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text(if (appLanguage == "ar") "الصوت مجاني ويعمل عبر محرك النطق الموجود في الهاتف، دون حساب أو خادم خارجي. قد يختلف الصوت المتاح حسب الهاتف واللغة." else if (appLanguage == "fr") "La lecture est gratuite et utilise le moteur vocal déjà présent sur le téléphone, sans compte ni serveur externe. La voix dépend du téléphone et de la langue." else "Free speech uses the engine already available on the phone, with no account or external server. Available voices depend on the phone and language.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                listOf(Triple("sara", "S", if (appLanguage == "ar") "سارة · نبرة أنثوية" else if (appLanguage == "fr") "Sara · tonalité féminine" else "Sara · feminine tone"), Triple("ahmed", "A", if (appLanguage == "ar") "أحمد · نبرة رجالية" else if (appLanguage == "fr") "Ahmed · tonalité masculine" else "Ahmed · masculine tone")).forEach { voice ->
                                    val isFemale = voice.first == "sara"
                                    val selected = voiceName == voice.first || (isFemale && voiceName == "lina") || (!isFemale && voiceName == "youssef")
                                    val accent = if (isFemale) Color(0xFFB56BFA) else Color(0xFF35B7D8)
                                    Card(modifier = Modifier.weight(1f).clickable {
                                        voiceName = voice.first
                                        voiceGender = if (isFemale) "female" else "male"
                                        preferences.edit().putString("summary_voice_name", voiceName).putString("summary_voice_gender", voiceGender).apply()
                                        activeSpeechText = when (appLanguage) {
                                            "ar" -> if (isFemale) "مرحبًا، هذه معاينة للنبرة الأنثوية. سأقرأ لك تقرير العملة أو تحليل السوق عند اختيار التشغيل." else "مرحبًا، هذه معاينة للنبرة الرجالية. سأقرأ لك تقرير العملة أو تحليل السوق عند اختيار التشغيل."
                                            "fr" -> if (isFemale) "Bonjour, voici un aperçu de la tonalité féminine. Je peux lire le rapport du projet ou l’analyse du marché." else "Bonjour, voici un aperçu de la tonalité masculine. Je peux lire le rapport du projet ou l’analyse du marché."
                                            else -> if (isFemale) "Hello, this is a preview of the feminine tone. I can read the coin project report or market outlook." else "Hello, this is a preview of the masculine tone. I can read the coin project report or market outlook."
                                        }
                                        speakFromWord(0)
                                    }, shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, accent), colors = CardDefaults.cardColors(containerColor = if (selected) accent.copy(alpha = 0.16f) else Color(0xFF0B1428))) {
                                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            Box(Modifier.size(42.dp).background(accent.copy(alpha = 0.22f), CircleShape), contentAlignment = Alignment.Center) { Text(voice.second, color = accent, fontSize = 22.sp, fontWeight = FontWeight.Black) }
                                            Column(Modifier.weight(1f)) { Text(voice.third, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text(if (selected) if (appLanguage == "ar") "✓ محدد" else "✓ Selected" else if (appLanguage == "ar") "اضغط للاختيار" else "Tap to select", color = accent, fontSize = 11.sp) }
                                        }
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick = { speakFromWord(speechWordOffset - 12) }, enabled = speechReady, modifier = Modifier.weight(1f)) { Text("⏪ −5s") }
                                OutlinedButton(onClick = { speakFromWord(speechWordOffset + 12) }, enabled = speechReady, modifier = Modifier.weight(1f)) { Text("+5s ⏩") }
                            }
                            Text(if (appLanguage == "ar") "الصوت مجاني ويُشغّل محليًا باستخدام محرك النطق الموجود على الهاتف؛ لا يحتاج إلى حساب أو خادم أو مفتاح API." else if (appLanguage == "fr") "La lecture est locale et gratuite ; aucun compte, serveur ou clé API n’est nécessaire." else "Speech is local and free; no account, server, or API key is required.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Text(tr("RISK NOTICE  ·  Scores are rule-based heuristics, not predictions or guarantees. Futures trading can cause rapid losses. Never trade from this screen alone.", appLanguage), color = Color(0xFF9BAAC2), style = MaterialTheme.typography.bodySmall)
            }
            item {
                Text(tr("DATA PRIVACY  ·  Public market data only. No exchange account connection or order execution. Network providers may process technical connection data such as IP address.", appLanguage), color = Color(0xFF73839D), style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        if (showPrivacyDialog) {
            AlertDialog(
                onDismissRequest = { showPrivacyDialog = false },
                title = { Text(tr("PRIVACY & RISK DISCLOSURE", appLanguage), color = Color(0xFF5EEAD4), fontWeight = FontWeight.ExtraBold) },
                text = {
                    Column(
                        modifier = Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(tr("What this app does", appLanguage), fontWeight = FontWeight.Bold, color = Color.White)
                        Text(tr("CryptoAnalyser-by ErrZhr displays public market prices and historical candles from Bitget, and recent headlines from public RSS feeds. It does not connect to an exchange account, request API keys, place orders, hold funds, or operate a wallet.", appLanguage), color = Color(0xFFD9E4F5))
                        Text(tr("Network and privacy", appLanguage), fontWeight = FontWeight.Bold, color = Color.White)
                        Text(tr("The app does not ask for your name, email address, contacts, camera, microphone, or precise location. To retrieve market and news data, it sends network requests to Bitget and the listed news-feed providers. Those providers may process technical connection data, such as your IP address, under their own privacy policies. The app itself does not create a user account or sell personal data.", appLanguage), color = Color(0xFFD9E4F5))
                        Text(tr("Financial risk", appLanguage), fontWeight = FontWeight.Bold, color = Color.White)
                        Text(tr("Indicators, scores, historical ranges, and backtests are informational estimates, not personalized financial advice or guarantees. Data may be delayed, incomplete, or incorrect. Crypto assets and futures are high risk; you are responsible for your decisions and possible losses.", appLanguage), color = Color(0xFFD9E4F5))
                        Text(tr("Third-party services", appLanguage), fontWeight = FontWeight.Bold, color = Color.White)
                        Text(tr("Bitget, CoinDesk, and Cointelegraph are independent services. This app is not an official Bitget product and does not imply endorsement by those providers. Their service and privacy terms apply to their respective endpoints.", appLanguage), color = Color(0xFFD9E4F5))
                        Text(tr("For publication, the developer must host a public privacy policy URL and ensure the Google Play Data safety form accurately matches the app and its providers.", appLanguage), color = Color(0xFFFFD18A), fontWeight = FontWeight.Medium)
                    }
                },
                confirmButton = { TextButton(onClick = { showPrivacyDialog = false }) { Text(tr("Close", appLanguage), color = Color(0xFF5EEAD4)) } },
                containerColor = Color(0xFF111A2E),
                titleContentColor = Color.White,
                textContentColor = Color.White
            )
        }
        if (researchWebUrl.isNotBlank()) {
            AlertDialog(
                onDismissRequest = { researchWebUrl = "" },
                title = { Text(researchWebTitle, color = Color(0xFF5EEAD4), fontWeight = FontWeight.Bold) },
                text = {
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().height(480.dp),
                        factory = { ctx -> WebView(ctx).apply { webViewClient = WebViewClient(); settings.javaScriptEnabled = false; settings.domStorageEnabled = true; loadUrl(researchWebUrl) } },
                        update = { view -> if (view.url != researchWebUrl) view.loadUrl(researchWebUrl) }
                    )
                },
                confirmButton = { TextButton(onClick = { researchWebUrl = "" }) { Text(tr("Close", appLanguage), color = Color(0xFF5EEAD4)) } },
                containerColor = Color(0xFF111A2E)
            )
        }
        if (selectedNews != null) {
            val article = selectedNews!!
            AlertDialog(
                onDismissRequest = { selectedNews = null },
                title = { Text(tr("ACTUALITÉ", appLanguage), color = Color(0xFF5EEAD4), fontWeight = FontWeight.ExtraBold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text(article.title, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("${article.source} · ${java.text.SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(article.publishedAt))}", color = Color(0xFF8FA2BE), style = MaterialTheme.typography.labelSmall)
                        val detail = article.summary.ifBlank { "Le flux RSS fournit le titre et la date, mais pas de résumé détaillé pour cet article." }
                        Text(detail.take(480), color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodyMedium, maxLines = 4)
                        Text(tr("Publié il y a moins de 7 jours. Cette information peut influencer le marché, mais son impact sur le prix reste incertain.", appLanguage), color = Color(0xFF8FA2BE), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    }
                },
                confirmButton = { TextButton(onClick = { selectedNews = null }) { Text(tr("Fermer", appLanguage), color = Color(0xFF5EEAD4)) } },
                containerColor = Color(0xFF111A2E),
                titleContentColor = Color.White,
                textContentColor = Color.White
            )
        }
    }
    }
}
private fun speechPrice(value: Double, language: String): String {
    if (!value.isFinite()) return "unavailable"
    val raw = String.format(Locale.US, "%.12f", value).trimEnd('0').trimEnd('.')
    val parts = raw.split('.')
    if (parts.size == 1) return parts[0]
    val decimals = parts[1]
    val zeroCount = decimals.takeWhile { it == '0' }.length
    // Say tiny prices digit by digit after the decimal, avoiding TTS collapsing repeated zeros.
    val spokenDecimals = if (zeroCount >= 3 || decimals.length >= 7) decimals.map { it.toString() }.joinToString(" ") else decimals
    val point = when (language) { "ar" -> " فاصلة "; "fr" -> " virgule "; "es" -> " coma "; "de" -> " Komma "; "it" -> " virgola "; "zh" -> " 点 "; "ja" -> " 点 "; "ko" -> " 점 "; else -> " point " }
    return parts[0] + point + spokenDecimals
}

private fun fmt(v: Double): String = if (!v.isFinite()) "—" else String.format(java.util.Locale.US, "%.8f", v).trimEnd('0').trimEnd('.')
