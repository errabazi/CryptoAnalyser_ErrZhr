/** CryptoAnalyser activation backend with receipt email notification (no SMS).
 * Deploy as Web app: Execute as Me; access: Anyone.
 * Keep the spreadsheet and receipt folder private. Do not share activation codes until payment is verified.
 */
const CONFIG = {
  SPREADSHEET_ID: '1wsOzTj5oEX_LN0KERuSqLShwcErDzpdF6oyh6g-ckPw',
  SHEET_NAME: 'ActivationRequests',
  ADMIN_EMAIL: 'errabazi@gmail.com',
  CASHPLUS_BENEFICIARY: 'Errabazi Zouhair',
  PAYMENT_AMOUNT_MAD: 50,
  ACTIVE_WINDOW_SECONDS: 100,
  REQUEST_COOLDOWN_SECONDS: 300,
  MAX_RECEIPT_BYTES: 4 * 1024 * 1024,
  HEADERS: ['Created At', 'Email', 'Request ID', 'Activation Code', 'Receipt File Name', 'Receipt File ID', 'Receipt URL', 'Payment Status', 'Activation Status', 'Device ID', 'Session Token', 'Last Seen', 'Notes', 'Updated At']
};

function doGet() {
  return json_({ok:true, service:'CryptoAnalyser', message:'Backend is running.', actions:['request','activate','login','recoverCode','checkPayment','heartbeat','authorizeAnalysis','logout','coinInfo','investmentAdvice','sendTrialCode','verifyTrialCode']});
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const input = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = String(input.action || '');
    // Public coin information does not touch the activation spreadsheet and does not require the script lock.
    if (action === 'coinInfo') {
      const query = String(input.symbol || input.coin || '').trim().toUpperCase().replace(/[^A-Z0-9._-]/g, '').slice(0,40);
      if (!query) return json_({ok:false, message:'أدخل رمز العملة أو اسمها.'});
      return json_(getFreeCoinInfo_(query));
    }
    // AI advice uses a server-side key; never put the provider key inside the Android APK.
    if (action === 'investmentAdvice') {
      const symbol = String(input.symbol || '').trim().toUpperCase().replace(/[^A-Z0-9._/-]/g, '').slice(0,40);
      const question = String(input.question || '').trim().slice(0,1800);
      const marketContext = String(input.marketContext || '').trim().slice(0,12000);
      const language = String(input.language || 'en').slice(0,8);
      if (!symbol || !question) return json_({ok:false, message:'أدخل رمز العملة وسؤالك.'});
      return json_(generateInvestmentAdvice_(symbol, question, marketContext, language));
    }
    if (!lock.tryLock(10000)) return json_({ok:false, message:'الخدمة مشغولة. أعد المحاولة بعد قليل.'});
    const sheet = getSheet_();
    const now = new Date();
    const email = normalizeEmail_(input.email);
    const deviceId = String(input.deviceId || '').trim().slice(0,128);

    if (action === 'request' || action === 'register') {
      if (!email || !deviceId) return json_({ok:false, message:'أدخل بريدًا إلكترونيًا صحيحًا.'});
      // Check for a previously paid email before validating/uploading a receipt or appending a row.
      const rows = readRows_(sheet);
      const alreadyPaid = rows.slice().reverse().find(r => r.email === email && r.paymentStatus === 'PAID');
      if (alreadyPaid) return json_({ok:true, alreadyPaid:true, message:'هذا البريد الإلكتروني سبق التحقق من دفعه. سجّل الدخول باستخدام بريدك وكود التفعيل.'});
      const mime = String(input.receiptMimeType || '').toLowerCase();
      const b64 = String(input.receiptBase64 || input.receiptData || '');
      if (!b64) return json_({ok:false, message:'يجب إرفاق إيصال الدفع.'});
      if (!['image/jpeg','image/png','application/pdf'].includes(mime)) return json_({ok:false, message:'نوع الإيصال غير مدعوم. استخدم JPG أو PNG أو PDF.'});
      const bytes = Utilities.base64Decode(b64);
      if (!bytes.length || bytes.length > CONFIG.MAX_RECEIPT_BYTES) return json_({ok:false, message:'حجم الإيصال فارغ أو يتجاوز 4 ميغابايت.'});
      const recent = rows.find(r => r.email === email && (now.getTime()-r.createdAt.getTime())/1000 < CONFIG.REQUEST_COOLDOWN_SECONDS && ['PENDING','PAID'].includes(r.paymentStatus));
      if (recent) return json_({ok:false, message:'يوجد طلب حديث لهذا البريد. انتظر مراجعة الدفع أو استخدم كود التفعيل إذا وصلك.'});

      const folder = getReceiptFolder_();
      const filename = sanitizeFileName_(String(input.receiptFileName || 'payment-receipt'));
      const blob = Utilities.newBlob(bytes, mime, filename);
      const file = folder.createFile(blob);
      const requestId = Utilities.getUuid();
      const code = makeCode_(24);
      const row = [now, email, requestId, code, filename, file.getId(), file.getUrl(), 'PENDING', 'NOT_ACTIVATED', deviceId, '', '', 'بانتظار التحقق اليدوي من وصول 50 درهمًا.', now];
      sheet.appendRow(row);
      const subject = 'CryptoAnalyser — طلب تفعيل جديد';
      const body = 'وصل طلب تفعيل جديد لتطبيق CryptoAnalyser.\n\n' +
        'البريد الإلكتروني: ' + email + '\n' +
        'رقم الطلب: ' + requestId + '\n' +
        'تاريخ الطلب: ' + Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss') + '\n' +
        'المبلغ المطلوب: ' + CONFIG.PAYMENT_AMOUNT_MAD + ' MAD\n' +
        'المستفيد: ' + CONFIG.CASHPLUS_BENEFICIARY + '\n' +
        'اسم الإيصال: ' + filename + '\n' +
        'ملف الإيصال محفوظ في مجلد Drive خاص ومرفق بهذه الرسالة.\n\n' +
        'الإجراء: تحقق يدويًا من وصول المال أولًا. بعد التأكد، غيّر Payment Status إلى PAID في ورقة ActivationRequests، ثم أرسل كود التفعيل الموجود في العمود Activation Code إلى صاحب البريد. لا ترسل الكود قبل تأكيد الدفع.\n\n' +
        'تنبيه: الإيصال وحده لا يثبت وصول المال.';
      MailApp.sendEmail({to:CONFIG.ADMIN_EMAIL, subject:subject, body:body, attachments:[blob.copyBlob()]});
      return json_({ok:true, message:'تم إرسال طلب التفعيل والإيصال للمراجعة. انتظر تأكيد الدفع وكود التفعيل عبر البريد الإلكتروني.', requestId:requestId});
    }

    const rows = readRows_(sheet);

    // Email-verified, server-side 24-hour trial. Device/email keys are hashed; no raw device identifier is stored in Script Properties.
    if (action === 'sendTrialCode') {
      if (!email || !deviceId) return json_({ok:false, message:'أدخل بريدًا صحيحًا وتعذر تحديد الجهاز.'});
      const props = PropertiesService.getScriptProperties();
      const emailHash = sha256Hex_(email);
      const deviceHash = sha256Hex_(deviceId);
      const usedDeviceRaw = props.getProperty('TRIAL_USED_DEVICE_' + deviceHash);
      const usedEmailRaw = props.getProperty('TRIAL_USED_EMAIL_' + emailHash);
      let priorTrial = null;
      try { priorTrial = JSON.parse(usedDeviceRaw || 'null'); } catch (_) {}
      // If this exact email/device already has a valid trial, return its existing session;
      // never force the user to request/verify a second code during the same 24-hour window.
      if (priorTrial && priorTrial.emailHash === emailHash && priorTrial.deviceHash === deviceHash && Number(priorTrial.expiresAt) > Date.now()) {
        props.setProperty('TRIAL_ACTIVE_DEVICE_' + deviceHash, JSON.stringify(priorTrial));
        return json_({ok:true, trial:true, alreadyActive:true, expiresAt:Number(priorTrial.expiresAt), message:'تجربتك المجانية ما زالت فعالة؛ لا تحتاج إلى رمز جديد.'});
      }
      if (usedDeviceRaw || usedEmailRaw) {
        return json_({ok:false, message:'سبق استخدام التجربة المجانية لهذا البريد أو الجهاز. إذا بدأت التجربة من قبل، افتح التطبيق بالبريد نفسه وعلى الجهاز نفسه؛ لا تطلب رمزًا جديدًا.'});
      }
      const rateKey = 'TRIAL_CODE_LAST_' + emailHash;
      const lastSent = Number(props.getProperty(rateKey) || '0');
      if (Date.now() - lastSent < 60000) return json_({ok:true, message:'انتظر دقيقة قبل طلب رمز آخر.'});
      const verifyCode = String(Math.floor(100000 + Math.random() * 900000));
      const deviceMeta = {manufacturer:String(input.deviceManufacturer || '').slice(0,80), model:String(input.deviceModel || '').slice(0,100), androidVersion:String(input.androidVersion || '').slice(0,30)};
      props.setProperty('TRIAL_CODE_' + emailHash, JSON.stringify({code:verifyCode, deviceHash:deviceHash, deviceMeta:deviceMeta, expiresAt:Date.now()+10*60*1000, attempts:0}));
      props.setProperty(rateKey, String(Date.now()));
      MailApp.sendEmail({to:email, subject:'CryptoAnalyser — رمز التحقق للتجربة المجانية', body:'رمز التحقق الخاص بك هو: ' + verifyCode + '\n\nالرمز صالح لمدة 10 دقائق. بعد التحقق تبدأ تجربة مجانية مدتها 24 ساعة. إذا لم تطلب هذا الرمز فتجاهل الرسالة.'});
      return json_({ok:true, message:'إذا كان الطلب صالحًا، أرسلنا رمز التحقق إلى بريدك الإلكتروني.'});
    }

    if (action === 'verifyTrialCode') {
      if (!email || !deviceId) return json_({ok:false, message:'البريد أو الجهاز غير صالح.'});
      const props = PropertiesService.getScriptProperties();
      const emailHash = sha256Hex_(email), deviceHash = sha256Hex_(deviceId);
      const usedDeviceRaw = props.getProperty('TRIAL_USED_DEVICE_' + deviceHash);
      const usedEmailRaw = props.getProperty('TRIAL_USED_EMAIL_' + emailHash);
      let priorTrial = null;
      try { priorTrial = JSON.parse(usedDeviceRaw || 'null'); } catch (_) {}
      if (priorTrial && priorTrial.emailHash === emailHash && priorTrial.deviceHash === deviceHash && Number(priorTrial.expiresAt) > Date.now()) {
        props.setProperty('TRIAL_ACTIVE_DEVICE_' + deviceHash, JSON.stringify(priorTrial));
        return json_({ok:true, trial:true, alreadyActive:true, expiresAt:Number(priorTrial.expiresAt), message:'تجربتك المجانية ما زالت فعالة؛ تم استرجاع الجلسة الحالية.'});
      }
      if (usedDeviceRaw || usedEmailRaw) return json_({ok:false, message:'سبق استخدام التجربة المجانية لهذا البريد أو الجهاز.'});
      const codeKey = 'TRIAL_CODE_' + emailHash;
      let pending = null; try { pending = JSON.parse(props.getProperty(codeKey) || 'null'); } catch (_) {}
      if (!pending || pending.expiresAt < Date.now() || pending.deviceHash !== deviceHash || pending.code !== String(input.code || '').trim()) {
        if (pending) { pending.attempts = Number(pending.attempts || 0) + 1; if (pending.attempts >= 5) props.deleteProperty(codeKey); else props.setProperty(codeKey, JSON.stringify(pending)); }
        return json_({ok:false, message:'رمز التحقق غير صحيح أو انتهت صلاحيته.'});
      }
      const trial = {emailHash:emailHash, deviceHash:deviceHash, deviceMeta:pending.deviceMeta || {}, startedAt:Date.now(), expiresAt:Date.now()+24*60*60*1000};
      props.setProperty('TRIAL_USED_DEVICE_' + deviceHash, JSON.stringify(trial));
      props.setProperty('TRIAL_USED_EMAIL_' + emailHash, JSON.stringify(trial));
      props.setProperty('TRIAL_ACTIVE_DEVICE_' + deviceHash, JSON.stringify(trial));
      props.deleteProperty(codeKey);
      return json_({ok:true, message:'بدأت تجربتك المجانية لمدة 24 ساعة.', expiresAt:trial.expiresAt});
    }

    if (action === 'checkPayment') {
      if (!email) return json_({ok:false, message:'أدخل بريدًا إلكترونيًا صحيحًا.'});
      const props = PropertiesService.getScriptProperties();
      const emailHash = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, email, Utilities.Charset.UTF_8)
        .map(b => ('0' + ((b + 256) % 256).toString(16)).slice(-2)).join('');
      const rateKey = 'PAYMENT_CHECK_LAST_' + emailHash;
      const lastCheck = Number(props.getProperty(rateKey) || '0');
      if (Date.now() - lastCheck < 60000) {
        return json_({ok:true, message:'تم استلام طلب التحقق مؤخرًا. تحقق من بريدك الإلكتروني، بما في ذلك مجلد الرسائل غير المرغوب فيها.'});
      }
      props.setProperty(rateKey, String(Date.now()));
      const paidRow = rows.slice().reverse().find(r => r.email === email && r.paymentStatus === 'PAID' && r.activationCode && r.activationStatus !== 'SUSPENDED');
      if (paidRow) {
        // For account safety, never expose an activation credential in a public API response
        // based only on knowledge of an email address. Deliver it to the matching mailbox.
        MailApp.sendEmail({
          to: email,
          subject: 'CryptoAnalyser — code d’activation confirmé',
          body: 'Bonjour,\n\nLe paiement associé à votre demande a été confirmé. Voici votre code d’activation :\n\n' + paidRow.activationCode + '\n\nSaisissez dans CryptoAnalyser la même adresse e-mail et ce code. Si vous n’avez pas demandé cette vérification, ignorez ce message et contactez ' + CONFIG.ADMIN_EMAIL + '.\n\nCryptoAnalyser by ErrZhr'
        });
      }
      // Avoid disclosing whether an email has an account or a paid request to strangers.
      return json_({ok:true, message:'Si une demande existe et que le paiement a été confirmé, le code d’activation a été envoyé à cette adresse e-mail. Vérifiez aussi les courriers indésirables.'});
    }

    if (action === 'recoverCode' || action === 'forgotCode') {
      if (!email) return json_({ok:false, message:'أدخل بريدًا إلكترونيًا صحيحًا.'});
      // Rate-limit recovery attempts per email to reduce abuse.
      const props = PropertiesService.getScriptProperties();
      const emailHash = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, email, Utilities.Charset.UTF_8)
        .map(b => ('0' + ((b + 256) % 256).toString(16)).slice(-2)).join('');
      const rateKey = 'RECOVERY_LAST_' + emailHash;
      const usedKey = 'RECOVERY_USED_ONCE_' + emailHash;
      const lastSent = Number(props.getProperty(rateKey) || '0');
      const genericMessage = 'إذا كان البريد مرتبطًا بطلب مدفوع ومؤكد ولم تُستخدم استعادة الكود من قبل، فستصلك رسالة بالبريد الإلكتروني. تحقق أيضًا من مجلد الرسائل غير المرغوب فيها.';
      // Recovery is a one-time account feature. This is enforced server-side so reinstalling
      // the app or changing phones cannot reset the limit.
      if (props.getProperty(usedKey) === 'YES') {
        return json_({ok:true, message:'تم استخدام استعادة كود التفعيل لهذا البريد من قبل. لأسباب أمنية، تواصل مع الدعم على ' + CONFIG.ADMIN_EMAIL + '.'});
      }
      if (Date.now() - lastSent < 300000) return json_({ok:true, message:genericMessage});
      const paidRow = rows.slice().reverse().find(r => r.email === email && r.paymentStatus === 'PAID' && r.activationCode && r.activationStatus !== 'SUSPENDED');
      if (paidRow) {
        MailApp.sendEmail({
          to: email,
          subject: 'CryptoAnalyser — استعادة كود التفعيل (استخدام لمرة واحدة)',
          body: 'مرحبًا،\n\nطلبت استعادة كود التفعيل الخاص بتطبيق CryptoAnalyser. هذه خاصية استعادة لمرة واحدة فقط لهذا البريد الإلكتروني.\n\nكود التفعيل: ' + paidRow.activationCode + '\n\nأدخل البريد الإلكتروني نفسه وهذا الكود داخل التطبيق. إذا لم تطلب هذه الرسالة، يمكنك تجاهلها. لا تشارك الكود مع أي شخص.\n\nCryptoAnalyser by ErrZhr'
        });
        // Mark as used only after MailApp accepts the send operation.
        props.setProperty(usedKey, 'YES');
        props.setProperty(rateKey, String(Date.now()));
      }
      return json_({ok:true, message:genericMessage});
    }

    if (!email || !deviceId) return json_({ok:false, message:'البريد الإلكتروني أو معرّف الجهاز غير صالح.'});

    if (action === 'activate' || action === 'login') {
      const code = String(input.code || input.activationCode || '').trim();
      if (!code || code.length > 64) return json_({ok:false, message:'كود التفعيل غير صالح.'});
      const row = rows.slice().reverse().find(r => r.email === email && constantTimeEqual_(r.activationCode, code));
      if (!row) return json_({ok:false, message:'البريد الإلكتروني أو الكود غير صحيح.'});
      if (row.paymentStatus !== 'PAID') return json_({ok:false, message:'لم يؤكد صاحب التطبيق الدفع بعد.'});
      if (row.activationStatus === 'SUSPENDED') return json_({ok:false, message:'تم إيقاف هذا الحساب. تواصل مع صاحب التطبيق.'});
      const activeOther = rows.find(r => r.email === email && r.activationStatus === 'ACTIVATED' && r.deviceId && r.deviceId !== deviceId && isFresh_(r.lastSeen, now));
      if (activeOther) return json_({ok:false, code:'DUPLICATE_SESSION', message:'هذا الحساب نشط على جهاز آخر.'});
      rows.filter(r => r.email === email && r.activationStatus === 'ACTIVATED' && r.sheetRow !== row.sheetRow).forEach(r => sheet.getRange(r.sheetRow,9).setValue('SESSION_REPLACED'));
      const token = Utilities.getUuid() + Utilities.getUuid();
      sheet.getRange(row.sheetRow,9).setValue('ACTIVATED');
      sheet.getRange(row.sheetRow,10).setValue(deviceId);
      sheet.getRange(row.sheetRow,11).setValue(token);
      sheet.getRange(row.sheetRow,12).setValue(now);
      sheet.getRange(row.sheetRow,14).setValue(now);
      return json_({ok:true, message:'تم تفعيل الحساب.', sessionToken:token});
    }

    if (action === 'heartbeat' || action === 'authorizeAnalysis') {
      const active = rows.find(r => r.email === email && r.activationStatus === 'ACTIVATED' && r.paymentStatus === 'PAID');
      if (!active) {
        const props = PropertiesService.getScriptProperties();
        const deviceHash = sha256Hex_(deviceId);
        const emailHash = sha256Hex_(email);
        const trialRaw = props.getProperty('TRIAL_ACTIVE_DEVICE_' + deviceHash) || props.getProperty('TRIAL_USED_DEVICE_' + deviceHash);
        let trial = null; try { trial = JSON.parse(trialRaw || 'null'); } catch (_) {}
        if (trial && trial.emailHash === emailHash && trial.deviceHash === deviceHash && Number(trial.expiresAt) > Date.now()) {
          // Repair the active-session pointer from the durable used-trial record if needed.
          props.setProperty('TRIAL_ACTIVE_DEVICE_' + deviceHash, JSON.stringify(trial));
          return json_({ok:true, trial:true, expiresAt:Number(trial.expiresAt), message:'التجربة المجانية فعالة.'});
        }
        return json_({ok:false, message:'انتهت التجربة المجانية أو لا يوجد ترخيص مفعّل لهذا البريد.'});
      }
      if (active.deviceId !== deviceId) return json_({ok:false, code:'DUPLICATE_SESSION', message:'هذا الحساب نشط على جهاز آخر. تم تسجيل الخروج.'});
      sheet.getRange(active.sheetRow,12).setValue(now);
      sheet.getRange(active.sheetRow,14).setValue(now);
      return json_({ok:true, message:action === 'authorizeAnalysis' ? 'Analysis request authorized.' : 'الجلسة صالحة.'});
    }

    if (action === 'logout') {
      const active = rows.find(r => r.email === email && r.activationStatus === 'ACTIVATED' && r.deviceId === deviceId);
      if (active) {
        sheet.getRange(active.sheetRow,9).setValue('LOGGED_OUT');
        sheet.getRange(active.sheetRow,10).clearContent();
        sheet.getRange(active.sheetRow,11).clearContent();
        sheet.getRange(active.sheetRow,12).clearContent();
        sheet.getRange(active.sheetRow,14).setValue(now);
      }
      return json_({ok:true, message:'تم تسجيل الخروج.'});
    }
    return json_({ok:false, message:'طلب غير معروف.'});
  } catch (err) {
    console.error(err && err.stack ? err.stack : err);
    return json_({ok:false, message:'حدث خطأ في خدمة التفعيل. تحقق من إعدادات Apps Script وحاول لاحقًا.'});
  } finally {
    try { lock.releaseLock(); } catch (_) {}
  }
}

/**
 * Generates contextual trading education with the Gemini API free tier where available.
 * Configure Script Property GEMINI_API_KEY once in Apps Script; the key is never sent to clients.
 */
function generateInvestmentAdvice_(symbol, question, marketContext, language) {
  const apiKey = PropertiesService.getScriptProperties().getProperty('GEMINI_API_KEY');
  if (!apiKey) return {ok:false, message:'خدمة الذكاء الاصطناعي لم تُفعّل بعد من جهة التطبيق. على المسؤول إضافة GEMINI_API_KEY إلى خصائص المشروع في Apps Script مرة واحدة.'};

  const languageNames = {ar:'Arabic', fr:'French', en:'English', es:'Spanish', de:'German', it:'Italian', zh:'Simplified Chinese', ja:'Japanese', ko:'Korean'};
  const outputLanguage = languageNames[language] || 'English';
  const prompt = [
    'You are the AI analysis assistant inside CryptoAnalyser, a cryptocurrency market analysis app.',
    'Answer in ' + outputLanguage + '. Be direct, clear, specific, reasoned, and useful. Do not give generic filler.',
    'The user is asking about the coin/market/position shown below. Use the supplied technical indicators and user position details explicitly.',
    'Structure the answer as: (1) direct answer, (2) evidence from the supplied data, (3) actionable conditional scenarios with key levels if supported, (4) what would invalidate the view, (5) concise risk note.',
    'Do not claim indicator scores are true probabilities; they are heuristic scores. Never guarantee profit or predict a price with certainty.',
    'Do not invent news, investors, project adoption, supply figures, or fundamental facts. If fundamental evidence is absent, say which specific fundamental fact is unverified, but still answer using the available technical and position data instead of refusing the whole question.',
    'If a price, entry, quantity, or target was supplied, calculate relevant percentage gain/loss and position P/L correctly when possible. State units and assumptions.',
    'If no entry/quantity is supplied, do not pretend to know the user position. For a sell target, assess feasibility against current price, resistance, timeframe and the data provided.',
    'Do not ask the user to repeat information already in the context. If an essential input is missing, provide a conditional answer using the available facts and name only that missing input briefly.',
    'No personalized certainty: present an evidence-based assessment, not a guaranteed buy/sell command.',
    'Symbol: ' + symbol,
    'User question: ' + question,
    'Current app analysis context (may contain empty fields):\n' + marketContext
  ].join('\n\n');

  const endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(apiKey);
  const payload = {
    contents: [{role:'user', parts:[{text:prompt}]}],
    generationConfig: {temperature:0.35, maxOutputTokens:1800, topP:0.9},
    safetySettings: [
      {category:'HARM_CATEGORY_HARASSMENT', threshold:'BLOCK_MEDIUM_AND_ABOVE'},
      {category:'HARM_CATEGORY_HATE_SPEECH', threshold:'BLOCK_MEDIUM_AND_ABOVE'},
      {category:'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold:'BLOCK_MEDIUM_AND_ABOVE'},
      {category:'HARM_CATEGORY_DANGEROUS_CONTENT', threshold:'BLOCK_MEDIUM_AND_ABOVE'}
    ]
  };
  try {
    const response = UrlFetchApp.fetch(endpoint, {
      method:'post', contentType:'application/json', payload:JSON.stringify(payload), muteHttpExceptions:true
    });
    const status = response.getResponseCode();
    const body = response.getContentText();
    if (status < 200 || status >= 300) {
      console.error('Gemini HTTP ' + status + ': ' + body.slice(0,500));
      if (status === 429) return {ok:false, message:'وصلت خدمة الذكاء الاصطناعي إلى حد الاستخدام المجاني مؤقتًا. حاول لاحقًا.'};
      if (status === 400 || status === 403) return {ok:false, message:'تعذر على خدمة الذكاء الاصطناعي قبول الطلب. تحقق من مفتاح Gemini وصلاحية الخدمة في إعدادات المسؤول.'};
      return {ok:false, message:'خدمة الذكاء الاصطناعي غير متاحة مؤقتًا. حاول مجددًا بعد قليل.'};
    }
    const data = JSON.parse(body);
    const candidates = data.candidates || [];
    const parts = candidates.length && candidates[0].content ? (candidates[0].content.parts || []) : [];
    const answer = parts.map(p => String(p.text || '')).join('\n').trim();
    if (!answer) return {ok:false, message:'لم تنتج الخدمة إجابة قابلة للعرض. أعد المحاولة بصياغة أخرى.'};
    return {ok:true, answer:answer, model:'gemini-2.5-flash', generatedAt:new Date().toISOString()};
  } catch (err) {
    const details = String(err && err.message ? err.message : err);
    console.error('Investment advice error: ' + (err && err.stack ? err.stack : details));
    return {
      ok: false,
      message: 'تفاصيل خطأ الاتصال: ' + details.slice(0, 250)
    };
  }
}

/**
 * Free public market/fundamental lookup.
 * Bitget ticker supplies 24h market volume when the coin has a SYMBOLUSDT Spot pair.
 * CoinPaprika public endpoints supply market cap, circulating/total/max supply and project description.
 * Symbols are ambiguous across projects, so the function refuses to silently select among multiple matches.
 */
function getFreeCoinInfo_(symbol) {
  const result = {
    ok: true, symbol: symbol, sources: [], updatedAt: new Date().toISOString(),
    priceUsdt: null, volume24hUsdt: null, marketCapUsd: null,
    circulatingSupply: null, totalSupply: null, maxSupply: null,
    projectName: null, description: null, categoryTags: [], website: null,
    whitepaper: null, sourceNotes: []
  };
  const normalized = symbol.toUpperCase();

  // Bitget's public market endpoint requires no API key or private account permissions.
  try {
    const pair = normalized.endsWith('USDT') ? normalized : normalized + 'USDT';
    const response = UrlFetchApp.fetch('https://api.bitget.com/api/v2/spot/market/tickers?symbol=' + encodeURIComponent(pair), {muteHttpExceptions:true});
    if (response.getResponseCode() >= 200 && response.getResponseCode() < 300) {
      const root = JSON.parse(response.getContentText());
      const data = root && root.data;
      const ticker = Array.isArray(data) ? data[0] : data;
      if (root.code === '00000' && ticker) {
        result.priceUsdt = numberOrNull_(ticker.lastPr || ticker.close);
        // quoteVolume is quote-currency turnover, generally USDT for a USDT pair.
        result.volume24hUsdt = numberOrNull_(ticker.quoteVolume || ticker.usdtVolume || ticker.turnover24h);
        result.bitgetPair = pair;
        result.sources.push('Bitget public Spot ticker');
      } else result.sourceNotes.push('Bitget did not return a ticker for ' + pair + '.');
    } else result.sourceNotes.push('Bitget public ticker temporarily unavailable (HTTP ' + response.getResponseCode() + ').');
  } catch (err) {
    result.sourceNotes.push('Bitget public ticker could not be read.');
  }

  // CoinPaprika has a free public API without an API key; same-symbol projects may be ambiguous.
  try {
    const searchUrl = 'https://api.coinpaprika.com/v1/search/?q=' + encodeURIComponent(normalized) + '&c=currencies&limit=25';
    const response = UrlFetchApp.fetch(searchUrl, {muteHttpExceptions:true});
    if (response.getResponseCode() >= 200 && response.getResponseCode() < 300) {
      const search = JSON.parse(response.getContentText());
      const currencies = (search && search.currencies) || [];
      const exact = currencies.filter(c => String(c.symbol || '').toUpperCase() === normalized || String(c.name || '').toUpperCase() === normalized);
      const candidates = exact.length ? exact : currencies.filter(c => String(c.symbol || '').toUpperCase() === normalized);
      if (candidates.length > 1) {
        result.ok = true;
        result.ambiguous = true;
        result.candidates = candidates.slice(0,8).map(c => ({id:c.id, name:c.name, symbol:c.symbol, rank:c.rank || null}));
        result.sourceNotes.push('Several projects match this symbol. Select the exact project before trusting fundamental data.');
      } else if (candidates.length === 1) {
        const coin = candidates[0];
        const id = String(coin.id || '');
        const tickerResponse = UrlFetchApp.fetch('https://api.coinpaprika.com/v1/tickers/' + encodeURIComponent(id) + '?quotes=USD', {muteHttpExceptions:true});
        if (tickerResponse.getResponseCode() >= 200 && tickerResponse.getResponseCode() < 300) {
          const ticker = JSON.parse(tickerResponse.getContentText());
          const usd = ticker && ticker.quotes && ticker.quotes.USD;
          if (usd) {
            result.projectName = ticker.name || coin.name || null;
            result.marketCapUsd = numberOrNull_(usd.market_cap);
            result.circulatingSupply = numberOrNull_(ticker.circulating_supply);
            result.totalSupply = numberOrNull_(ticker.total_supply);
            result.maxSupply = numberOrNull_(ticker.max_supply);
            if (result.priceUsdt == null) result.priceUsd = numberOrNull_(usd.price);
            result.coinPaprikaId = id;
            result.sources.push('CoinPaprika public ticker');
          }
        }
        const detailResponse = UrlFetchApp.fetch('https://api.coinpaprika.com/v1/coins/' + encodeURIComponent(id), {muteHttpExceptions:true});
        if (detailResponse.getResponseCode() >= 200 && detailResponse.getResponseCode() < 300) {
          const detail = JSON.parse(detailResponse.getContentText());
          result.projectName = result.projectName || detail.name || coin.name || null;
          result.description = String(detail.description || '').slice(0,5000) || null;
          result.categoryTags = (detail.tags || []).slice(0,20).map(t => t.name).filter(Boolean);
          const links = detail.links || {};
          result.website = (links.website || [])[0] || null;
          result.whitepaper = (links.whitepaper || [])[0] || null;
          result.sources.push('CoinPaprika public project profile');
        }
      } else {
        result.sourceNotes.push('No exact CoinPaprika project match was found; supply and market capitalization are unknown.');
      }
    } else result.sourceNotes.push('CoinPaprika public API temporarily unavailable (HTTP ' + response.getResponseCode() + ').');
  } catch (err) {
    result.sourceNotes.push('CoinPaprika data could not be read.');
  }

  if (result.sources.length === 0) {
    result.ok = false;
    result.message = 'لم تتوفر بيانات عامة موثوقة لهذه العملة الآن. حاول لاحقًا أو تحقق من رمز العملة.';
  }
  result.disclaimer = 'Public market data can be delayed or incomplete. Market volume is trading turnover, not verified net cash inflow. Supply and market cap depend on provider coverage and project identity.';
  return result;
}

function numberOrNull_(value) {
  if (value === null || value === undefined || value === '') return null;
  const n = Number(value);
  return isFinite(n) ? n : null;
}

function setupSheet() {
  const sheet = getSheet_();
  sheet.setFrozenRows(1);
  sheet.getRange(1,1,1,CONFIG.HEADERS.length).setFontWeight('bold');
  sheet.setColumnWidths(1, CONFIG.HEADERS.length, 170);
  sheet.getRange('A:A').setNumberFormat('yyyy-mm-dd hh:mm:ss');
  sheet.getRange('N:N').setNumberFormat('yyyy-mm-dd hh:mm:ss');
  getReceiptFolder_();
  return 'ActivationRequests is ready.';
}

function getSheet_() {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  let sheet = ss.getSheetByName(CONFIG.SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(CONFIG.SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1,1,1,CONFIG.HEADERS.length).setValues([CONFIG.HEADERS]);
  } else {
    const existing = sheet.getRange(1,1,1,Math.max(sheet.getLastColumn(),1)).getValues()[0].map(String);
    if (existing.length === 7 && existing[0] === 'Request timestamp') {
      // Preserve existing rows while expanding the older seven-column schema.
      sheet.getRange(1,1,1,CONFIG.HEADERS.length).setValues([CONFIG.HEADERS]);
      const last = sheet.getLastRow();
      if (last > 1) {
        const old = sheet.getRange(2,1,last-1,7).getValues();
        const upgraded = old.map(r => [r[0], r[1], Utilities.getUuid(), r[2], '', '', '', r[3] === 'PAID' ? 'PAID' : 'PENDING', r[3] === 'ACTIVE' ? 'ACTIVATED' : 'NOT_ACTIVATED', r[4] || '', '', r[5] || '', 'Migrated from previous version', r[6] || new Date()]);
        sheet.getRange(2,1,upgraded.length,CONFIG.HEADERS.length).setValues(upgraded);
      }
    } else {
      const first = existing.slice(0, CONFIG.HEADERS.length);
      if (first[0] !== CONFIG.HEADERS[0] || first[1] !== CONFIG.HEADERS[1]) {
        throw new Error('ActivationRequests headers do not match the expected schema. Back up the sheet before changing headers.');
      }
      if (sheet.getLastColumn() < CONFIG.HEADERS.length) sheet.insertColumnsAfter(sheet.getLastColumn(), CONFIG.HEADERS.length - sheet.getLastColumn());
      sheet.getRange(1,1,1,CONFIG.HEADERS.length).setValues([CONFIG.HEADERS]);
    }
  }
  return sheet;
}

function getReceiptFolder_() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('CRYPTOANALYSER_RECEIPT_FOLDER_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (_) {} }
  const folder = DriveApp.createFolder('CryptoAnalyser_Private_Receipts');
  props.setProperty('CRYPTOANALYSER_RECEIPT_FOLDER_ID', folder.getId());
  return folder;
}

function readRows_(sheet) {
  if (sheet.getLastRow() < 2) return [];
  return sheet.getRange(2,1,sheet.getLastRow()-1,CONFIG.HEADERS.length).getValues().map((r,i) => ({
    createdAt:r[0] instanceof Date ? r[0] : new Date(r[0]), email:normalizeEmail_(r[1]), requestId:String(r[2]||''),
    activationCode:String(r[3]||''), receiptFileName:String(r[4]||''), receiptFileId:String(r[5]||''), receiptUrl:String(r[6]||''),
    paymentStatus:String(r[7]||''), activationStatus:String(r[8]||''), deviceId:String(r[9]||''), sessionToken:String(r[10]||''),
    lastSeen:r[11] instanceof Date ? r[11] : (r[11] ? new Date(r[11]) : null), notes:String(r[12]||''), updatedAt:r[13], sheetRow:i+2
  }));
}
function makeCode_(length) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*-_';
  let out = '';
  while (out.length < length) {
    const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, Utilities.getUuid()+':'+Date.now()+':'+Math.random());
    for (let i=0; i<bytes.length && out.length<length; i++) out += chars[(bytes[i] & 0xff) % chars.length];
  }
  return out;
}
function sha256Hex_(value) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(value), Utilities.Charset.UTF_8).map(b => ('0' + ((b + 256) % 256).toString(16)).slice(-2)).join(''); }
function normalizeEmail_(value) { const email=String(value||'').trim().toLowerCase(); return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : ''; }
function isFresh_(date, now) { return date instanceof Date && !isNaN(date.getTime()) && (now.getTime()-date.getTime())/1000 <= CONFIG.ACTIVE_WINDOW_SECONDS; }
function constantTimeEqual_(a,b) { a=String(a); b=String(b); let d=a.length^b.length; for(let i=0,n=Math.max(a.length,b.length);i<n;i++) d|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0); return d===0; }
function sanitizeFileName_(name) { return name.replace(/[\\/:*?"<>|\r\n]/g,'_').slice(0,120) || 'payment-receipt'; }
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
