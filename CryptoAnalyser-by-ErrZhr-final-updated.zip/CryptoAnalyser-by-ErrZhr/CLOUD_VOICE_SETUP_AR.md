# إعداد الصوت السحابي باستخدام Amazon Polly

يستخدم التطبيق خادم Cloudflare Worker وسيطًا، ثم يطلب الصوت من Amazon Polly. لا يستخدم محرك الصوت المحلي للهاتف ولا ElevenLabs. **لن يعمل الصوت قبل نشر الخادم وضبط بيانات AWS ومعرّفات أصوات صالحة.**

## 1. المتطلبات
- حساب AWS مع تفعيل Amazon Polly.
- مستخدم IAM مخصص بأقل صلاحيات لازمة لاستدعاء `polly:SynthesizeSpeech`.
- حساب Cloudflare ونظام Node.js حديث.

## 2. نشر الخادم
من مجلد `cloud-voice-worker` نفّذ:

```bash
npm install
npx wrangler login
npx wrangler secret put AWS_ACCESS_KEY_ID
npx wrangler secret put AWS_SECRET_ACCESS_KEY
npx wrangler secret put AWS_REGION
npx wrangler deploy
```

أدخل القيم المطلوبة عندما يطلبها Wrangler. استخدم منطقة AWS التي تدعم Amazon Polly في حسابك. لا تضع أي مفتاح في `MainActivity.kt` أو في مستودع GitHub.

## 3. إعداد الأصوات
يوجد في التطبيق أربعة أسماء اختيارية: Sara وLina وAhmed وYoussef. عيّن لكل اسم ولكل لغة معرّف صوت Polly صالحًا عبر متغيرات Worker مثل `VOICE_SARA_AR` و`VOICE_AHMED_FR` و`VOICE_LINA_EN`. أسماء المتغيرات للغات هي `AR`, `FR`, `EN`, `ZH`, `JA`, `ES`, `DE`, `IT`, `KO`.

لا تفترض أن كل صوت أو نمط Neural متوفر في كل لغة أو منطقة؛ اختر معرّفات فعلية من قائمة Amazon Polly الرسمية، واختبر كل لغة. يمكن أن يشير اسمان إلى الصوت نفسه إذا لم يتوفر بديل مناسب، لكنهما لن يكونا صوتين مختلفين حينها. لا تستخدم صوت شخص حقيقي دون إذن.

يمكن اختيار المحرك عبر متغير `POLLY_ENGINE` بقيمة `neural` أو `standard`، وفق دعم الصوت المختار. إذا أعاد المزود خطأ بسبب عدم دعم المحرك، اختر `standard` أو صوتًا متوافقًا.

## 4. ربط التطبيق
في `app/src/main/java/com/example/cryptoanalyzer/MainActivity.kt` استبدل القيمة التجريبية `https://YOUR-CRYPTOANALYSER-VOICE-WORKER.workers.dev/tts` بعنوان Worker المنشور مع المسار الذي تستخدمه. ثم ابنِ APK من GitHub Actions واختبره على جهاز فعلي.

## 5. السلاسة والتكلفة
- تقسيم التقرير الطويل إلى أجزاء قصيرة يحسن الاستئناف والتحكم في التشغيل، لكنه قد يضيف تأخيرًا بين الأجزاء.
- يجب اختبار نطق الأسعار الصغيرة والرموز الرقمية باللغات التسع؛ لا توجد معالجة واحدة تضمن النطق المثالي لكل لغة.
- Amazon Polly خدمة مدفوعة وفق الاستخدام والخطة المؤهلة؛ راجع الأسعار وحدود الاستخدام قبل الاختبار المتكرر.
- لا تضع مفاتيح AWS في APK أو في مستودع عام. قيّد صلاحيات IAM وراقب الاستهلاك.
