/** Cloudflare Worker proxy for Amazon Polly. Provider credentials stay in Worker secrets. */
import { AwsClient } from 'aws4fetch';
const LANGS = new Set(['ar','fr','en','zh','ja','es','de','it','ko']);
const LOCALES = { ar:'AR', fr:'FR', en:'EN', zh:'ZH', ja:'JA', es:'ES', de:'DE', it:'IT', ko:'KO' };
const VOICES = ['sara','lina','ahmed','youssef'];
function voiceKey(name, lang) { return `VOICE_${name.toUpperCase()}_${LOCALES[lang]}`; }
export default {
  async fetch(request, env) {
    const cors = { 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'POST, OPTIONS', 'Access-Control-Allow-Headers':'Content-Type', 'X-Content-Type-Options':'nosniff' };
    if (request.method === 'OPTIONS') return new Response(null, { status:204, headers:cors });
    if (request.method !== 'POST') return new Response('Method not allowed', { status:405, headers:{...cors,'Allow':'POST, OPTIONS'} });
    if (!env.AWS_ACCESS_KEY_ID || !env.AWS_SECRET_ACCESS_KEY || !env.AWS_REGION) return Response.json({error:'Amazon Polly service is not configured'}, {status:503, headers:cors});
    let data;
    try { data = await request.json(); } catch { return Response.json({error:'Invalid JSON'}, {status:400, headers:cors}); }
    const text = typeof data.text === 'string' ? data.text.trim() : '';
    const lang = typeof data.language === 'string' ? data.language.toLowerCase() : 'en';
    const voice = typeof data.voice === 'string' && VOICES.includes(data.voice.toLowerCase()) ? data.voice.toLowerCase() : (data.speaker === 'male' ? 'ahmed' : 'sara');
    if (!text || text.length > 5000) return Response.json({error:'Text must contain 1–5000 characters'}, {status:400, headers:cors});
    if (!LANGS.has(lang)) return Response.json({error:'Unsupported language'}, {status:400, headers:cors});
    const voiceId = env[voiceKey(voice, lang)];
    if (!voiceId) return Response.json({error:`Missing Amazon Polly voice setting: ${voiceKey(voice, lang)}`}, {status:503, headers:cors});
    const endpoint = `https://polly.${env.AWS_REGION}.amazonaws.com/v1/speech`;
    const client = new AwsClient({ accessKeyId:env.AWS_ACCESS_KEY_ID, secretAccessKey:env.AWS_SECRET_ACCESS_KEY, region:env.AWS_REGION, service:'polly' });
    try {
      const upstream = await client.fetch(endpoint, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({Text:text, OutputFormat:'mp3', VoiceId:voiceId, Engine:env.POLLY_ENGINE || 'neural'}) });
      if (!upstream.ok) {
        const detail = (await upstream.text()).slice(0,500);
        return Response.json({error:'Amazon Polly rejected request', detail}, {status:502, headers:cors});
      }
      return new Response(upstream.body, {headers:{...cors,'Content-Type':'audio/mpeg','Cache-Control':'no-store'}});
    } catch (error) {
      return Response.json({error:'Could not reach Amazon Polly'}, {status:502, headers:cors});
    }
  }
};
