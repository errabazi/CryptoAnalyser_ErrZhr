
# CryptoAnalyser-by ErrZhr (Android)

Kotlin + Jetpack Compose Android project for educational cryptocurrency market analysis using public Bitget endpoints.

## Features
- Bitget Spot and USDT Futures public market data.
- Coin-pair autocomplete, EMA/OBV/MACD indicators, support/resistance, historical extremes and an educational EMA crossover backtest.
- Recent crypto news from public CoinDesk and Cointelegraph RSS feeds, limited to four items from the last seven days.
- Separate spoken coin/project profile and technical market outlook, with play/stop/restart controls, voice preview on selection, and free on-device Android text-to-speech. No cloud voice account, paid service, or extra app download is required; voice availability depends on the phone and language.
- `FLAG_SECURE`, portrait orientation, non-resizable activity declaration, disabled app backup, and HTTPS-only network traffic.
- In-app privacy and financial-risk disclosure.

## Build locally
Open this folder in Android Studio with JDK 17 and Android SDK Platform 36 installed. Let Gradle sync, then run `lintDebug` and `assembleDebug`. CI uses Gradle 8.11.1 and builds a debug APK.

## Before publishing
Read `PLAY_STORE_RELEASE_CHECKLIST.md` and `PRIVACY_POLICY.md`. The package ID `com.example.cryptoanalyzer` is a placeholder and must be changed before the first Play release. Host the completed privacy policy at a public HTTPS URL, fill in the real developer contact email, complete the Data safety and Financial features declarations, sign a release AAB, and configure Play App Signing. Enable Protected with Play / Automatic protection in Play Console if available.

**No guarantee of Google Play approval is possible from source changes alone.** The app has not been built in this environment; CI must pass and the app must be tested before release. The app provides market information only and is not an official Bitget product.


## Summary voice

After a market analysis, use the **Listen to the Summary** card to hear the summary aloud. Tap the woman or man avatar to select a preferred voice; the selection is saved on the device. The actual voice depends on the text-to-speech voices installed and exposed by the Android device, so some devices may use their default voice if a matching voice is unavailable.

## Build

Run `gradle --no-daemon assembleDebug` from the project root (with Java 17, Gradle 8.11.1, and Android SDK platform 36 installed). The GitHub Actions workflow builds from the project root and verifies that the debug APK was generated. A local build was not run in the environment used to prepare this archive.

## Automatic entry plan
After market analysis, the app displays three long/Spot reference scenarios automatically: an aggressive entry near support, a breakout-confirmation trigger, and a more conservative trigger. Each scenario includes its own stop-loss level and three risk-multiple take-profit targets (1R, 2R, 3R). These are analytical reference levels derived from the current price and 4H support/resistance, not live orders or guaranteed forecasts. Breakout scenarios require candle-close confirmation and trading involves risk.

## Spoken summary voice
The summary panel offers Woman and Man voice choices and saves the selection on the device. Actual voice gender and availability depend on the installed Android text-to-speech engine and voice packs.


## Patch notes (2026-10-19)
- Added paginated daily-candle scanning for ATH/ATL separately for the selected Bitget Spot market or USDT Futures contract. Values are only marked complete when the history endpoint indicates the scan reached the end; otherwise they are estimates of available history and should be treated accordingly.
- Added API-level Bitget error-code validation so failed responses are not silently parsed as empty market data.
- Replaced the Favorites feature with a persisted list of the last three analyzed symbols; tapping a symbol reruns its analysis.
- Added a collapsible Token Unlocks section with links to Tokenomist, CryptoRank, and official-announcement searches. This build does **not** fetch or verify unlock schedules automatically; it explicitly warns users not to treat these links as a verified unlock table.
- Price alerts support editing and deleting existing alerts.

Build validation note: source/ZIP integrity checks are performed for this package, but an Android SDK/Gradle build environment is not available in this session, so successful APK compilation is not claimed.


## Activation setup (Arabic)

This project includes a fail-closed activation gate backed by Google Sheets and Google Apps Script (no Firebase). Before building a usable APK, follow [`SETUP_ACTIVATION_AR.md`](SETUP_ACTIVATION_AR.md) and replace the placeholder web-app URL in `ActivationGate.kt`. Without a deployed endpoint configured, the app intentionally blocks market analysis.

## Payment activation + receipt upload
See `SETUP_ACTIVATION_AR.md` for the required Apps Script deployment update, private receipt storage, admin email notification, and the WhatsApp contact note shown to users. No SMS notification is sent.

## Recent interface updates
- The activation-code field displays the characters as typed so the user can review the code before submitting it.
- The activation help card now gives Arabic, English, and French instructions: if the code does not arrive within 30 minutes, email `errabazi@gmail.com` with the payment receipt or contact WhatsApp `00212620202714`.
- The candlestick chart overlays dashed 24-hour high and low levels from Bitget ticker data, independent of the selected candle timeframe.
- The Coin News section now starts with a collapsible research hub for project utility, launch history, funding, token unlocks, adoption/partnerships, and long-horizon price scenarios. Search results open in an in-app WebView.
- Token-unlock source searches also open inside the app. Unlock dates and quantities are explicitly marked unverified unless confirmed by a reliable data source; this build does not claim a complete automated unlock database.

Build validation note: this source archive was structurally checked in the available environment, but an Android Gradle build was not run here because Gradle/Android SDK tooling was not installed. Use the included GitHub Actions workflow to perform the authoritative APK build and lint checks.


## Final app and APK names

- Installed app label on the phone: `cryptoanalyser`
- APK file produced by GitHub Actions: `cryptoanalyser.apk`
- GitHub Actions artifact name: `cryptoanalyser-apk`


## Platform and language selection
- The first launch defaults to English. The user can select one of the nine supported languages from the visible language menu on the main analysis card; the choice is saved between launches.
- A visible platform selector lets the user switch between Bitget and Binance. Spot/Futures symbol suggestions, ticker prices, candles, and saved price-alert checks use the selected platform where supported. Binance ATH/ATL are left unavailable rather than guessed.

### One-shot price alert behavior

When a saved price alert fires and its notification is posted, the alert is marked `triggered` and remains visible in the Price alerts list with a localized **Deactivated** status. It will not send another notification unless the user edits/saves it (which resets it) or taps **Activate** to re-arm it. The user can still edit its target price or delete it. Background polling uses WorkManager and is approximate (minimum 15 minutes); notification delivery also depends on Android notification permission and battery/background restrictions.


## User-focused market movement notifications

- The periodic `PriceAlertWorker` keeps checking user-defined price alerts and also scans up to 25 relevant USDT spot pairs from recent searches, favorites, and saved price-alert pairs on both Bitget and Binance public endpoints.
- A movement notification is a heuristic warning, not a forecast: it triggers at approximately +8%/-8% 24-hour change, or a sampled move of +2.5%/-2.5% between checks. Larger moves are labeled as a possible strong move.
- The same directional signal for a pair is rate-limited to one notification per six hours to reduce duplicates. The worker stores prior sampled prices locally.
- The worker uses WorkManager's periodic cadence (minimum 15 minutes, approximate timing); it is not real-time and Android battery/network restrictions or notification permissions can delay or block notifications.
- Favorites are stored locally and can be added or removed from the main analysis screen. Up to 50 recent searches are retained for monitoring while only the three most recent are shown in the compact recent-search row.
- This feature uses public spot ticker data for movement scanning. Existing explicit alerts continue to respect their saved market type and the currently selected exchange.

## Bitget coin profile data coverage

The in-app Bitget coin profile reads Bitget's public Spot endpoints for supported coin chains, contract addresses, transfer availability, and available trading pairs/status. The public Spot coin endpoint does not provide circulating supply, total/max supply, a whitepaper, or a verified project-purpose description. Those fields must remain unknown rather than being guessed. Bitget Wallet's richer token-info API documents supply, website, whitepaper, `about`, holder and liquidity fields, but its current API authentication requires an API key and signed requests; do not embed that key in the Android APK. A secure server-side proxy (for example, Apps Script Script Properties) would be required to add those fields.



## Free coin fundamentals and detailed spoken analysis
See `COIN_DATA_AND_VOICE_SUMMARY_AR.md` for the free Bitget/CoinPaprika data sources, the added Apps Script `coinInfo` action, the detailed voice-summary metrics, limitations, and deployment steps. No private Bitget API key is required for the public market data used here.


## Audio summary UI update (v14)
- The summary panel now uses four selectable voice presets named Sara, Lina, Ahmed and Youssef, remembers the selected preset, and provides icon-only stop/replay controls plus ±5-second navigation.
- Voice output still uses Android's installed TextToSpeech engine and the selected app language. Availability and actual voice identity depend on the TTS engine installed on the device; presets use gender/language matching and pitch variation and are not four guaranteed independent studio voices. Portraits in this version are emoji-style placeholders, not illustrated portrait assets.
- The project ZIP is source code; a complete Android build must be verified by the repository's GitHub Actions workflow.


## v15 — Vérification des demandes de paiement
- Les liens sous le bouton de demande sont cliquables et visuellement mis en évidence.
- « Vérifier ma demande de paiement » ouvre un écran dédié avec état de chargement animé et textes localisés dans les 9 langues.
- Le backend vérifie les demandes marquées PAID et envoie le code à l'adresse e-mail correspondante. Pour protéger les comptes, l'API publique ne renvoie jamais directement le code à une personne qui connaît seulement l'adresse e-mail.
- Après avoir remplacé le code Google Apps Script, redéployez la Web App en conservant le même déploiement/URL.
