
# CryptoAnalyser-by ErrZhr (Android)

Kotlin + Jetpack Compose Android project for educational cryptocurrency market analysis using public Bitget endpoints.

## Features
- Bitget Spot and USDT Futures public market data.
- Coin-pair autocomplete, EMA/OBV/MACD indicators, support/resistance, historical extremes and an educational EMA crossover backtest.
- Recent crypto news from public CoinDesk and Cointelegraph RSS feeds, limited to four items from the last seven days.
- `FLAG_SECURE`, portrait orientation, non-resizable activity declaration, disabled app backup, and HTTPS-only network traffic.
- In-app privacy and financial-risk disclosure.

## Build locally
Open this folder in Android Studio with JDK 17 and Android SDK Platform 36 installed. Let Gradle sync, then run `lintDebug` and `assembleDebug`. CI uses Gradle 8.11.1 and builds a debug APK.

## Before publishing
Read `PLAY_STORE_RELEASE_CHECKLIST.md` and `PRIVACY_POLICY.md`. The package ID `com.example.cryptoanalyzer` is a placeholder and must be changed before the first Play release. Host the completed privacy policy at a public HTTPS URL, fill in the real developer contact email, complete the Data safety and Financial features declarations, sign a release AAB, and configure Play App Signing. Enable Protected with Play / Automatic protection in Play Console if available.

**No guarantee of Google Play approval is possible from source changes alone.** The app has not been built in this environment; CI must pass and the app must be tested before release. The app provides market information only and is not an official Bitget product.


## Summary voice

After a market analysis, use the **Listen to the Summary** card to hear the summary aloud. Tap the woman or man avatar to select a preferred voice; the selection is saved on the device. The actual voice depends on the text-to-speech voices installed and exposed by the Android device, so some devices may use their default voice if a matching voice is unavailable.

## Build

Run `gradle --no-daemon assembleDebug` from the project root (with Java 17, Gradle 8.11.1, and Android SDK platform 36 installed). The GitHub Actions workflow builds from the project root and verifies that the debug APK was generated. A local build was not run in the environment used to prepare this archive.

## Automatic entry plan
After market analysis, the app displays three long/Spot reference scenarios automatically: an aggressive entry near support, a breakout-confirmation trigger, and a more conservative trigger. Each scenario includes its own stop-loss level and three risk-multiple take-profit targets (1R, 2R, 3R). These are analytical reference levels derived from the current price and 4H support/resistance, not live orders or guaranteed forecasts. Breakout scenarios require candle-close confirmation and trading involves risk.

## Spoken summary voice
The summary panel offers Woman and Man voice choices and saves the selection on the device. Actual voice gender and availability depend on the installed Android text-to-speech engine and voice packs.


## Patch notes (2026-10-19)
- Added paginated daily-candle scanning for ATH/ATL separately for the selected Bitget Spot market or USDT Futures contract. Values are only marked complete when the history endpoint indicates the scan reached the end; otherwise they are estimates of available history and should be treated accordingly.
- Added API-level Bitget error-code validation so failed responses are not silently parsed as empty market data.
- Replaced the Favorites feature with a persisted list of the last three analyzed symbols; tapping a symbol reruns its analysis.
- Added a collapsible Token Unlocks section with links to Tokenomist, CryptoRank, and official-announcement searches. This build does **not** fetch or verify unlock schedules automatically; it explicitly warns users not to treat these links as a verified unlock table.
- Price alerts support editing and deleting existing alerts.

Build validation note: source/ZIP integrity checks are performed for this package, but an Android SDK/Gradle build environment is not available in this session, so successful APK compilation is not claimed.
