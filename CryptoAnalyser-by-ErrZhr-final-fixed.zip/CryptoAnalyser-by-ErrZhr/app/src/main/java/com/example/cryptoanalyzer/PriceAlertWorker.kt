package com.example.cryptoanalyzer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Checks saved one-shot price alerts in the background. WorkManager periodic work is approximate (minimum 15 min). */
class PriceAlertWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    private val client = OkHttpClient.Builder().callTimeout(12, TimeUnit.SECONDS).build()

    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("cryptoanalyser_preferences", Context.MODE_PRIVATE)
        val alerts = try { JSONArray(prefs.getString("price_alerts", "[]")) } catch (_: Exception) { return Result.success() }
        if (alerts.length() == 0) return Result.success()
        val language = prefs.getString("app_language", "en") ?: "en"
        val channelId = ensureChannel(language)
        val updated = JSONArray()
        for (i in 0 until alerts.length()) {
            val alert = alerts.optJSONObject(i) ?: continue
            if (alert.optBoolean("triggered", false)) {
                updated.put(alert)
                continue
            }
            val symbol = alert.optString("symbol", "").uppercase()
            val market = alert.optString("market", "Spot")
            val target = alert.optDouble("target", Double.NaN)
            if (symbol.isBlank() || !target.isFinite() || target <= 0.0) {
                updated.put(alert)
                continue
            }
            try {
                val url = if (market.equals("Futures", true) || market.contains("Futures", true)) {
                    "https://api.bitget.com/api/v2/mix/market/ticker?productType=USDT-FUTURES&symbol=$symbol"
                } else {
                    "https://api.bitget.com/api/v2/spot/market/tickers?symbol=$symbol"
                }
                val request = Request.Builder().url(url).get().build()
                val response = client.newCall(request).execute()
                val body = response.use { if (it.isSuccessful) it.body?.string() else null }
                if (body != null) {
                    val root = JSONObject(body)
                    val data = root.optJSONArray("data")
                    val ticker = if (data != null && data.length() > 0) data.optJSONObject(0) ?: JSONObject() else root.optJSONObject("data") ?: JSONObject()
                    val current = listOf("lastPr", "last", "close", "lastPrice").firstNotNullOfOrNull { ticker.optString(it, "").toDoubleOrNull() } ?: 0.0
                    val direction = alert.optString("direction", "ABOVE")
                    val hit = current > 0.0 && if (direction == "BELOW") current <= target else current >= target
                    if (hit) {
                        val (title, text) = localizedNotification(language, symbol, target, current, direction)
                        postNotification(channelId, alert.optLong("id", System.currentTimeMillis()).toInt(), title, text)
                        alert.put("triggered", true)
                    }
                }
            } catch (_: Exception) {
                // A temporary network/API failure leaves the alert active for the next periodic check.
            }
            updated.put(alert)
        }
        prefs.edit().putString("price_alerts", updated.toString()).apply()
        return Result.success()
    }

    private fun ensureChannel(language: String): String {
        val channelId = "crypto_price_alerts_$language"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(channelId) == null) {
                val channelName = when (language) {
                    "fr" -> "Alertes de prix crypto"; "ar" -> "تنبيهات أسعار العملات الرقمية"; "es" -> "Alertas de precios cripto"; "de" -> "Krypto-Preisalarme"; "it" -> "Avvisi prezzi crypto"; "zh" -> "加密货币价格提醒"; "ja" -> "暗号資産の価格アラート"; "ko" -> "암호화폐 가격 알림"; else -> "Crypto price alerts"
                }
                val channel = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_HIGH).apply {
                    description = channelName
                    enableVibration(true)
                    setShowBadge(true)
                }
                manager.createNotificationChannel(channel)
            }
        }
        return channelId
    }

    private fun localizedNotification(language: String, symbol: String, target: Double, current: Double, direction: String): Pair<String, String> {
        val above = direction != "BELOW"
        val title = when (language) {
            "fr" -> "Alerte de prix : $symbol"; "ar" -> "تنبيه سعر: $symbol"; "es" -> "Alerta de precio: $symbol"; "de" -> "Preisalarm: $symbol"; "it" -> "Avviso di prezzo: $symbol"; "zh" -> "价格提醒：$symbol"; "ja" -> "価格アラート：$symbol"; "ko" -> "가격 알림: $symbol"; else -> "$symbol price alert"
        }
        val message = when (language) {
            "fr" -> "Le prix a ${if (above) "atteint ou dépassé" else "atteint ou est passé sous"} $target USDT (actuel : $current USDT)."
            "ar" -> "${if (above) "وصل السعر إلى" else "انخفض السعر إلى"} $target USDT (السعر الحالي: $current USDT)."
            "es" -> "El precio ${if (above) "alcanzó o superó" else "alcanzó o cayó por debajo de"} $target USDT (actual: $current USDT)."
            "de" -> "Der Preis hat $target USDT ${if (above) "erreicht oder überschritten" else "erreicht oder unterschritten"} (aktuell: $current USDT)."
            "it" -> "Il prezzo ha ${if (above) "raggiunto o superato" else "raggiunto o è sceso sotto"} $target USDT (attuale: $current USDT)."
            "zh" -> "价格${if (above) "达到或超过" else "达到或低于"} $target USDT（当前：$current USDT）。"
            "ja" -> "価格が $target USDT に${if (above) "到達または上回りました" else "到達または下回りました"}（現在：$current USDT）。"
            "ko" -> "가격이 $target USDT에 ${if (above) "도달하거나 초과했습니다" else "도달하거나 하회했습니다"} (현재: $current USDT)."
            else -> "$symbol ${if (above) "reached or exceeded" else "fell to or below"} $target USDT (current: $current USDT)."
        }
        return title to message
    }

    private fun postNotification(channelId: String, id: Int, title: String, message: String) {
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
        try { NotificationManagerCompat.from(applicationContext).notify(id, notification) } catch (_: SecurityException) { }
    }

}
