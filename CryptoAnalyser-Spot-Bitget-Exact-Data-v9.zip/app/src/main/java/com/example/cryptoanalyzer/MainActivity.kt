package com.example.cryptoanalyzer

import android.os.Bundle
import android.os.Build
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.DisposableEffect
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import android.text.Html
import android.util.Xml
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZonedDateTime
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Block screenshots, screen recording, and the app preview in Recents.
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            val darkScheme = darkColorScheme(
                primary = Color(0xFF5EEAD4),
                onPrimary = Color(0xFF062A2A),
                secondary = Color(0xFFA78BFA),
                tertiary = Color(0xFF60A5FA),
                background = Color(0xFF080D1B),
                surface = Color(0xFF111A2E),
                surfaceVariant = Color(0xFF1B2942),
                onBackground = Color(0xFFEAF2FF),
                onSurface = Color(0xFFEAF2FF),
                onSurfaceVariant = Color(0xFFB7C5DA),
                error = Color(0xFFFF718B)
            )
            MaterialTheme(colorScheme = darkScheme) { AnalyzerApp() }
        }
    }
}

data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)
data class IndicatorRow(val timeframe: String, val price: Double, val emas: Map<Int, Double>, val obv: Double, val macd: Double, val signal: Double, val hist: Double, val upProbability: Int, val downProbability: Int, val support: Double, val resistance: Double, val setup: String)
private data class AnalysisResult(val price: Double, val rows: List<IndicatorRow>, val backtest: String, val extremes: PriceExtremes, val chartCandles: List<Candle>)

private val client = OkHttpClient.Builder().connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS).readTimeout(10, java.util.concurrent.TimeUnit.SECONDS).build()

data class MarketNews(
    val title: String,
    val summary: String,
    val publishedAt: Long,
    val source: String,
    val url: String
)

private data class NewsFeed(val url: String, val source: String)
private val newsFeeds = listOf(
    NewsFeed("https://www.coindesk.com/arc/outboundfeeds/rss/", "CoinDesk"),
    NewsFeed("https://cointelegraph.com/rss", "Cointelegraph")
)

private fun parseNewsDate(value: String): Long? {
    val raw = value.trim()
    if (raw.isBlank()) return null
    try { return Instant.parse(raw).toEpochMilli() } catch (_: Exception) {}
    try { return OffsetDateTime.parse(raw).toInstant().toEpochMilli() } catch (_: Exception) {}
    try { return ZonedDateTime.parse(raw).toInstant().toEpochMilli() } catch (_: Exception) {}
    val patterns = listOf("EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm Z", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd'T'HH:mm:ss.SSSX")
    for (pattern in patterns) {
        try {
            val format = SimpleDateFormat(pattern, Locale.US).apply { isLenient = true; timeZone = TimeZone.getTimeZone("UTC") }
            return format.parse(raw)?.time
        } catch (_: Exception) {}
    }
    return null
}

private fun cleanNewsText(raw: String): String = Html.fromHtml(raw, Html.FROM_HTML_MODE_LEGACY).toString()
    .replace(Regex("\\s+"), " ").trim()

private fun parseRssFeed(xml: String, source: String): List<MarketNews> {
    val parser = Xml.newPullParser()
    parser.setInput(StringReader(xml))
    val output = mutableListOf<MarketNews>()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        if (event == XmlPullParser.START_TAG && parser.name.substringAfter(':') in setOf("item", "entry")) {
            var title = ""; var summary = ""; var date = ""; var link = ""
            val itemTag = parser.name
            var depth = 1
            while (depth > 0) {
                event = parser.next()
                when (event) {
                    XmlPullParser.START_TAG -> {
                        depth++
                        val tag = parser.name.substringAfter(':').lowercase(Locale.ROOT)
                        if (tag == "link") {
                            val href = parser.getAttributeValue(null, "href")
                            if (!href.isNullOrBlank()) link = href
                            else { val t = try { parser.nextText() } catch (_: Exception) { "" }; if (t.isNotBlank()) link = t; depth-- }
                        } else if (tag in setOf("title", "description", "summary", "encoded", "pubdate", "published", "updated", "date")) {
                            val value = try { parser.nextText() } catch (_: Exception) { "" }
                            when (tag) {
                                "title" -> if (title.isBlank()) title = value
                                "description", "summary", "encoded" -> if (summary.isBlank() || tag == "encoded") summary = value
                                "pubdate", "published", "updated", "date" -> if (date.isBlank()) date = value
                            }
                            depth--
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        depth--
                        if (depth == 0 && parser.name == itemTag) break
                    }
                }
            }
            val timestamp = parseNewsDate(date)
            val cleanedTitle = cleanNewsText(title)
            val cleanedSummary = cleanNewsText(summary)
            if (timestamp != null && cleanedTitle.isNotBlank()) output.add(MarketNews(cleanedTitle, cleanedSummary, timestamp, source, link))
        }
        event = parser.next()
    }
    return output
}

private fun loadRecentNews(symbol: String): List<MarketNews> {
    val now = System.currentTimeMillis()
    val sevenDays = 7L * 24L * 60L * 60L * 1000L
    val token = symbol.uppercase(Locale.ROOT).removeSuffix("USDT")
    val tokenAliases = when (token) {
        "BTC" -> listOf("bitcoin", "btc")
        "ETH" -> listOf("ethereum", "ether", "eth")
        "SOL" -> listOf("solana", "sol")
        "XRP" -> listOf("xrp", "ripple")
        "BNB" -> listOf("bnb", "binance coin")
        "DOGE" -> listOf("dogecoin", "doge")
        else -> listOf(token.lowercase(Locale.ROOT))
    }.filter { it.length >= 2 }
    val marketKeywords = listOf("crypto", "cryptocurrency", "bitcoin", "ethereum", "market", "etf", "federal reserve", "fed ", "interest rate", "inflation", "sec ", "regulation", "exchange", "stablecoin", "liquidation", "hack", "exploit", "tariff", "trading volume")
    val all = mutableListOf<MarketNews>()
    for (feed in newsFeeds) {
        try {
            val request = Request.Builder().url(feed.url).header("User-Agent", "CryptoAnalyserByErrZhr/1.0").get().build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val xml = response.body?.string().orEmpty()
                    all.addAll(parseRssFeed(xml, feed.source))
                }
            }
        } catch (_: Exception) { /* The other feed may still be available. */ }
    }
    val fresh = all.distinctBy { it.url.ifBlank { it.title } }
        .filter { it.publishedAt in (now - sevenDays)..(now + 10L * 60L * 1000L) }
    val coinSpecific = fresh.filter { item ->
        val text = (item.title + " " + item.summary).lowercase(Locale.ROOT)
        tokenAliases.any { alias -> if (alias.length <= 3) Regex("(^|[^a-z0-9])" + Regex.escape(alias) + "([^a-z0-9]|$)").containsMatchIn(text) else text.contains(alias) }
    }
    val broadMarket = fresh.filter { item ->
        val text = (item.title + " " + item.summary).lowercase(Locale.ROOT)
        marketKeywords.any { text.contains(it) }
    }
    return (coinSpecific.sortedByDescending { it.publishedAt } + broadMarket.sortedByDescending { it.publishedAt })
        .distinctBy { it.url.ifBlank { it.title } }.take(4)
}

/** Accepts base symbols (BTC), concatenated pairs (BTCUSDT), and separated pairs (BTC/USDT or BTC-USDT). */
private fun normalizeUsdtSymbol(input: String): String {
    val cleaned = input.trim().uppercase()
        .replace("/", "")
        .replace("-", "")
        .replace("_", "")
        .replace(" ", "")
    if (cleaned.isBlank()) throw IllegalArgumentException("Enter a coin symbol, e.g. BTC, BTCUSDT or AIAV/USDT.")
    val pair = if (cleaned.endsWith("USDT")) cleaned else "${cleaned}USDT"
    if (!pair.matches(Regex("[A-Z0-9]{2,20}USDT"))) {
        throw IllegalArgumentException("Invalid symbol. Enter a coin like BTC, BTCUSDT or AIAV/USDT.")
    }
    return pair
}

private fun loadListedUsdtSymbols(market: String): List<String> {
    val url = if (market == "Spot") {
        "https://api.bitget.com/api/v2/spot/public/symbols"
    } else {
        "https://api.bitget.com/api/v2/mix/market/contracts?productType=USDT-FUTURES"
    }
    val root = getJson(url)
    val data = root.optJSONArray("data") ?: JSONArray()
    val symbols = linkedSetOf<String>()
    for (i in 0 until data.length()) {
        val item = data.optJSONObject(i) ?: continue
        val pair = item.optString("symbol").uppercase()
        val quote = item.optString("quoteCoin", "USDT").uppercase()
        val status = item.optString("status", item.optString("symbolStatus", "online")).lowercase()
        if (pair.endsWith("USDT") && quote == "USDT" && status !in setOf("offline", "gray", "delisted", "halt")) {
            symbols.add(pair)
        }
    }
    return symbols.sorted()
}

private fun getJson(url: String): JSONObject {
    val request = Request.Builder().url(url).get().build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw Exception("Error")
        return JSONObject(response.body?.string() ?: "{}")
    }
}
private fun parseCandles(root: JSONObject): List<Candle> {
    val data = root.optJSONArray("data") ?: JSONArray()
    val result = mutableListOf<Candle>()
    for (i in 0 until data.length()) {
        val a = data.optJSONArray(i) ?: continue
        if (a.length() < 6) continue
        result.add(Candle(a.optString(0).toLongOrNull() ?: 0L, a.optString(1).toDoubleOrNull() ?: 0.0, a.optString(2).toDoubleOrNull() ?: 0.0, a.optString(3).toDoubleOrNull() ?: 0.0, a.optString(4).toDoubleOrNull() ?: 0.0, a.optString(5).toDoubleOrNull() ?: 0.0))
    }
    return result.filter { it.close > 0.0 }.sortedBy { it.time }
}

private data class PriceExtremes(
    val allTimeHigh: Double,
    val allTimeLow: Double,
    val high24h: Double,
    val low24h: Double,
    val historyComplete: Boolean,
    val last24hComplete: Boolean
)

private fun historyCandlesUrl(symbol: String, isSpot: Boolean, granularity: String, endTime: Long): String {
    return if (isSpot) {
        "https://api.bitget.com/api/v2/spot/market/history-candles?symbol=$symbol&granularity=$granularity&endTime=$endTime&limit=200"
    } else {
        "https://api.bitget.com/api/v2/mix/market/history-candles?productType=USDT-FUTURES&symbol=$symbol&granularity=$granularity&endTime=$endTime&limit=200"
    }
}

/** Calculate extremes locally from candle high/low values. Ticker high/low fields are deliberately not used. */
private fun loadPriceExtremes(symbol: String, isSpot: Boolean): PriceExtremes {
    val now = System.currentTimeMillis()
    val cutoff24h = now - 24L * 60L * 60L * 1000L

    // Build the 24-hour range from minute candles, paging backwards until the full window is covered.
    var minuteEnd = now
    val recentCandles = mutableListOf<Candle>()
    var last24hComplete = false
    var recentPages = 0
    while (recentPages < 12) {
        val url = historyCandlesUrl(symbol, isSpot, if (isSpot) "1min" else "1m", minuteEnd)
        val root = try { getJson(url) } catch (_: Exception) { break }
        if (root.optString("code") != "00000") break
        val page = parseCandles(root)
        if (page.isEmpty()) { last24hComplete = recentCandles.any { it.time <= cutoff24h }; break }
        recentCandles.addAll(page.filter { it.time >= cutoff24h && it.time <= now })
        val oldest = page.minOfOrNull { it.time } ?: break
        if (oldest <= cutoff24h) { last24hComplete = true; break }
        if (oldest <= 0L || oldest >= minuteEnd) break
        minuteEnd = oldest - 1L
        recentPages++
        if (page.size < 200) break
    }
    val high24 = recentCandles.maxOfOrNull { it.high } ?: 0.0
    val low24 = recentCandles.filter { it.low > 0.0 }.minOfOrNull { it.low } ?: 0.0

    // Calculate all-time extremes from daily historical candles, not ticker fields or a fixed recent window.
    var dailyEnd = now
    var highest = 0.0
    var lowest = Double.POSITIVE_INFINITY
    var pages = 0
    var historyComplete = false
    while (pages < 200) {
        val url = historyCandlesUrl(symbol, isSpot, if (isSpot) "1day" else "1D", dailyEnd)
        val root = try { getJson(url) } catch (_: Exception) { break }
        if (root.optString("code") != "00000") break
        val candles = parseCandles(root)
        if (candles.isEmpty()) { historyComplete = true; break }
        for (c in candles) {
            if (c.high > 0.0) highest = max(highest, c.high)
            if (c.low > 0.0) lowest = min(lowest, c.low)
        }
        pages++
        val oldest = candles.minOfOrNull { it.time } ?: break
        if (oldest <= 0L || oldest >= dailyEnd) break
        dailyEnd = oldest - 1L
        if (candles.size < 200) { historyComplete = true; break }
    }
    if (pages >= 200) historyComplete = false
    return PriceExtremes(
        allTimeHigh = highest,
        allTimeLow = if (lowest.isFinite()) lowest else 0.0,
        high24h = high24,
        low24h = low24,
        historyComplete = historyComplete,
        last24hComplete = last24hComplete
    )
}

private fun ema(values: List<Double>, period: Int): Double {
    if (values.isEmpty()) return 0.0
    val alpha = 2.0 / (period + 1.0)
    var result = values.take(min(period, values.size)).average()
    for (v in values.drop(min(period, values.size))) result = alpha * v + (1 - alpha) * result
    return result
}
private fun analyze(candles: List<Candle>, tf: String): IndicatorRow {
    val closes = candles.map { it.close }
    val price = closes.last()
    val emas = listOf(9,14,21,50,100,200).associateWith { ema(closes, it) }
    var obv = 0.0
    for (i in 1 until candles.size) obv += when { candles[i].close > candles[i-1].close -> candles[i].volume; candles[i].close < candles[i-1].close -> -candles[i].volume; else -> 0.0 }
    val macdSeries = mutableListOf<Double>()
    for (i in closes.indices) macdSeries.add(ema(closes.take(i + 1), 12) - ema(closes.take(i + 1), 26))
    val macd = macdSeries.lastOrNull() ?: 0.0
    val signal = ema(macdSeries, 9)
    val hist = macd - signal
    val votes = (if (price > emas.getValue(9)) 1 else -1) + (if (price > emas.getValue(21)) 1 else -1) + (if (price > emas.getValue(50)) 1 else -1) + (if (emas.getValue(9) > emas.getValue(21)) 1 else -1) + (if (hist > 0) 1 else -1) + (if (obv > 0) 1 else -1)
    val up = (50 + votes * 7).coerceIn(8, 92)
    val lows = candles.takeLast(30).map { it.low }
    val highs = candles.takeLast(30).map { it.high }
    val support = lows.minOrNull() ?: price
    val resistance = highs.maxOrNull() ?: price
    val setup = when {
        price > emas.getValue(50) && hist > 0 -> "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry."
        price < emas.getValue(50) && hist < 0 -> "Bearish bias; SHORT only after confirmation; avoid chasing a drop."
        else -> "Mixed signals; wait for a confirmed breakout or support rejection."
    }
    return IndicatorRow(tf, price, emas, obv, macd, signal, hist, up, 100-up, support, resistance, setup)
}

@Composable
private fun CandlestickChart(candles: List<Candle>, modifier: Modifier = Modifier) {
    val visible = candles.takeLast(60)
    if (visible.size < 2) {
        Text("Les bougies apparaîtront après l’analyse.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    val minPrice = visible.minOf { it.low }.coerceAtLeast(0.0)
    val maxPrice = visible.maxOf { it.high }
    val range = (maxPrice - minPrice).takeIf { it > 0.0 } ?: (maxPrice * 0.01).coerceAtLeast(0.00000001)
    Canvas(modifier = modifier.fillMaxWidth().height(250.dp)) {
        val topPad = 12.dp.toPx()
        val bottomPad = 12.dp.toPx()
        val chartHeight = size.height - topPad - bottomPad
        val step = size.width / visible.size
        val bodyWidth = (step * 0.58f).coerceAtLeast(2.dp.toPx())
        fun y(v: Double): Float = topPad + ((maxPrice - v) / range).toFloat() * chartHeight
        // Horizontal price grid
        for (i in 0..4) {
            val gy = topPad + chartHeight * i / 4f
            drawLine(Color(0xFF283650), androidx.compose.ui.geometry.Offset(0f, gy), androidx.compose.ui.geometry.Offset(size.width, gy), strokeWidth = 1.dp.toPx())
        }
        visible.forEachIndexed { index, candle ->
            val x = step * index + step / 2f
            val rising = candle.close >= candle.open
            val color = if (rising) Color(0xFF5EEAD4) else Color(0xFFFF718B)
            drawLine(color, androidx.compose.ui.geometry.Offset(x, y(candle.high)), androidx.compose.ui.geometry.Offset(x, y(candle.low)), strokeWidth = 1.2.dp.toPx())
            val openY = y(candle.open)
            val closeY = y(candle.close)
            val bodyTop = minOf(openY, closeY)
            val bodyHeight = kotlin.math.abs(closeY - openY).coerceAtLeast(2.dp.toPx())
            drawRect(color, topLeft = androidx.compose.ui.geometry.Offset(x - bodyWidth / 2f, bodyTop), size = androidx.compose.ui.geometry.Size(bodyWidth, bodyHeight))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzerApp() {
    val appContext = LocalContext.current
    val preferences = remember(appContext) { appContext.getSharedPreferences("crypto_analyzer_settings", android.content.Context.MODE_PRIVATE) }
    var selectedLanguage by remember { mutableStateOf(preferences.getString("language", "English") ?: "English") }
    var languageMenuExpanded by remember { mutableStateOf(false) }
    val languages = listOf("English", "Français", "العربية الفصحى", "中文", "日本語", "Español", "Deutsch", "Italiano", "한국어")
    LaunchedEffect(selectedLanguage) { preferences.edit().putString("language", selectedLanguage).apply() }
    var symbol by remember { mutableStateOf("BTC/USDT") }
    var listedSymbols by remember { mutableStateOf<List<String>>(emptyList()) }
    var showSuggestions by remember { mutableStateOf(false) }
    var market by remember { mutableStateOf("Spot") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var price by remember { mutableStateOf<Double?>(null) }
    var extremes by remember { mutableStateOf<PriceExtremes?>(null) }
    var rows by remember { mutableStateOf<List<IndicatorRow>>(emptyList()) }
    var chartCandles by remember { mutableStateOf<List<Candle>>(emptyList()) }
    var showPriceLevels by remember { mutableStateOf(true) }
    var showCandlestickChart by remember { mutableStateOf(true) }
    var backtest by remember { mutableStateOf("") }
    var news by remember { mutableStateOf<List<MarketNews>>(emptyList()) }
    var newsLoading by remember { mutableStateOf(false) }
    var newsError by remember { mutableStateOf("") }
    var selectedNews by remember { mutableStateOf<MarketNews?>(null) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(preferences.getString("favorites", "")?.split("|")?.filter { it.isNotBlank() } ?: emptyList()) }
    var recentCoins by remember { mutableStateOf(preferences.getString("recent_coins", "")?.split("|")?.filter { it.isNotBlank() } ?: emptyList()) }
    var alertTarget by remember { mutableStateOf("") }
    var alertDirection by remember { mutableStateOf("ABOVE") }
    var priceAlerts by remember { mutableStateOf(loadSavedPriceAlerts(preferences)) }
    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }
    DisposableEffect(appContext) {
        val engine = TextToSpeech(appContext) { status -> ttsReady = status == TextToSpeech.SUCCESS }
        ttsEngine = engine
        onDispose {
            engine.stop()
            engine.shutdown()
            ttsEngine = null
            ttsReady = false
        }
    }
    val scope = rememberCoroutineScope()
    LaunchedEffect(market) {
        listedSymbols = withContext(Dispatchers.IO) {
            try {
                loadListedUsdtSymbols(market)
            } catch (_: Exception) {
                // Keep the input usable if Bitget's symbol-list endpoint is temporarily unavailable.
                listOf("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "BNBUSDT", "DOGEUSDT", "AIAVUSDT")
            }
        }
    }
    val cleanedQuery = symbol.trim().uppercase().replace("/", "").replace("-", "").replace("_", "").replace(" ", "")
    val suggestionQuery = cleanedQuery.removeSuffix("USDT")
    val filteredSuggestions = remember(listedSymbols, cleanedQuery, showSuggestions) {
        if (!showSuggestions || suggestionQuery.isBlank()) emptyList()
        else listedSymbols.filter { pair ->
            pair.startsWith(cleanedQuery) || pair.removeSuffix("USDT").startsWith(suggestionQuery)
        }.take(8)
    }
    val tfMap = if (market == "Spot") {
        listOf("1H" to "1h", "4H" to "4h", "1D" to "1day")
    } else {
        listOf("1H" to "1H", "4H" to "4H", "1D" to "1D")
    }

    fun runAnalysis() {
        val clean = try {
            normalizeUsdtSymbol(symbol)
        } catch (e: IllegalArgumentException) {
            error = "Error"
            return
        }
        symbol = if (market == "Spot") "${clean.removeSuffix("USDT")}/USDT" else clean
        val recentKey = "$market:$clean"
        recentCoins = (listOf(recentKey) + recentCoins.filter { it != recentKey }).take(3)
        preferences.edit().putString("recent_coins", recentCoins.joinToString("|")).apply()
        newsLoading = true; newsError = ""; news = emptyList()
        scope.launch {
            val result = withContext(Dispatchers.IO) { loadRecentNews(clean) }
            news = result
            newsLoading = false
            if (result.isEmpty()) newsError = "Aucune actualité vérifiée disponible sur les 7 derniers jours. Réessayez plus tard."
        }
        loading = true; error = ""; rows = emptyList(); chartCandles = emptyList(); backtest = ""; extremes = null
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val isSpot = market == "Spot"
                    val tickerUrl = if (isSpot) "https://api.bitget.com/api/v2/spot/market/ticker?symbol=$clean" else "https://api.bitget.com/api/v2/mix/market/ticker?productType=USDT-FUTURES&symbol=$clean"
                    val tickerRoot = getJson(tickerUrl)
                    val tickerData = tickerRoot.optJSONArray("data")
                    val ticker = if (tickerData != null && tickerData.length() > 0) tickerData.optJSONObject(0) ?: JSONObject() else tickerRoot.optJSONObject("data") ?: JSONObject()
                    val currentPrice = ticker.optString("lastPrice", ticker.optString("lastPr", ticker.optString("last", ""))).toDoubleOrNull() ?: 0.0
                    // Historical extremes are supplementary. If their endpoint is unavailable,
                    // do not fail the entire Spot/Futures analysis.
                    val priceExtremes = runCatching { loadPriceExtremes(clean, isSpot) }.getOrElse { e ->
                        android.util.Log.w("CryptoAnalyzer", "Historical extremes unavailable", e)
                        PriceExtremes(0.0, 0.0, 0.0, 0.0, false, false)
                    }
                    val analyzed = mutableListOf<IndicatorRow>()
                    val candleSets = mutableListOf<Pair<String, List<Candle>>>()
                    for ((label, granularity) in tfMap) {
                        val candleUrl = if (isSpot) "https://api.bitget.com/api/v2/spot/market/candles?symbol=$clean&granularity=$granularity&limit=200" else "https://api.bitget.com/api/v2/mix/market/candles?symbol=$clean&granularity=$granularity&productType=USDT-FUTURES&limit=200"
                        val candleResponse = getJson(candleUrl)
                        val candles = parseCandles(candleResponse)
                        if (candles.size < 30) {
                            android.util.Log.w("CryptoAnalyzer", "Not enough candles for $market/$label: ${candles.size}; response code=${candleResponse.optString("code")}, message=${candleResponse.optString("msg")}")
                            throw Exception("Error")
                        }
                        candleSets.add(label to candles)
                        analyzed.add(analyze(candles, label))
                    }
                    val hourly = candleSets.first().second
                    // Simple educational EMA(9)/EMA(21) crossover backtest, one position at a time, close-to-close, fees excluded.
                    var cash = 1.0; var held = false; var entry = 0.0; var trades = 0; var wins = 0
                    for (i in 25 until hourly.size) {
                        val cs = hourly.take(i + 1).map { it.close }
                        val fast = ema(cs, 9); val slow = ema(cs, 21); val prevFast = ema(cs.dropLast(1), 9); val prevSlow = ema(cs.dropLast(1), 21)
                        if (!held && prevFast <= prevSlow && fast > slow) { held = true; entry = hourly[i].close }
                        else if (held && prevFast >= prevSlow && fast < slow) { val r = hourly[i].close / entry; cash *= r; trades++; if (r > 1) wins++; held = false }
                    }
                    if (held) { val r = hourly.last().close / entry; cash *= r; trades++; if (r > 1) wins++ }
                    val usablePrice = currentPrice.takeIf { it > 0.0 } ?: hourly.last().close
                    AnalysisResult(usablePrice, analyzed, "EMA 9/21 crossover on 1H · ${hourly.size} candles · $trades closed trades · return ${(cash - 1) * 100.0}% · win rate ${if (trades > 0) wins * 100 / trades else 0}% (fees/slippage excluded; not a forecast).", priceExtremes, hourly)
                }
                price = result.price.takeIf { it > 0.0 }; rows = result.rows; backtest = result.backtest; extremes = result.extremes; chartCandles = result.chartCandles
                if (price == null) error = "Error"
            } catch (e: Exception) {
                android.util.Log.e("CryptoAnalyzer", "Analysis request failed", e)
                error = "Error"
            }
            finally { loading = false }
        }
    }

    Scaffold(
        containerColor = Color(0xFF080D1B),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier.size(38.dp).background(
                                Brush.linearGradient(listOf(Color(0xFF5EEAD4), Color(0xFF60A5FA), Color(0xFFA78BFA))),
                                RoundedCornerShape(13.dp)
                            ), contentAlignment = Alignment.Center
                        ) { Text("₿", color = Color(0xFF07111F), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge) }
                        Column {
                            Text("CRYPTOANALYSER-BY ERRZHR", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, letterSpacing = 1.2.sp)
                            Text("PUBLIC MARKET DATA", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 0.7.sp)
                        }
                    }
                },
                actions = {
                    Box {
                        TextButton(onClick = { languageMenuExpanded = true }) {
                            Text("🌐 $selectedLanguage", color = Color(0xFF5EEAD4), maxLines = 1)
                        }
                        DropdownMenu(expanded = languageMenuExpanded, onDismissRequest = { languageMenuExpanded = false }) {
                            languages.forEach { language ->
                                DropdownMenuItem(text = { Text(language) }, onClick = {
                                    selectedLanguage = language
                                    languageMenuExpanded = false
                                })
                            }
                        }
                    }
                    TextButton(onClick = { showPrivacyDialog = true }) { Text("PRIVACY", color = Color(0xFF5EEAD4)) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF080D1B))
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).background(Color(0xFF080D1B)).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp)
        ) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().background(
                        Brush.linearGradient(listOf(Color(0xFF172E4A), Color(0xFF202047), Color(0xFF122C35))),
                        RoundedCornerShape(24.dp)
                    ).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("YOUR MARKET,\nCLEARER.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = Color.White, lineHeight = 34.sp)
                    Text("Technical signals and multi-timeframe insights in one place.", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFD1DEF2))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(Color(0xFF5EEAD4), RoundedCornerShape(50)))
                        Text("PUBLIC BITGET DATA", style = MaterialTheme.typography.labelSmall, color = Color(0xFF5EEAD4), fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ANALYZE A MARKET", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("Choose a pair and market type", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("01", color = Color(0xFFA78BFA), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                        }
                        ExposedDropdownMenuBox(
                            expanded = filteredSuggestions.isNotEmpty(),
                            onExpandedChange = { showSuggestions = it }
                        ) {
                            OutlinedTextField(
                                value = symbol,
                                onValueChange = { symbol = it.uppercase(); showSuggestions = true },
                                label = { Text("Coin or trading pair") },
                                placeholder = { Text(if (market == "Spot") "Type BTC/USDT, ETH/USDT, AIAV/USDT…" else "Type BTCUSDT, ETHUSDT, AIAVUSDT…") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().menuAnchor(),
                                shape = RoundedCornerShape(15.dp),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = filteredSuggestions.isNotEmpty()) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF5EEAD4),
                                    unfocusedBorderColor = Color(0xFF34445F),
                                    focusedLabelColor = Color(0xFF5EEAD4),
                                    cursorColor = Color(0xFF5EEAD4)
                                )
                            )
                            ExposedDropdownMenu(
                                expanded = filteredSuggestions.isNotEmpty(),
                                onDismissRequest = { showSuggestions = false }
                            ) {
                                filteredSuggestions.forEach { pair ->
                                    DropdownMenuItem(
                                        text = {
                                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text(pair, fontWeight = FontWeight.Bold)
                                                Text("${pair.removeSuffix("USDT")} · ${if (market == "Spot") "Spot" else "USDT Futures"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        },
                                        onClick = { symbol = if (market == "Spot") "${pair.removeSuffix("USDT")}/USDT" else pair; showSuggestions = false },
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                        Text("MARKET TYPE", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            FilterChip(
                                selected = market == "Spot", onClick = {
                                    if (market != "Spot") {
                                        market = "Spot"; symbol = ""; showSuggestions = false
                                        error = ""; rows = emptyList(); price = null; extremes = null; backtest = ""
                                    }
                                },
                                label = { Text("Spot") }, leadingIcon = { Text("●", color = if (market == "Spot") Color(0xFF5EEAD4) else Color.Gray) },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp)
                            )
                            FilterChip(
                                selected = market == "Futures", onClick = {
                                    if (market != "Futures") {
                                        market = "Futures"; symbol = ""; showSuggestions = false
                                        error = ""; rows = emptyList(); price = null; extremes = null; backtest = ""
                                    }
                                },
                                label = { Text("USDT Futures") }, leadingIcon = { Text("↗", color = if (market == "Futures") Color(0xFFA78BFA) else Color.Gray) },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp)
                            )
                        }
                        Button(
                            onClick = { runAnalysis() }, enabled = !loading,
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(15.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5EEAD4), contentColor = Color(0xFF062A2A))
                        ) {
                            if (loading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF062A2A))
                                Spacer(Modifier.width(10.dp)); Text("ANALYZING MARKET…", fontWeight = FontWeight.Bold)
                            } else { Text("✦  ANALYZE MARKET", fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp) }
                        }
                        val activePair = runCatching { normalizeUsdtSymbol(symbol) }.getOrNull()
                        if (activePair != null) {
                            val favoriteKey = "$market:$activePair"
                            OutlinedButton(onClick = {
                                favorites = if (favoriteKey in favorites) favorites.filterNot { it == favoriteKey } else (favorites + favoriteKey).distinct()
                                preferences.edit().putString("favorites", favorites.joinToString("|")).apply()
                            }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (favoriteKey in favorites) "★ Remove from Favorites" else "☆ Add to Favorites")
                            }
                        }
                        if (favorites.isNotEmpty() || recentCoins.isNotEmpty()) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("FAVORITES", color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                if (favorites.isEmpty()) Text("No favorites yet", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                favorites.forEach { entry ->
                                    val bits = entry.split(":", limit = 2)
                                    if (bits.size == 2) Row(verticalAlignment = Alignment.CenterVertically) {
                                        TextButton(onClick = {
                                            market = bits[0]
                                            symbol = if (bits[0] == "Spot") "${bits[1].removeSuffix("USDT")}/USDT" else bits[1]
                                            error = ""; price = null; rows = emptyList(); extremes = null; chartCandles = emptyList()
                                        }, modifier = Modifier.weight(1f)) { Text("★ ${bits[1]} · ${bits[0]}") }
                                        TextButton(onClick = {
                                            favorites = favorites.filterNot { it == entry }
                                            preferences.edit().putString("favorites", favorites.joinToString("|")).apply()
                                        }) { Text("×") }
                                    }
                                }
                                Text("RECENT · LAST 3", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                recentCoins.forEach { entry ->
                                    val bits = entry.split(":", limit = 2)
                                    if (bits.size == 2) TextButton(onClick = {
                                        market = bits[0]
                                        symbol = if (bits[0] == "Spot") "${bits[1].removeSuffix("USDT")}/USDT" else bits[1]
                                        error = ""; price = null; rows = emptyList(); extremes = null; chartCandles = emptyList()
                                    }) { Text("${bits[1]} · ${bits[0]}") }
                                }
                            }
                        }
                    }
                }
            }
            if (loading) item {
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFF5EEAD4), trackColor = Color(0xFF24324B))
            }
            if (error.isNotBlank()) item {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF3A1C2B))) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                        Text("!", color = Color(0xFFFF718B), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                        Text(error, color = Color(0xFFFFD9E0), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            if (price != null) item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF102B30))) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("LIVE PRICE", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                            Spacer(Modifier.weight(1f))
                            Text(market.uppercase(), color = Color(0xFFB8C7E3), style = MaterialTheme.typography.labelSmall)
                        }
                        Text(symbol, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(fmt(price!!), style = MaterialTheme.typography.headlineLarge, color = Color.White, fontWeight = FontWeight.Black)
                        Text("Live public market data", color = Color(0xFFB8D8D5), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (price != null) item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("PRICE ALERT", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                        Text("Set a target for $symbol. Background checks run about every 15 minutes.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(value = alertTarget, onValueChange = { alertTarget = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("Target price (USDT)") }, placeholder = { Text("e.g. 0.0015") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = alertDirection == "ABOVE", onClick = { alertDirection = "ABOVE" }, label = { Text("At or above") }, modifier = Modifier.weight(1f))
                            FilterChip(selected = alertDirection == "BELOW", onClick = { alertDirection = "BELOW" }, label = { Text("At or below") }, modifier = Modifier.weight(1f))
                        }
                        Button(onClick = {
                            val target = alertTarget.toDoubleOrNull()
                            if (target != null && target > 0.0) {
                                val alert = PriceAlert(java.util.UUID.randomUUID().toString(), market, normalizeUsdtSymbol(symbol), target, alertDirection)
                                priceAlerts = priceAlerts + alert
                                savePriceAlerts(preferences, priceAlerts)
                                schedulePriceAlertWorker(appContext)
                                createPriceAlertChannel(appContext)
                                if (Build.VERSION.SDK_INT >= 33 && appContext is android.app.Activity) appContext.requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 4102)
                                alertTarget = ""
                            } else error = "Error"
                        }, modifier = Modifier.fillMaxWidth()) { Text("＋ Create price alert") }
                        priceAlerts.filter { it.market == market && it.symbol == runCatching { normalizeUsdtSymbol(symbol) }.getOrDefault("") }.forEach { alert ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${if (alert.direction == "ABOVE") "≥" else "≤"} ${alert.target} USDT", modifier = Modifier.weight(1f), color = Color.White)
                                TextButton(onClick = { priceAlerts = priceAlerts.filterNot { it.id == alert.id }; savePriceAlerts(preferences, priceAlerts) }) { Text("Remove") }
                            }
                        }
                    }
                }
            }
            if (price != null && rows.isNotEmpty()) item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("SUPPORT & RESISTANCE", color = Color(0xFFA78BFA), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("${symbol} · niveaux calculés sur les dernières bougies 1H", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { showPriceLevels = !showPriceLevels }) { Text(if (showPriceLevels) "Masquer ▲" else "Afficher ▼", color = Color(0xFF5EEAD4)) }
                        }
                        if (showPriceLevels) {
                            val current = price ?: 0.0
                            val hourly = rows.firstOrNull { it.timeframe == "1H" } ?: rows.first()
                            val support = hourly.support
                            val resistance = hourly.resistance
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.weight(1f).background(Color(0xFF382338), RoundedCornerShape(13.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("SUPPORT PROCHE", color = Color(0xFFFFB5C5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(fmt(support), color = Color.White, fontWeight = FontWeight.Bold)
                                    Text(if (current > 0 && support > 0) "${fmt((support / current - 1.0) * 100.0)}% depuis le prix" else "—", color = Color(0xFFFFB5C5), style = MaterialTheme.typography.bodySmall)
                                }
                                Column(Modifier.weight(1f).background(Color(0xFF123A38), RoundedCornerShape(13.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("RÉSISTANCE PROCHE", color = Color(0xFF8CEBDD), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(fmt(resistance), color = Color.White, fontWeight = FontWeight.Bold)
                                    Text(if (current > 0 && resistance > 0) "+${fmt((resistance / current - 1.0) * 100.0)}% jusqu’au niveau" else "—", color = Color(0xFF8CEBDD), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Text("Ces niveaux sont des estimations issues des plus hauts et plus bas récents en 1H, pas des niveaux garantis. Ils peuvent évoluer avec le marché.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (price != null && rows.isNotEmpty()) item {
                val current = price ?: 0.0
                val hourly = rows.firstOrNull { it.timeframe == "1H" } ?: rows.first()
                val support = hourly.support.takeIf { it > 0.0 } ?: current * 0.98
                val resistance = hourly.resistance.takeIf { it > 0.0 } ?: current * 1.02
                val ema21 = hourly.emas[21]?.takeIf { it > 0.0 } ?: current
                val bullish = hourly.upProbability >= hourly.downProbability && current >= ema21
                val bearish = hourly.downProbability > hourly.upProbability && current <= ema21
                val spotLow = minOf(support, ema21).coerceAtMost(current)
                val spotHigh = maxOf(support * 1.01, ema21).coerceAtMost(current * 1.03)
                val longLow = minOf(support, ema21).coerceAtMost(current)
                val longHigh = maxOf(support * 1.01, ema21).coerceAtMost(current * 1.02)
                val shortLow = minOf(resistance * 0.99, ema21).coerceAtLeast(current * 0.97)
                val shortHigh = maxOf(resistance, ema21).coerceAtLeast(current)
                val trendText = when { bullish -> "biais technique plutôt haussier"; bearish -> "biais technique plutôt baissier"; else -> "signal mixte, sans direction nette" }
                val summaryText = when (selectedLanguage) {
                    "العربية الفصحى" -> "ملخص تحليل ${symbol}. السعر الحالي ${fmt(current)} تيثر. على إطار الساعة، ${if (bullish) "المؤشرات تميل إلى الصعود" else if (bearish) "المؤشرات تميل إلى الهبوط" else "الإشارات مختلطة ولا يوجد اتجاه واضح"}. احتمال الصعود حسب المؤشرات ${hourly.upProbability} بالمئة، واحتمال الهبوط ${hourly.downProbability} بالمئة. الدعم القريب ${fmt(support)} والمقاومة القريبة ${fmt(resistance)}. منطقة شراء سبوت المحتملة من ${fmt(spotLow)} إلى ${fmt(spotHigh)}. منطقة لونغ المحتملة من ${fmt(longLow)} إلى ${fmt(longHigh)}. منطقة شورت المحتملة من ${fmt(shortLow)} إلى ${fmt(shortHigh)}. هذه تقديرات فنية وليست ضمانا أو نصيحة مالية. تحقق من وقف الخسارة وحجم الصفقة ومخاطر التصفية قبل اتخاذ القرار."
                    "English" -> "Analysis summary for ${symbol}. Current price ${fmt(current)} USDT. On the one-hour timeframe, ${if (bullish) "indicators lean bullish" else if (bearish) "indicators lean bearish" else "signals are mixed with no clear direction"}. Indicator-based upside estimate ${hourly.upProbability} percent and downside estimate ${hourly.downProbability} percent. Nearby support ${fmt(support)} and resistance ${fmt(resistance)}. Potential Spot entry zone ${fmt(spotLow)} to ${fmt(spotHigh)}. Potential Long zone ${fmt(longLow)} to ${fmt(longHigh)}. Potential Short zone ${fmt(shortLow)} to ${fmt(shortHigh)}. These are technical estimates, not guarantees or financial advice. Consider stop loss, position size and liquidation risk."
                    else -> "Résumé de l'analyse de ${symbol}. Prix actuel ${fmt(current)} USDT. Sur une heure, ${trendText}. Probabilité estimée de hausse ${hourly.upProbability} pour cent et de baisse ${hourly.downProbability} pour cent. Support proche ${fmt(support)} et résistance proche ${fmt(resistance)}. Zone candidate Spot de ${fmt(spotLow)} à ${fmt(spotHigh)}. Zone candidate Long de ${fmt(longLow)} à ${fmt(longHigh)}. Zone candidate Short de ${fmt(shortLow)} à ${fmt(shortHigh)}. Ces niveaux sont des estimations, pas des garanties ni un conseil financier. Vérifiez le stop loss, la taille de position et le risque de liquidation."
                }
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("RÉSUMÉ / RÉSUMÉ VOCAL", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                        Text("${symbol} · Synthèse des indicateurs 1H", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = {
                            val engine = ttsEngine
                            if (engine != null && ttsReady) {
                                val locale = when (selectedLanguage) {
                                    "Français" -> Locale.FRANCE
                                    "العربية الفصحى" -> Locale("ar")
                                    "中文" -> Locale.SIMPLIFIED_CHINESE
                                    "日本語" -> Locale.JAPAN
                                    "Español" -> Locale("es", "ES")
                                    "Deutsch" -> Locale.GERMANY
                                    "Italiano" -> Locale.ITALY
                                    "한국어" -> Locale.KOREA
                                    else -> Locale.US
                                }
                                val languageResult = engine.setLanguage(locale)
                                if (languageResult >= TextToSpeech.LANG_AVAILABLE) engine.speak(summaryText, TextToSpeech.QUEUE_FLUSH, null, "crypto_summary")
                                else engine.speak(summaryText, TextToSpeech.QUEUE_FLUSH, null, "crypto_summary")
                            } else {
                                error = "Error"
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("🔊 Résumé · Écouter l’analyse") }
                        Text("BIAIS 1H: ${if (bullish) "HAUSSIER" else if (bearish) "BAISSIER" else "MIXTE"} · Hausse ${hourly.upProbability}% / Baisse ${hourly.downProbability}%", color = if (bullish) Color(0xFF5EEAD4) else if (bearish) Color(0xFFFF718B) else Color(0xFFFFD166), fontWeight = FontWeight.Bold)
                        Text("Spot · zone candidate", color = Color(0xFF5EEAD4), fontWeight = FontWeight.Bold)
                        Text("${fmt(spotLow)} – ${fmt(spotHigh)} USDT", color = Color.White)
                        Text("Long · zone candidate", color = Color(0xFF60A5FA), fontWeight = FontWeight.Bold)
                        Text("${fmt(longLow)} – ${fmt(longHigh)} USDT", color = Color.White)
                        Text("Short · zone candidate", color = Color(0xFFFF718B), fontWeight = FontWeight.Bold)
                        Text("${fmt(shortLow)} – ${fmt(shortHigh)} USDT", color = Color.White)
                        Text("Méthode indicative basée sur le support, la résistance et l’EMA 21 en 1H. Attendre une confirmation de prix; pour Long/Short, tenir compte du levier et du risque de liquidation. Ce ne sont pas des signaux garantis.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (price != null && chartCandles.isNotEmpty()) item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("JAPANESE CANDLESTICK CHART", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("${symbol} · 1H · ${minOf(60, chartCandles.size)} dernières bougies", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { showCandlestickChart = !showCandlestickChart }) { Text(if (showCandlestickChart) "Masquer ▲" else "Afficher ▼", color = Color(0xFF5EEAD4)) }
                        }
                        if (showCandlestickChart) {
                            CandlestickChart(chartCandles)
                            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("■ Haussier", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.labelSmall)
                                Text("■ Baissier", color = Color(0xFFFF718B), style = MaterialTheme.typography.labelSmall)
                            }
                            Text("Chaque bougie représente une heure : ouverture, clôture, plus haut et plus bas. Le graphique affiche les 60 dernières bougies disponibles.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ACTUALITÉ", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                                Text("Marché crypto · ${symbol.removeSuffix("USDT")} · 7 derniers jours", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                            Text("MAX. 4", color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                        Text("Les nouvelles sont filtrées par date récente et par pertinence pour la crypto choisie ou le marché global.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        if (newsLoading) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFF5EEAD4))
                                Text("Chargement des actualités récentes…", color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodySmall)
                            }
                        } else if (news.isEmpty()) {
                            Text(newsError.ifBlank { "Lancez l’analyse pour charger les actualités récentes." }, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        } else {
                            news.forEachIndexed { index, item ->
                                HorizontalDivider(color = Color(0xFF283650))
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable { selectedNews = item }.padding(vertical = 5.dp),
                                    verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                        Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                                        Text("${item.source} · ${java.text.SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(item.publishedAt))}", color = Color(0xFF8FA2BE), style = MaterialTheme.typography.labelSmall)
                                    }
                                    Text("›", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall)
                                }
                            }
                        }
                        Text("Sources RSS publiques · les titres et résumés sont informatifs, pas des signaux d’achat/vente.", color = Color(0xFF73839D), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (extremes != null) item {
                val e = extremes!!
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("PRICE RANGE", color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Text("${symbol} · ${market}", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Text("HIGH / LOW", color = Color(0xFF9BAAC2), style = MaterialTheme.typography.labelSmall)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f).background(Color(0xFF123A38), RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("ALL-TIME HIGH", color = Color(0xFF8CEBDD), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(if (e.allTimeHigh > 0) fmt(e.allTimeHigh) else "Unavailable", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                            }
                            Column(Modifier.weight(1f).background(Color(0xFF382338), RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("ALL-TIME LOW", color = Color(0xFFFFB5C5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(if (e.allTimeLow > 0) fmt(e.allTimeLow) else "Unavailable", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f).background(Color(0xFF182A3D), RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("24H HIGH", color = Color(0xFF60A5FA), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(if (e.high24h > 0) fmt(e.high24h) else "Unavailable", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Column(Modifier.weight(1f).background(Color(0xFF382A25), RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("24H LOW", color = Color(0xFFFFC078), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Text(if (e.low24h > 0) fmt(e.low24h) else "Unavailable", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text("All values are calculated locally from Bitget historical candles, not copied from ticker high/low fields. " + (if (e.historyComplete) "Daily history scan completed." else "Historical daily data could not be fully scanned; all-time values may be incomplete.") + " " + (if (e.last24hComplete) "24-hour minute-candle window covered." else "24-hour minute-candle history may be incomplete."), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (rows.isNotEmpty()) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("TECHNICAL OVERVIEW", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                            Text("Signals across three timeframes", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        Text("02", color = Color(0xFF60A5FA), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                    }
                }
                items(rows) { r ->
                    val bullish = r.upProbability >= r.downProbability
                    Card(shape = RoundedCornerShape(21.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2E))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.background(if (bullish) Color(0xFF123A38) else Color(0xFF3B2436), RoundedCornerShape(11.dp)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                                    Text(r.timeframe, color = if (bullish) Color(0xFF5EEAD4) else Color(0xFFFF9EB5), fontWeight = FontWeight.ExtraBold)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("${r.timeframe} timeframe", fontWeight = FontWeight.Bold)
                                    Text("Last close: ${fmt(r.price)}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.weight(1f).background(Color(0xFF123A38), RoundedCornerShape(14.dp)).padding(12.dp)) {
                                    Text("BULLISH SCORE", color = Color(0xFF8CEBDD), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text("${r.upProbability}%", color = Color(0xFF5EEAD4), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                }
                                Column(Modifier.weight(1f).background(Color(0xFF382338), RoundedCornerShape(14.dp)).padding(12.dp)) {
                                    Text("BEARISH SCORE", color = Color(0xFFFFB5C5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text("${r.downProbability}%", color = Color(0xFFFF8BA6), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                }
                            }
                            Text("MOVING AVERAGES", color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                            Column(Modifier.horizontalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                r.emas.forEach { (period, value) ->
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 10.dp)) {
                                        Text("EMA $period", modifier = Modifier.width(70.dp), color = Color(0xFFC7D2E7), style = MaterialTheme.typography.bodySmall)
                                        Text(fmt(value), color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                        Spacer(Modifier.width(8.dp))
                                        Text(if (r.price >= value) "ABOVE" else "BELOW", color = if (r.price >= value) Color(0xFF5EEAD4) else Color(0xFFFF9EB5), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            HorizontalDivider(color = Color(0xFF283650))
                            Text("MOMENTUM", color = Color(0xFF60A5FA), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                            Text("OBV: ${fmt(r.obv)}", color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodySmall)
                            Text("MACD ${fmt(r.macd)}   ·   Signal ${fmt(r.signal)}   ·   Hist ${fmt(r.hist)}", color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.weight(1f).background(Color(0xFF182A3D), RoundedCornerShape(12.dp)).padding(11.dp)) {
                                    Text("SUPPORT", color = Color(0xFF60A5FA), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(fmt(r.support), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                }
                                Column(Modifier.weight(1f).background(Color(0xFF382A25), RoundedCornerShape(12.dp)).padding(11.dp)) {
                                    Text("RESISTANCE", color = Color(0xFFFFC078), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(fmt(r.resistance), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Text("Signal interpretation", color = Color(0xFFA78BFA), fontWeight = FontWeight.Bold)
                            Text(r.setup, color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodyMedium)
                            Text("Scores are heuristic signals, not calibrated probabilities.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF18233A))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("BACKTEST LAB", color = Color(0xFFA78BFA), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("EMA 9/21 crossover", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(backtest, color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodyMedium)
                            Text("Educational baseline only. Fees, slippage, funding, liquidation and position sizing are not modeled.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF211D3D))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("PROJECT RESEARCH", color = Color(0xFFC4B5FD), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("Fundamentals & investors", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("This version does not automatically verify investors, partnerships, token unlocks or fundamentals. Check primary sources and classify claims as verified, unverified or unknown.", color = Color(0xFFE2DDFB), style = MaterialTheme.typography.bodyMedium)
                            Text("Search: ${symbol} crypto investors funding official", color = Color(0xFFA78BFA), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Text("RISK NOTICE  ·  Scores are rule-based heuristics, not predictions or guarantees. Futures trading can cause rapid losses. Never trade from this screen alone.", color = Color(0xFF9BAAC2), style = MaterialTheme.typography.bodySmall)
            }
            item {
                Text("DATA PRIVACY  ·  Public market data only. No exchange account connection or order execution. Network providers may process technical connection data such as IP address.", color = Color(0xFF73839D), style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        if (showPrivacyDialog) {
            AlertDialog(
                onDismissRequest = { showPrivacyDialog = false },
                title = { Text("PRIVACY & RISK DISCLOSURE", color = Color(0xFF5EEAD4), fontWeight = FontWeight.ExtraBold) },
                text = {
                    Column(
                        modifier = Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("What this app does", fontWeight = FontWeight.Bold, color = Color.White)
                        Text("CryptoAnalyser-by ErrZhr displays public market prices and historical candles from the market data provider, and recent headlines from public RSS feeds. It does not connect to an exchange account, request API keys, place orders, hold funds, or operate a wallet.", color = Color(0xFFD9E4F5))
                        Text("Network and privacy", fontWeight = FontWeight.Bold, color = Color.White)
                        Text("The app does not ask for your name, email address, contacts, camera, microphone, or precise location. To retrieve market and news data, it sends network requests to Bitget and the listed news-feed providers. Those providers may process technical connection data, such as your IP address, under their own privacy policies. The app itself does not create a user account or sell personal data.", color = Color(0xFFD9E4F5))
                        Text("Financial risk", fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Indicators, scores, historical ranges, and backtests are informational estimates, not personalized financial advice or guarantees. Data may be delayed, incomplete, or incorrect. Crypto assets and futures are high risk; you are responsible for your decisions and possible losses.", color = Color(0xFFD9E4F5))
                        Text("Third-party services", fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Market-data and news providers are independent services. This app is not an official product of those providers and does not imply endorsement. Their service and privacy terms apply to their respective endpoints.", color = Color(0xFFD9E4F5))
                        Text("For publication, the developer must host a public privacy policy URL and ensure the Google Play Data safety form accurately matches the app and its providers.", color = Color(0xFFFFD18A), fontWeight = FontWeight.Medium)
                    }
                },
                confirmButton = { TextButton(onClick = { showPrivacyDialog = false }) { Text("Close", color = Color(0xFF5EEAD4)) } },
                containerColor = Color(0xFF111A2E),
                titleContentColor = Color.White,
                textContentColor = Color.White
            )
        }
        if (selectedNews != null) {
            val article = selectedNews!!
            AlertDialog(
                onDismissRequest = { selectedNews = null },
                title = { Text("ACTUALITÉ", color = Color(0xFF5EEAD4), fontWeight = FontWeight.ExtraBold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text(article.title, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("${article.source} · ${java.text.SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(article.publishedAt))}", color = Color(0xFF8FA2BE), style = MaterialTheme.typography.labelSmall)
                        val detail = article.summary.ifBlank { "Le flux RSS fournit le titre et la date, mais pas de résumé détaillé pour cet article." }
                        Text(detail.take(480), color = Color(0xFFD9E4F5), style = MaterialTheme.typography.bodyMedium, maxLines = 4)
                        Text("Publié il y a moins de 7 jours. Cette information peut influencer le marché, mais son impact sur le prix reste incertain.", color = Color(0xFF8FA2BE), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    }
                },
                confirmButton = { TextButton(onClick = { selectedNews = null }) { Text("Fermer", color = Color(0xFF5EEAD4)) } },
                containerColor = Color(0xFF111A2E),
                titleContentColor = Color.White,
                textContentColor = Color.White
            )
        }
    }
}
private fun fmt(v: Double): String = if (!v.isFinite()) "—" else String.format(java.util.Locale.US, "%.8f", v).trimEnd('0').trimEnd('.')
