package com.example.cryptoanalyzer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

internal data class PriceAlert(
    val id: String,
    val market: String,
    val symbol: String,
    val target: Double,
    val direction: String
)

internal fun loadSavedPriceAlerts(prefs: android.content.SharedPreferences): List<PriceAlert> {
    val raw = prefs.getString("price_alerts", "[]") ?: "[]"
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            val o = array.optJSONObject(i) ?: return@mapNotNull null
            val target = o.optDouble("target", 0.0)
            if (target <= 0.0) null else PriceAlert(
                o.optString("id"), o.optString("market", "Spot"),
                o.optString("symbol"), target, o.optString("direction", "ABOVE")
            )
        }
    } catch (_: Exception) { emptyList() }
}

internal fun savePriceAlerts(prefs: android.content.SharedPreferences, alerts: List<PriceAlert>) {
    val array = JSONArray()
    alerts.forEach { a ->
        array.put(JSONObject().put("id", a.id).put("market", a.market).put("symbol", a.symbol)
            .put("target", a.target).put("direction", a.direction))
    }
    prefs.edit().putString("price_alerts", array.toString()).apply()
}

internal fun createPriceAlertChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel("price_alerts", "Crypto price alerts", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Notifications when a selected cryptocurrency reaches your target price"
        })
    }
}

internal fun schedulePriceAlertWorker(context: Context) {
    val request = PeriodicWorkRequestBuilder<PriceAlertWorker>(15, TimeUnit.MINUTES).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork("crypto_price_alert_checks", ExistingPeriodicWorkPolicy.UPDATE, request)
}

class PriceAlertWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("crypto_analyzer_settings", Context.MODE_PRIVATE)
        val alerts = loadSavedPriceAlerts(prefs)
        if (alerts.isEmpty()) return Result.success()
        val client = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).build()
        val triggered = mutableListOf<PriceAlert>()
        for (alert in alerts) {
            try {
                val url = if (alert.market == "Spot")
                    "https://api.bitget.com/api/v2/spot/market/tickers?symbol=${alert.symbol}"
                else "https://api.bitget.com/api/v2/mix/market/ticker?productType=USDT-FUTURES&symbol=${alert.symbol}"
                val request = Request.Builder().url(url).get().build()
                val current = client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@use null
                    val root = JSONObject(response.body?.string().orEmpty())
                    val data = root.optJSONArray("data")
                    val ticker = if (data != null && data.length() > 0) data.optJSONObject(0) else root.optJSONObject("data")
                    ticker?.let { it.optString("lastPr", it.optString("last", "")).toDoubleOrNull() }
                } ?: continue
                val reached = if (alert.direction == "ABOVE") current >= alert.target else current <= alert.target
                if (reached) {
                    createPriceAlertChannel(applicationContext)
                    val notification = NotificationCompat.Builder(applicationContext, "price_alerts")
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle("Price target reached: ${alert.symbol}")
                        .setContentText("Current price: $current USDT · Target: ${alert.target} USDT")
                        .setStyle(NotificationCompat.BigTextStyle().bigText("${alert.symbol} reached your target. Current price: $current USDT; target: ${alert.target} USDT."))
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setAutoCancel(true)
                        .build()
                    try { NotificationManagerCompat.from(applicationContext).notify(alert.id.hashCode(), notification) } catch (_: SecurityException) {}
                    triggered.add(alert)
                }
            } catch (_: Exception) {
                // Keep the alert active and retry during the next scheduled check.
            }
        }
        if (triggered.isNotEmpty()) savePriceAlerts(prefs, alerts.filterNot { a -> triggered.any { it.id == a.id } })
        return Result.success()
    }
}
