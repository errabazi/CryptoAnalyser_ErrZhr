# CryptoAnalyser-by ErrZhr (Android)

Kotlin + Jetpack Compose Android project for educational cryptocurrency market analysis using public Bitget endpoints.

## Features
- Bitget Spot and USDT Futures public market data.
- Coin-pair autocomplete, EMA/OBV/MACD indicators, support/resistance, historical extremes and an educational EMA crossover backtest.
- Recent crypto news from public CoinDesk and Cointelegraph RSS feeds, limited to four items from the last seven days.
- `FLAG_SECURE`, portrait orientation, non-resizable activity declaration, disabled app backup, and HTTPS-only network traffic.
- In-app privacy and financial-risk disclosure.

## Build locally
Open this folder in Android Studio with JDK 17 and Android SDK Platform 36 installed. Let Gradle sync, then run `lintDebug` and `assembleDebug`. CI uses Gradle 8.11.1 and builds a debug APK.

## Before publishing
Read `PLAY_STORE_RELEASE_CHECKLIST.md` and `PRIVACY_POLICY.md`. The package ID `com.example.cryptoanalyzer` is a placeholder and must be changed before the first Play release. Host the completed privacy policy at a public HTTPS URL, fill in the real developer contact email, complete the Data safety and Financial features declarations, sign a release AAB, and configure Play App Signing. Enable Protected with Play / Automatic protection in Play Console if available.

**No guarantee of Google Play approval is possible from source changes alone.** The app has not been built in this environment; CI must pass and the app must be tested before release. The app provides market information only and is not an official Bitget product.


## Recent fixes included in this package

- Spot pair input and suggestion selections display the quote suffix as `BASE/USDT` (for example `AIAV/USDT`). The normalizer removes the slash before calling Bitget, so API requests still use `AIAVUSDT`.
- Switching between Spot and USDT Futures clears the coin input and resets the previous analysis so the next market is not accidentally queried with the previous pair.
- A 9-language selector is available in the top bar; the chosen language is saved in app preferences and restored after restarting the app. This selector currently saves the selection, but not every screen string is fully translated yet.
- The GitHub Actions workflow searches nested folders and can safely extract a project ZIP when the repository does not contain an already-extracted Android project.

Build status: source changes were packaged, but an APK build has not been verified in this environment. Run the GitHub Actions workflow to verify compilation and download the APK artifact.


## Fixes in v3
- Spot candle requests use the valid interval values `1h`, `4h`, and `1day`; Futures intervals remain `1H`, `4H`, and `1D`.
- Every analysis/input error shown inside the app is normalized to exactly `Error`; provider names and technical response details are not shown in error messages.


## Added in v6
- A spoken analysis summary using Android Text-to-Speech, with Arabic, English, and French speech text and locale selection based on the selected app language (other selected languages currently use the French summary text).
- Indicative Spot, Long, and Short entry zones calculated from the latest 1H support/resistance and EMA 21, with explicit risk disclaimers. These zones are not guaranteed trading signals.
- Android version incremented to 0.3.0 (versionCode 3).
- Build not verified in this environment because a Gradle executable/wrapper is not available here; run the GitHub Actions workflow to confirm compilation.
