package com.example.cryptoanalyzer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Checks user-selected one-shot price alerts and watches recently searched/favourite pairs
 * on both public exchanges. WorkManager's 15-minute cadence is approximate, not real-time.
 */
class PriceAlertWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    private val client = OkHttpClient.Builder().callTimeout(8, TimeUnit.SECONDS).build()

    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("cryptoanalyser_preferences", Context.MODE_PRIVATE)
        val language = prefs.getString("app_language", "en") ?: "en"
        val channelId = ensureChannel(language)
        checkPriceAlerts(prefs, language, channelId)
        checkMovementSignals(prefs, language, channelId)
        return Result.success()
    }

    private fun checkPriceAlerts(prefs: android.content.SharedPreferences, language: String, channelId: String) {
        val alerts = try { JSONArray(prefs.getString("price_alerts", "[]")) } catch (_: Exception) { return }
        if (alerts.length() == 0) return
        val platform = prefs.getString("market_platform", "Bitget") ?: "Bitget"
        val updated = JSONArray()
        for (i in 0 until alerts.length()) {
            val alert = alerts.optJSONObject(i) ?: continue
            if (alert.optBoolean("triggered", false)) { updated.put(alert); continue }
            val symbol = alert.optString("symbol", "").uppercase(Locale.ROOT)
            val market = alert.optString("market", "Spot")
            val target = alert.optDouble("target", Double.NaN)
            if (symbol.isBlank() || !target.isFinite() || target <= 0.0) { updated.put(alert); continue }
            try {
                val futures = market.equals("Futures", true) || market.contains("Futures", true)
                val url = if (platform == "Binance") {
                    if (futures) "https://fapi.binance.com/fapi/v1/ticker/price?symbol=$symbol" else "https://api.binance.com/api/v3/ticker/price?symbol=$symbol"
                } else {
                    if (futures) "https://api.bitget.com/api/v2/mix/market/ticker?productType=USDT-FUTURES&symbol=$symbol" else "https://api.bitget.com/api/v2/spot/market/tickers?symbol=$symbol"
                }
                val body = fetch(url)
                if (body != null) {
                    val root = JSONObject(body)
                    val data = root.optJSONArray("data")
                    val ticker = if (platform == "Binance") root else if (data != null && data.length() > 0) data.optJSONObject(0) ?: JSONObject() else root.optJSONObject("data") ?: JSONObject()
                    val current = listOf("lastPr", "last", "close", "lastPrice", "price").firstNotNullOfOrNull { ticker.optString(it, "").toDoubleOrNull() } ?: 0.0
                    val direction = alert.optString("direction", "ABOVE")
                    val hit = current > 0.0 && if (direction == "BELOW") current <= target else current >= target
                    if (hit) {
                        val (title, message) = localizedPriceNotification(language, symbol, target, current, direction)
                        postNotification(channelId, alert.optLong("id", System.currentTimeMillis()).toInt(), title, message)
                        alert.put("triggered", true)
                    }
                }
            } catch (_: Exception) { /* Keep alert active on temporary API/network errors. */ }
            updated.put(alert)
        }
        prefs.edit().putString("price_alerts", updated.toString()).apply()
    }

    /** Watches up to 50 recent searches plus all favourites and explicit price-alert pairs. */
    private fun checkMovementSignals(prefs: android.content.SharedPreferences, language: String, channelId: String) {
        val candidates = linkedSetOf<String>()
        try {
            val recent = JSONArray(prefs.getString("recent_symbols", "[]"))
            for (i in 0 until minOf(recent.length(), 50)) normalizePair(recent.optString(i))?.let(candidates::add)
        } catch (_: Exception) { }
        try {
            val favs = JSONArray(prefs.getString("favorite_symbols", "[]"))
            for (i in 0 until favs.length()) normalizePair(favs.optString(i))?.let(candidates::add)
        } catch (_: Exception) { }
        try {
            val alerts = JSONArray(prefs.getString("price_alerts", "[]"))
            for (i in 0 until alerts.length()) normalizePair(alerts.optJSONObject(i)?.optString("symbol").orEmpty())?.let(candidates::add)
        } catch (_: Exception) { }
        if (candidates.isEmpty()) return

        val now = System.currentTimeMillis()
        val lastPrices = try { JSONObject(prefs.getString("movement_last_prices", "{}")) } catch (_: Exception) { JSONObject() }
        val lastSignals = try { JSONObject(prefs.getString("movement_last_signals", "{}")) } catch (_: Exception) { JSONObject() }
        var checked = 0
        // Keep request volume modest and avoid hammering exchange public APIs.
        for (symbol in candidates.take(25)) {
            for (exchange in listOf("Bitget", "Binance")) {
                if (checked >= 50) break
                checked++
                try {
                    val ticker = fetchTicker(exchange, symbol) ?: continue
                    val price = ticker.first
                    val change24h = ticker.second
                    if (price <= 0.0 || !price.isFinite() || !change24h.isFinite()) continue
                    val sampleKey = "${exchange}_$symbol"
                    val previous = lastPrices.optDouble(sampleKey, Double.NaN)
                    val previousAt = lastPrices.optLong("${sampleKey}_at", 0L)
                    val shortMovePct = if (previous.isFinite() && previous > 0 && now - previousAt >= 8 * 60 * 1000L) (price - previous) / previous * 100.0 else 0.0
                    lastPrices.put(sampleKey, price).put("${sampleKey}_at", now)

                    val direction = when {
                        change24h >= 8.0 || shortMovePct >= 2.5 -> "UP"
                        change24h <= -8.0 || shortMovePct <= -2.5 -> "DOWN"
                        else -> null
                    } ?: continue
                    val strength = when {
                        abs(change24h) >= 15.0 || abs(shortMovePct) >= 5.0 -> "STRONG"
                        else -> "POTENTIAL"
                    }
                    val signalKey = "${symbol}_$direction"
                    val lastAt = lastSignals.optLong(signalKey, 0L)
                    // Do not repeat the same directional signal more than once every 6 hours.
                    if (now - lastAt < 6 * 60 * 60 * 1000L) continue
                    val (title, message) = movementNotification(language, symbol, exchange, direction, strength, price, change24h, shortMovePct)
                    val notificationId = 0x40000000 or (signalKey.hashCode() and 0x0FFFFFFF)
                    postNotification(channelId, notificationId, title, message)
                    lastSignals.put(signalKey, now)
                } catch (_: Exception) {
                    // One unavailable market should not prevent checks for other symbols/exchanges.
                }
            }
        }
        prefs.edit()
            .putString("movement_last_prices", lastPrices.toString())
            .putString("movement_last_signals", lastSignals.toString())
            .apply()
    }

    /** Pair of current price and 24-hour percentage change, using public spot market endpoints. */
    private fun fetchTicker(exchange: String, symbol: String): Pair<Double, Double>? {
        val url = if (exchange == "Binance") {
            "https://api.binance.com/api/v3/ticker/24hr?symbol=$symbol"
        } else {
            "https://api.bitget.com/api/v2/spot/market/tickers?symbol=$symbol"
        }
        val body = fetch(url) ?: return null
        val root = JSONObject(body)
        val data = root.optJSONArray("data")
        val ticker = if (exchange == "Binance") root else data?.optJSONObject(0) ?: return null
        val price = if (exchange == "Binance") ticker.optString("lastPrice").toDoubleOrNull() else ticker.optString("lastPr").toDoubleOrNull()
        val change = if (exchange == "Binance") {
            ticker.optString("priceChangePercent").toDoubleOrNull()
        } else {
            val last = price ?: 0.0
            val open = ticker.optString("open24h").toDoubleOrNull() ?: ticker.optString("openUtc").toDoubleOrNull()
            if (open != null && open > 0.0 && last > 0.0) (last - open) / open * 100.0
            else ticker.optString("change24h").toDoubleOrNull()?.let { if (abs(it) <= 1.0) it * 100.0 else it }
        }
        if (price == null || change == null) return null
        return price to change
    }

    private fun fetch(url: String): String? {
        val request = Request.Builder().url(url).get().header("User-Agent", "CryptoAnalyser/1.0").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val body = response.body?.string() ?: return null
            if (url.contains("bitget.com")) {
                val root = try { JSONObject(body) } catch (_: Exception) { return null }
                val code = root.optString("code", "00000")
                if (code.isNotBlank() && code != "00000") return null
            }
            return body
        }
    }

    private fun normalizePair(value: String): String? {
        val clean = value.trim().uppercase(Locale.ROOT).replace("/", "").replace("-", "").replace("_", "").replace(" ", "")
        if (clean.isBlank()) return null
        val pair = if (clean.endsWith("USDT")) clean else "${clean}USDT"
        return pair.takeIf { it.matches(Regex("[A-Z0-9]{3,30}USDT")) }
    }

    private fun ensureChannel(language: String): String {
        val channelId = "crypto_price_alerts_$language"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(channelId) == null) {
                val name = when (language) {
                    "fr" -> "Alertes de prix crypto"; "ar" -> "تنبيهات أسعار العملات الرقمية"; "es" -> "Alertas de precios cripto"; "de" -> "Krypto-Preisalarme"; "it" -> "Avvisi prezzi crypto"; "zh" -> "加密货币价格提醒"; "ja" -> "暗号資産の価格アラート"; "ko" -> "암호화폐 가격 알림"; else -> "Crypto price alerts"
                }
                manager.createNotificationChannel(NotificationChannel(channelId, name, NotificationManager.IMPORTANCE_HIGH).apply { description = name; enableVibration(true); setShowBadge(true) })
            }
        }
        return channelId
    }

    private fun localizedPriceNotification(language: String, symbol: String, target: Double, current: Double, direction: String): Pair<String, String> {
        val above = direction != "BELOW"
        val title = when (language) { "fr" -> "Alerte de prix : $symbol"; "ar" -> "تنبيه سعر: $symbol"; else -> "$symbol price alert" }
        val message = when (language) {
            "fr" -> "Le prix a ${if (above) "atteint ou dépassé" else "atteint ou est passé sous"} $target USDT (actuel : $current USDT)."
            "ar" -> "${if (above) "وصل السعر إلى" else "انخفض السعر إلى"} $target USDT (السعر الحالي: $current USDT)."
            else -> "$symbol ${if (above) "reached or exceeded" else "fell to or below"} $target USDT (current: $current USDT)."
        }
        return title to message
    }

    private fun movementNotification(language: String, symbol: String, exchange: String, direction: String, strength: String, price: Double, change24h: Double, shortMove: Double): Pair<String, String> {
        val upward = direction == "UP"
        val title = when (language) {
            "fr" -> "Signal ${if (upward) "haussier" else "baissier"} : $symbol"
            "ar" -> "إشارة ${if (upward) "صعود" else "هبوط"} محتملة: $symbol"
            "es" -> "Señal ${if (upward) "alcista" else "bajista"}: $symbol"
            else -> "$symbol potential ${if (upward) "upward" else "downward"} move"
        }
        val level = when (language) { "fr" -> if (strength == "STRONG") "Mouvement fort possible" else "Mouvement possible"; "ar" -> if (strength == "STRONG") "احتمال حركة قوية" else "احتمال حركة ملحوظة"; else -> if (strength == "STRONG") "Possible strong move" else "Potential move" }
        val details = "${exchange} · ${String.format(Locale.US, "%.8f", price)} USDT · 24h ${String.format(Locale.US, "%+.2f", change24h)}% · recent ${String.format(Locale.US, "%+.2f", shortMove)}%"
        val caveat = when (language) { "fr" -> "Signal indicatif, pas une prédiction garantie."; "ar" -> "إشارة احتمالية وليست توقعًا مضمونًا."; else -> "Indicative signal, not a guaranteed prediction." }
        return title to "$level\n$details\n$caveat"
    }

    private fun postNotification(channelId: String, id: Int, title: String, message: String) {
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
        try { NotificationManagerCompat.from(applicationContext).notify(id, notification) } catch (_: SecurityException) { }
    }
}
