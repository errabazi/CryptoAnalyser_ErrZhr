package com.example.cryptoanalyzer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

private const val ACTIVATION_ENDPOINT = "https://script.google.com/macros/s/AKfycbzX5LyGohau7F1e6RSG6slMv7LGmtcUqJpYsmOOXXwOaLAu5LzCwRw1KCe9LhpMbwVrkw/exec"
private const val MAX_RECEIPT_BYTES = 4 * 1024 * 1024
private val activationHttp = OkHttpClient.Builder()
    .connectTimeout(20, TimeUnit.SECONDS).readTimeout(40, TimeUnit.SECONDS).writeTimeout(40, TimeUnit.SECONDS).build()
private val activationJsonType = "application/json; charset=utf-8".toMediaType()
private val activationBg = Color(0xFF080D1B)
private val activationCard = Color(0xFF111A2E)
private val activationMint = Color(0xFF5EEAD4)

private fun activationDeviceId(context: Context): String =
    Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)?.takeIf { it.isNotBlank() }
        ?: "android-device-unknown"

private suspend fun activationCall(payload: JSONObject): JSONObject = withContext(Dispatchers.IO) {
    val request = Request.Builder().url(ACTIVATION_ENDPOINT)
        .post(payload.toString().toRequestBody(activationJsonType)).build()
    activationHttp.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw IllegalStateException("تعذر الاتصال بخدمة التفعيل (HTTP ${response.code}).")
        val body = response.body?.string().orEmpty()
        val json = try { JSONObject(body) } catch (_: Exception) { throw IllegalStateException("استجابة خدمة التفعيل غير صالحة. تحقق من نشر Apps Script كـ Web App.") }
        if (!json.optBoolean("ok", false)) throw IllegalStateException(json.optString("message", "رفضت خدمة التفعيل الطلب."))
        json
    }
}

private fun receiptName(context: Context, uri: Uri): String {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0) return cursor.getString(index) ?: "payment-receipt"
        }
    }
    return "payment-receipt"
}

private fun receiptMime(context: Context, uri: Uri): String =
    context.contentResolver.getType(uri)?.lowercase() ?: "application/octet-stream"

private fun receiptBase64(context: Context, uri: Uri): String {
    val mime = receiptMime(context, uri)
    require(mime in listOf("image/jpeg", "image/png", "application/pdf")) {
        "اختر صورة JPG أو PNG أو ملف PDF فقط."
    }
    val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            require(total <= MAX_RECEIPT_BYTES) { "حجم الإيصال يجب ألا يتجاوز 4 ميغابايت." }
            output.write(buffer, 0, read)
        }
        output.toByteArray()
    } ?: throw IllegalStateException("تعذر قراءة ملف الإيصال.")
    require(bytes.isNotEmpty()) { "ملف الإيصال فارغ." }
    return Base64.encodeToString(bytes, Base64.NO_WRAP)
}

@Composable
fun ActivationGate(content: @Composable (suspend () -> Boolean) -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("cryptoanalyser_activation", Context.MODE_PRIVATE) }
    val deviceId = remember(context) { activationDeviceId(context) }
    var email by remember { mutableStateOf(prefs.getString("activation_email", "") ?: "") }
    var code by remember { mutableStateOf("") }
    var receiptUri by remember { mutableStateOf<Uri?>(null) }
    var receiptLabel by remember { mutableStateOf("") }
    var activated by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var messageIsError by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val receiptPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val mime = receiptMime(context, uri)
                require(mime in listOf("image/jpeg", "image/png", "application/pdf")) { "اختر صورة JPG أو PNG أو ملف PDF فقط." }
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                // Validate and enforce the size limit immediately, before the user submits.
                receiptBase64(context, uri)
                receiptUri = uri
                receiptLabel = receiptName(context, uri)
                message = "تم اختيار الإيصال: $receiptLabel"
                messageIsError = false
            } catch (e: Exception) {
                receiptUri = null; receiptLabel = ""
                message = e.message ?: "تعذر فتح الإيصال."; messageIsError = true
            }
        }
    }

    LaunchedEffect(Unit) {
        val savedEmail = prefs.getString("activation_email", "").orEmpty()
        if (savedEmail.isNotBlank()) {
            try {
                activationCall(JSONObject().put("action", "heartbeat").put("email", savedEmail).put("deviceId", deviceId))
                email = savedEmail
                activated = true
            } catch (e: Exception) {
                message = e.message ?: "تعذر التحقق من الترخيص."
                messageIsError = true
            }
        }
        checking = false
    }

    LaunchedEffect(activated, email, deviceId) {
        if (activated && email.isNotBlank()) {
            while (true) {
                delay(30_000)
                try {
                    activationCall(JSONObject().put("action", "heartbeat").put("email", email).put("deviceId", deviceId))
                } catch (e: Exception) {
                    activated = false
                    val detail = e.message ?: "انتهت جلسة التفعيل. سجّل الدخول مجددًا."
                    if (detail.contains("another device", ignoreCase = true) || detail.contains("جهاز آخر")) {
                        prefs.edit().remove("activation_email").apply()
                        message = "هذا الحساب نشط على جهاز آخر. تم تسجيل الخروج."
                    } else message = detail
                    messageIsError = true
                    break
                }
            }
        }
    }

    if (activated) {
        content {
            try {
                activationCall(JSONObject().put("action", "authorizeAnalysis").put("email", email).put("deviceId", deviceId))
                true
            } catch (e: Exception) {
                val detail = e.message.orEmpty()
                if (detail.contains("another device", ignoreCase = true) || detail.contains("جهاز آخر")) {
                    prefs.edit().remove("activation_email").apply()
                    activated = false
                    message = "هذا الحساب نشط على جهاز آخر. تم تسجيل الخروج."
                    messageIsError = true
                } else {
                    message = detail.ifBlank { "تعذر التحقق من الترخيص قبل التحليل." }
                    messageIsError = true
                }
                false
            }
        }
        return
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = activationMint, background = activationBg, surface = activationCard, onSurface = Color(0xFFEAF2FF))) {
        Box(
            Modifier.fillMaxSize()
                .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFF0B1224), Color(0xFF080D1B), Color(0xFF101D32))))
                .padding(horizontal = 14.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            if (checking) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    CircularProgressIndicator(color = activationMint)
                    Text("جارٍ التحقق من ترخيص CryptoAnalyser…", color = Color.White)
                }
            } else {
                Column(
                    Modifier.fillMaxWidth().fillMaxHeight().verticalScroll(rememberScrollState())
                        .background(activationCard, RoundedCornerShape(28.dp))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Brand header
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            Modifier.size(54.dp).background(
                                androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF5EEAD4), Color(0xFF38BDF8))),
                                RoundedCornerShape(17.dp)
                            ), contentAlignment = Alignment.Center
                        ) {
                            Text("CA", color = Color(0xFF07111F), fontSize = 20.sp, fontWeight = FontWeight.Black)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("CryptoAnalyser", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                            Text("by ErrZhr  •  SMART CRYPTO INSIGHTS", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    HorizontalDivider(color = Color(0xFF26354D))
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("تفعيل حسابك", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Text("خطوات بسيطة وآمنة للوصول إلى أدوات التحليل", color = activationMint, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }

                    // Morocco payment instructions
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF142A35)), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("الدفع داخل المغرب", color = Color(0xFF99F6E4), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("رسوم التفعيل: 50 درهمًا مغربيًا", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("أرسل المبلغ عبر وفاكاش أو كاش بليس إلى المستفيد: Errabazi Zouhair، ثم أرفق وصل الدفع. سيتم التحقق من وصول المبلغ يدويًا قبل إصدار كود التفعيل.", color = Color(0xFFD5E4EF), fontSize = 13.sp, lineHeight = 19.sp)
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("1  •  بريدك الإلكتروني", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = email, onValueChange = { email = it.trim() }, modifier = Modifier.fillMaxWidth(),
                            label = { Text("البريد الإلكتروني") }, placeholder = { Text("name@example.com") },
                            singleLine = true, shape = RoundedCornerShape(14.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = activationMint, unfocusedBorderColor = Color(0xFF3A4A63),
                                focusedLabelColor = activationMint, cursorColor = activationMint
                            )
                        )
                        Text("استخدم بريدًا صحيحًا حتى تتمكن الإدارة من ربط طلبك وإرسال تعليمات التفعيل.", color = Color(0xFF94A3B8), fontSize = 12.sp, lineHeight = 17.sp)
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("2  •  إثبات الدفع", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17243A)), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                Text("أرفق صورة أو ملف PDF", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                Text("الصيغ المقبولة: JPG، PNG، PDF  •  الحد الأقصى 4 MB", color = Color(0xFFB8C7DA), fontSize = 12.sp)
                                OutlinedButton(
                                    onClick = { receiptPicker.launch(arrayOf("image/jpeg", "image/png", "application/pdf")) },
                                    modifier = Modifier.fillMaxWidth(), enabled = !busy,
                                    shape = RoundedCornerShape(13.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = activationMint)
                                ) {
                                    Text(if (receiptLabel.isBlank()) "＋  اختيار إيصال الدفع من الهاتف" else "✓  $receiptLabel  •  تغيير الملف", fontWeight = FontWeight.SemiBold)
                                }
                                if (receiptLabel.isNotBlank()) {
                                    Text("تم اختيار الملف. تأكد من وضوح بيانات الدفع قبل إرسال الطلب.", color = Color(0xFF86EFAC), fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // International payment instructions in separate readable sections
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2339)), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("INTERNATIONAL PAYMENTS", color = Color(0xFF93C5FD), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Outside Morocco: pay 5 USDT via Bitget internal transfer to ID 6569055905. Before confirming, verify that the recipient account name is zhr_err. The screenshot must show the sender, recipient and amount. Alternatively, send 5 USDT over the BEP-20 (BSC) network to:", color = Color(0xFFE2E8F0), fontSize = 12.sp, lineHeight = 18.sp)
                            Text("0x56c878126b17d8029f2646bf0107b47edca28658", color = Color(0xFF93C5FD), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Attach the payment screenshot to this request and enter your email address above.", color = Color(0xFFCBD5E1), fontSize = 12.sp, lineHeight = 18.sp)
                            HorizontalDivider(color = Color(0xFF334155))
                            Text("PAIEMENTS INTERNATIONAUX", color = Color(0xFF93C5FD), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Si vous résidez hors du Maroc, payez 5 USDT par transfert interne Bitget à l’identifiant 6569055905. Avant de confirmer, vérifiez que le nom du compte destinataire est zhr_err. La capture d’écran doit afficher l’expéditeur, le destinataire et le montant. Vous pouvez aussi envoyer 5 USDT via le réseau BEP-20 (BSC) à l’adresse suivante :", color = Color(0xFFE2E8F0), fontSize = 12.sp, lineHeight = 18.sp)
                            Text("0x56c878126b17d8029f2646bf0107b47edca28658", color = Color(0xFF93C5FD), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Joignez la capture d’écran du paiement à cette demande et saisissez votre adresse e-mail ci-dessus.", color = Color(0xFFCBD5E1), fontSize = 12.sp, lineHeight = 18.sp)
                        }
                    }

                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF332A18)), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Besoin d’aide ? / تحتاج إلى مساعدة؟", color = Color(0xFFFDE68A), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("إذا لم تتوصل بكود التفعيل خلال 30 دقيقة، أرسل رسالة عبر واتساب إلى 0620202714 وأرفق صورة وصل الدفع عبر وفاكاش أو كاش بليس.", color = Color(0xFFFFF3C4), fontSize = 12.sp, lineHeight = 18.sp)
                            Text("Merci pour votre confiance. / Thank you for your trust. / شكراً لثقتكم.", color = Color(0xFFFDE68A), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("3  •  إرسال الطلب", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("راجع بريدك الإلكتروني والملف المرفق قبل الإرسال. لا يُفعّل الحساب إلا بعد مراجعة الدفع.", color = Color(0xFF94A3B8), fontSize = 12.sp, lineHeight = 17.sp)
                        Button(
                            onClick = {
                                val normalized = email.trim().lowercase()
                                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(normalized).matches()) {
                                    message = "أدخل بريدًا إلكترونيًا صحيحًا."; messageIsError = true
                                } else if (receiptUri == null) {
                                    message = "يجب إرفاق إيصال الدفع قبل إرسال الطلب."; messageIsError = true
                                } else {
                                    busy = true; message = ""
                                    scope.launch {
                                        try {
                                            val uri = receiptUri ?: throw IllegalStateException("أرفق إيصال الدفع أولًا.")
                                            val base64 = withContext(Dispatchers.IO) { receiptBase64(context, uri) }
                                            val payload = JSONObject()
                                                .put("action", "request")
                                                .put("email", normalized)
                                                .put("deviceId", deviceId)
                                                .put("receiptBase64", base64)
                                                .put("receiptMimeType", receiptMime(context, uri))
                                                .put("receiptFileName", receiptName(context, uri))
                                            activationCall(payload)
                                            email = normalized
                                            message = "تم إرسال طلب التفعيل وإيصال الدفع بنجاح. ستتم مراجعة الدفع يدويًا، ثم ستصلك تعليمات التفعيل عند الموافقة."
                                            messageIsError = false
                                        } catch (e: Exception) { message = e.message ?: "تعذر إرسال الطلب."; messageIsError = true }
                                        finally { busy = false }
                                    }
                                }
                            }, modifier = Modifier.fillMaxWidth().height(52.dp), enabled = !busy,
                            shape = RoundedCornerShape(15.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = activationMint, contentColor = Color(0xFF07111F))
                        ) {
                            if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF07111F))
                            else Text("طلب التفعيل واستلام كود التفعيل", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        }
                    }

                    HorizontalDivider(color = Color(0xFF26354D))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("لديك كود تفعيل بالفعل؟", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = code, onValueChange = { code = it.filter { ch -> ch.isLetterOrDigit() || "-_*#@!\$%".contains(ch) }.take(48) },
                            modifier = Modifier.fillMaxWidth(), label = { Text("أدخل كود التفعيل") }, singleLine = true,
                            shape = RoundedCornerShape(14.dp), visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = activationMint, unfocusedBorderColor = Color(0xFF3A4A63), focusedLabelColor = activationMint, cursorColor = activationMint)
                        )
                        OutlinedButton(
                            onClick = {
                                val normalized = email.trim().lowercase()
                                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(normalized).matches() || code.trim().isBlank()) {
                                    message = "أدخل البريد الإلكتروني وكود التفعيل."; messageIsError = true
                                } else {
                                    busy = true; message = ""
                                    scope.launch {
                                        try {
                                            activationCall(JSONObject().put("action", "activate").put("email", normalized).put("code", code.trim()).put("deviceId", deviceId))
                                            prefs.edit().putString("activation_email", normalized).apply()
                                            email = normalized; activated = true; message = ""; messageIsError = false
                                        } catch (e: Exception) { message = e.message ?: "تعذر تفعيل الحساب."; messageIsError = true }
                                        finally { busy = false }
                                    }
                                }
                            }, modifier = Modifier.fillMaxWidth().height(48.dp), enabled = !busy,
                            shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = activationMint)
                        ) { Text("تسجيل الدخول وتفعيل الحساب", fontWeight = FontWeight.Bold) }
                    }

                    if (message.isNotBlank()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = if (messageIsError) Color(0xFF3B202A) else Color(0xFF15352D)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(message, modifier = Modifier.fillMaxWidth().padding(13.dp), color = if (messageIsError) Color(0xFFFFB4C0) else Color(0xFF9FF3D2), fontSize = 13.sp, lineHeight = 19.sp)
                        }
                    }
                    Text("يسمح النظام بجهاز نشط واحد لكل بريد إلكتروني. يلزم اتصال بالإنترنت للتحقق من الترخيص.", color = Color(0xFF64748B), fontSize = 11.sp, lineHeight = 16.sp)
                    Text("CryptoAnalyser by ErrZhr  •  Thank you for your trust", modifier = Modifier.fillMaxWidth(), color = Color(0xFF64748B), fontSize = 10.sp)
                }
            }
        }
    }
}
